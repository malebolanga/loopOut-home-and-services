import mongoose from 'mongoose';
import { hideSuspendedOwnerContent } from '../utils/hideSuspendedOwnerContent.js';

const mealSchema = new mongoose.Schema({
  id: { type: String, required: true },
  name: { type: String, required: true },
  description: { type: String, default: '' },
  price: { type: Number, required: true },
  tag: { type: String, default: '' },
  category: { type: String, default: '' },
  itemType: { type: String, enum: ['meal', 'combo', 'special'], default: 'meal' },
  image: { type: String, default: '🍱' },
  isAvailable: { type: Boolean, default: true },
  portions: [{ name: { type: String, enum: ['Small', 'Medium', 'Large', 'Full plate'] }, price: { type: Number, min: 0 } }],
  addOns: [{ name: String, price: Number }],
  sides: { type: [String], default: [] }
}, { _id: false });

const itemRatingSchema = new mongoose.Schema({
  itemIndex: { type: Number, required: true },
  mealId: { type: String, default: '' },
  mealName: { type: String, required: true },
  rating: { type: Number, min: 1, max: 5, required: true }
}, { _id: false });

const reviewSchema = new mongoose.Schema({
  id: { type: String, required: true },
  userName: { type: String, default: 'Customer' },
  shopRating: { type: Number, default: 5 },
  foodRating: { type: Number, default: 5 },
  itemRatings: { type: [itemRatingSchema], default: [] },
  comment: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
}, { _id: false });

const shopSchema = new mongoose.Schema({
  name: { type: String, required: true },
  cuisine: { type: String, default: 'General' },
  distance: { type: String, default: '1.0 km' },
  time: { type: String, default: '20–30 min' },
  rating: { type: String, default: '' },
  ratingsCount: { type: Number, default: 0 },
  image: { type: String, default: '🏪' },
  address: { type: String, default: '' },
  phone: { type: String, default: '' },
  ownerId: { type: String, default: 'guest' },
  ownerName: { type: String, default: 'Store Manager' },
  // Pauses orders while keeping the shop and menu visible to customers.
  isOpen: { type: Boolean, default: true },
  // Shop owner can opt into a clearly labeled free home food-row promotion.
  isPromoted: { type: Boolean, default: false },
  whatsapp: { type: String, default: '' },
  operatingHours: {
    openTime: { type: String, default: '08:00' },
    closeTime: { type: String, default: '20:00' },
    days: { type: [String], default: () => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] }
  },
  meals: [mealSchema],
  reviews: [reviewSchema]
}, { timestamps: true });

shopSchema.index({ ownerId: 1, createdAt: -1 });
hideSuspendedOwnerContent(shopSchema, [{ field: 'ownerId', storedAsString: true }]);

const Shop = mongoose.model('Shop', shopSchema);
export default Shop;
