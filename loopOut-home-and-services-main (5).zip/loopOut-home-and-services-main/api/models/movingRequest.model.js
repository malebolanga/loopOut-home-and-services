import mongoose from 'mongoose';

const movingRequestSchema = new mongoose.Schema({
  vehicleRef: { type: mongoose.Schema.Types.ObjectId, ref: 'MovingVehicle', required: true, index: true },
  requesterRef: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  driverRef: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  requesterName: { type: String, required: true, trim: true },
  requesterPhone: { type: String, required: true, trim: true },
  pickupAddress: { type: String, required: true, trim: true, maxlength: 300 },
  pickupCoordinates: { lat: { type: Number, min: -90, max: 90 }, lng: { type: Number, min: -180, max: 180 } },
  // Temporary customer location, shared only with the assigned driver while
  // this request is accepted or in progress.
  livePickupCoordinates: {
    lat: { type: Number, min: -90, max: 90, default: null },
    lng: { type: Number, min: -180, max: 180, default: null },
    accuracy: { type: Number, min: 0, default: null },
    updatedAt: { type: Date, default: null },
  },
  driverArrivalNotifiedAt: { type: Date, default: null },
  dropoffAddress: { type: String, required: true, trim: true, maxlength: 300 },
  itemDescription: { type: String, required: true, trim: true, maxlength: 1000 },
  requestedAt: { type: Date, required: true },
  status: { type: String, enum: ['pending', 'accepted', 'in_progress', 'declined', 'service_completed', 'payment_reported', 'paid', 'completed', 'cancelled'], default: 'pending', index: true },
  quoteAmount: { type: Number, min: 0, default: null },
  quoteStatus: { type: String, enum: ['not_proposed', 'pending', 'accepted', 'declined'], default: 'not_proposed', index: true },
  quoteProposedAt: { type: Date, default: null },
  quoteRespondedAt: { type: Date, default: null },
  finalPrice: { type: Number, min: 0, default: null },
  serviceCompletedAt: { type: Date, default: null },
  paymentMethod: { type: String, enum: ['cash', 'eft'], default: null },
  paymentReportedAt: { type: Date, default: null },
  paymentConfirmedAt: { type: Date, default: null },
  cancelledAt: { type: Date, default: null },
  cancelledBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  cancelledByRole: { type: String, enum: ['requester', 'driver', null], default: null },
  cancellationReason: { type: String, trim: true, maxlength: 500, default: '' },
  issueStatus: { type: String, enum: ['none', 'open', 'resolved'], default: 'none', index: true },
  issueType: { type: String, enum: ['driver_no_show', 'late_pickup', 'customer_no_show', 'damage', 'price_dispute', 'safety', 'other', null], default: null },
  issueDescription: { type: String, trim: true, maxlength: 1000, default: '' },
  issueReportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  issueReportedByRole: { type: String, enum: ['requester', 'driver', null], default: null },
  issueReportedAt: { type: Date, default: null },
  issueResolutionNote: { type: String, trim: true, maxlength: 1000, default: '' },
  issueResolvedAt: { type: Date, default: null },
  issueResolvedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  ratingStars: { type: Number, min: 1, max: 5, default: null },
  ratingReview: { type: String, trim: true, maxlength: 500, default: '' },
  ratedAt: { type: Date, default: null },
}, { timestamps: true });

const MovingRequest = mongoose.models.MovingRequest || mongoose.model('MovingRequest', movingRequestSchema);
export default MovingRequest;
