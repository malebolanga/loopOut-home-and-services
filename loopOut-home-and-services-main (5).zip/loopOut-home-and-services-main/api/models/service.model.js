import mongoose from 'mongoose';
import { hideSuspendedOwnerContent } from '../utils/hideSuspendedOwnerContent.js';

const serviceSchema = new mongoose.Schema(
  {
    creator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    userRef: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    name: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    near: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    contact: {
      type: mongoose.Schema.Types.Mixed,
      required: true,
    },
    host: {
      type: String,
      required: true,
    },
    providerType: {
      type: String,
      enum: ['individual', 'company'],
    },
    citizenship: {
      type: String,
    },
    kind: {
      type: String,
      required: true,
    },
    period: {
      type: String,
      required: false,
    },
    cancel: {
      type: String,
      required: true,
    },
    regularPrice: {
      type: Number,
      required: true,
    },
    security: {
      type: Boolean,
      required: true,
    },
    pets: {
      type: Boolean,
      required: true,
    },
    type: {
      type: String,
      required: true,
      enum: [
        'cleaning', 
        'handyman',
        'maintenance', 
        'moving', 
        'landscaping', 
        'catering', 
        'other',
        'daycare',
        'schoolTransport',
        'carwash', // ✅ NEW: Car wash service type
        'storage' // ✅ NEW: Storage service type
      ]
    },
    offer: {
      type: Boolean,
      required: true,
    },
    imageUrls: {
      type: [String],
      required: true,
    },
    rating: { 
      type: Number, 
      default: 0, 
      min: 0, 
      max: 5 
    },
    reviews: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Review'
    }],
    comments: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ServiceComment'
    }],
    
    // Daycare fields
    ageGroup: {
      type: String,
      required: false
    },
    licenseNumber: {
      type: String,
      required: false
    },
    capacity: {
      type: String,
      required: false
    },
    meals: {
      type: Boolean,
      required: false
    },
    
    // School transport fields
    vehicleType: {
      type: String,
      required: false
    },
    routeAreas: {
      type: String,
      required: false
    },
    childSeats: {
      type: Boolean,
      required: false
    },
    
    // Moving rate configuration fields
    moveCostPerBox: {
      type: Number,
      default: 50
    },
    moveCostPerKilo: {
      type: Number,
      default: 10
    },
    movePriceVan: {
      type: Number,
      default: 800
    },
    movePriceVanTrailer: {
      type: Number,
      default: 1200
    },
    movePriceMiniTruck: {
      type: Number,
      default: 1500
    },
    movePriceOtherTruck: {
      type: Number,
      default: 2000
    },
    movePriceBigTruckTrailer: {
      type: Number,
      default: 3500
    },

    // ✅ NEW: Car Wash specific fields
    carWashPackages: {
      type: String, // Comma-separated: basic,premium,detailing,ceramic
      required: function() { return this.type === 'carwash'; }
    },
    vehicleTypes: {
      type: String, // sedan, suv, van, truck, motorcycle, all
      required: function() { return this.type === 'carwash'; }
    },
    additionalServices: {
      type: String, // Comma-separated additional services
      required: false
    },
    serviceDuration: {
      type: String, // e.g., "30-45 mins", "1-2 hours"
      required: function() { return this.type === 'carwash'; }
    },
    mobileService: {
      type: Boolean,
      default: false,
      required: function() { return this.type === 'carwash'; }
    },
    serviceLocationMode: {
      type: String,
      enum: ['fixed', 'mobile', 'both'],
      default: 'fixed',
      required: function() { return this.type === 'carwash'; }
    },
    ecoFriendly: {
      type: Boolean,
      default: false,
      required: false
    },
    additionalPricing: {
      type: String, // Detailed pricing for different packages
      required: false
    },
    // ✅ NEW: Storage specific fields
    storageSize: {
      type: String,
      required: function() { return this.type === 'storage'; }
    },
    storagePriceDay: {
      type: Number,
      required: function() { return this.type === 'storage'; }
    },
    storagePriceMonth: {
      type: Number,
      required: function() { return this.type === 'storage'; }
    },
    storageFailurePolicy: {
      type: String,
      required: false
    },
    storageTerms: {
      type: String,
      required: false
    },
    storagePolicyDocUrl: {
      type: String,
      required: false
    },
    serviceList: [
      {
        type: { type: String },
        name: { type: String, required: true },
        description: { type: String },
        price: { type: Number, required: true },
        image: { type: String }
      }
    ],
    bookingsCount: { type: Number, default: 0 },
    experience: {
      type: String, // e.g., "5 years", "Expert", "Junior"
      required: false
    },
    performers: [
      {
        name: { type: String, required: true },
        image: { type: String, required: true },
        experience: { type: String, required: true },
        rating: { type: Number, default: 5, min: 1, max: 5 },
        ratingsCount: { type: Number, default: 1 }
      }
    ],
    checkInTime: { type: String, default: '14:00' },
    checkOutTime: { type: String, default: '11:00' },
    operatingHours: {
        monday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: false } },
        tuesday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: false } },
        wednesday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: false } },
        thursday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: false } },
        friday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: false } },
        saturday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: false } },
        sunday: { open: { type: String, default: '08:00' }, close: { type: String, default: '19:00' }, closed: { type: Boolean, default: true } }
    }
  },
  { timestamps: true }
);

// ── Indexes ───────────────────────────────────────────────────────────────
serviceSchema.index({ createdAt: -1 });
serviceSchema.index({ type: 1, createdAt: -1 });
serviceSchema.index({ regularPrice: 1, createdAt: -1 });
serviceSchema.index({ kind: 1, createdAt: -1 });
serviceSchema.index({ userRef: 1, createdAt: -1 });
serviceSchema.index({ creator: 1, createdAt: -1 });
hideSuspendedOwnerContent(serviceSchema, [{ field: 'userRef' }, { field: 'creator' }]);

const Service = mongoose.model('Service', serviceSchema);

export default Service;
