import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  listing: { type: mongoose.Schema.Types.ObjectId, ref: 'Listing' },
  helper: { type: mongoose.Schema.Types.ObjectId, ref: 'Helper' },
  service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service' },
  event: { type: mongoose.Schema.Types.ObjectId, ref: 'Event' },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  totalPrice: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ['pending', 'confirmed', 'cancelled', 'completed', 'approved', 'declined', 'assigned', 'enroute', 'ongoing', 'work_completed'],
    default: 'pending'
  },
  cancellationReason: { type: String, trim: true, maxlength: 500 },
  cancelledAt: { type: Date },
  cancelledBy: { type: String, enum: ['client', 'provider', 'admin'] },
  phone: { type: String },
  message: { type: String },
  subtype: { type: String },
  selectedServices: { type: [String], default: [] },
  numberOfGuests: { type: Number, min: 1 },
  breakfast: { type: Boolean, default: false },
  numberOfRooms: { type: Number, min: 1 },
  accommodationSelection: { type: String, enum: ['entire', 'rooms'] },
  functionType: { type: String, trim: true },
  selectedPerformer: { type: String },
  serviceDuration: { type: String, trim: true },
  selectedHaircut: { type: String, trim: true },
  beardGrooming: { type: String, trim: true },
  specialRequirements: { type: String, trim: true },
  foodProvided: { type: String, enum: ['yes', 'no'] },
  electricityProvided: { type: String, enum: ['yes', 'no'] },
  performerExperience: { type: String },
  performerImage: { type: String },
  deviceType: { type: String },
  vehicleType: { type: String, trim: true },
  vehicleMake: { type: String, trim: true },
  vehicleModel: { type: String, trim: true },
  requestLocation: { type: String },
  locationOption: { type: String, enum: ['comeToYou', 'goToThem'] },
  remindersSent: { type: [String], default: [] },
  // Legacy flag retained for old records; new reminders use remindersSent per stage.
  reminderSent: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Booking', bookingSchema);
