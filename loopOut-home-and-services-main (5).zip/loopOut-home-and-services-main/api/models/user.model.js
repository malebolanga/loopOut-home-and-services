import mongoose from 'mongoose';

const driverVerificationSchema = new mongoose.Schema({
    status: { type: String, enum: ['unverified', 'pending', 'verified', 'rejected'], default: 'unverified' },
    idDocumentUrl: { type: String, default: '' },
    facePhotoUrl: { type: String, default: '' },
    licenceDocumentUrl: { type: String, default: '' },
    submittedAt: { type: Date, default: null },
    reviewedAt: { type: Date, default: null },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    reviewNote: { type: String, default: '' },
    reviewChecks: {
        idIsReadable: { type: Boolean, default: false },
        faceMatchesId: { type: Boolean, default: false },
        licenceIsValid: { type: Boolean, default: false },
    },
}, { _id: false });

const pushTokenSchema = new mongoose.Schema({
    token: { type: String, required: true },
    platform: { type: String, enum: ['android', 'ios', 'web'], default: 'android' },
    updatedAt: { type: Date, default: Date.now }
}, { _id: false });

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    authProviders: {
        type: [{ type: String, enum: ['password', 'google'] }],
        default: ['password'],
    },
    firebaseUid: { type: String, default: '', select: false },
    loginFailureCount: { type: Number, default: 0, select: false },
    lastLoginAlertAt: { type: Date, default: null, select: false },
    avatar: {
        type: String,
        default: "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png",
    },
    location: {
        type: String,
        default: "",
    },
    workerAvailability: {
        online: { type: Boolean, default: false },
        latitude: { type: Number, min: -90, max: 90 },
        longitude: { type: Number, min: -180, max: 180 },
        serviceTypes: [{ type: String }],
        updatedAt: { type: Date },
    },
    bio: {
        type: String,
        default: "",
    },
    occupation: {
        type: String,
        default: "",
    },
    offeringType: {
        type: String,
        enum: ['viewer', 'services', 'property', 'food', 'goods', 'shuttle', ''],
        default: '',
    },
    interests: {
        type: String,
        default: "",
    },
    website: {
        type: String,
        default: "",
    },
    socialMedia: {
        type: String,
        default: "",
    },
    phone: {
        type: String,
        default: "",
    },
    preferredLanguage: {
        type: String,
        enum: ['en', 'af', 'zu', 'xh', 'es', 'fr', 'de', 'pt', 'ar'],
        default: "en",
    },
    favorites: [{
        itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Listing' },
        addedAt: { type: Date, default: Date.now }
    }],
    favoriteServices: [{
        itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Service' },
        addedAt: { type: Date, default: Date.now }
    }],
    favoriteHelpers: [{
        itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Helper' },
        addedAt: { type: Date, default: Date.now }
    }],
    favoriteEvents: [{
        itemId: { type: mongoose.Schema.Types.ObjectId, ref: 'Event' },
        addedAt: { type: Date, default: Date.now }
    }],
    services: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Service'
    }],
    reviews: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Review'
    }],
    comments: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Comment'
    }],
    isPromoted: {
      type: Boolean,
      default: false
    },
    promotionPackage: {
      type: String,
      enum: ['standard', 'premium', null],
      default: null
    },
    promotionExpiry: {
      type: Date
    },
    helpers: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Helper'
    }],
    events: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Event'
    }],

    // Face Recognition Data
    faceData: {
        imageUrl: String,
        descriptor: [Number],
        verified: { type: Boolean, default: false },
        detectedAt: Date,
        method: { type: String, enum: ['camera', 'upload'], default: 'camera' }
    },

    // Add host rating fields
    likeCount: {
        type: Number,
        default: 0
    },
    dislikeCount: {
        type: Number,
        default: 0
    },

    // Add user actions tracking
    ratedBy: [{
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true
        },
        action: {
            type: String,
            enum: ['like', 'dislike'],
            required: true
        },
        ratedAt: {
            type: Date,
            default: Date.now
        }
    }],
    isVerified: {
        type: Boolean,
        default: false
    },
    kycStatus: {
        type: String,
        enum: ['unverified', 'pending', 'verified', 'rejected'],
        default: 'unverified'
    },
    // Sensitive KYC values are excluded from normal user queries and cleared
    // after an administrator completes the document review.
    idDocumentNumber: {
        type: String,
        default: '',
        select: false
    },
    kycReviewedAt: { type: Date, default: null },
    kycReviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    kycReviewNote: { type: String, default: '' },
    kycReviewChecks: {
        numberMatches: { type: Boolean, default: false },
        documentHasFace: { type: Boolean, default: false },
        faceMatchesSelfie: { type: Boolean, default: false },
    },
    // Sensitive driver documents are private and are exposed only through the
    // authenticated driver status and administrator review endpoints.
    driverVerification: {
        type: driverVerificationSchema,
        default: () => ({}),
        select: false,
    },
    idDocumentUrl: {
        type: String,
        default: ""
    },
    liveSelfieUrl: {
        type: String,
        default: ""
    },
    coverPhoto: {
        type: String,
        default: ""
    },
    followers: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    following: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    listingLimit: {
        type: Number,
        default: 1
    },
    // Trusted contacts are private account data. Keep name and number together;
    // Mixed also allows legacy string-only phone entries to be read safely.
    contacts: {
        type: [mongoose.Schema.Types.Mixed],
        default: []
    },
    accessContacts: {
        type: Boolean,
        default: false
    },
    profileVisibility: {
        type: Boolean,
        default: true
    },
    contactVisibility: {
        type: String,
        enum: ['public', 'private'],
        default: 'private'
    },
    notificationPreferences: {
        security: {
            loginAttempts: { type: Boolean, default: true },
            passwordChanges: { type: Boolean, default: true }
        },
        activity: {
            bookingUpdates: { type: Boolean, default: true },
            paymentReceipts: { type: Boolean, default: true }
        },
        promotions: {
            specialOffers: { type: Boolean, default: false },
            platformUpdates: { type: Boolean, default: true }
        }
    },
    // Device tokens are private and must never be included in normal user API responses.
    pushTokens: {
        type: [pushTokenSchema],
        default: [],
        select: false
    },
    dataSharing: {
        marketing: { type: Boolean, default: false },
        research: { type: Boolean, default: false }
    },
    sharedInfo: {
        bookingHistory: { type: Boolean, default: false },
        reviews: { type: Boolean, default: true },
        socialConnections: { type: Boolean, default: false }
    },
    otp: {
        type: String,
    },
    otpExpiry: {
        type: Date,
    },
    otpAttempts: {
        type: Number,
        default: 0,
    },
    otpPurpose: {
        type: String,
        enum: ['verify', 'reset', 'two-factor-login', 'two-factor-setup', 'two-factor-disable', null],
        default: null,
    },
    twoFactorEnabled: {
        type: Boolean,
        default: false,
    },
    termsAcceptedAt: {
        type: Date,
    },
    privacyAcceptedAt: {
        type: Date,
    },
    plannerTasks: [{
        task: { type: String, required: true },
        completed: { type: Boolean, default: false },
        createdAt: { type: Date, default: Date.now }
    }],
    lastLogin: {
        type: Date,
        default: null,
    },
    lastLoginRecorded: { type: Boolean, default: false },
    kycSubmittedAt: { type: Date, default: null },
    shareActivityWithAdmins: { type: Boolean, default: false },
    shareDetailedActivityWithAdmins: { type: Boolean, default: false },
    shareDetailedActivityWithAdmins: { type: Boolean, default: false },
    shareLoginGpsArea: { type: Boolean, default: false },
    accountStatus: { type: String, enum: ['active', 'suspended'], default: 'active', index: true },
    accountStatusChangedAt: { type: Date, default: null },
    accountStatusChangedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    accountStatusNote: { type: String, default: '', maxlength: 500 },
}, { timestamps: true });

const User = mongoose.model('User', userSchema);

export default User;
