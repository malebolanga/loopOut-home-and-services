import mongoose from 'mongoose';
import { hideSuspendedOwnerContent } from '../utils/hideSuspendedOwnerContent.js';

const sellSchema = new mongoose.Schema(
  {
    creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    price: { type: Number, required: true },
    category: {
      type: String,
      enum: ['furniture', 'electronics', 'clothes', 'universities', 'books', 'other'],
      required: true,
    },
    imageUrls: { type: [String], required: true },
    address: { type: String, required: false },
    contact: { type: String, required: true },
    condition: { type: String, required: false }, // e.g., 'New', 'Used'
    bookAuthor: { type: String, required: false },
    bookYear: { type: String, required: false },
    bookUsageHistory: { type: String, required: false },
  },
  { timestamps: true }
);

// ── Indexes ───────────────────────────────────────────────────────────────
sellSchema.index({ createdAt: -1 });
sellSchema.index({ category: 1, createdAt: -1 });
sellSchema.index({ creator: 1, createdAt: -1 });
hideSuspendedOwnerContent(sellSchema, [{ field: 'creator' }]);

const Sell = mongoose.model('Sell', sellSchema);
export default Sell;
