import mongoose from 'mongoose';
import { hideSuspendedOwnerContent } from '../utils/hideSuspendedOwnerContent.js';

const replySchema = new mongoose.Schema({
  content: {
    type: String,
    required: [true, 'Reply content is required'],
    maxlength: [1000, 'Reply cannot exceed 1000 characters']
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  userName: {
    type: String,
    required: [true, 'Username is required']
  },
  userAvatar: {
    type: String,
    default: '/default-avatar.jpg'
  }
}, { timestamps: true });

const serviceCommentSchema = new mongoose.Schema({
  bookingId: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking' },
  content: {
    type: String,
    required: [true, 'Comment content is required'],
    maxlength: [1000, 'Comment cannot exceed 1000 characters']
  },
  rating: { type: Number, required: true, min: 0, max: 5 },
  punctualityRating: { type: Number, min: 1, max: 5 },
  qualityRating: { type: Number, min: 1, max: 5 },
  communicationRating: { type: Number, min: 1, max: 5 },
  cleanlinessRating: { type: Number, min: 1, max: 5 },
  respectfulnessRating: { type: Number, min: 1, max: 5 },
  valueRating: { type: Number, min: 1, max: 5 },
  recommendationRating: { type: Number, min: 1, max: 5 },
  tyresRating: { type: Number, min: 1, max: 5 },
  interiorRating: { type: Number, min: 1, max: 5 },
  exteriorRating: { type: Number, min: 1, max: 5 },
  dashboardRating: { type: Number, min: 1, max: 5 },
  windowsRating: { type: Number, min: 1, max: 5 },
  matsRating: { type: Number, min: 1, max: 5 },
  serviceCommunicationRating: { type: Number, min: 1, max: 5 },
  serviceId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Service',
    required: [true, 'Service ID is required']
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  userName: {
    type: String,
    required: [true, 'Username is required']
  },
  userAvatar: {
    type: String,
    default: '/default-avatar.jpg'
  },
  likes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }],
  replies: [replySchema]
}, { timestamps: true });

serviceCommentSchema.index({ bookingId: 1 }, { unique: true, sparse: true });

hideSuspendedOwnerContent(serviceCommentSchema, [{ field: 'userId' }]);
const ServiceComment = mongoose.model('ServiceComment', serviceCommentSchema);

export default ServiceComment;
