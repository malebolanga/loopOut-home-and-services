import Listing from '../models/listing.model.js';
import LookingFor from '../models/lookingFor.model.js';
import Comment from '../models/comment.model.js';
import Sell from '../models/sell.model.js';
import Booking from '../models/Booking.js';
import mongoose from 'mongoose';
import { errorHandler } from '../utils/error.js';
import { createUserNotification } from '../utils/notificationUtils.js';

export const createComment = async (req, res, next) => {
  try {
    const {
      content, listingId, bookingId, userName, userAvatar, rating,
      hospitalityRating, comfortRating, locationRating, hostRating, cleanlinessRating,
    } = req.body;
    const userId = req.user.id;

    if (!content || !listingId) {
      return next(errorHandler(400, 'Content and target ID are required'));
    }

    // Check if it's a listing OR a looking-for request
    let target = await Listing.findById(listingId);
    let targetType = 'listing';
    
    if (!target) {
      target = await LookingFor.findById(listingId);
      targetType = 'lookingFor';
    }
    if (!target) {
      target = await Sell.findById(listingId);
      targetType = 'sell';
    }

    if (!target) {
      return next(errorHandler(404, 'Listing or Request not found'));
    }

    if (targetType === 'listing' && rating !== undefined && rating !== null) {
      if (!bookingId || !mongoose.Types.ObjectId.isValid(bookingId)) return next(errorHandler(400, 'A completed booking is required to leave a listing review'));
      const completedBooking = await Booking.findOne({ _id: bookingId, user: userId, listing: listingId, status: 'completed' }).select('_id endDate');
      if (!completedBooking) return next(errorHandler(403, 'Only the customer who completed this booking can review the listing'));
      if (!completedBooking.endDate || new Date(completedBooking.endDate).getTime() > Date.now()) {
        return next(errorHandler(409, 'You can review this stay after its scheduled end time.'));
      }
      const categoryScores = { hospitalityRating, comfortRating, locationRating, hostRating, cleanlinessRating };
      const validScores = Object.values(categoryScores).every((score) => Number.isInteger(Number(score)) && Number(score) >= 1 && Number(score) <= 5);
      if (!validScores) return next(errorHandler(400, 'Please submit a 1–5 score for all five stay categories.'));
      if (await Comment.exists({ bookingId })) return next(errorHandler(409, 'This booking already has a review'));
    }

    const comment = new Comment({
      content,
      listingId, // keeping the field name as listingId in the DB for now to avoid migration
      userId,
      userName: userName || req.user.username,
      userAvatar: userAvatar || req.user.avatar || '/default-avatar.jpg',
      rating: rating ? Number(rating) : undefined,
      hospitalityRating: targetType === 'listing' && rating ? Number(hospitalityRating) : undefined,
      comfortRating: targetType === 'listing' && rating ? Number(comfortRating) : undefined,
      locationRating: targetType === 'listing' && rating ? Number(locationRating) : undefined,
      hostRating: targetType === 'listing' && rating ? Number(hostRating) : undefined,
      cleanlinessRating: targetType === 'listing' && rating ? Number(cleanlinessRating) : undefined,
      bookingId: targetType === 'listing' && rating ? bookingId : undefined
    });

    await comment.save();

    // Initialize comments array if it doesn't exist
    if (!target.comments) {
      target.comments = [];
    }
    target.comments.push(comment._id);

    // Update the average rating on the target entity
    if (rating) {
      const allComments = await Comment.find({ listingId, rating: { $exists: true, $ne: null } });
      if (allComments.length > 0) {
        const sum = allComments.reduce((acc, curr) => acc + curr.rating, 0);
        target.rating = sum / allComments.length;
      } else {
        target.rating = Number(rating);
      }
    }

    await target.save();

    // Notify owner
    const ownerId = targetType === 'listing' ? target.userRef : target.userRef;
    const itemName = targetType === 'listing' ? target.name : target.title;

    if (ownerId.toString() !== userId) {
      await createUserNotification(
        ownerId,
        'system',
        'New Comment',
        `${userName || req.user.username} commented on your ${targetType === 'listing' ? 'listing' : 'request'} "${itemName}"`,
        { itemId: listingId, itemType: targetType, commentId: comment._id }
      );
    }

    res.status(201).json(comment);
  } catch (error) {
    if (error?.code === 11000) return next(errorHandler(409, 'This booking already has a review'));
    next(errorHandler(500, error.message || 'Failed to create comment'));
  }
};

export const getComments = async (req, res, next) => {
  try {
    const { listingId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 5;
    const skip = (page - 1) * limit;

    const listingExists = await Listing.exists({ _id: listingId });
    const requestExists = !listingExists ? await LookingFor.exists({ _id: listingId }) : false;
    const sellExists = !listingExists && !requestExists ? await Sell.exists({ _id: listingId }) : false;

    if (!listingExists && !requestExists && !sellExists) {
      return next(errorHandler(404, 'Listing or Request not found'));
    }

    const comments = await Comment.find({ listingId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    const totalComments = await Comment.countDocuments({ listingId });

    // Calculate ratings summary based on comments
    const allComments = await Comment.find({ listingId, rating: { $exists: true, $ne: null } });

    const averageFor = (field) => {
      const values = allComments.map((comment) => Number(comment[field])).filter((value) => Number.isFinite(value) && value >= 1 && value <= 5);
      return values.length ? Number((values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(1)) : 0;
    };
    const ratings = {
      overall: averageFor('rating'),
      hospitality: averageFor('hospitalityRating'),
      comfort: averageFor('comfortRating'),
      location: averageFor('locationRating'),
      host: averageFor('hostRating'),
      cleanliness: averageFor('cleanlinessRating'),
    };

    res.status(200).json({
      comments,
      totalComments,
      ratings,
      totalPages: Math.ceil(totalComments / limit),
      currentPage: page
    });
  } catch (error) {
    next(errorHandler(500, error.message || 'Failed to fetch comments'));
  }
};

export const likeComment = async (req, res, next) => {
  try {
    const { commentId } = req.params;
    const userId = req.user.id;

    const comment = await Comment.findById(commentId);
    if (!comment) {
      return next(errorHandler(404, 'Comment not found'));
    }

    const alreadyLiked = comment.likes.includes(userId);
    if (alreadyLiked) {
      comment.likes = comment.likes.filter(id => id.toString() !== userId);
    } else {
      comment.likes.push(userId);
    }

    await comment.save();
    res.status(200).json(comment);
  } catch (error) {
    next(errorHandler(500, error.message || 'Failed to like comment'));
  }
};

export const addReply = async (req, res, next) => {
  try {
    const { commentId } = req.params;
    const { content, userName, userAvatar } = req.body;
    const userId = req.user.id;

    if (!content) {
      return next(errorHandler(400, 'Reply content is required'));
    }

    const comment = await Comment.findById(commentId);
    if (!comment) {
      return next(errorHandler(404, 'Comment not found'));
    }

    const reply = {
      content,
      userId,
      userName: userName || req.user.username,
      userAvatar: userAvatar || req.user.avatar || '/default-avatar.jpg'
    };

    comment.replies.push(reply);
    await comment.save();

    res.status(201).json(comment);
  } catch (error) {
    next(errorHandler(500, error.message || 'Failed to add reply'));
  }
};
