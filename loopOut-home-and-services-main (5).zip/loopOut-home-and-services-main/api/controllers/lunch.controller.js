import crypto from 'crypto';
import mongoose from 'mongoose';
import Shop from '../models/shop.model.js';
import User from '../models/user.model.js';
import FoodOrder from '../models/foodOrder.model.js';
import TableBooking from '../models/tableBooking.model.js';
import Notification from '../models/notification.model.js';

const ORDER_STATUSES = ['Pending', 'Preparing', 'Ready for Collection', 'Completed', 'Cancelled'];
const requireDatabase = (res) => {
  if (mongoose.connection.readyState === 1) return true;
  res.status(503).json({ success: false, message: 'Lunch ordering is temporarily unavailable. Please try again later.' });
  return false;
};
const format = (document) => ({ id: document._id.toString(), ...document.toObject() });
const formatShop = (shop) => {
  const formatted = format(shop);
  const ratings = (formatted.reviews || []).map((review) => Number(review.shopRating)).filter((rating) => Number.isFinite(rating) && rating >= 1 && rating <= 5);
  return {
    ...formatted,
    ratingsCount: ratings.length,
    rating: ratings.length ? (ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length).toFixed(1) : '',
  };
};
const validId = (id) => mongoose.Types.ObjectId.isValid(id);
const userId = (req) => String(req.user?.id || req.user?._id || '');
const cleanText = (value, limit = 500) => String(value || '').trim().slice(0, limit);
const isOwner = async (shop, req) => {
  const currentUid = userId(req);
  if (!currentUid || !shop) return false;
  if (String(shop.ownerId || '') === currentUid) return true;
  const user = await User.findById(currentUid).select('isAdmin role').lean();
  return Boolean(user && (user.isAdmin === true || user.role === 'admin'));
};
const cleanImage = (value, fallback = '') => {
  const image = cleanText(value, 2048);
  if (/^https?:\/\//i.test(image) || image.startsWith('/') || image.startsWith('data:image/')) return image;
  return image.length <= 16 ? image : fallback;
};
const PORTION_NAMES = ['Small', 'Medium', 'Large', 'Full plate'];
const normalizePortions = (value) => {
  if (!Array.isArray(value)) return [];
  const portions = [];
  for (const entry of value) {
    const name = PORTION_NAMES.find((option) => option.toLowerCase() === cleanText(entry?.name, 20).toLowerCase());
    const price = Number(entry?.price);
    if (!name || !Number.isFinite(price) || price <= 0 || price > 10000 || portions.some((portion) => portion.name === name)) return null;
    portions.push({ name, price: Math.round(price * 100) / 100 });
  }
  return portions;
};
const normalizeAddOns = (value) => {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 20) return null;
  const addOns = [];
  for (const entry of value) {
    const name = cleanText(entry?.name, 80);
    const price = Number(entry?.price);
    if (!name || !Number.isFinite(price) || price < 0 || price > 10000 || addOns.some((addOn) => addOn.name.toLowerCase() === name.toLowerCase())) return null;
    addOns.push({ name, price: Math.round(price * 100) / 100 });
  }
  return addOns;
};
const getOwnedShop = async (id, req, res) => {
  if (!validId(id)) { res.status(404).json({ success: false, message: 'Shop not found.' }); return null; }
  const shop = await Shop.findById(id);
  if (!shop) { res.status(404).json({ success: false, message: 'Shop not found.' }); return null; }
  const currentUid = userId(req);
  if (!currentUid) { res.status(403).json({ success: false, message: 'You do not manage this shop.' }); return null; }
  // Quick ownership check — avoids a DB round-trip for the common case
  if (String(shop.ownerId || '') === currentUid) return shop;
  // Fallback: check if the user is an admin in the database (JWT does not embed isAdmin/role)
  const user = await User.findById(currentUid).select('isAdmin role').lean();
  if (user && (user.isAdmin === true || user.role === 'admin')) return shop;
  res.status(403).json({ success: false, message: 'You do not manage this shop.' }); return null;
};
const createNotification = async (userId, title, message, data, type = 'booking') => {
  if (!validId(userId)) return;
  await Notification.create({ userId, type, title, message, data });
};

const PICKUP_AUTO_COMPLETE_MS = 2 * 60 * 60 * 1000;

export const autoCompletePickupOrders = async () => {
  if (mongoose.connection.readyState !== 1) return 0;
  const cutoff = new Date(Date.now() - PICKUP_AUTO_COMPLETE_MS);
  const overdueOrders = await FoodOrder.find({
    status: 'Ready for Collection',
    fulfilment: 'pickup',
    $or: [
      { pickupReadyAt: { $lte: cutoff } },
      { pickupReadyAt: { $exists: false }, updatedAt: { $lte: cutoff } },
    ],
  }).select('_id customerId orderCode');

  let completedCount = 0;
  for (const order of overdueOrders) {
    const completed = await FoodOrder.findOneAndUpdate(
      {
        _id: order._id,
        status: 'Ready for Collection',
        fulfilment: 'pickup',
        $or: [
          { pickupReadyAt: { $lte: cutoff } },
          { pickupReadyAt: { $exists: false }, updatedAt: { $lte: cutoff } },
        ],
      },
      { $set: { status: 'Completed', completedAt: new Date(), completionMethod: 'auto_timeout' } },
      { new: true }
    );
    if (!completed) continue;
    completedCount += 1;
    await createNotification(
      completed.customerId,
      'Pickup order closed',
      `Order #${completed.orderCode} was automatically completed two hours after it was ready for collection.`,
      { orderId: completed._id, status: completed.status }
    ).catch(() => {});
  }
  return completedCount;
};

export const getShops = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const shops = await Shop.find({ ownerId: { $ne: 'guest' } }).sort({ createdAt: -1 });
    return res.json(shops.map(formatShop));
  } catch (error) { return next(error); }
};

export const getMyShops = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const currentUid = userId(req);
    if (!currentUid) return res.status(401).json({ success: false, message: 'Please sign in to continue.' });
    const user = await User.findById(currentUid).select('isAdmin role').lean();
    const isAdmin = Boolean(user && (user.isAdmin === true || user.role === 'admin'));
    const shops = await Shop.find(isAdmin ? { ownerId: { $ne: 'guest' } } : { ownerId: currentUid }).sort({ createdAt: -1 });
    return res.json(shops.map(formatShop));
  } catch (error) { return next(error); }
};

export const createShop = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const currentUid = userId(req);
    if (!currentUid) return res.status(401).json({ success: false, message: 'Please sign in to continue.' });

    const user = await User.findById(currentUid).select('offeringType');
    if (!user || user.offeringType !== 'food') {
      return res.status(403).json({
        success: false,
        message: 'Only accounts registered as a food shop owner on sign-up can register a shop. Other accounts can only view and order.'
      });
    }

    const name = cleanText(req.body.name, 80);
    const address = cleanText(req.body.address, 180);
    const phone = cleanText(req.body.phone, 30);
    if (!name || !address || !phone) return res.status(400).json({ success: false, message: 'Shop name, address, and phone are required.' });
    if (await Shop.exists({ name: new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') })) return res.status(409).json({ success: false, message: 'A shop with that name already exists.' });
    const shop = await Shop.create({ name, address, phone, cuisine: cleanText(req.body.cuisine, 60) || 'General', image: cleanImage(req.body.image, '🏪') || '🏪', whatsapp: cleanText(req.body.whatsapp, 30), ownerId: userId(req), ownerName: cleanText(req.body.ownerName, 80) || 'Shop owner', isOpen: false, meals: [] });
    return res.status(201).json(format(shop));
  } catch (error) { return next(error); }
};

export const updateShop = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const shop = await getOwnedShop(req.params.id, req, res); if (!shop) return;
    for (const key of ['name', 'cuisine', 'address', 'phone', 'whatsapp']) if (req.body[key] !== undefined) shop[key] = cleanText(req.body[key], key === 'address' ? 180 : 80);
    if (req.body.image !== undefined) shop.image = cleanImage(req.body.image, shop.image || '🏪');
    if (typeof req.body.isOpen === 'boolean') shop.isOpen = req.body.isOpen;
    if (typeof req.body.isPromoted === 'boolean') shop.isPromoted = req.body.isPromoted;
    if (req.body.operatingHours && typeof req.body.operatingHours === 'object') shop.operatingHours = req.body.operatingHours;
    await shop.save(); return res.json(format(shop));
  } catch (error) { return next(error); }
};

export const addMealToShop = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const shop = await getOwnedShop(req.params.id, req, res); if (!shop) return;
    const name = cleanText(req.body.name, 100); const price = Number(req.body.price);
    if (!name || !Number.isFinite(price) || price <= 0 || price > 10000) return res.status(400).json({ success: false, message: 'Enter a valid meal name and price.' });
    const sides = Array.isArray(req.body.sides) ? req.body.sides.map(s => cleanText(s, 60)).filter(Boolean) : [];
    const portions = normalizePortions(req.body.portions);
    if (portions === null) return res.status(400).json({ success: false, message: 'Enter a valid price for each serving size.' });
    const itemType = ['combo', 'special'].includes(String(req.body.itemType || '').toLowerCase()) ? String(req.body.itemType).toLowerCase() : 'meal';
    const addOns = normalizeAddOns(req.body.addOns);
    if (addOns === null) return res.status(400).json({ success: false, message: 'Enter valid add-on names and prices.' });
    const meal = { id: crypto.randomUUID(), name, description: cleanText(req.body.description, 500), price: Math.round(price * 100) / 100, tag: cleanText(req.body.tag, 40), category: cleanText(req.body.category, 60), itemType, image: cleanImage(req.body.image, '🍽️') || '🍽️', isAvailable: req.body.isAvailable !== false, addOns, sides, portions };
    shop.meals.push(meal); await shop.save(); return res.status(201).json(meal);
  } catch (error) { return next(error); }
};

export const updateMealInShop = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const shop = await getOwnedShop(req.params.id, req, res); if (!shop) return;
    const meal = shop.meals.find((entry) => entry.id === req.params.mealId); if (!meal) return res.status(404).json({ success: false, message: 'Meal not found.' });
    if (req.body.name !== undefined) meal.name = cleanText(req.body.name, 100);
    if (req.body.description !== undefined) meal.description = cleanText(req.body.description, 500);
    if (req.body.tag !== undefined) meal.tag = cleanText(req.body.tag, 40);
    if (req.body.category !== undefined) meal.category = cleanText(req.body.category, 60);
    if (req.body.itemType !== undefined) meal.itemType = ['combo', 'special'].includes(String(req.body.itemType).toLowerCase()) ? String(req.body.itemType).toLowerCase() : 'meal';
    if (req.body.image !== undefined) meal.image = cleanImage(req.body.image, meal.image || '🍽️');
    if (req.body.isAvailable !== undefined) meal.isAvailable = Boolean(req.body.isAvailable);
    if (req.body.sides !== undefined) meal.sides = Array.isArray(req.body.sides) ? req.body.sides.map(s => cleanText(s, 60)).filter(Boolean) : [];
    if (req.body.addOns !== undefined) {
      const addOns = normalizeAddOns(req.body.addOns);
      if (addOns === null) return res.status(400).json({ success: false, message: 'Enter valid add-on names and prices.' });
      meal.addOns = addOns;
    }
    if (req.body.portions !== undefined) {
      const portions = normalizePortions(req.body.portions);
      if (portions === null) return res.status(400).json({ success: false, message: 'Enter a valid price for each serving size.' });
      meal.portions = portions;
    }
    if (req.body.price !== undefined) { const price = Number(req.body.price); if (!Number.isFinite(price) || price <= 0 || price > 10000) return res.status(400).json({ success: false, message: 'Enter a valid price.' }); meal.price = Math.round(price * 100) / 100; }
    await shop.save(); return res.json(meal.toObject());
  } catch (error) { return next(error); }
};

export const deleteMealFromShop = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const shop = await getOwnedShop(req.params.id, req, res); if (!shop) return;
    const before = shop.meals.length; shop.meals = shop.meals.filter((meal) => meal.id !== req.params.mealId);
    if (shop.meals.length === before) return res.status(404).json({ success: false, message: 'Meal not found.' });
    await shop.save(); return res.json({ success: true });
  } catch (error) { return next(error); }
};

export const getOrders = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    await autoCompletePickupOrders();
    const ownedShops = await Shop.find({ ownerId: userId(req) }).select('_id');
    const orders = await FoodOrder.find({ $or: [{ customerId: userId(req) }, { shopId: { $in: ownedShops.map((shop) => shop._id.toString()) } }] }).sort({ createdAt: -1 });
    return res.json(orders.map(format));
  } catch (error) { return next(error); }
};

export const createOrder = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const { shopId, items, customerPhone, customerName, orderComments, scheduledFor, fulfilment, deliveryAddress, deliveryNotes } = req.body;
    if (!validId(shopId) || !Array.isArray(items) || !items.length) return res.status(400).json({ success: false, message: 'Choose a shop and at least one meal.' });
    const shop = await Shop.findById(shopId); if (!shop || !shop.isOpen) return res.status(409).json({ success: false, message: 'This shop is not accepting orders.' });
    const normalizedItems = items.map((item) => {
      if (!item || typeof item !== 'object') return null;
      const meal = shop.meals.find((entry) => entry.id === item.id);
      const quantity = Number(item.quantity);
      if (!meal || !meal.isAvailable || !Number.isInteger(quantity) || quantity < 1 || quantity > 20) return null;
      if ((item.sides !== undefined && !Array.isArray(item.sides)) || (item.addOns !== undefined && !Array.isArray(item.addOns))) return null;
      const submittedSides = Array.isArray(item.sides) ? item.sides.map(s => cleanText(s, 60)).filter(Boolean) : [];
      const availableSides = Array.isArray(meal.sides) ? meal.sides : [];
      if (submittedSides.length > 3 || submittedSides.some((side) => !availableSides.includes(side)) || new Set(submittedSides).size !== submittedSides.length) return null;
      const itemSides = submittedSides;
      const submittedAddOns = Array.isArray(item.addOns) ? item.addOns : [];
      if (submittedAddOns.length > 10) return null;
      const normalizedAddOns = submittedAddOns.map((addOn) => {
        const name = cleanText(addOn?.name, 80);
        const menuAddOn = Array.isArray(meal.addOns) ? meal.addOns.find((entry) => entry.name === name) : null;
        const addOnQuantity = Number(addOn?.quantity);
        const menuPrice = Number(menuAddOn?.price);
        if (!menuAddOn || !Number.isFinite(menuPrice) || menuPrice < 0 || !Number.isInteger(addOnQuantity) || addOnQuantity < 1 || addOnQuantity > 20) return null;
        return { name: menuAddOn.name, price: menuPrice, quantity: addOnQuantity };
      });
      if (normalizedAddOns.some((addOn) => !addOn) || new Set(normalizedAddOns.map((addOn) => addOn.name)).size !== normalizedAddOns.length) return null;
      const portionName = cleanText(item.portionName, 20);
      const selectedPortion = portionName ? meal.portions?.find((portion) => portion.name === portionName) : null;
      if ((meal.portions?.length && !selectedPortion) || (portionName && !selectedPortion)) return null;
      const itemPrice = selectedPortion?.price ?? meal.price;
      return { id: meal.id, name: selectedPortion ? `${meal.name} (${selectedPortion.name})` : meal.name, portionName: selectedPortion?.name || '', price: itemPrice, quantity, image: meal.image || '🍱', sides: itemSides, addOns: normalizedAddOns };
    });
    if (normalizedItems.some((item) => !item)) return res.status(409).json({ success: false, message: 'One or more meals are unavailable. Refresh your basket and try again.' });
    const phone = cleanText(customerPhone, 30); if (!phone) return res.status(400).json({ success: false, message: 'A contact phone number is required.' });
    const requestedFulfilment = fulfilment === 'delivery' ? 'delivery' : 'pickup';
    const cleanDeliveryAddress = cleanText(deliveryAddress, 180);
    if (requestedFulfilment === 'delivery' && !cleanDeliveryAddress) return res.status(400).json({ success: false, message: 'A delivery address is required for delivery orders.' });
    const total = normalizedItems.reduce((sum, item) => sum + item.price * item.quantity + item.addOns.reduce((addOnSum, addOn) => addOnSum + addOn.price * addOn.quantity, 0), 0);
    const requestedTime = scheduledFor ? new Date(scheduledFor) : null;
    if (requestedTime && (Number.isNaN(requestedTime.getTime()) || requestedTime <= new Date())) return res.status(400).json({ success: false, message: 'Choose a future collection time.' });
    const order = await FoodOrder.create({ orderCode: `LNCH-${crypto.randomInt(100000, 1000000)}`, customerId: userId(req), customerName: cleanText(customerName, 100) || 'Customer', customerPhone: phone, shopId: shop._id.toString(), shopName: shop.name, shopImage: shop.image, items: normalizedItems, total: Math.round(total * 100) / 100, fulfilment: requestedFulfilment, deliveryAddress: cleanDeliveryAddress, deliveryNotes: cleanText(deliveryNotes, 500), orderComments: cleanText(orderComments, 500), scheduledFor: requestedTime || undefined, paymentMethod: 'counter', paymentStatus: requestedFulfilment === 'delivery' ? 'Delivery payment pending' : 'Pay at Counter', status: 'Pending' });
    await Promise.allSettled([createNotification(userId(req), 'Food order received', `Your order #${order.orderCode} has been sent to ${shop.name}.`, { orderId: order._id, status: order.status }), createNotification(shop.ownerId, 'New food order', `Order #${order.orderCode} is waiting for your confirmation.`, { orderId: order._id, status: order.status })]);
    return res.status(201).json(format(order));
  } catch (error) { return next(error); }
};

export const updateOrderStatus = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const status = req.body.status; if (!ORDER_STATUSES.includes(status)) return res.status(400).json({ success: false, message: 'Invalid order status.' });
    const order = validId(req.params.id) ? await FoodOrder.findById(req.params.id) : null; if (!order) return res.status(404).json({ success: false, message: 'Order not found.' });
    const shop = await Shop.findById(order.shopId);
    const isShopManager = shop ? await isOwner(shop, req) : false;
    const isCustomer = order.customerId === userId(req);
    if (status === 'Cancelled') {
      if (isCustomer) {
        if (!['Pending', 'Preparing'].includes(order.status)) {
          return res.status(409).json({ success: false, message: 'You can cancel this order only before it is ready.' });
        }
      } else if (!isShopManager) {
        return res.status(403).json({ success: false, message: 'You do not manage this order.' });
      }
      if (['Completed', 'Cancelled', 'Ready for Collection'].includes(order.status)) {
        return res.status(409).json({ success: false, message: 'This order can no longer be cancelled.' });
      }
    } else if (status === 'Completed') {
      if (!isCustomer) return res.status(403).json({ success: false, message: 'Only the customer who placed this order can confirm receipt.' });
      if (order.status === 'Completed') return res.json(format(order));
      if (order.status !== 'Ready for Collection') return res.status(409).json({ success: false, message: 'You can complete this order after the shop marks it ready.' });
      order.completionMethod = 'customer';
      order.completedAt = new Date();
    } else if (!isShopManager) {
      return res.status(403).json({ success: false, message: 'You do not manage this order.' });
    }
    const statusChanged = order.status !== status;
    if (!statusChanged) return res.json(format(order));
    order.status = status;
    if (status === 'Ready for Collection') order.pickupReadyAt = new Date();
    else if (status !== 'Completed') order.pickupReadyAt = undefined;
    await order.save();
    const isReady = status === 'Ready for Collection';
    const notificationTitle = isReady
      ? (order.fulfilment === 'delivery' ? 'Your food order is ready for delivery' : 'Your food is ready for collection')
      : 'Food order update';
    const notificationMessage = isReady
      ? (order.fulfilment === 'delivery'
        ? `Order #${order.orderCode} from ${order.shopName} is ready for delivery.`
        : `Order #${order.orderCode} from ${order.shopName} is ready. You can collect it now.`)
      : `Order #${order.orderCode} is now ${status}.`;
    await createNotification(order.customerId, notificationTitle, notificationMessage, {
      orderId: order._id,
      orderCode: order.orderCode,
      status,
      link: '/food',
    }, 'food_order');
    return res.json(format(order));
  } catch (error) { return next(error); }
};

export const createTableBooking = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const { shopId, date, time, guests, name, phone } = req.body; if (!validId(shopId) || !date || !time) return res.status(400).json({ success: false, message: 'Select a shop, date, and time.' });
    const shop = await Shop.findById(shopId); if (!shop || !shop.isOpen) return res.status(409).json({ success: false, message: 'This shop is not accepting bookings.' });
    const requestedAt = new Date(`${date}T${time}:00`); if (Number.isNaN(requestedAt.getTime()) || requestedAt <= new Date()) return res.status(400).json({ success: false, message: 'Choose a future booking time.' });
    const booking = await TableBooking.create({ customerId: userId(req), customerName: cleanText(name, 100), customerPhone: cleanText(phone, 30), shopId: shop._id.toString(), shopName: shop.name, date, time, guests: String(Math.min(Math.max(Number(guests) || 1, 1), 12)), status: 'Requested' });
    await createNotification(shop.ownerId, 'New table request', `${booking.customerName} requested a table for ${booking.guests}.`, { bookingId: booking._id }); return res.status(201).json(format(booking));
  } catch (error) { return next(error); }
};

export const rateShop = async (req, res, next) => {
  try {
    if (!requireDatabase(res)) return;
    const shop = await Shop.findById(req.params.id);
    if (!shop) return res.status(404).json({ success: false, message: 'Shop not found.' });

    const orderId = req.body.orderId;
    if (!orderId) return res.status(400).json({ success: false, message: 'A completed food order is required to leave a review.' });
    const order = validId(orderId)
      ? await FoodOrder.findById(orderId)
      : await FoodOrder.findOne({ orderCode: orderId });
    if (!order) return res.status(404).json({ success: false, message: 'Order not found.' });
    if (order.shopId !== shop._id.toString()) return res.status(403).json({ success: false, message: 'This order does not belong to this shop.' });
    if (order.customerId !== userId(req)) return res.status(403).json({ success: false, message: 'Only the customer who placed this order can leave a review.' });
    if (order.status !== 'Completed') return res.status(409).json({ success: false, message: 'Complete the order before leaving a review.' });
    if (order.isRated) return res.status(409).json({ success: false, message: 'This order has already been reviewed.' });

    const rating = Number(req.body.shopRating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({ success: false, message: 'Choose a rating from 1 to 5.' });
    }

    const requestedItemRatings = Array.isArray(req.body.itemRatings) ? req.body.itemRatings : [];
    const orderItems = order.items || [];
    const itemRatings = orderItems.map((item, itemIndex) => {
      const requested = requestedItemRatings.find((entry) => Number(entry.itemIndex) === itemIndex);
      const itemRating = Number(requested?.rating);
      if (!requested || String(requested.mealId || '') !== String(item.id || '') || !Number.isInteger(itemRating) || itemRating < 1 || itemRating > 5) return null;
      return {
        itemIndex,
        mealId: item.id || '',
        mealName: cleanText(item.name, 100),
        rating: itemRating
      };
    });
    if (!orderItems.length || itemRatings.some((entry) => !entry) || requestedItemRatings.length !== orderItems.length) {
      return res.status(400).json({ success: false, message: 'Rate every food item in this order individually.' });
    }
    const averageFoodRating = Math.round((itemRatings.reduce((sum, entry) => sum + entry.rating, 0) / itemRatings.length) * 10) / 10;

    const review = {
      id: crypto.randomUUID(),
      userName: cleanText(order.customerName, 50) || 'Customer',
      shopRating: rating,
      foodRating: averageFoodRating,
      itemRatings,
      comment: cleanText(req.body.comment, 500),
      createdAt: new Date()
    };

    const claimedOrder = await FoodOrder.findOneAndUpdate(
      { _id: order._id, customerId: userId(req), status: 'Completed', isRated: { $ne: true } },
      { $set: { isRated: true, ratingDetails: review } },
      { new: true }
    );
    if (!claimedOrder) return res.status(409).json({ success: false, message: 'This order has already been reviewed.' });

    shop.reviews = shop.reviews || [];
    shop.reviews.push(review);
    shop.ratingsCount = shop.reviews.length;
    shop.rating = (shop.reviews.reduce((sum, entry) => sum + entry.shopRating, 0) / shop.reviews.length).toFixed(1);

    try {
      await shop.save();
    } catch (saveError) {
      await FoodOrder.updateOne({ _id: claimedOrder._id, isRated: true }, { $set: { isRated: false }, $unset: { ratingDetails: 1 } });
      throw saveError;
    }

    return res.json({ success: true, review });
  } catch (error) { return next(error); }
};
