import User from '../models/user.model.js';
import bcryptjs from 'bcryptjs';
import { errorHandler } from '../utils/error.js';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import Notification from '../models/notification.model.js';

import { sendEmail } from '../utils/email.js';
import { sendSMS } from '../utils/sms.js';

const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_RESEND_COOLDOWN_MS = 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;
const SESSION_MAX_AGE_MS = 365 * 24 * 60 * 60 * 1000;
const SESSION_EXPIRES_IN = '365d';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const normalizeEmail = (email) => String(email || '').trim().toLowerCase();
const hashOtp = (otp) => crypto.createHash('sha256').update(String(otp)).digest('hex');
const generateOtp = () => crypto.randomInt(100000, 1000000).toString();
const isStrongPassword = (password) => typeof password === 'string' && password.length >= 8;

const cookieOptions = () => ({
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax',
  path: '/',
  maxAge: SESSION_MAX_AGE_MS,
});

const issueSession = async (res, user, status = 200) => {
  if (user.accountStatus === 'suspended') {
    return res.status(403).json({ success: false, message: 'This account is suspended. Contact LoopOut support for help.' });
  }
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: SESSION_EXPIRES_IN });
  const loginTime = new Date();
  try {
    await User.findByIdAndUpdate(user._id, { $set: { lastLogin: loginTime, lastLoginRecorded: true, loginFailureCount: 0 } });
  } catch (err) {
    console.error('Failed to update lastLogin:', err.message);
  }
  const safeUser = safeUserPayload(user);
  return res.cookie('access_token', token, cookieOptions()).status(status).json({ ...safeUser, token, access_token: token, lastLogin: loginTime });
};

const sendVerificationCode = async (user, subject = 'Your LoopOut verification code', purpose = 'verify') => {
  const otp = generateOtp();
  const otpExpiry = new Date(Date.now() + OTP_TTL_MS);
  user.otp = hashOtp(otp);
  user.otpExpiry = otpExpiry;
  user.otpAttempts = 0;
  user.otpPurpose = purpose;
  await user.save();
  const text = `Your LoopOut verification code is: ${otp}. It expires in 10 minutes.`;
  const html = `<p>Use this code to verify your LoopOut account. It expires in <strong>10 minutes</strong>.</p><p style="font-size:28px;letter-spacing:6px"><strong>${otp}</strong></p>`;
  try {
    const emailResult = await sendEmail(user.email, subject, text, html);
    if (!emailResult.success) console.warn(`Verification email delivery to ${user.email} failed: ${emailResult.error}`);
    if (user.phone) await sendSMS(user.phone, text);
    return { success: emailResult.success, otp };
  } catch (error) {
    console.error('Verification code delivery failed:', error.message);
    return { success: false, otp };
  }
};

const sendTwoFactorCode = async (user, purpose) => {
  const otp = generateOtp();
  user.otp = hashOtp(otp);
  user.otpExpiry = new Date(Date.now() + OTP_TTL_MS);
  user.otpAttempts = 0;
  user.otpPurpose = purpose;
  await user.save();

  const setup = purpose === 'two-factor-setup';
  const text = `Your LoopOut ${setup ? 'security setup' : 'sign-in'} code is ${otp}. It expires in 10 minutes. Do not share this code.`;
  const html = `<p>Use this one-time code to ${setup ? 'enable two-factor sign-in' : 'sign in to'} your LoopOut account. It expires in <strong>10 minutes</strong>.</p><p style="font-size:28px;letter-spacing:6px"><strong>${otp}</strong></p><p>Do not share this code.</p>`;
  const delivery = await sendEmail(user.email, setup ? 'Confirm LoopOut two-factor setup' : 'Your LoopOut sign-in code', text, html);
  return { success: delivery.success, otp };
};

const clearOtp = (user) => {
  user.otp = undefined;
  user.otpExpiry = undefined;
  user.otpAttempts = 0;
  user.otpPurpose = undefined;
};

const safeUserPayload = (user) => {
  const safeUser = user.toObject ? user.toObject() : { ...user };
  for (const field of ['password', 'firebaseUid', 'loginFailureCount', 'lastLoginAlertAt', 'otp', 'otpExpiry', 'otpAttempts', 'otpPurpose']) delete safeUser[field];
  return safeUser;
};

const startTwoFactorLogin = async (user, res) => {
  const now = Date.now();
  const challengeIsValid = user.otpPurpose === 'two-factor-login' && user.otp && user.otpExpiry && now <= user.otpExpiry.getTime();
  if (challengeIsValid && (user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) {
    return res.status(429).json({ success: false, message: 'Too many incorrect codes. Wait for this code to expire and try signing in again.' });
  }

  const sentAt = user.otpExpiry ? user.otpExpiry.getTime() - OTP_TTL_MS : 0;
  const shouldSend = !challengeIsValid || now - sentAt >= OTP_RESEND_COOLDOWN_MS;
  let developmentCode;
  if (shouldSend) {
    const delivery = await sendTwoFactorCode(user, 'two-factor-login');
    if (!delivery.success) {
      if (process.env.NODE_ENV === 'production') {
        clearOtp(user);
        await user.save();
        return res.status(503).json({ success: false, message: 'We could not send your sign-in code. Please try again shortly.' });
      }
      developmentCode = delivery.otp;
    }
  }

  return res.status(200).json({
    success: true,
    requiresTwoFactor: true,
    email: user.email,
    message: shouldSend ? 'Enter the one-time code sent to your email.' : 'A sign-in code was sent recently. Check your email for the code.',
    ...(developmentCode ? { devCode: developmentCode } : {}),
  });
};

const firebaseAuth = async () => {
  const { getApps, initializeApp, cert, applicationDefault } = await import('firebase-admin/app');
  const { getAuth } = await import('firebase-admin/auth');
  const fs = await import('fs');
  const path = await import('path');
  if (!getApps().length) {
    const rawServiceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
    const credPath = process.env.GOOGLE_APPLICATION_CREDENTIALS;
    const localSaPath = path.resolve(process.cwd(), 'firebase-service-account.json');
    const rootSaPath = path.resolve(process.cwd(), '..', 'firebase-service-account.json');

    const loadParsedSa = (sa) => {
      if (typeof sa.private_key === 'string') {
        sa.private_key = sa.private_key
          .replace(/^-----[^\n]+-----/, '-----BEGIN PRIVATE KEY-----')
          .replace(/-----[^\n]+-----\n?$/, '-----END PRIVATE KEY-----\n')
          .replace(/\\n/g, '\n');
      }
      return sa;
    };

    if (rawServiceAccount) {
      const sa = loadParsedSa(JSON.parse(rawServiceAccount));
      initializeApp({ credential: cert(sa) });
    } else if (credPath && fs.existsSync(credPath)) {
      const sa = loadParsedSa(JSON.parse(fs.readFileSync(credPath, 'utf8')));
      initializeApp({ credential: cert(sa) });
    } else if (fs.existsSync(localSaPath)) {
      const sa = loadParsedSa(JSON.parse(fs.readFileSync(localSaPath, 'utf8')));
      initializeApp({ credential: cert(sa) });
    } else if (fs.existsSync(rootSaPath)) {
      const sa = loadParsedSa(JSON.parse(fs.readFileSync(rootSaPath, 'utf8')));
      initializeApp({ credential: cert(sa) });
    } else if (credPath) {
      initializeApp({ credential: applicationDefault() });
    } else {
      throw new Error('Firebase Admin credentials are not configured.');
    }
  }
  return getAuth();
};

const validateSignup = ({ username, email, password, phone, location, offeringType, acceptedTerms }) => {
  if (!String(username || '').trim()) return 'Please enter a username.';
  if (!emailPattern.test(normalizeEmail(email))) return 'Enter a valid email address.';
  if (!isStrongPassword(password)) return 'Use a password of at least 8 characters.';
  if (!String(phone || '').trim() || !String(location || '').trim()) return 'Phone number and location are required.';
  if (!['viewer', 'services', 'property', 'food', 'goods', 'shuttle'].includes(offeringType)) return 'Choose how you would like to use LoopOut.';
  if (acceptedTerms !== true) return 'You must accept the Terms of Service and Privacy Policy.';
  return null;
};

export const signup = async (req, res, next) => {
  try {
    const username = String(req.body.username || '').trim();
    const email = normalizeEmail(req.body.email);
    const validationError = validateSignup({ ...req.body, username, email });
    if (validationError) return next(errorHandler(400, validationError));

    const existingEmail = await User.findOne({ email });
    const existingUsername = await User.findOne({ username });
    if (existingEmail?.isVerified) return next(errorHandler(409, 'An account already exists for those details. Please sign in.'));
    if (existingUsername && (!existingEmail || String(existingUsername._id) !== String(existingEmail._id))) return next(errorHandler(409, 'That username is already taken.'));

    const updates = {
      username,
      email,
      password: await bcryptjs.hash(req.body.password, 12),
      phone: String(req.body.phone).trim(),
      location: String(req.body.location).trim(),
      offeringType: req.body.offeringType,
      accessContacts: false,
      contacts: [],
      isVerified: false,
      termsAcceptedAt: new Date(),
      privacyAcceptedAt: new Date(),
    };

    let user;
    if (existingEmail) {
      Object.assign(existingEmail, updates);
      user = existingEmail;
    } else {
      user = new User(updates);
    }

    const delivery = await sendVerificationCode(user, existingEmail ? 'Complete your LoopOut registration' : 'Your LoopOut verification code');
    const isDev = process.env.NODE_ENV !== 'production';
    if (!delivery.success) {
      if (isDev) {
        console.warn(`⚠️ [DEV MODE] Email delivery failed, but allowing signup with dev code for ${email}. OTP: ${delivery.otp}`);
        return res.status(existingEmail ? 200 : 201).json({
          success: true,
          requiresVerification: true,
          email,
          message: `Verification code generated (Dev mode: ${delivery.otp}).`,
          devCode: delivery.otp
        });
      }
      console.error(`Signup verification email to ${email} failed to send.`);
      return res.status(503).json({
        success: false,
        requiresVerification: true,
        email,
        message: "We couldn't send your verification email right now. Please try again shortly."
      });
    }

    return res.status(existingEmail ? 200 : 201).json({
      success: true,
      requiresVerification: true,
      email,
      message: `A verification code has been sent to ${email}.`,
      ...(isDev ? { devCode: delivery.otp } : {})
    });
  } catch (error) { return next(error); }
};

export const signin = async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = req.body.password;
    const user = emailPattern.test(email) ? await User.findOne({ email }) : null;
    const validPassword = user && await bcryptjs.compare(password || '', user.password);
    if (!validPassword) {
      if (user) {
        try {
          const account = await User.findById(user._id).select('+loginFailureCount +lastLoginAlertAt notificationPreferences');
          const failures = Number(account?.loginFailureCount || 0) + 1;
          const shouldAlert = failures >= 3 && (!account.lastLoginAlertAt || Date.now() - account.lastLoginAlertAt.getTime() > 60 * 60 * 1000)
            && account.notificationPreferences?.security?.loginAttempts !== false;
          await User.updateOne({ _id: user._id }, { $set: { loginFailureCount: failures, ...(shouldAlert ? { lastLoginAlertAt: new Date() } : {}) } });
          if (shouldAlert) {
            const message = 'We noticed several unsuccessful sign-in attempts on your LoopOut account. If this was not you, update your password.';
            await new Notification({ userId: user._id, type: 'security', title: 'Unsuccessful sign-in attempts', message }).save();
          }
        } catch (alertError) {
          console.warn('[signin] Could not record failed login alert:', alertError.message);
        }
      }
      return next(errorHandler(401, 'Invalid email or password.'));
    }
    if (user.accountStatus === 'suspended') {
      return res.status(403).json({ success: false, message: 'This account is suspended. Contact LoopOut support for help.' });
    }
    if (!user.isVerified) {
      const codeCreatedAt = user.otpExpiry ? user.otpExpiry.getTime() - OTP_TTL_MS : 0;
      if (user.otpPurpose !== 'verify' || Date.now() - codeCreatedAt >= OTP_RESEND_COOLDOWN_MS) await sendVerificationCode(user);
      return res.status(403).json({ success: false, requiresVerification: true, email, message: 'Verify your email before signing in.' });
    }
    if (user.twoFactorEnabled) return startTwoFactorLogin(user, res);
    return issueSession(res, user);
  } catch (error) { return next(error); }
};

export const google = async (req, res, next) => {
  try {
    const allowedOfferingTypes = ['viewer', 'services', 'property', 'food', 'goods', 'shuttle'];
    const requestedOfferingType = req.body.offeringType;
    if (requestedOfferingType && (!allowedOfferingTypes.includes(requestedOfferingType) || req.body.acceptedTerms !== true || !String(req.body.phone || '').trim() || !String(req.body.location || '').trim())) {
      return next(errorHandler(400, 'Choose an account type, provide your phone and area, and accept the Terms and Privacy Policy.'));
    }
    if (!req.body.idToken || typeof req.body.idToken !== 'string') return next(errorHandler(400, 'A Google identity token is required.'));
    let decoded;
    try {
      decoded = await (await firebaseAuth()).verifyIdToken(req.body.idToken, true);
    } catch (error) {
      console.warn('Firebase Admin verification failed, trying Google tokeninfo fallback:', error.message);
      try {
        const tokenRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(req.body.idToken)}`);
        if (tokenRes.ok) {
          const info = await tokenRes.json();
          if (info.email && (info.email_verified === 'true' || info.email_verified === true)) {
            decoded = {
              email: info.email,
              email_verified: true,
              name: info.name || info.email.split('@')[0],
              picture: info.picture,
            };
          }
        }
      } catch (fallbackError) {
        console.error('Google tokeninfo fallback error:', fallbackError.message);
      }

      if (!decoded) {
        if (error.message === 'Firebase Admin credentials are not configured.') {
          return next(errorHandler(503, 'Google sign-in is temporarily unavailable (Firebase service account not configured on server).'));
        }
        return next(errorHandler(401, 'Google sign-in could not be verified.'));
      }
    }
    const email = normalizeEmail(decoded.email);
    if (!email || !decoded.email_verified) return next(errorHandler(401, 'A verified Google email address is required.'));
    let user = await User.findOne({ email });
    if (user?.accountStatus === 'suspended') {
      return res.status(403).json({ success: false, message: 'This account is suspended. Contact LoopOut support for help.' });
    }
    if ((!user || !user.offeringType) && !requestedOfferingType) {
      return res.status(200).json({ success: true, requiresOfferingType: true, email });
    }
    if (!user) {
      const base = (decoded.name || email.split('@')[0]).replace(/[^a-zA-Z0-9_]/g, '').slice(0, 24) || 'member';
      const username = `${base}${crypto.randomBytes(3).toString('hex')}`;
      user = await User.create({
        username,
        email,
        password: await bcryptjs.hash(crypto.randomBytes(32).toString('hex'), 12),
        authProviders: ['google'],
        firebaseUid: decoded.uid || '',
        avatar: decoded.picture || undefined,
        phone: String(req.body.phone || '').trim(),
        location: String(req.body.location || '').trim(),
        offeringType: requestedOfferingType || 'viewer',
        ...(req.body.acceptedTerms === true ? { termsAcceptedAt: new Date(), privacyAcceptedAt: new Date() } : {}),
        isVerified: true
      });
    } else {
      let needsSave = false;
      if (!user.authProviders?.includes('google')) {
        user.authProviders = [...(user.authProviders || []), 'google'];
        needsSave = true;
      }
      if (decoded.uid && user.firebaseUid !== decoded.uid) {
        user.firebaseUid = decoded.uid;
        needsSave = true;
      }
      if (requestedOfferingType && !user.offeringType) {
        user.offeringType = requestedOfferingType;
        if (req.body.phone) user.phone = String(req.body.phone).trim();
        if (req.body.location) user.location = String(req.body.location).trim();
        user.termsAcceptedAt = new Date();
        user.privacyAcceptedAt = new Date();
        needsSave = true;
      }
      if (!user.isVerified) {
        user.isVerified = true;
        needsSave = true;
      }
      if (!user.avatar && decoded.picture) {
        user.avatar = decoded.picture;
        needsSave = true;
      }
      if (needsSave) {
        await user.save();
      }
    }
    if (user.twoFactorEnabled) return startTwoFactorLogin(user, res);
    return issueSession(res, user);
  } catch (error) { return next(error); }
};

export const verifyTwoFactorLogin = async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const otp = String(req.body.otp || '').trim();
    if (!emailPattern.test(email) || !/^\d{6}$/.test(otp)) return next(errorHandler(400, 'Enter the six-digit code sent to your email.'));

    const user = await User.findOne({ email });
    const challengeIsValid = user?.twoFactorEnabled && user.otpPurpose === 'two-factor-login' && user.otp && user.otpExpiry && Date.now() <= user.otpExpiry.getTime();
    if (!challengeIsValid) return next(errorHandler(400, 'That sign-in code is invalid or has expired. Start sign-in again to request a new code.'));
    if ((user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) return next(errorHandler(429, 'Too many incorrect codes. Start sign-in again later.'));
    if (hashOtp(otp) !== user.otp) {
      user.otpAttempts = (user.otpAttempts || 0) + 1;
      await user.save();
      return next(errorHandler(400, 'That sign-in code is invalid or has expired.'));
    }

    clearOtp(user);
    await user.save();
    return issueSession(res, user);
  } catch (error) { return next(error); }
};

export const beginTwoFactorSetup = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return next(errorHandler(404, 'User not found.'));
    if (user.twoFactorEnabled) return next(errorHandler(409, 'Two-factor sign-in is already enabled.'));

    const now = Date.now();
    const pendingCodeIsValid = user.otpPurpose === 'two-factor-setup' && user.otp && user.otpExpiry && now <= user.otpExpiry.getTime();
    if (pendingCodeIsValid && (user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) return next(errorHandler(429, 'Too many incorrect codes. Wait for this setup code to expire and try again.'));
    const sentAt = user.otpExpiry ? user.otpExpiry.getTime() - OTP_TTL_MS : 0;
    if (pendingCodeIsValid && now - sentAt < OTP_RESEND_COOLDOWN_MS) {
      return res.json({ success: true, requiresCode: true, email: user.email, message: 'A setup code was sent recently. Check your email.' });
    }

    const delivery = await sendTwoFactorCode(user, 'two-factor-setup');
    if (!delivery.success && process.env.NODE_ENV === 'production') {
      clearOtp(user);
      await user.save();
      return next(errorHandler(503, 'We could not send your setup code. Please try again shortly.'));
    }
    return res.json({
      success: true,
      requiresCode: true,
      email: user.email,
      message: 'Enter the one-time code sent to your email to finish enabling two-factor sign-in.',
      ...(!delivery.success && process.env.NODE_ENV !== 'production' ? { devCode: delivery.otp } : {}),
    });
  } catch (error) { return next(error); }
};

export const confirmTwoFactorSetup = async (req, res, next) => {
  try {
    const otp = String(req.body.otp || '').trim();
    if (!/^\d{6}$/.test(otp)) return next(errorHandler(400, 'Enter the six-digit code sent to your email.'));
    const user = await User.findById(req.user.id);
    const challengeIsValid = user && !user.twoFactorEnabled && user.otpPurpose === 'two-factor-setup' && user.otp && user.otpExpiry && Date.now() <= user.otpExpiry.getTime();
    if (!challengeIsValid) return next(errorHandler(400, 'That setup code is invalid or has expired. Request a new code.'));
    if ((user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) return next(errorHandler(429, 'Too many incorrect codes. Request a new setup code later.'));
    if (hashOtp(otp) !== user.otp) {
      user.otpAttempts = (user.otpAttempts || 0) + 1;
      await user.save();
      return next(errorHandler(400, 'That setup code is invalid or has expired.'));
    }

    user.twoFactorEnabled = true;
    clearOtp(user);
    await user.save();
    return res.json({ success: true, user: safeUserPayload(user), message: 'Two-factor sign-in is now enabled.' });
  } catch (error) { return next(error); }
};

export const disableTwoFactor = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return next(errorHandler(404, 'User not found.'));
    if (!user.twoFactorEnabled) return next(errorHandler(409, 'Two-factor sign-in is not enabled.'));

    const now = Date.now();
    const challengeIsValid = user.otpPurpose === 'two-factor-disable' && user.otp && user.otpExpiry && now <= user.otpExpiry.getTime();
    if (challengeIsValid && (user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) return next(errorHandler(429, 'Too many incorrect codes. Wait for this code to expire and try again.'));
    const sentAt = user.otpExpiry ? user.otpExpiry.getTime() - OTP_TTL_MS : 0;
    if (challengeIsValid && now - sentAt < OTP_RESEND_COOLDOWN_MS) {
      return res.json({ success: true, requiresCode: true, email: user.email, message: 'A confirmation code was sent recently. Check your email.' });
    }

    const delivery = await sendTwoFactorCode(user, 'two-factor-disable');
    if (!delivery.success && process.env.NODE_ENV === 'production') {
      clearOtp(user);
      await user.save();
      return next(errorHandler(503, 'We could not send your confirmation code. Please try again shortly.'));
    }
    return res.json({
      success: true,
      requiresCode: true,
      email: user.email,
      message: 'Enter the one-time code sent to your email to turn off two-factor sign-in.',
      ...(!delivery.success && process.env.NODE_ENV !== 'production' ? { devCode: delivery.otp } : {}),
    });
  } catch (error) { return next(error); }
};

export const confirmTwoFactorDisable = async (req, res, next) => {
  try {
    const otp = String(req.body.otp || '').trim();
    if (!/^\d{6}$/.test(otp)) return next(errorHandler(400, 'Enter the six-digit code sent to your email.'));
    const user = await User.findById(req.user.id);
    const challengeIsValid = user?.twoFactorEnabled && user.otpPurpose === 'two-factor-disable' && user.otp && user.otpExpiry && Date.now() <= user.otpExpiry.getTime();
    if (!challengeIsValid) return next(errorHandler(400, 'That confirmation code is invalid or has expired. Request a new code.'));
    if ((user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) return next(errorHandler(429, 'Too many incorrect codes. Request a new confirmation code later.'));
    if (hashOtp(otp) !== user.otp) {
      user.otpAttempts = (user.otpAttempts || 0) + 1;
      await user.save();
      return next(errorHandler(400, 'That confirmation code is invalid or has expired.'));
    }
    user.twoFactorEnabled = false;
    clearOtp(user);
    await user.save();
    return res.json({ success: true, user: safeUserPayload(user), message: 'Two-factor sign-in has been disabled.' });
  } catch (error) { return next(error); }
};

export const signOut = async (req, res) => {
  res.clearCookie('access_token', { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/' });
  return res.status(200).json({ success: true, message: 'Signed out successfully' });
};

export const validateToken = async (req, res, next) => {
  try {
    const candidateTokens = [];
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
      const headerToken = req.headers.authorization.split(' ')[1];
      if (headerToken && headerToken !== 'null' && headerToken !== 'undefined') {
        candidateTokens.push(headerToken);
      }
    }
    if (req.cookies && req.cookies.access_token) {
      const cookieToken = req.cookies.access_token;
      if (cookieToken && cookieToken !== 'null' && cookieToken !== 'undefined') {
        candidateTokens.push(cookieToken);
      }
    }

    let decoded = null;
    let validToken = null;

    for (const cand of candidateTokens) {
      try {
        decoded = jwt.verify(cand, process.env.JWT_SECRET);
        validToken = cand;
        break;
      } catch (err) {
        // Try next candidate token
      }
    }

    if (!decoded || !validToken) return res.status(200).json({ valid: false });

    const user = await User.findById(decoded.id).select('-password -otp -otpExpiry -otpAttempts -otpPurpose');
    if (!user || user.isVerified === false) return res.status(200).json({ valid: false });

    const refreshedToken = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: SESSION_EXPIRES_IN });
    try {
      await User.findByIdAndUpdate(user._id, { $set: { lastLogin: new Date(), lastLoginRecorded: true } });
    } catch (err) {}
    const safeUser = safeUserPayload(user);
    return res.cookie('access_token', refreshedToken, cookieOptions()).status(200).json({
      valid: true,
      user: safeUser,
      token: refreshedToken,
      access_token: refreshedToken
    });
  } catch (error) {
    return res.status(200).json({ valid: false });
  }
};

export const verifyOtp = async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const otp = String(req.body.otp || '').trim();
    if (!emailPattern.test(email) || !/^\d{6}$/.test(otp)) return next(errorHandler(400, 'Enter your email and the six-digit verification code.'));
    const user = await User.findOne({ email });
    if (!user || user.isVerified || user.otpPurpose !== 'verify') return next(errorHandler(400, 'That verification code is invalid or has expired.'));
    if (!user.otp || !user.otpExpiry || Date.now() > user.otpExpiry.getTime()) return next(errorHandler(400, 'That verification code is invalid or has expired.'));
    if ((user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) return next(errorHandler(429, 'Too many incorrect codes. Request a new code and try again.'));
    if (hashOtp(otp) !== user.otp) { user.otpAttempts = (user.otpAttempts || 0) + 1; await user.save(); return next(errorHandler(400, 'That verification code is invalid or has expired.')); }
    user.isVerified = true; user.otp = undefined; user.otpExpiry = undefined; user.otpAttempts = 0; user.otpPurpose = undefined; await user.save();
    return issueSession(res, user);
  } catch (error) { return next(error); }
};

export const requestPasswordReset = async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const user = emailPattern.test(email) ? await User.findOne({ email }) : null;
    if (user?.isVerified) {
      const createdAt = user.otpExpiry ? user.otpExpiry.getTime() - OTP_TTL_MS : 0;
      if (user.otpPurpose !== 'reset' || Date.now() - createdAt >= OTP_RESEND_COOLDOWN_MS) await sendVerificationCode(user, 'Your LoopOut password reset code', 'reset');
    }
    return res.status(200).json({ success: true, message: 'If an account matches that email, a reset code has been sent.' });
  } catch (error) { return next(error); }
};

export const resetPassword = async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const otp = String(req.body.otp || '').trim();
    const password = req.body.password;
    if (!emailPattern.test(email) || !/^\d{6}$/.test(otp) || !isStrongPassword(password)) return next(errorHandler(400, 'Enter a valid email, six-digit code, and a password of at least 8 characters.'));
    const user = await User.findOne({ email });
    if (!user || user.otpPurpose !== 'reset' || !user.otp || !user.otpExpiry || Date.now() > user.otpExpiry.getTime() || (user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS || hashOtp(otp) !== user.otp) {
      if (user?.otp && user.otpPurpose === 'reset') { user.otpAttempts = (user.otpAttempts || 0) + 1; await user.save(); }
      return next(errorHandler(400, 'That reset code is invalid or has expired.'));
    }
    user.password = await bcryptjs.hash(password, 12); user.otp = undefined; user.otpExpiry = undefined; user.otpAttempts = 0; user.otpPurpose = undefined; await user.save();
    return res.status(200).json({ success: true, message: 'Your password has been reset. Please sign in.' });
  } catch (error) { return next(error); }
};

export const resendOtp = async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const user = emailPattern.test(email) ? await User.findOne({ email }) : null;
    if (!user || user.isVerified) return res.status(200).json({ success: true, message: 'If an unverified account exists, a code has been sent.' });
    const createdAt = user.otpExpiry ? user.otpExpiry.getTime() - OTP_TTL_MS : 0;
    if (Date.now() - createdAt < OTP_RESEND_COOLDOWN_MS) return next(errorHandler(429, 'Please wait a minute before requesting another code.'));
    const delivery = await sendVerificationCode(user, 'Your new LoopOut verification code');
    const isDev = process.env.NODE_ENV !== 'production';
    if (!delivery.success) {
      if (isDev) {
        console.warn(`⚠️ [DEV MODE] Resend email failed, but providing dev code for ${email}. OTP: ${delivery.otp}`);
        return res.status(200).json({
          success: true,
          message: 'If an unverified account exists, a code has been sent.',
          devCode: delivery.otp
        });
      }
      console.error(`Resend verification email to ${email} failed to send.`);
      return res.status(503).json({ success: false, message: "We couldn't send your verification email right now. Please try again shortly." });
    }
    return res.status(200).json({ success: true, message: 'If an unverified account exists, a code has been sent.', ...(isDev ? { devCode: delivery.otp } : {}) });
  } catch (error) { return next(error); }
};
