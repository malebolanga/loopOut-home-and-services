import User from '../models/user.model.js';

export const requireOfferingType = (...allowedTypes) => async (req, res, next) => {
  try {
    const user = await User.findById(req.user?.id).select('offeringType isAdmin role idDocumentUrl liveSelfieUrl faceData avatar isVerified kycStatus');
    if (!user) return res.status(401).json({ success: false, message: 'Please sign in to continue.' });

    // Admins bypass offering type restrictions
    if (user.isAdmin === true || user.role === 'admin') return next();

    // Food shop operations strictly require the 'food' offering type selected on sign-up
    if (allowedTypes.includes('food')) {
      if (user.offeringType !== 'food') {
        return res.status(403).json({
          success: false,
          message: 'Only accounts registered as a food shop owner on sign-up can register or manage a shop. Other accounts can only view and order.'
        });
      }
      return next();
    }

    // Accounts created before offering roles were added keep their existing access.
    if (!user.offeringType) return next();
    if (user.offeringType === 'viewer' || !allowedTypes.includes(user.offeringType)) {
      return res.status(403).json({ success: false, message: 'Your account is set up for browsing, booking, and requests. Choose a matching provider account to publish.' });
    }

    // Service providers & helpers must have submitted documents, completed face scan, and uploaded a profile picture
    if (allowedTypes.includes('services') || user.offeringType === 'services') {
      const hasIdDocument = Boolean(user.idDocumentUrl && user.idDocumentUrl.trim() !== '');
      const hasFaceScan = Boolean(
        (user.liveSelfieUrl && user.liveSelfieUrl.trim() !== '') ||
        (user.faceData?.imageUrl && user.faceData.imageUrl.trim() !== '')
      );
      const isDefaultAvatar = !user.avatar || user.avatar.includes('blank-profile-picture') || user.avatar.trim() === '';
      const hasProfilePicture = !isDefaultAvatar;
      const isIdentityReviewed = user.kycStatus === 'verified';

      if (!hasIdDocument || !hasFaceScan || !hasProfilePicture || !isIdentityReviewed) {
        const missing = [];
        if (!hasIdDocument) missing.push('ID document or passport');
        if (!hasFaceScan) missing.push('face scan (live selfie)');
        if (!hasProfilePicture) missing.push('profile picture');
        if (!isIdentityReviewed) missing.push(user.kycStatus === 'rejected' ? 'resubmitted identity documents' : 'administrator identity review');

        return res.status(403).json({
          success: false,
          requiresVerification: true,
          message: `As a service provider or helper, your ID number and document photo must be reviewed against your live selfie before posting. Please complete: ${missing.join(', ')}.`,
          missing: {
            idDocument: !hasIdDocument,
            faceScan: !hasFaceScan,
            profilePicture: !hasProfilePicture,
          }
        });
      }
    }

    return next();
  } catch (error) {
    return next(error);
  }
};

export const requireProviderAccount = async (req, res, next) => {
  try {
    const user = await User.findById(req.user?.id).select('offeringType');
    if (!user) return res.status(401).json({ success: false, message: 'Please sign in to continue.' });
    if (user.offeringType === 'viewer') return res.status(403).json({ success: false, message: 'Browsing accounts cannot publish listings.' });
    return next();
  } catch (error) {
    return next(error);
  }
};
