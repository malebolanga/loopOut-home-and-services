import express from 'express';
import mongoose from 'mongoose';
import { verifyToken } from '../utils/verifyUser.js';
import Notification from '../models/notification.model.js';

const router = express.Router();

// Get all notifications for current user
router.get('/', verifyToken, async(req, res) => {
    try {
        if (!req.user || !req.user.id) {
            console.error('[NOTIF] Error: req.user.id is missing');
            return res.status(401).json({ success: false, message: 'Unauthorized: No user ID in token' });
        }

        const userId = req.user.id;

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            console.error('[NOTIF] Error: Invalid ObjectId:', userId);
            return res.status(400).json({ success: false, message: 'Invalid user ID format' });
        }

        const rawLimit = Number.parseInt(req.query.limit, 10);
        const rawOffset = Number.parseInt(req.query.offset, 10);
        const limit = Number.isFinite(rawLimit) ? Math.min(Math.max(rawLimit, 1), 50) : 20;
        const offset = Number.isFinite(rawOffset) ? Math.max(rawOffset, 0) : 0;
        const [notifications, unreadCount, totalCount] = await Promise.all([
            Notification.find({ userId }).sort({ createdAt: -1, _id: -1 }).skip(offset).limit(limit).lean(),
            Notification.countDocuments({ userId, read: false }),
            Notification.countDocuments({ userId })
        ]);

        return res.json({
            notifications,
            unreadCount,
            totalCount,
            hasMore: offset + notifications.length < totalCount,
            nextOffset: offset + notifications.length
        });
    } catch (error) {
        console.error('[NOTIF] CRITICAL SERVER ERROR:', error.message);
        return res.status(500).json({ 
            success: false,
            message: 'Notification service error',
            error: error.message
        });
    }
});


// Mark notifications as read
router.post('/read', verifyToken, async(req, res) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ success: false, message: 'Unauthorized' });
        }

        const { notificationId } = req.body;
        const userId = req.user.id;

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ success: false, message: 'Invalid user ID format' });
        }

        if (notificationId && !mongoose.Types.ObjectId.isValid(notificationId)) {
            return res.status(400).json({ success: false, message: 'Invalid notification ID format' });
        }

        if (notificationId) {
            await Notification.findOneAndUpdate({ _id: notificationId, userId }, { read: true });
        } else {
            await Notification.updateMany({ userId, read: false }, { read: true });
        }

        res.json({ success: true });
    } catch (error) {
        console.error('[NOTIF] Mark Read Error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Failed to update notifications',
            error: error.message 
        });
    }
});

// Mark all notifications as read (RESTful PUT /read-all)
router.put('/read-all', verifyToken, async(req, res) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ success: false, message: 'Unauthorized' });
        }

        const userId = req.user.id;

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ success: false, message: 'Invalid user ID format' });
        }
        await Notification.updateMany({ userId, read: false }, { read: true });

        res.json({ success: true });
    } catch (error) {
        console.error('[NOTIF] Mark All Read Error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Failed to mark all notifications as read',
            error: error.message 
        });
    }
});

// Mark a single notification as read (RESTful PUT /:id/read)
router.put('/:id/read', verifyToken, async(req, res) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ success: false, message: 'Unauthorized' });
        }

        const userId = req.user.id;
        const notificationId = req.params.id;

        if (!mongoose.Types.ObjectId.isValid(userId) || !mongoose.Types.ObjectId.isValid(notificationId)) {
            return res.status(400).json({ success: false, message: 'Invalid ID format' });
        }

        const notification = await Notification.findOneAndUpdate(
            { _id: notificationId, userId },
            { read: true },
            { new: true }
        );

        if (!notification) {
            return res.status(404).json({ success: false, message: 'Notification not found' });
        }

        res.json({ success: true, notification });
    } catch (error) {
        console.error('[NOTIF] Mark Single Read Error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Failed to mark notification as read',
            error: error.message 
        });
    }
});

// Clear all notifications (RESTful DELETE /clear-all)
router.delete('/clear-all', verifyToken, async(req, res) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ success: false, message: 'Unauthorized' });
        }

        const userId = req.user.id;

        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ success: false, message: 'Invalid user ID format' });
        }
        await Notification.deleteMany({ userId });

        res.json({ success: true, message: 'All notifications cleared successfully' });
    } catch (error) {
        console.error('[NOTIF] Clear All Error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Failed to clear notifications',
            error: error.message 
        });
    }
});

// Delete a notification (RESTful DELETE /:id)
router.delete('/:id', verifyToken, async(req, res) => {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ success: false, message: 'Unauthorized' });
        }

        const userId = req.user.id;
        const notificationId = req.params.id;

        if (!mongoose.Types.ObjectId.isValid(userId) || !mongoose.Types.ObjectId.isValid(notificationId)) {
            return res.status(400).json({ success: false, message: 'Invalid ID format' });
        }

        const notification = await Notification.findOneAndDelete({ _id: notificationId, userId });

        if (!notification) {
            return res.status(404).json({ success: false, message: 'Notification not found' });
        }

        res.json({ success: true, message: 'Notification deleted successfully' });
    } catch (error) {
        console.error('[NOTIF] Delete Error:', error);
        res.status(500).json({ 
            success: false,
            message: 'Failed to delete notification',
            error: error.message 
        });
    }
});

export default router;
