import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Bell, X, CheckCircle2, AlertCircle, MessageSquare, Calendar, Sparkles, ChevronRight, ShieldCheck } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { authenticatedFetch } from '../utils/authenticatedFetch';

// Global helper function to trigger a top phone notification from anywhere in the app
export const pushPhoneNotification = (notificationData) => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('trigger_top_notification', { detail: notificationData }));
  }
};

const PhoneNotificationManager = () => {
  const navigate = useNavigate();
  const currentUser = useSelector((state) => state.user?.currentUser);
  const isNativeAndroid = Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  const [activeNotification, setActiveNotification] = useState(null);
  const activeNotificationRef = useRef(null);
  const notificationQueueRef = useRef([]);
  const [permissionState, setPermissionState] = useState(
    isNativeAndroid ? 'prompt' : (typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'denied')
  );
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);
  const audioRef = useRef(null);
  const hasUserActivatedRef = useRef(false);
  const [hasUserInteracted, setHasUserInteracted] = useState(false);
  const nativeListenersInstalledRef = useRef(false);
  const nativeListenersReadyRef = useRef(Promise.resolve());
  const lastRegisteredTokenRef = useRef('');
  const recentNotificationIdsRef = useRef(new Set());
  const [nativePushToken, setNativePushToken] = useState(() => (
    typeof window !== 'undefined' ? localStorage.getItem('loopout_fcm_token') || '' : ''
  ));

  const enqueuePhoneNotification = (notification) => {
    if (activeNotificationRef.current) {
      notificationQueueRef.current.push(notification);
      return;
    }
    activeNotificationRef.current = notification;
    setActiveNotification(notification);
  };

  const showNextPhoneNotification = () => {
    const next = notificationQueueRef.current.shift() || null;
    activeNotificationRef.current = next;
    setActiveNotification(next);
  };

  // Browsers only permit haptics after the page has received a user gesture.
  // Keep this state locally so background notifications never trigger a console
  // intervention warning before the user has interacted with the app.
  useEffect(() => {
    const markUserActivated = () => {
      hasUserActivatedRef.current = true;
      setHasUserInteracted(true);
    };

    window.addEventListener('pointerdown', markUserActivated, { once: true });
    window.addEventListener('keydown', markUserActivated, { once: true });

    return () => {
      window.removeEventListener('pointerdown', markUserActivated);
      window.removeEventListener('keydown', markUserActivated);
    };
  }, []);

  // Check native notification permission and show an in-app prompt when needed.
  useEffect(() => {
    if (isNativeAndroid) {
      let active = true;
      PushNotifications.checkPermissions()
        .then(async ({ receive }) => {
          if (!active) return;
          setPermissionState(receive);
          if (receive === 'granted') {
            try {
              await nativeListenersReadyRef.current;
              await PushNotifications.createChannel({
                id: 'loopout_updates',
                name: 'LoopOut updates',
                description: 'Booking, message, follower, and order alerts',
                importance: 5,
                visibility: 1,
                vibration: true,
              });
              await PushNotifications.register();
            } catch (error) {
              console.warn('Could not register this phone for LoopOut alerts:', error);
            }
          }
        })
        .catch((error) => console.warn('Could not check Android notification permission:', error));
      return () => {
        active = false;
      };
    }

    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermissionState(Notification.permission);
    }
  }, [isNativeAndroid]);

  // Ask only after the user has interacted with the app, and remember the
  // choice across visits so the prompt does not keep returning.
  useEffect(() => {
    if (!hasUserInteracted) return;
    if (isNativeAndroid) {
      PushNotifications.checkPermissions().then(({ receive }) => {
        setPermissionState(receive);
        if (receive === 'denied') {
          setShowPermissionPrompt(true);
        } else if (localStorage.getItem('phone_notif_prompted') !== 'true' && (receive === 'prompt' || receive === 'prompt-with-rationale')) {
          setShowPermissionPrompt(true);
        }
      }).catch(() => {});
      return;
    }
    if (localStorage.getItem('phone_notif_prompted') === 'true') return;
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      setShowPermissionPrompt(true);
    }
  }, [hasUserInteracted, isNativeAndroid]);

  // Install Capacitor listeners before the user grants permission and registers with FCM.
  useEffect(() => {
    if (!isNativeAndroid || nativeListenersInstalledRef.current) return undefined;
    const handles = [];
    nativeListenersInstalledRef.current = true;

    const installListeners = async () => {
      try {
        handles.push(await PushNotifications.addListener('registration', ({ value }) => {
          if (value) {
            localStorage.setItem('loopout_fcm_token', value);
            setNativePushToken(value);
          }
        }));
        handles.push(await PushNotifications.addListener('registrationError', ({ error }) => {
          console.warn('Android push registration failed:', error);
        }));
        handles.push(await PushNotifications.addListener('pushNotificationReceived', (notification) => {
          pushPhoneNotification({
            title: notification.title || 'LoopOut update',
            message: notification.body || 'You have a new LoopOut update.',
            type: notification.data?.type || 'info',
            notificationId: notification.data?.notificationId,
            link: notification.data?.route || notification.data?.link || '/notifications',
          });
        }));
        handles.push(await PushNotifications.addListener('pushNotificationActionPerformed', ({ notification }) => {
          const link = notification.data?.route || notification.data?.link;
          navigate(typeof link === 'string' && link.startsWith('/') ? link : '/notifications');
        }));
      } catch (error) {
        console.warn('Could not initialize Android push listeners:', error);
      }
    };

    nativeListenersReadyRef.current = installListeners();
    return () => {
      nativeListenersInstalledRef.current = false;
      handles.forEach((handle) => handle.remove());
    };
  }, [isNativeAndroid, navigate]);

  // Attach this installation's FCM token to the signed-in account. The API moves
  // a token off any other account so a shared phone cannot leak alerts between users.
  useEffect(() => {
    const userId = currentUser?._id || currentUser?.id;
    if (!userId) lastRegisteredTokenRef.current = '';
    if (!isNativeAndroid || !userId || !nativePushToken) return undefined;

    const registrationKey = `${userId}:${nativePushToken}`;
    if (lastRegisteredTokenRef.current === registrationKey) return undefined;
    let cancelled = false;
    let retryTimer;
    let attempts = 0;

    const registerToken = async () => {
      try {
        const response = await authenticatedFetch('/api/user/push-token', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: nativePushToken, platform: 'android' }),
        });
        if (!response.ok) throw new Error(`Push-token registration failed (${response.status}).`);
        if (!cancelled) lastRegisteredTokenRef.current = registrationKey;
      } catch (error) {
        attempts += 1;
        if (attempts < 3 && !cancelled) retryTimer = setTimeout(registerToken, 2000 * attempts);
        else if (!cancelled) console.warn('Could not register this phone for LoopOut alerts:', error.message);
      }
    };

    registerToken();
    return () => {
      cancelled = true;
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [currentUser?._id, currentUser?.id, isNativeAndroid, nativePushToken]);

  const requestPhonePermission = async () => {
    if (isNativeAndroid) {
      try {
        await nativeListenersReadyRef.current;
        const permission = await PushNotifications.requestPermissions();
        setPermissionState(permission.receive);
        setShowPermissionPrompt(permission.receive === 'denied');
        localStorage.setItem('phone_notif_prompted', 'true');

        if (permission.receive !== 'granted') return;

        await PushNotifications.createChannel({
          id: 'loopout_updates',
          name: 'LoopOut updates',
          description: 'Booking, message, follower, and order alerts',
          importance: 5,
          visibility: 1,
          vibration: true,
        });
        await PushNotifications.register();
        pushPhoneNotification({
          title: '🔔 Phone notifications enabled',
          message: 'Notifications are enabled for LoopOut on this phone.',
          type: 'success',
        });
      } catch (err) {
        console.error('Android push permission or registration failed:', err);
        setShowPermissionPrompt(false);
      }
      return;
    }

    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const permission = await Notification.requestPermission();
        setPermissionState(permission);
        setShowPermissionPrompt(false);
        localStorage.setItem('phone_notif_prompted', 'true');
        
        if (permission === 'granted') {
          pushPhoneNotification({
            title: '🔔 Phone Notifications Enabled!',
            message: 'You will now receive instant push alerts on your phone screen.',
            type: 'success'
          });
        }
      } catch (err) {
        console.error('Permission request failed', err);
      }
    }
  };

  const dismissPermissionPrompt = () => {
    setShowPermissionPrompt(false);
    localStorage.setItem('phone_notif_prompted', 'true');
  };

  // Event listener for in-app top notification triggers
  useEffect(() => {
    const handleTrigger = (event) => {
      const detail = event.detail || {};
      const notificationId = detail.notificationId || detail.id;
      if (notificationId && recentNotificationIdsRef.current.has(String(notificationId))) return;
      if (notificationId) {
        const id = String(notificationId);
        recentNotificationIdsRef.current.add(id);
        window.setTimeout(() => recentNotificationIdsRef.current.delete(id), 60_000);
      }
      const newNotif = {
        id: Date.now(),
        notificationId: notificationId ? String(notificationId) : undefined,
        title: detail.title || 'loopOut Alert',
        message: detail.message || 'New notification received.',
        type: detail.type || 'info',
        link: detail.link || null,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      enqueuePhoneNotification(newNotif);

      // Play subtle vibration if supported
      if (hasUserActivatedRef.current && typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([80, 40, 80]);
      }

      // Also trigger native browser notification if granted
      if (!isNativeAndroid && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        try {
          new window.Notification(newNotif.title, {
            body: newNotif.message,
            icon: '/apple-touch-icon.png'
          });
        } catch (e) {
          console.warn('Native notification failed', e);
        }
      }
    };

    window.addEventListener('trigger_top_notification', handleTrigger);
    return () => window.removeEventListener('trigger_top_notification', handleTrigger);
  }, []);

  // Auto-dismiss top banner after 5 seconds
  useEffect(() => {
    if (activeNotification) {
      const timer = setTimeout(showNextPhoneNotification, 5500);
      return () => clearTimeout(timer);
    }
  }, [activeNotification]);

  const handleNotificationClick = () => {
    if (activeNotificationRef.current?.link) {
      navigate(activeNotificationRef.current.link);
    } else {
      navigate('/notifications');
    }
    showNextPhoneNotification();
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'success':
      case 'booking':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
      case 'message':
        return <MessageSquare className="w-5 h-5 text-sky-400" />;
      case 'event':
        return <Calendar className="w-5 h-5 text-amber-400" />;
      case 'warning':
      case 'alert':
        return <AlertCircle className="w-5 h-5 text-rose-400" />;
      default:
        return <Bell className="w-5 h-5 text-[#FF5A5F]" />;
    }
  };

  return (
    <>
      {/* 1. TOP PHONE NOTIFICATION BANNER (iOS/Android Dynamic Push Bar Style) */}
      <AnimatePresence>
        {activeNotification && (
          <motion.div
            initial={{ y: -80, opacity: 0, scale: 0.9 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -80, opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="fixed top-3 inset-x-3 sm:left-auto sm:right-4 sm:w-96 z-[9999] cursor-pointer touch-target select-none"
            onClick={handleNotificationClick}
          >
            <div className="bg-gray-950/90 backdrop-blur-2xl text-white rounded-3xl p-3.5 shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/15 flex items-start gap-3">
              {/* App logo stays transparent against the notification surface. */}
              <div className="relative mt-0.5 shrink-0">
                <img src="/apple-touch-icon.png" alt="LoopOut" className="h-10 w-10 rounded-2xl object-contain" />
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-gray-950" />
              </div>

              {/* Message Details */}
              <div className="flex-1 min-w-0 pr-1">
                <div className="flex items-center justify-between gap-1 mb-0.5">
                  <span className="text-[10px] font-black tracking-wider uppercase text-slate-400 flex items-center gap-1">
                    <span>loopOut</span>
                    <span>•</span>
                    <span>{activeNotification.timestamp}</span>
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                </div>
                <h4 className="text-xs font-black text-white truncate leading-snug">
                  {activeNotification.title}
                </h4>
                <p className="text-[11px] font-medium text-slate-300 line-clamp-2 leading-tight mt-0.5">
                  {activeNotification.message}
                </p>
              </div>

              {/* Dismiss Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  showNextPhoneNotification();
                }}
                aria-label="Dismiss notification"
                className="p-1.5 text-slate-400 hover:text-white rounded-full active:scale-90 transition-transform"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. SYNC PHONE NOTIFICATIONS PROMPT BANNER */}
      <AnimatePresence>
        {showPermissionPrompt && ['default', 'prompt', 'prompt-with-rationale', 'denied'].includes(permissionState) && (
          <motion.div
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -50, opacity: 0 }}
            className="fixed top-2 inset-x-3 sm:left-auto sm:right-4 sm:w-96 z-[9998]"
          >
            <div className="bg-slate-900/95 backdrop-blur-2xl border border-rose-500/30 text-white rounded-3xl p-4 shadow-2xl flex flex-col gap-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-rose-500/20 text-[#FF5A5F] rounded-2xl border border-rose-500/30">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xs font-black uppercase tracking-wider text-white">Enable Phone Alerts</h3>
                    <p className="text-[11px] text-slate-300 font-medium">Allow alerts so LoopOut can notify you about food orders, bookings, and messages.</p>
                  </div>
                </div>
                <button
                  onClick={dismissPermissionPrompt}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-2 pt-1">
                {permissionState === 'denied' ? (
                  <p className="flex-1 text-[11px] leading-relaxed text-amber-200">
                    Notifications are blocked. Turn them on in Android Settings → Apps → LoopOut → Notifications.
                  </p>
                ) : (
                  <button
                    onClick={requestPhonePermission}
                    className="flex-1 py-2.5 bg-gradient-to-r from-[#FF5A5F] to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white text-xs font-black uppercase tracking-wider rounded-2xl shadow-md active:scale-95 transition-all text-center"
                  >
                    Allow Phone Alerts
                  </button>
                )}
                <button
                  onClick={dismissPermissionPrompt}
                  className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold uppercase tracking-wider rounded-2xl active:scale-95 transition-all"
                >
                  Later
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default PhoneNotificationManager;
