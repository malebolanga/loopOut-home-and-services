// src/components/Header.jsx
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { useEffect, useState, useRef, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import BrandLogo, { BrandIcon } from './BrandLogo';
import ImageWithFallback from './ImageWithFallback';
import { motion, AnimatePresence } from 'framer-motion';
import { authenticatedFetch, authenticatedFetchWithRetry, clearPersistedSessionToken } from '../utils/authenticatedFetch';

import { pushPhoneNotification } from './PhoneNotificationManager';
import { canCreateListings, getCreationRoute } from '../utils/offeringPermissions';

import {
  MagnifyingGlassIcon,
  HeartIcon,
  GlobeAltIcon,
  BellIcon,
  UserCircleIcon,
  Bars3Icon,
  ChatBubbleLeftRightIcon,
  Squares2X2Icon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronDownIcon,
  CheckIcon,
  CheckBadgeIcon,
  QueueListIcon,
  UserIcon,
  HomeIcon,
  Cog6ToothIcon,
  ArrowRightOnRectangleIcon,
  QuestionMarkCircleIcon,
  ChartPieIcon,
  MapPinIcon,
  UserGroupIcon,
  BriefcaseIcon,
  XMarkIcon,
  BuildingOfficeIcon,
  HomeModernIcon,
  ShieldCheckIcon,
  ChartBarIcon,
  CpuChipIcon,
  InboxIcon,
  MapIcon,
  ArrowRightIcon,
  ArrowLongRightIcon,
  MicrophoneIcon,
  PlusIcon,
  BoltIcon,
  FireIcon,
  CalendarIcon,
  CalendarDaysIcon
} from '@heroicons/react/24/outline';

import {
  MagnifyingGlassIcon as MagnifyingGlassIconSolid,
  HeartIcon as HeartIconSolid,
  BellIcon as BellIconSolid,
  UserCircleIcon as UserCircleIconSolid,
  ChatBubbleLeftRightIcon as ChatBubbleLeftRightIconSolid,
  Squares2X2Icon as Squares2X2IconSolid,
  ChartBarIcon as ChartBarIconSolid,
} from '@heroicons/react/24/solid';

import {
  generateSuggestions,
  extractFiltersFromQuery,
  saveSearchHistory,
  getSearchHistory
} from '../utils/searchUtils';

import {
  signOutUserStart,
  signOutUserSuccess,
  signOutUserFailure,
} from "../redux/user/userSlice";

import { Sparkles, UtensilsCrossed } from 'lucide-react';
import { useSearchIntelligence } from '../hooks/useSearchIntelligence';

const PROPERTY_SUBTYPES = [
  { id: 'rent', label: 'Rental', icon: '🏠' },
  { id: 'sale', label: 'Hotel', icon: '🏨' },
  { id: 'over', label: 'Vacation', icon: '🌙' },
  { id: 'resort', label: 'Resort', icon: '🏖️' },
  { id: 'office', label: 'Office', icon: '🏢' }
];

const SERVICE_SUBTYPES = [
  { id: 'photography', label: 'Photography', icon: '📸' },
  { id: 'carwash', label: 'Car Wash', icon: '🚗' },
  { id: 'landscaping', label: 'Landscaping', icon: '🌿' },
  { id: 'electrician', label: 'Electrician', icon: '⚡' },
  { id: 'handyman', label: 'Handyman', icon: '🔧' }
];

const HELPER_SUBTYPES = [
  { id: 'maid', label: 'Maid', icon: '🧼' },
  { id: 'barber', label: 'Barber', icon: '💇' },
  { id: 'chef', label: 'Chef', icon: '👨‍🍳' },
  { id: 'tutor', label: 'Tutor', icon: '📚' },
  { id: 'domestic', label: 'Domestic', icon: '🧹' }
];

const normalizeSearchType = (type) => {
  if (type === 'helper') return 'helpers';
  if (type === 'property') return 'properties';
  if (type === 'lunch') return 'food';
  return type || 'all';
};

const QUICK_DISCOVERY_MAP = {
  food: { searchType: 'food', subType: '' },
  lunch: { searchType: 'food', subType: '' },
  'street-food': { searchType: 'food', subType: 'street_food' },
  resort: { searchType: 'properties', subType: 'resort' },
  hotel: { searchType: 'properties', subType: 'sale' },
  guesthouse: { searchType: 'properties', subType: 'guest_house' },
  'room-rent': { searchType: 'properties', subType: 'rent' },
  'house-rent': { searchType: 'properties', subType: 'rent' },
  'self-catering': { searchType: 'properties', subType: 'land' },
  photograph: { searchType: 'helpers', subType: 'photography' },
  carwash: { searchType: 'helpers', subType: 'carwash' },
  moving: { searchType: 'helpers', subType: 'moving' },
  electrician: { searchType: 'services', subType: 'electrician' },
  handyman: { searchType: 'services', subType: 'handyman' },
  catering: { searchType: 'services', subType: 'catering' },
  transport: { searchType: 'services', subType: 'transport' },
  maid: { searchType: 'helpers', subType: 'maid' },
  nanny: { searchType: 'helpers', subType: 'nanny' },
  barber: { searchType: 'helpers', subType: 'barber' },
  beauty: { searchType: 'helpers', subType: 'beauty' }
};

const HEADER_CATEGORY_ICONS = {
  food: UtensilsCrossed,
  lunch: UtensilsCrossed,
  'street-food': UtensilsCrossed,
  properties: HomeIcon,
  services: BriefcaseIcon,
  helpers: UserGroupIcon,
  events: BellIcon,
  rent: HomeIcon,
  sale: BuildingOfficeIcon,
  over: Sparkles,
  resort: Sparkles,
  office: BuildingOfficeIcon,
  hotel: BuildingOfficeIcon,
  guesthouse: HomeModernIcon,
  'room-rent': HomeIcon,
  'house-rent': HomeModernIcon,
  'self-catering': BriefcaseIcon,
  photography: MagnifyingGlassIcon,
  photograph: MagnifyingGlassIcon,
  carwash: MapIcon,
  landscaping: Sparkles,
  electrician: BoltIcon,
  handyman: Cog6ToothIcon,
  catering: BriefcaseIcon,
  transport: MapPinIcon,
  maid: HomeModernIcon,
  nanny: UserIcon,
  barber: UserIcon,
  beauty: Sparkles,
  chef: BriefcaseIcon,
  tutor: QuestionMarkCircleIcon,
  domestic: HomeModernIcon
};

export default function Header() {
  const { currentUser } = useSelector((state) => state.user);
  const hostingMenuPath = currentUser?.offeringType && currentUser.offeringType !== 'viewer' ? '/hosting-menu' : '/become';
  const hostingMenuLabel = hostingMenuPath === '/hosting-menu' ? 'Hosting menu' : 'Become a host or provider';
  const hostingMenuDescription = hostingMenuPath === '/hosting-menu' ? 'Manage your hosting account and listings' : 'Choose property, services, food, or goods';
  const { hideHeader } = useSelector((state) => state.frontend || {});
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('all');
  const [selectedSubCategory, setSelectedSubCategory] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [searchHistory, setSearchHistory] = useState(() => getSearchHistory());
  const [suggestions, setSuggestions] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const knownNotificationIdsRef = useRef(new Set());
  const hasLoadedNotificationsRef = useRef(false);
  const [isSoundEnabled, setIsSoundEnabled] = useState(() => localStorage.getItem('loopOutSound') !== 'false');
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [adminOverview, setAdminOverview] = useState(null);
  const [adminOverviewLoading, setAdminOverviewLoading] = useState(false);
  const [adminOverviewRetry, setAdminOverviewRetry] = useState(0);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [currentLocation, setCurrentLocation] = useState('Polokwane');
  const [isNavVisible, setIsNavVisible] = useState(true);
  const lastScrollY = useRef(0);
  const lastNavDirectionY = useRef(0);

  const playNotificationChime = useCallback(() => {
    if (!isSoundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // Ignore browser autoplay restrictions
    }
  }, [isSoundEnabled]);

  // Currency and Language states
  const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState(() => {
    return localStorage.getItem('preferredCurrency') || localStorage.getItem('currency') || 'ZAR';
  });
  const [selectedLanguage, setSelectedLanguage] = useState(() => {
    return localStorage.getItem('preferredLanguage') || 'en';
  });

  const profileDropdownRef = useRef(null);
  const searchInputRef = useRef(null);
  const mobileMenuRef = useRef(null);
  const headerRef = useRef(null);
  const currencyDropdownRef = useRef(null);
  const languageDropdownRef = useRef(null);

  useEffect(() => {
    const syncCurrencyPreference = (event) => {
      const nextCurrency = event.detail?.currency || localStorage.getItem('preferredCurrency') || 'ZAR';
      setSelectedCurrency(nextCurrency);
    };
    window.addEventListener('loopout:currency-change', syncCurrencyPreference);
    return () => window.removeEventListener('loopout:currency-change', syncCurrencyPreference);
  }, []);
  useEffect(() => {
    const syncLanguagePreference = (event) => {
      const nextLanguage = event.detail?.language || localStorage.getItem('preferredLanguage') || 'en';
      setSelectedLanguage(nextLanguage);
    };
    window.addEventListener('loopout:language-change', syncLanguagePreference);
    return () => window.removeEventListener('loopout:language-change', syncLanguagePreference);
  }, []);
  useEffect(() => {
    if (!currentUser?.preferredLanguage) return;
    setSelectedLanguage(currentUser.preferredLanguage);
    localStorage.setItem('preferredLanguage', currentUser.preferredLanguage);
  }, [currentUser?._id, currentUser?.preferredLanguage]);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  // Available currencies and languages
  const currencies = [
    { code: 'ZAR', name: 'South African Rand', symbol: 'R' },
    { code: 'USD', name: 'US Dollar', symbol: '$' },
    { code: 'EUR', name: 'Euro', symbol: '€' },
    { code: 'GBP', name: 'British Pound', symbol: '£' },
    { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
    { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
    { code: 'JPY', name: 'Japanese Yen', symbol: '¥' }
  ];

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'af', name: 'Afrikaans', flag: '🇿🇦' },
    { code: 'zu', name: 'Zulu', flag: '🇿🇦' },
    { code: 'xh', name: 'Xhosa', flag: '🇿🇦' },
    { code: 'es', name: 'Spanish', flag: '🇪🇸' },
    { code: 'fr', name: 'French', flag: '🇫🇷' },
    { code: 'de', name: 'German', flag: '🇩🇪' },
    { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
    { code: 'ar', name: 'Arabic', flag: '🇸🇦' }
  ];

  // Fetch notifications
  const fetchNotifications = useCallback(async (signal) => {
    if (!currentUser) return;

    try {
      const res = await authenticatedFetchWithRetry(
        '/api/notifications',
        { headers: { 'Content-Type': 'application/json' }, signal },
        { maxRetries: 3, timeoutMs: 40000, quiet: true }
      );

      // Silently ignore auth errors, rate limit states, and server-not-ready states
      if (res.status === 401 || res.status === 403 || res.status === 429 || res.status === 503) return;

      if (res.ok) {
        const data = await res.json();
        const newUnreadCount = data.unreadCount || 0;

        const incomingNotifications = Array.isArray(data.notifications) ? data.notifications : [];
        const unseenNotifications = hasLoadedNotificationsRef.current
          ? incomingNotifications.filter((notification) => notification._id && !knownNotificationIdsRef.current.has(String(notification._id)))
          : [];

        // Don't replay an old unread alert on first load. After that, show every
        // newly-created notification even when another alert was read at the same time.
        if (unseenNotifications.length > 0) {
          playNotificationChime();
          unseenNotifications.reverse().forEach((notification) => {
            const notificationId = String(notification._id);
            pushPhoneNotification({
              title: notification.title || 'loopOut Alert',
              message: notification.message || 'You have a new update.',
              type: notification.type || 'info',
              notificationId,
              link: notification.data?.route || notification.data?.link ||
                (notification.type === 'message' && notification.data?.conversationId ? `/messages/${notification.data.conversationId}` :
                  notification.type === 'system' && notification.data?.followerId ? `/user/${notification.data.followerId}` : '/notifications')
            });
          });
        }

        setNotifications(data.notifications || []);
        setUnreadCount(newUnreadCount);
        incomingNotifications.forEach((notification) => {
          if (notification._id) knownNotificationIdsRef.current.add(String(notification._id));
        });
        if (knownNotificationIdsRef.current.size > 200) {
          knownNotificationIdsRef.current = new Set([...knownNotificationIdsRef.current].slice(-100));
        }
        hasLoadedNotificationsRef.current = true;
      }
    } catch (error) {
      // Ignore AbortError (unmount) and transient network errors (Render cold-start)
      if (error.name === 'AbortError') return;
      const msg = error?.message?.toLowerCase() || '';
      const isTransient = msg.includes('failed to fetch') || msg.includes('connection') || msg.includes('network');
      if (!isTransient) console.error('Error fetching notifications:', error);
    }
  }, [currentUser?._id, playNotificationChime]);

  // Track confirmed calendar appointments for user or host
  const [calendarAlertCount, setCalendarAlertCount] = useState(0);
  const isLoopOutAdmin = ['malebolanga3@gmail.com', 'admin@loopout.co.za'].includes(
    String(currentUser?.email || '').trim().toLowerCase()
  );

  useEffect(() => {
    if (!showProfileDropdown || !isLoopOutAdmin) return;
    const controller = new AbortController();
    setAdminOverviewLoading(true);
    authenticatedFetch('/api/stats/admin-overview', { signal: controller.signal })
      .then(async (response) => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.message || 'Could not load admin report.');
        setAdminOverview(data);
      })
      .catch(() => {
        if (!controller.signal.aborted) setAdminOverview(null);
      })
      .finally(() => {
        if (!controller.signal.aborted) setAdminOverviewLoading(false);
      });
    return () => controller.abort();
  }, [showProfileDropdown, isLoopOutAdmin, adminOverviewRetry]);

  const fetchCalendarAlerts = useCallback(async (signal) => {
    if (!currentUser?._id) {
      setCalendarAlertCount(0);
      return;
    }
    try {
      const [userRes, hostRes] = await Promise.allSettled([
        authenticatedFetchWithRetry(`/api/bookings/user/${currentUser._id}`, { signal }, { maxRetries: 3, timeoutMs: 40000, quiet: true }),
        authenticatedFetchWithRetry(`/api/bookings/host/${currentUser._id}`, { signal }, { maxRetries: 3, timeoutMs: 40000, quiet: true })
      ]);

      let confirmedCount = 0;
      const now = new Date();
      now.setHours(0, 0, 0, 0);

      if (userRes.status === 'fulfilled' && userRes.value?.ok) {
        const uData = await userRes.value.json();
        if (Array.isArray(uData)) {
          const activeUser = uData.filter(b => {
            const d = new Date(b.startDate);
            d.setHours(0, 0, 0, 0);
            return (b.status === 'confirmed' || b.status === 'approved') && d >= now;
          });
          confirmedCount += activeUser.length;
        }
      }

      if (hostRes.status === 'fulfilled' && hostRes.value?.ok) {
        const hData = await hostRes.value.json();
        if (Array.isArray(hData)) {
          const activeHost = hData.filter(b => {
            const d = new Date(b.startDate);
            d.setHours(0, 0, 0, 0);
            return (b.status === 'confirmed' || b.status === 'approved') && d >= now;
          });
          confirmedCount += activeHost.length;
        }
      }

      setCalendarAlertCount(confirmedCount);
    } catch {
      // Ignore aborts or network issues
    }
  }, [currentUser?._id]);

  // Combined calendar notification indicator (unread calendar alerts + upcoming confirmed bookings)
  const calendarBadgeCount = useMemo(() => {
    const calendarUnread = notifications.filter(n =>
      !n.read && (
        n.type === 'booking' ||
        n.data?.isCalendar ||
        n.title?.toLowerCase().includes('calendar') ||
        n.title?.toLowerCase().includes('confirmed') ||
        n.message?.toLowerCase().includes('calendar') ||
        n.message?.toLowerCase().includes('confirmed')
      )
    ).length;
    return calendarUnread > 0 ? calendarUnread : calendarAlertCount;
  }, [notifications, calendarAlertCount]);

  useEffect(() => {
    const controller = new AbortController();
    fetchNotifications(controller.signal);
    fetchCalendarAlerts(controller.signal);

    const refreshNotifications = () => {
      fetchNotifications();
      fetchCalendarAlerts();
    };
    window.addEventListener('loopout:notification-created', refreshNotifications);

    // Set up polling for real-time alerts
    const interval = setInterval(() => {
      const pollController = new AbortController();
      fetchNotifications(pollController.signal);
      fetchCalendarAlerts(pollController.signal);
    }, 30000); // Poll every 30s

    return () => {
      controller.abort();
      clearInterval(interval);
      window.removeEventListener('loopout:notification-created', refreshNotifications);
    };
  }, [fetchNotifications, fetchCalendarAlerts]);

  // Sync search state with URL
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const term = urlParams.get('searchTerm');
    const type = normalizeSearchType(urlParams.get('type'));
    const subType = urlParams.get('subType') || urlParams.get('category');
    const address = urlParams.get('address') || urlParams.get('location');

    if (term) setSearchTerm(term);
    if (type) setSearchType(type);
    setSelectedSubCategory(subType || '');
    if (address) setCurrentLocation(address);
  }, [location.search]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(e.target)) {
        setShowProfileDropdown(false);
      }


      if (mobileMenuRef.current && !mobileMenuRef.current.contains(e.target) && !e.target.closest('.mobile-menu-button')) {
        setShowMobileMenu(false);
      }

      if (currencyDropdownRef.current && !currencyDropdownRef.current.contains(e.target) && !e.target.closest('.currency-button')) {
        setShowCurrencyDropdown(false);
      }

      if (languageDropdownRef.current && !languageDropdownRef.current.contains(e.target) && !e.target.closest('.language-button')) {
        setShowLanguageDropdown(false);
      }

      // Close search if clicking outside search area
      if (showSearch && !e.target.closest('.search-container') && !e.target.closest('.search-trigger')) {
        setShowSearch(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showSearch]);

  // Toggle bottom nav visibility on scroll
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const isScrollingUp = currentScrollY < lastScrollY.current;

      if (currentScrollY < 50) {
        setIsNavVisible(true);
        lastNavDirectionY.current = currentScrollY;
      } else if (Math.abs(currentScrollY - lastNavDirectionY.current) >= 8) {
        setIsNavVisible(isScrollingUp);
        lastNavDirectionY.current = currentScrollY;
      }

      setScrolled(currentScrollY > 20);
      lastScrollY.current = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Suggestions debouncing
  useEffect(() => {
    if (!searchTerm.trim()) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(() => {
      const newSuggestions = generateSuggestions(searchTerm, 'all', searchHistory);
      setSuggestions(newSuggestions);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, searchHistory]);

  // Focus search input when opened
  useEffect(() => {
    if (showSearch && searchInputRef.current) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 100);
    }
  }, [showSearch]);

  // Handle sign out
  const handleSignOut = async () => {
    try {
      dispatch(signOutUserStart());
      fetch('/api/auth/signout', { credentials: 'include' }).catch(() => {});
      clearPersistedSessionToken();
      dispatch(signOutUserSuccess());
      navigate('/sign-in');
      setShowProfileDropdown(false);
      setShowMobileMenu(false);
    } catch (error) {
      clearPersistedSessionToken();
      dispatch(signOutUserSuccess());
      navigate('/sign-in');
    }
  };

  // Clear search history
  const clearSearchHistory = () => {
    localStorage.removeItem('searchHistory');
    setSearchHistory([]);
  };

  // Command Center Navigation
  const MASTER_COMMANDS = [
    { label: 'FOOD & LUNCH', route: '/food', icon: <UtensilsCrossed className="w-5 h-5" />, color: 'bg-gradient-to-tr from-amber-500 to-orange-500' },
    { label: 'MY LOOP OUT', route: '/my-loopout', icon: <CalendarDaysIcon className="w-5 h-5" />, color: 'bg-gradient-to-tr from-rose-500 to-purple-500' },
    { label: 'LOOPBOT AI', route: '/loopbot', icon: <Sparkles className="w-5 h-5" />, color: 'bg-gradient-to-tr from-rose-500 to-amber-500' },
    { label: 'DASHBOARD', route: '/dashboard', icon: <HomeModernIcon className="w-5 h-5" />, color: 'bg-indigo-500' },
    { label: 'ELITE REWARDS', route: '/rewards', icon: <Sparkles className="w-5 h-5" />, color: 'bg-purple-500' },
    { label: 'SALON CALENDAR', route: '/calendar', icon: <CalendarIcon className="w-5 h-5" />, color: 'bg-gradient-to-tr from-purple-600 to-violet-500' },
    { label: 'AI PLANNER', route: '/planner', icon: <MapIcon className="w-5 h-5" />, color: 'bg-pink-500' },
    { label: 'BILL SPLITTER', route: '/splitter', icon: <ChartPieIcon className="w-5 h-5" />, color: 'bg-emerald-600' },
    { label: 'MY LISTINGS', route: `/${currentUser?._id}/listings`, icon: <QueueListIcon className="w-5 h-5" />, color: 'bg-blue-500' },
    { label: 'HELP CENTER', route: '/help-center', icon: <QuestionMarkCircleIcon className="w-5 h-5" />, color: 'bg-indigo-600' },
    { label: 'SIGNAL INBOX', route: '/messages', icon: <InboxIcon className="w-5 h-5" />, color: 'bg-cyan-500' },
    { label: 'VERIFY IDENTITY', route: '/verification', icon: <CheckBadgeIcon className="w-5 h-5" />, color: 'bg-rose-600' },
    { label: 'SECURITY LAB', route: '/trust', icon: <ShieldCheckIcon className="w-5 h-5" />, color: 'bg-gray-800' },
    { label: 'FOR BUSINESS', route: '/for-business', icon: <BriefcaseIcon className="w-5 h-5" />, color: 'bg-rose-500' },
    { label: 'HOST EARNINGS', route: '/host-earnings', icon: <ChartBarIcon className="w-5 h-5" />, color: 'bg-amber-500' },
    { label: 'HOST TOOLS', route: '/host-tools', icon: <Squares2X2Icon className="w-5 h-5" />, color: 'bg-indigo-500' },
    { label: 'SETTINGS', route: '/settings', icon: <Cog6ToothIcon className="w-5 h-5" />, color: 'bg-indigo-500' },
    ...(isLoopOutAdmin ? [{ label: 'ADMIN REVIEW', route: '/admin/verification', icon: <ShieldCheckIcon className="w-5 h-5" />, color: 'bg-gradient-to-tr from-rose-600 to-red-500' }] : [])
  ];

  // Handle search submission
  const { recordSearch } = useSearchIntelligence();

  const handleSearch = (eventOrOptions, maybeOptions) => {
    const hasEvent = eventOrOptions && typeof eventOrOptions.preventDefault === 'function';
    if (hasEvent) eventOrOptions.preventDefault();

    const options = hasEvent ? (maybeOptions || {}) : (eventOrOptions || {});
    const nextSearchTerm = options.searchTerm ?? searchTerm;
    const nextSearchType = normalizeSearchType(options.searchType ?? searchType);
    const nextSubCategory = options.subType ?? options.selectedSubCategory ?? selectedSubCategory;

    // Only block if absolutely no criteria is provided
    if (!nextSearchTerm.trim() && !nextSubCategory && !nextSearchType) return;

    if (nextSearchTerm.trim()) {
      recordSearch(nextSearchTerm);
      const updatedHistory = saveSearchHistory(nextSearchTerm, nextSearchType);
      setSearchHistory(updatedHistory);
    }

    const extractedFilters = nextSearchTerm.trim() ? extractFiltersFromQuery(nextSearchTerm) : {};
    const resolvedType = normalizeSearchType(options.searchType ?? extractedFilters.type ?? nextSearchType ?? 'all');
    const resolvedSubType = options.subType ?? nextSubCategory ?? extractedFilters.subType ?? '';
    const resolvedLocation = options.location ?? extractedFilters.location ?? currentLocation;
    const urlParams = new URLSearchParams();
    const isLocationOnly = extractedFilters.location && nextSearchTerm.toLowerCase().trim() === extractedFilters.location.toLowerCase().trim();

    if (nextSearchTerm.trim() && !isLocationOnly) urlParams.set('searchTerm', nextSearchTerm);
    urlParams.set('type', resolvedType);
    if (resolvedSubType) urlParams.set('subType', resolvedSubType);
    if (resolvedLocation) urlParams.set('location', resolvedLocation);

    Object.entries(extractedFilters).forEach(([key, value]) => {
      if (key !== 'type' && key !== 'subType' && key !== 'location') {
        urlParams.set(key, value);
      }
    });

    navigate(`/search?${urlParams.toString()}`);
    setShowSearch(false);
    setSearchTerm(nextSearchTerm);
    setSearchType(resolvedType);
    setSelectedSubCategory(resolvedSubType);
    setSuggestions([]);
  };

  // Handle currency change
  const handleCurrencyChange = (currencyCode) => {
    setSelectedCurrency(currencyCode);
    localStorage.setItem('preferredCurrency', currencyCode);
    localStorage.setItem('currency', currencyCode);
    window.dispatchEvent(new CustomEvent('loopout:currency-change', { detail: { currency: currencyCode } }));
    setShowCurrencyDropdown(false);

    // Dispatch currency change to Redux store if you have currency slice
    // dispatch(setCurrency(currencyCode));

  };

  // Handle language change
  const handleLanguageChange = (languageCode, languageName) => {
    setSelectedLanguage(languageCode);
    localStorage.setItem('preferredLanguage', languageCode);
    window.dispatchEvent(new CustomEvent('loopout:language-change', { detail: { language: languageCode } }));
    setShowLanguageDropdown(false);

    // Dispatch language change to Redux store if you have language slice
    // dispatch(setLanguage(languageCode));

  };

  // Get current currency symbol
  const getCurrencySymbol = () => {
    const currency = currencies.find(c => c.code === selectedCurrency);
    return currency ? currency.symbol : 'R';
  };

  // Search categories
  const searchCategories = [
    { key: 'properties', label: 'Homes', icon: '🏠' },
    { key: 'helpers', label: 'Helpers', icon: '👨‍💼' },
    { key: 'events', label: 'Events', icon: '🎪' }
  ];

  // Handle navigation helper
  const handleNavigate = (path) => {
    navigate(path);
    setShowProfileDropdown(false);
    setShowMobileMenu(false);
  };

  const handleNotificationsClick = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      await window.Notification.requestPermission();
    }
    handleNavigate('/notifications');
  };

  // Handle mobile profile click - navigate to profile page instead of showing dropdown
  const handleMobileProfileClick = () => {
    if (currentUser) {
      navigate('/profile');
    } else {
      navigate('/sign-in');
    }
  };

  const hiddenRoutes = ['/profile', '/wishlist', '/search', '/dashboard', '/host-dashboard', '/planner', '/lunch', '/food', '/notifications', '/my-orders', '/food-orders', '/my-loopout', '/admin/verification'];
  const hiddenPrefixes = ['/food', '/lunch', '/user/', '/user-profile/', '/listing/', '/rent/', '/helper/', '/service/', '/event/', '/carwash/', '/admin'];
  
  const isHeaderHidden = 
    hiddenRoutes.includes(location.pathname) || 
    hiddenPrefixes.some(prefix => location.pathname.startsWith(prefix)) ||
    location.pathname.includes('create-listing');

  const profileMenuContent = (
    <div className="flex flex-col">
      {currentUser ? (
        <>
          {/* User Header */}
          <div
            className="p-6 bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 rounded-[2.2rem] mb-4 flex items-center cursor-pointer shadow-xl"
            onClick={() => handleNavigate('/profile')}
          >
            <div className="relative flex-shrink-0">
               <ImageWithFallback
                 src={currentUser.avatar}
                 type="avatar"
                 alt="Profile"
                 className="w-14 h-14 rounded-full border-2 border-rose-500 p-0.5"
               />
               <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 border-2 border-black rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
               <div className="flex items-center gap-2">
                  <p className="text-lg font-black text-white truncate">{currentUser.username}</p>
                  <CheckBadgeIcon className="w-5 h-5 text-blue-500" />
               </div>
               <div className="flex items-center gap-1.5">
                 <span className="text-[10px] text-rose-500 font-bold uppercase tracking-[0.2em]">ELITE USER</span>
               </div>
            </div>
            <ChevronRightIcon className="w-5 h-5 text-gray-500 hover:text-white transition-colors" />
          </div>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {MASTER_COMMANDS.map((cmd) => (
              <button
                key={cmd.label}
                onClick={() => handleNavigate(cmd.route)}
                aria-label={`${cmd.label}${cmd.route === '/my-loopout' && calendarBadgeCount ? `, ${calendarBadgeCount} upcoming booking or calendar alert${calendarBadgeCount === 1 ? '' : 's'}` : ''}`}
                className="flex flex-col items-center justify-center gap-2 p-3 bg-gray-50 dark:bg-gray-800/60 hover:bg-rose-50/50 dark:hover:bg-rose-500/10 rounded-2xl transition-all border border-transparent hover:border-rose-100/50"
              >
                <div className={`relative p-2 ${cmd.color} text-white rounded-xl shadow-md transition-transform hover:scale-110`}>
                  {cmd.icon}
                  {cmd.route === '/my-loopout' && calendarBadgeCount > 0 && (
                    <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full border-2 border-white bg-rose-600 px-1 text-[9px] font-black leading-none text-white dark:border-gray-900">
                      {calendarBadgeCount > 99 ? '99+' : calendarBadgeCount}
                    </span>
                  )}
                </div>
                <span className="text-[8px] font-black text-gray-900 dark:text-gray-300 uppercase tracking-widest text-center leading-tight">
                  {cmd.label}
                </span>
              </button>
            ))}
          </div>

          {isLoopOutAdmin && (
            <section aria-label="LoopOut admin tools" className="mb-3 overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white shadow-sm dark:border-gray-700 dark:bg-gray-900">
              <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-800 p-4 text-white">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 text-rose-300 ring-1 ring-white/10"><ChartBarIcon className="h-5 w-5" /></span>
                    <div>
                      <p className="text-xs font-black tracking-wide">LoopOut overview</p>
                      <p className="mt-0.5 text-[10px] text-slate-300">Your platform at a glance</p>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-2 py-1 text-[9px] font-bold text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />LIVE</span>
                </div>
                {adminOverview && !adminOverviewLoading && (
                  <div className="mt-4 flex items-end justify-between border-t border-white/10 pt-3">
                    <div><p className="text-[10px] font-medium text-slate-300">Total registered users</p><p className="mt-0.5 text-3xl font-black tracking-tight">{Number(adminOverview.users.total).toLocaleString()}</p></div>
                    <span className="pb-1 text-[9px] font-semibold uppercase tracking-wider text-slate-400">All time</span>
                  </div>
                )}
              </div>
              {adminOverviewLoading ? (
                <div className="grid grid-cols-2 gap-2 p-3" aria-label="Loading admin report">
                  {[0, 1, 2, 3].map((item) => <div key={item} className="h-16 animate-pulse rounded-xl bg-slate-100 dark:bg-gray-800" />)}
                </div>
              ) : adminOverview ? (
                <div className="p-3">
                  <div className="mb-2 flex items-center justify-between"><p className="text-[9px] font-black uppercase tracking-[0.16em] text-slate-400 dark:text-slate-500">Activity</p><p className="text-[9px] font-semibold text-slate-400 dark:text-slate-500">South Africa time</p></div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 dark:border-gray-800 dark:bg-gray-800/70"><p className="text-[10px] font-medium text-slate-500 dark:text-slate-400">Logged in today*</p><p className="mt-1 text-xl font-black text-slate-900 dark:text-white">{Number(adminOverview.logins.uniqueUsersToday).toLocaleString()}</p></div>
                    <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5 dark:border-gray-800 dark:bg-gray-800/70"><p className="text-[10px] font-medium text-slate-500 dark:text-slate-400">New users today</p><p className="mt-1 text-xl font-black text-slate-900 dark:text-white">{Number(adminOverview.users.signupsToday).toLocaleString()}</p></div>
                    <div className="col-span-2 flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-2.5 py-2 dark:border-gray-800 dark:bg-gray-800/70"><p className="text-[10px] font-medium text-slate-500 dark:text-slate-400">Accounts with recorded login · this week*</p><p className="text-base font-black text-slate-900 dark:text-white">{Number(adminOverview.logins.uniqueUsersThisWeek).toLocaleString()}</p></div>
                  </div>
                  <p className="mt-2 px-0.5 text-[9px] leading-relaxed text-slate-400 dark:text-slate-500">*Successful logins explicitly recorded by LoopOut.</p>
                </div>
              ) : (
                <div className="p-3"><p className="text-xs text-slate-500 dark:text-slate-400">We couldn’t load the latest admin report.</p><button type="button" onClick={() => setAdminOverviewRetry((attempt) => attempt + 1)} className="mt-2 text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-300">Try again</button></div>
              )}
              <div className="border-t border-slate-100 p-3 dark:border-gray-800">
                <button type="button" onClick={() => handleNavigate('/admin/verification')} className="group flex w-full items-center justify-between rounded-xl bg-rose-600 px-3 py-3 text-left text-white shadow-sm transition hover:bg-rose-700 active:scale-[0.99]">
                  <span className="flex items-center gap-2.5"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/15"><ShieldCheckIcon className="h-4 w-4" /></span><span><span className="block text-xs font-extrabold">Review identity submissions</span><span className="mt-0.5 block text-[9px] text-rose-100">Check ID documents and selfies</span></span></span>
                  <ChevronRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </button>
              </div>
            </section>
          )}

          <button
            type="button"
            onClick={() => handleNavigate(hostingMenuPath)}
            className="mb-2 flex w-full items-center gap-3 rounded-2xl border border-rose-100 bg-rose-50/80 p-3 text-left transition hover:border-rose-200 hover:bg-rose-100/80 active:scale-[0.98] dark:border-rose-900/40 dark:bg-rose-950/20 dark:hover:bg-rose-950/40"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-amber-500 text-white shadow-sm">
              <Sparkles className="h-5 w-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-xs font-black text-slate-900 dark:text-white">{hostingMenuLabel}</span>
              <span className="mt-0.5 block text-[10px] text-slate-600 dark:text-gray-400">{hostingMenuDescription}</span>
            </span>
            <ChevronRightIcon className="h-4 w-4 text-rose-500" />
          </button>

          <div className="sticky bottom-0 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md pt-3 border-t border-slate-100 dark:border-gray-800 mt-3 -mx-4 px-4 pb-3">
  <button
    onClick={handleSignOut}
    aria-label="Sign out"
    className="flex items-center justify-center gap-2 w-full py-3 text-xs font-black uppercase text-slate-600 dark:text-gray-400 hover:text-rose-600 transition-all tracking-[0.2em] bg-slate-50 dark:bg-gray-800/60 rounded-2xl hover:bg-rose-50 dark:hover:bg-rose-500/10 border border-transparent hover:border-rose-100 active:scale-95"
  >
    <ArrowRightOnRectangleIcon className="w-4 h-4" />
    Sign out
  </button>
</div>
<div className="text-center text-[9px] text-slate-400 dark:text-gray-500 font-bold mt-3 uppercase tracking-[0.15em]">
  <Link to="/terms" className="hover:text-rose-500 transition-colors">Terms</Link>
  <span className="mx-1.5 text-slate-300 dark:text-gray-700">&middot;</span>
  <Link to="/privacy" className="hover:text-rose-500 transition-colors">Privacy</Link>
  <span className="mx-1.5 text-slate-300 dark:text-gray-700">&middot;</span>
  <Link to="/contact" className="hover:text-rose-500 transition-colors">Contact</Link>
  <span className="mx-1.5 text-slate-300 dark:text-gray-700">&middot;</span>
  <span>&copy; {new Date().getFullYear()}</span>
</div>
        </>
      ) : (
        <div className="p-4 space-y-3">
          <button
            onClick={() => handleNavigate('/sign-in')}
            className="w-full py-4 bg-slate-950 dark:bg-white dark:text-slate-950 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl hover:bg-black dark:hover:bg-gray-200 transition-all active:scale-95"
          >Sign In</button>
          <button
            onClick={() => handleNavigate('/sign-up')}
            className="w-full py-4 border-2 border-slate-200 text-slate-900 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-50 transition-all active:scale-95"
          >Create Account</button>
          <button
            type="button"
            onClick={() => handleNavigate(hostingMenuPath)}
            className="flex w-full items-center gap-3 rounded-2xl border border-rose-100 bg-rose-50/80 p-3 text-left transition hover:border-rose-200 hover:bg-rose-100/80 active:scale-[0.98] dark:border-rose-900/40 dark:bg-rose-950/20 dark:hover:bg-rose-950/40"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-amber-500 text-white shadow-sm">
              <Sparkles className="h-5 w-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-xs font-black text-slate-900 dark:text-white">{hostingMenuLabel}</span>
              <span className="mt-0.5 block text-[10px] text-slate-600 dark:text-gray-400">{hostingMenuDescription}</span>
            </span>
            <ChevronRightIcon className="h-4 w-4 text-rose-500" />
          </button>
          <div className="text-center text-[9px] text-slate-400 dark:text-gray-500 font-bold mt-3 uppercase tracking-[0.15em]">
  <Link to="/terms" className="hover:text-rose-500 transition-colors">Terms</Link>
  <span className="mx-1.5 text-slate-300 dark:text-gray-700">&middot;</span>
  <Link to="/privacy" className="hover:text-rose-500 transition-colors">Privacy</Link>
  <span className="mx-1.5 text-slate-300 dark:text-gray-700">&middot;</span>
  <Link to="/contact" className="hover:text-rose-500 transition-colors">Contact</Link>
  <span className="mx-1.5 text-slate-300 dark:text-gray-700">&middot;</span>
  <span>&copy; {new Date().getFullYear()}</span>
</div>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Native-style app bar */}
      {!isHeaderHidden && (
        <motion.header
          initial={{ y: 0 }}
          animate={{ 
            y: (hideHeader || !isNavVisible) ? -120 : 0,
            opacity: (hideHeader || !isNavVisible) ? 0 : 1,
            paddingTop: scrolled ? '0.5rem' : '0.75rem',
            paddingBottom: scrolled ? '0.5rem' : '0.75rem',
          }}
          transition={{ type: 'spring', damping: 25, stiffness: 120, opacity: { duration: 0.2 } }}
          ref={headerRef}
        className={`app-safe-top fixed top-0 left-0 right-0 z-50 bg-white dark:bg-gray-950 border-b-0 backdrop-blur-xl transition-all duration-500 ${
          scrolled ? 'shadow-[0_4px_20px_rgba(15,23,42,0.03)]' : ''
        } ${hideHeader ? 'pointer-events-none' : ''}`}
        >
        <div className="max-w-[2520px] mx-auto xl:px-[82px] md:px-[42px] px-4 sm:px-6">
          <div className="flex flex-row items-center justify-between h-14 md:h-16">
            
            {/* Left: Branding — hidden on mobile, visible on sm+ */}
            <div className={`hidden sm:flex flex-shrink-0 transition-all duration-500 ${showSearch ? 'opacity-0 scale-90 pointer-events-none' : 'opacity-100 scale-100'}`}>
              <Link
                to="/"
                aria-label="loopOut Home"
                className="flex items-center gap-2 cursor-pointer"
              >
                <div className="relative">
                  <div className="absolute inset-0 rounded-full bg-rose-500/20 blur-lg" />
                  <BrandIcon className="relative z-10 h-8 w-8" />
                </div>
                <div className="hidden sm:block">
                  <h1 className="text-lg font-black leading-none tracking-tighter">
                    <span className="text-rose-500">loop</span><span className="text-orange-500">Out</span>
                  </h1>
                  <p className="mt-1 text-[8px] font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">Your local hub</p>
                </div>
              </Link>
            </div>

            {/* Mobile Search Pill — sits beside the brand rather than replacing it. */}
            <div className={`min-w-0 flex-1 mx-3 md:hidden transition-all duration-500 ${showSearch ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'}`}>
              <button
                onClick={() => setShowSearch(true)}
                aria-label="Open search"
                className="search-trigger w-full flex items-center gap-2.5 rounded-full border border-slate-200 dark:border-gray-700 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer bg-white dark:bg-gray-900 py-2 px-2.5"
              >
                <div className="w-7 h-7 flex-shrink-0 bg-gradient-to-br from-rose-500 to-rose-600 rounded-full flex items-center justify-center text-white shadow-md shadow-rose-200">
                  <MagnifyingGlassIcon className="w-3.5 h-3.5 stroke-[2.5px]" />
                </div>
                <span className="text-[13px] font-black text-slate-900 dark:text-white leading-tight truncate">Where to?</span>
              </button>
            </div>

            {/* Center: Search Pill (Airbnb Style) */}
            <div className={`flex-1 hidden md:flex justify-center transition-all duration-500 ${showSearch ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'}`}>
              <button
                onClick={() => setShowSearch(true)}
                aria-label="Open search"
                className="search-trigger flex items-center gap-0 border border-slate-200 dark:border-gray-700 rounded-full shadow-sm hover:shadow-lg transition-all duration-300 cursor-pointer bg-white dark:bg-gray-900 overflow-hidden"
              >
                <span className="text-[11px] font-black text-slate-900 dark:text-white px-5 py-2.5 hover:bg-slate-50 dark:hover:bg-gray-800 transition-colors">Anywhere</span>
                <div className="w-[1px] h-5 bg-slate-200 dark:bg-gray-700" />
                <span className="text-[11px] font-black text-slate-900 dark:text-white px-5 py-2.5 hover:bg-slate-50 dark:hover:bg-gray-800 transition-colors">Any type</span>
                <div className="w-[1px] h-5 bg-slate-200 dark:bg-gray-700" />
                <span className="text-[11px] font-medium text-slate-400 dark:text-gray-500 px-4 py-2.5">Search</span>
                <div className="w-9 h-9 bg-gradient-to-br from-rose-500 to-rose-600 rounded-full flex items-center justify-center text-white mr-1.5 group-hover:from-rose-600 group-hover:to-rose-700 transition-all shadow-md shadow-rose-200">
                  <MagnifyingGlassIcon className="w-4 h-4 stroke-[2.5px]" />
                </div>
              </button>
            </div>

            {/* Right: alerts on every device, account menu on desktop. */}
            <div className="relative">
              <div className="flex flex-row items-center gap-1.5 md:gap-3">
                {/* Notification Bell Icon - Desktop and Mobile (Alone, sleek, without circle) */}
                <button
                  onClick={handleNotificationsClick}
                  aria-label={`Notifications. ${unreadCount} unread`}
                  title="Notifications"
                  className="relative p-2 text-slate-700 dark:text-gray-300 hover:text-slate-950 dark:hover:text-white transition-colors flex items-center justify-center cursor-pointer rounded-xl hover:bg-slate-100/80 dark:hover:bg-gray-800/60"
                >
                  <BellIcon className="w-6 h-6 stroke-[1.8px]" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 bg-rose-500 text-white text-[8px] min-w-[15px] h-[15px] px-1 flex items-center justify-center rounded-full border-[1.5px] border-white dark:border-gray-900 shadow-sm z-10 font-black">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {currentUser && canCreateListings(currentUser) && currentUser.offeringType !== 'viewer' ? (
                  <Link
                    to={getCreationRoute(currentUser)}
                    aria-label="Create a listing"
                    className="hidden h-10 items-center gap-2 rounded-full bg-rose-500 px-4 text-xs font-bold text-white shadow-sm transition-all hover:bg-rose-600 hover:shadow-md active:scale-95 md:flex"
                  >
                    <PlusIcon className="h-4 w-4" />
                    <span>Create</span>
                  </Link>
                ) : (
                  <Link
                    to="/become"
                    aria-label="Become a host or provider"
                    className="hidden h-10 items-center gap-1.5 rounded-full border border-rose-200 bg-rose-50/70 px-4 text-xs font-bold text-rose-600 shadow-sm transition-all hover:bg-rose-100 hover:border-rose-400 active:scale-95 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300 md:flex"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Become a Host</span>
                  </Link>
                )}

                <div className="relative hidden md:block" ref={profileDropdownRef}>
                  <button
                    type="button"
                    onClick={() => {
                      setShowProfileDropdown((open) => !open);
                      setShowLanguageDropdown(false);
                      setShowCurrencyDropdown(false);
                    }}
                    aria-label={currentUser ? 'Open profile menu' : 'Sign in'}
                    aria-expanded={showProfileDropdown}
                    className={`flex h-10 items-center gap-2 rounded-full border px-3 transition-all hover:shadow-md ${
                      currentUser
                        ? 'border-slate-200 bg-white text-slate-800 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-100'
                        : 'border-slate-900 bg-slate-900 text-white dark:border-white dark:bg-white dark:text-slate-900'
                    }`}
                  >
                    {currentUser ? (
                      <>
                        <div className="h-6 w-6 overflow-hidden rounded-full border border-slate-200 dark:border-gray-700">
                          <ImageWithFallback src={currentUser.avatar} type="avatar" alt="Profile" className="h-full w-full" />
                        </div>
                        <span className="max-w-24 truncate text-xs font-bold">{currentUser.username}</span>
                      </>
                    ) : (
                      <span className="text-xs font-bold">Sign in</span>
                    )}
                  </button>

                  <AnimatePresence>
                    {showProfileDropdown && (
                      <motion.div
                        initial={{ opacity: 0, y: -8, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -8, scale: 0.98 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 top-full z-50 mt-3 max-h-[85vh] w-80 overflow-y-auto rounded-[2rem] border border-gray-100 bg-white p-4 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] dark:border-gray-800 dark:bg-gray-900"
                      >
                        {profileMenuContent}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

              </div>

              {/* Language Dropdown */}
              {showLanguageDropdown && (
                <div
                  ref={languageDropdownRef}
                  className="absolute rounded-[2.5rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] w-[260px] bg-white dark:bg-gray-900 overflow-hidden right-0 top-12 text-sm border border-gray-100 dark:border-gray-800 max-h-[400px] overflow-y-auto hidden md:block z-[60]"
                >
                  <div className="p-4 border-b border-[#DDDDDD] dark:border-gray-800 font-semibold text-[#222222] dark:text-white">
                    Choose a language
                  </div>
                  {languages.filter((language) => language.code === 'en').map((language) => (
                    <button
                      key={language.code}
                      onClick={() => handleLanguageChange(language.code, language.name)}
                      className="w-full px-4 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 transition text-left flex items-center justify-between text-[#222222] dark:text-white"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-lg">{language.flag}</span>
                        <span>{language.name}</span>
                      </div>
                      {selectedLanguage === language.code && (
                        <CheckIcon className="w-4 h-4 text-[#FF5A5F]" />
                      )}
                    </button>
                  ))}
                </div>
              )}

              {/* Currency Dropdown Menu */}
              {showCurrencyDropdown && (
                <div
                  ref={currencyDropdownRef}
                  className="absolute rounded-[2.5rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] w-[260px] bg-white dark:bg-gray-900 overflow-hidden right-12 top-12 text-sm border border-gray-100 dark:border-gray-800 max-h-[400px] overflow-y-auto hidden md:block z-[60]"
                >
                  <div className="p-4 border-b border-[#DDDDDD] dark:border-gray-800 font-semibold text-[#222222] dark:text-white">
                    Choose currency
                  </div>
                  {currencies.map((currency) => (
                    <button
                      key={currency.code}
                      onClick={() => handleCurrencyChange(currency.code)}
                      className="w-full px-4 py-3 hover:bg-gray-100 dark:hover:bg-gray-800 transition text-left flex items-center justify-between text-[#222222] dark:text-white"
                    >
                      <span className="font-bold text-xs">{currency.code} ({currency.symbol})</span>
                      <span className="text-gray-700 text-xs">{currency.name}</span>
                      {selectedCurrency === currency.code && (
                        <CheckIcon className="w-4 h-4 text-[#FF5A5F]" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.header>
    )}

    {/* User Profile Dropdown - Mobile Bottom Sheet */}
    <AnimatePresence>
      {/* Mobile user dropdown bottom sheet is removed */}
    </AnimatePresence>

    {/* Full Screen Elite Search Modal - Airbnb Style */}
    <AnimatePresence>
      {showSearch && (
        <>
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            onClick={() => setShowSearch(false)} 
            aria-hidden="true"
            className="fixed inset-0 bg-gray-900/60 backdrop-blur-md z-[1000]" 
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'tween', duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="search-container fixed inset-0 bg-gray-50 dark:bg-gray-950 z-[1001] flex flex-col md:max-w-md md:left-auto md:right-0 md:shadow-2xl overflow-hidden"
          >
            <div className="app-safe-top flex-shrink-0 bg-white dark:bg-gray-900 px-4 sm:px-6 pt-4 pb-4 flex items-center justify-between">
              <div className="flex gap-8 overflow-x-auto scrollbar-hide py-2">
                {[
                  { id: 'all', label: 'Universe', icon: Sparkles, color: 'rose' },
                  { id: 'properties', label: 'Homes', icon: HomeIcon, color: 'rose' },
                  { id: 'food', label: 'Food & Lunch', icon: UtensilsCrossed, color: 'orange', path: '/food' },
                  { id: 'events', label: 'Experiences', icon: MagnifyingGlassIcon, color: 'rose' },
                  { id: 'helpers', label: 'Helpers', icon: BriefcaseIcon, color: 'rose' }
                ].map((item) => {
                  const Icon = item.icon;
                  const isActive = searchType === item.id;
                  
                  return (
                    <button 
                      key={item.id}
                      onClick={() => {
                        if (item.path) {
                          navigate(item.path);
                          setShowSearch(false);
                        } else {
                          setSearchType(item.id);
                        }
                      }}
                      className="flex flex-col items-center gap-2 relative outline-none"
                    >
                       <motion.div 
                         animate={isActive ? { scale: [1, 1.15, 1], rotate: [0, 5, -5, 0] } : { scale: 1, rotate: 0 }}
                         transition={{ duration: 0.4, ease: "backOut" }}
                         className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 ${isActive ? 'bg-rose-500 text-white shadow-lg shadow-rose-200' : 'bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white hover:-translate-y-1'}`}
                       >
                          <Icon className="w-6 h-6" />
                       </motion.div>
                       
                       <motion.span 
                         animate={{ opacity: isActive ? 1 : 0.4, scale: isActive ? 1.05 : 1 }}
                         className={`text-[10px] font-black uppercase tracking-widest transition-colors ${isActive ? 'text-gray-900 dark:text-white' : 'text-gray-600 dark:text-gray-400'}`}
                       >
                         {item.label}
                       </motion.span>
                       
                       {isActive && (
                         <motion.div 
                           layoutId="categoryLine" 
                           className="absolute -bottom-1 w-6 h-1 bg-rose-500 rounded-full" 
                         />
                       )}
                    </button>
                  );
                })}
              </div>
              
              <button
                onClick={() => setShowSearch(false)}
                aria-label="Close search"
                className="w-10 h-10 rounded-full bg-slate-100 dark:bg-gray-800 border border-slate-200 dark:border-gray-700 flex items-center justify-center hover:bg-slate-200 dark:hover:bg-gray-700 transition-all active:scale-90"
              >
                <XMarkIcon className="w-5 h-5 text-slate-900 dark:text-white" />
              </button>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
               {/* Section: WHERE? */}
               <div className="bg-white dark:bg-gray-900 rounded-[2rem] shadow-xl p-6 border border-gray-100 dark:border-gray-800">
                  <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-6 tracking-tight">Where to?</h2>
                  
                  <div className="relative mb-8">
                     <BrandIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 grayscale opacity-40" />
                     <input 
                       ref={searchInputRef}
                       type="text"
                       placeholder="Search destinations"
                       value={searchTerm}
                       onChange={(e) => setSearchTerm(e.target.value)}
                       onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                       className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 text-gray-900 dark:text-white rounded-2xl py-4 pl-12 pr-12 focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all outline-none font-medium placeholder-gray-500 dark:placeholder-gray-500"
                     />
                     <button 
                       aria-label="Voice search"
                       className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-gray-600 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all"
                     >
                        <MicrophoneIcon className="w-5 h-5" />
                     </button>
                  </div>

                  <div className="space-y-4">
                     {searchHistory.length > 0 && (
                       <div className="mb-6">
                         <div className="flex justify-between items-center mb-4">
                           <p className="text-[10px] font-black text-gray-600 dark:text-gray-400 uppercase tracking-[0.2em]">Recent searches</p>
                           <button onClick={clearSearchHistory} className="text-[10px] font-bold text-gray-600 dark:text-gray-400 hover:text-rose-500 uppercase tracking-widest">Clear</button>
                         </div>
                         <div className="flex flex-wrap gap-2">
                           {searchHistory.slice(0, 5).map((item, i) => (
                             <button 
                               key={i} 
                               onClick={() => handleSearch({ searchTerm: item.term })}
                               className="px-4 py-2 bg-gray-100 dark:bg-gray-800 hover:bg-rose-50 dark:hover:bg-rose-500/10 hover:text-rose-600 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 transition-all"
                             >
                               {item.term}
                             </button>
                           ))}
                         </div>
                       </div>
                     )}

                     <p className="text-[10px] font-black text-gray-600 dark:text-gray-400 uppercase tracking-[0.2em]">Suggested destinations</p>
                     
                     <button 
                       onClick={() => handleSearch({ searchTerm: 'Nearby' })}
                       className="w-full flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all active:scale-98"
                     >
                        <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-500">
                           <MapPinIcon className="w-6 h-6" />
                        </div>
                        <div className="text-left">
                           <p className="text-sm font-bold text-gray-900 dark:text-white">Nearby</p>
                           <p className="text-xs text-gray-700 dark:text-gray-400">Find what's around you</p>
                        </div>
                     </button>

                     <button 
                       onClick={() => handleSearch({ searchTerm: 'Cape Town, Western Cape', location: 'Cape Town' })}
                       className="w-full flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all active:scale-98"
                     >
                        <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center text-green-500">
                           <BuildingOfficeIcon className="w-6 h-6" />
                        </div>
                        <div className="text-left">
                           <p className="text-sm font-bold text-gray-900 dark:text-white">Cape Town, Western Cape</p>
                           <p className="text-xs text-gray-700 dark:text-gray-400">Popular beach destination</p>
                        </div>
                     </button>

                     <button 
                       onClick={() => handleSearch({ searchTerm: 'Durban, KwaZulu-Natal', location: 'Durban' })}
                       className="w-full flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all active:scale-98"
                     >
                        <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center text-orange-500">
                           <HomeModernIcon className="w-6 h-6" />
                        </div>
                        <div className="text-left">
                           <p className="text-sm font-bold text-gray-900 dark:text-white">Durban, KwaZulu-Natal</p>
                           <p className="text-xs text-gray-700 dark:text-gray-400">For sights like uShaka Marine World</p>
                        </div>
                     </button>

                     <button 
                       onClick={() => handleSearch({ searchTerm: 'Tembisa, Gauteng', location: 'Tembisa' })}
                       className="w-full flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-all active:scale-98"
                     >
                        <div className="w-12 h-12 bg-rose-50 rounded-xl flex items-center justify-center text-rose-500">
                           <MapPinIcon className="w-6 h-6" />
                        </div>
                        <div className="text-left">
                           <p className="text-sm font-bold text-gray-900">Tembisa, Gauteng</p>
                           <p className="text-xs text-gray-700">Popular destination in Gauteng</p>
                        </div>
                     </button>
                  </div>
               </div>

               {/* Section: CATEGORIES DISCOVERY */}
               <div className="bg-white rounded-[2rem] shadow-xl p-6 border border-gray-100">
                  <h2 className="text-lg font-black text-gray-900 mb-6 tracking-tight uppercase">Quick Discovery</h2>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { id: 'food', label: 'Food & Lunch', icon: '🍱', color: 'bg-orange-50', path: '/food' },
                      { id: 'helpers', label: 'Helper', icon: '👨‍💼', color: 'bg-emerald-50' },
                      { id: 'properties', label: 'Homes', icon: '🏠', color: 'bg-rose-50' },
                      { id: 'events', label: 'Events', icon: '🎪', color: 'bg-amber-50' },
                      { id: 'resort', label: 'Resort', icon: '🏖️', color: 'bg-cyan-50' },
                      { id: 'hotel', label: 'Hotel', icon: '🏨', color: 'bg-indigo-50' },
                      { id: 'guesthouse', label: 'Guest House', icon: '🏡', color: 'bg-emerald-50' },
                      { id: 'room-rent', label: 'Room Rent', icon: '🛏️', color: 'bg-blue-50' },
                      { id: 'house-rent', label: 'House Rent', icon: '🏠', color: 'bg-amber-50' },
                      { id: 'self-catering', label: 'Catering', icon: '🍳', color: 'bg-orange-50' },
                      { id: 'maid', label: 'Maids', icon: '🧹', color: 'bg-purple-50' },
                      { id: 'carwash', label: 'Car Wash', icon: '🚗', color: 'bg-cyan-50' },
                      { id: 'nanny', label: 'Nanny', icon: '👶', color: 'bg-pink-50' },
                      { id: 'photograph', label: 'Photo', icon: '📸', color: 'bg-indigo-50' },
                      { id: 'transport', label: 'Transport', icon: '🚐', color: 'bg-orange-50' },
                      { id: 'electrician', label: 'Electric', icon: '⚡', color: 'bg-yellow-50' },
                      { id: 'handyman', label: 'Handyman', icon: '🔨', color: 'bg-gray-100' },
                      { id: 'catering', label: 'Catering', icon: '🍽️', color: 'bg-red-50' },
                      { id: 'barber', label: 'Barber', icon: '💈', color: 'bg-blue-100' },
                      { id: 'beauty', label: 'Beauty', icon: '💄', color: 'bg-rose-100' }
                    ].map((cat) => {
                      const CategoryIcon = HEADER_CATEGORY_ICONS[cat.id] || Sparkles;
                      return (
                        <button 
                          key={cat.id}
                          onClick={() => {
                            if (cat.path) {
                              navigate(cat.path);
                              setShowSearch(false);
                              return;
                            }
                            const isCore = ['properties', 'helpers', 'events', 'food'].includes(cat.id);
                            const discovery = QUICK_DISCOVERY_MAP[cat.id] || {
                              searchType: isCore ? cat.id : 'all',
                              subType: ''
                            };

                            setSearchType(discovery.searchType);
                            setSelectedSubCategory(discovery.subType);
                            handleSearch({
                              searchType: discovery.searchType,
                              subType: discovery.subType
                            });
                          }}
                          className="flex items-center gap-3 p-3 rounded-2xl border border-gray-100 hover:border-rose-200 hover:bg-rose-50/30 transition-all text-left"
                        >
                          <div className={`w-10 h-10 ${cat.color} rounded-xl flex items-center justify-center shadow-sm`}>
                            <CategoryIcon className="w-5 h-5 text-gray-800" />
                          </div>
                          <span className="text-xs font-black text-gray-900 uppercase tracking-tighter">{cat.label}</span>
                        </button>
                      );
                    })}
                  </div>
               </div>

               {/* Category Selection Section */}
               {(searchType === 'properties' || searchType === 'services' || searchType === 'helpers') && (
                 <div className="bg-white rounded-[2rem] shadow-xl p-6 border border-gray-100">
                    <h2 className="text-xl font-black text-gray-900 mb-6 tracking-tight">Select Category</h2>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                       {(searchType === 'properties' ? PROPERTY_SUBTYPES : 
                         searchType === 'services' ? SERVICE_SUBTYPES : 
                         HELPER_SUBTYPES).map((sub) => {
                          const SubIcon = HEADER_CATEGORY_ICONS[sub.id] || Sparkles;
                          return (
                            <button
                              key={sub.id}
                              onClick={() => setSelectedSubCategory(sub.id === selectedSubCategory ? '' : sub.id)}
                              className={`flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all ${
                                selectedSubCategory === sub.id 
                                  ? 'border-rose-500 bg-rose-50 shadow-md scale-105' 
                                  : 'border-gray-50 bg-gray-50 hover:border-gray-200'
                              }`}
                            >
                              <SubIcon className={`w-5 h-5 ${
                                selectedSubCategory === sub.id ? 'text-rose-600' : 'text-gray-700'
                              }`} />
                              <span className={`text-[9px] font-black uppercase tracking-widest ${
                                selectedSubCategory === sub.id ? 'text-rose-600' : 'text-gray-700'
                              }`}>
                                {sub.label}
                              </span>
                            </button>
                          );
                       })}
                    </div>
                 </div>
               )}
            </div>

            {/* Footer - Search Button */}
            <div className="flex-shrink-0 bg-white border-t border-slate-100 px-6 py-5 flex items-center justify-between">
               <button
                 onClick={() => {
                   setSearchTerm('');
                   setSearchType('all');
                   setSelectedSubCategory('');
                   setSuggestions([]);
                 }}
                 className="text-sm font-black text-slate-700 underline underline-offset-4 hover:text-rose-600 transition-colors uppercase tracking-wide"
               >
                 Clear all
               </button>

               <button
                  onClick={() => { handleSearch(); setShowSearch(false); }}
                  className="bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white px-8 py-4 rounded-2xl flex items-center gap-3 shadow-xl shadow-rose-200 transition-all active:scale-95 hover:shadow-2xl hover:shadow-rose-300"
                >
                 <BrandIcon className="w-5 h-5" color="white" />
                 <span className="text-sm font-black uppercase tracking-widest">Search</span>
               </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>

      {!isHeaderHidden && (
        <div className="app-safe-top" aria-hidden="true">
          <div className="h-20 md:h-24"></div>
        </div>
      )}
    </>
  );
}
