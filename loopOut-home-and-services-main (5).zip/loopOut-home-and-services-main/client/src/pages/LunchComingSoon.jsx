import React, { useMemo, useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  Bike,
  CheckCircle2,
  Clock3,
  MapPin,
  Minus,
  Plus,
  ShoppingBag,
  Store,
  UtensilsCrossed,
  Users,
  PlusCircle,
  ChefHat,
  Phone,
  ShieldCheck,
  CreditCard,
  Bell,
  Sparkles,
  X,
  Building2,
  Calendar,
  AlertCircle,
  Star,
  MessageSquare,
  ThumbsUp,
  TrendingUp,
  Lightbulb,
  Megaphone,
  ListPlus,
  Search,
  Edit3,
  Trash2,
  Filter,
  Check,
  ExternalLink
} from 'lucide-react';
import { FaWhatsapp, FaPhone } from 'react-icons/fa';
import { useNavigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { canCreateFor } from '../utils/offeringPermissions';
import {
  subscribeToShops,
  subscribeToOrders,
  getMyShops,
  createLunchOrder,
  createShop,
  addMealToShop,
  updateOrderStatus,
  createTableBooking,
  updateShop,
  updateMealInShop,
  deleteMealFromShop,
  rateShop
} from '../services/lunchService';
import { uploadFiles } from '../services/upload.service';
import {
  FOOD_EMOJIS,
  generateVendorMealAI
} from '../utils/aiLunchAssistant';
import { resolveApiUrl } from '../utils/apiBaseUrl';

const formatPrice = (price) => `R${Number(price || 0).toFixed(2)}`;
const PORTION_SIZES = ['Small', 'Medium', 'Large', 'Full plate'];
const getStartingMealPrice = (meal) => {
  const prices = (meal?.portions || []).map((portion) => Number(portion.price)).filter((price) => Number.isFinite(price) && price > 0);
  return prices.length ? Math.min(...prices) : Number(meal?.price) || 0;
};
const formatMealPrice = (meal) => meal?.portions?.length ? `From ${formatPrice(getStartingMealPrice(meal))}` : formatPrice(meal?.price);

const PortionPriceFields = ({ portions = [], onChange }) => (
  <fieldset className="rounded-xl border border-gray-200 p-3 dark:border-gray-700">
    <legend className="px-1 text-[10px] font-bold uppercase tracking-wider text-gray-500">Serving sizes &amp; prices (optional)</legend>
    <p className="mb-2 text-[10px] text-gray-500 dark:text-gray-400">Add a price for each size you offer. Customers will choose one before ordering.</p>
    <div className="grid grid-cols-2 gap-2">
      {PORTION_SIZES.map((name) => (
        <label key={name} className="text-[10px] font-semibold text-gray-600 dark:text-gray-300">
          {name}
          <div className="mt-1 flex items-center rounded-lg bg-gray-50 px-2 dark:bg-gray-800">
            <span className="text-xs text-gray-400">R</span>
            <input type="number" min="0.01" max="10000" step="0.01" inputMode="decimal" aria-label={`${name} price`} value={portions.find((portion) => portion.name === name)?.price || ''} onChange={(event) => {
              const price = event.target.value;
              onChange((current) => [...current.filter((portion) => portion.name !== name), ...(price ? [{ name, price }] : [])]);
            }} className="w-full bg-transparent px-1 py-2 text-xs text-gray-900 outline-none dark:text-white" placeholder="Not offered" />
          </div>
        </label>
      ))}
    </div>
  </fieldset>
);

const getFoodRatingSummary = (shop, meal) => {
  const mealId = String(meal?.id || meal?._id || '');
  if (!shop || !mealId) return { average: 0, count: 0 };
  const ratings = (shop.reviews || [])
    .flatMap((review) => Array.isArray(review.itemRatings) ? review.itemRatings : [])
    .filter((entry) => String(entry.mealId || '') === mealId)
    .map((entry) => Number(entry.rating))
    .filter((rating) => Number.isFinite(rating) && rating >= 1 && rating <= 5);
  return {
    average: ratings.length ? ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length : 0,
    count: ratings.length
  };
};

const uploadFoodImage = async (file) => {
  if (!file || !file.type.startsWith('image/')) throw new Error('Choose an image file.');
  if (file.size > 8 * 1024 * 1024) throw new Error('Choose an image smaller than 8 MB.');

  // Primary: Upload directly to Firebase Cloud Storage for permanent cloud persistence
  try {
    const urls = await uploadFiles([file]);
    if (urls && urls[0]) return urls[0];
  } catch (cloudErr) {
    console.warn('Firebase cloud upload failed, falling back to server upload:', cloudErr);
  }

  // Fallback: upload to server endpoint
  const formData = new FormData();
  formData.append('files', file);
  const token = localStorage.getItem('access_token') || localStorage.getItem('token');
  const response = await fetch('/api/uploads', {
    method: 'POST', credentials: 'include', body: formData,
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.urls?.[0]) throw new Error(data.message || 'Photo upload failed. Please try again.');
  const apiOrigin = new URL(resolveApiUrl('/api/uploads'), window.location.origin).origin;
  return new URL(data.urls[0], apiOrigin).toString();
};

const FoodImageField = ({ label, value, onChange, emojis = FOOD_EMOJIS }) => {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [imgError, setImgError] = useState(false);
  useEffect(() => setImgError(false), [value]);
  const isImage = !imgError && typeof value === 'string' && (/^https?:\/\//i.test(value) || value.startsWith('/uploads/'));
  const handleFile = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setError(''); setUploading(true);
    try { onChange(await uploadFoodImage(file)); }
    catch (uploadError) { setError(uploadError.message || 'Photo upload failed.'); }
    finally { setUploading(false); }
  };
  return (
    <div className="col-span-2 rounded-xl border border-gray-200 dark:border-gray-700 p-3">
      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">{label}</label>
      <div className="flex items-center gap-3">
        <div className="h-14 w-14 shrink-0 rounded-xl bg-amber-50 dark:bg-gray-800 overflow-hidden flex items-center justify-center text-3xl">
          {isImage ? (
            <img
              src={value}
              alt={`${label} preview`}
              className="h-full w-full object-contain"
              onError={() => setImgError(true)}
            />
          ) : (
            (typeof value === 'string' && value.length <= 4 && !value.startsWith('/') && !value.startsWith('http')) ? value : '🍱'
          )}
        </div>
        <div className="min-w-0 flex-1 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <label className="cursor-pointer rounded-lg bg-amber-500 hover:bg-amber-600 px-3 py-2 text-xs font-bold text-white">
              {uploading ? 'Uploading…' : isImage ? 'Change photo' : 'Upload a photo'}
              <input type="file" accept="image/*" className="sr-only" disabled={uploading} onChange={handleFile} />
            </label>
            {isImage && <button type="button" onClick={() => onChange('🍱')} className="rounded-lg border border-gray-200 dark:border-gray-700 px-3 py-2 text-xs font-semibold text-gray-600 dark:text-gray-300">Use emoji</button>}
          </div>
          <select aria-label={`${label} emoji fallback`} value={isImage ? '' : value} onChange={(event) => onChange(event.target.value)} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
            {isImage && <option value="">Photo selected</option>}
            {emojis.map((emoji) => <option key={emoji.emoji} value={emoji.emoji}>{emoji.emoji} {emoji.name}</option>)}
          </select>
        </div>
      </div>
      <p className="mt-2 text-[10px] text-gray-500">Add one photo, or choose an emoji if you don’t have one.</p>
      {error && <p role="alert" className="mt-1 text-[11px] text-red-600">{error}</p>}
    </div>
  );
};

export const ShopImage = ({ image, className = '' }) => {
  const [error, setError] = useState(false);
  useEffect(() => setError(false), [image]);
  const isImage = !error && typeof image === 'string' && (
    image.startsWith('http://') ||
    image.startsWith('https://') ||
    image.startsWith('/uploads/') ||
    image.startsWith('/') ||
    image.startsWith('data:image/')
  );
  const fallbackEmoji = (typeof image === 'string' && image.length <= 4 && !image.startsWith('/') && !image.startsWith('http')) ? image : '🏪';
  return isImage
    ? <img src={image.trim()} alt="Shop" className={`object-cover ${className}`} onError={() => setError(true)} loading="lazy" />
    : <span className={className}>{fallbackEmoji}</span>;
};

export const FoodVisual = ({ visual, alt = 'Food', className = 'h-full w-full object-cover rounded-lg', emojiClassName = 'text-2xl' }) => {
  const [error, setError] = useState(false);
  useEffect(() => setError(false), [visual?.src]);
  const showImage = !error && Boolean(visual?.isImage && visual?.src);
  const imageClassName = className.replace(/\bobject-cover\b/g, 'object-contain');

  if (showImage) {
    return (
      <img
        src={visual.src.trim()}
        alt={alt}
        className={`block h-full w-full object-contain ${imageClassName}`}
        style={{ width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center' }}
        onError={() => setError(true)}
        loading="lazy"
      />
    );
  }

  return (
    <span className={emojiClassName} role="img" aria-label={alt}>
      {visual?.emoji || '🍱'}
    </span>
  );
};

const PRESET_MOODS = [
  { id: 'quick', label: '⚡ Quick Lunch' },
  { id: 'budget', label: '💰 Under R100' },
  { id: 'healthy', label: '🥗 Healthy & Fresh' },
  { id: 'comfort', label: '🍲 Comfort Food' },
];

export const FOOD_CATEGORIES = [
  { id: 'all', name: 'Full Menu', icon: '🍽️', label: 'Full Menu', desc: 'All items, pap, kotas & full selection' },
  { id: 'african', name: 'African Cuisines', icon: '🍲', label: 'African Cuisines', desc: 'Pap, stews, mogodu & traditional meals' },
  { id: 'light', name: 'Light Food', icon: '🥗', label: 'Light Food', desc: 'Salads, burgers, pies, kotas & quick bites' },
  { id: 'drinks', name: 'Soft Drinks', icon: '🥤', label: 'Soft Drinks', desc: 'Cold drinks, juices & sodas' },
  { id: 'fruits', name: 'Fruits', icon: '🍎', label: 'Fruits', desc: 'Fresh fruits & fruit salads' }
];

export const detectMealCategory = (meal) => {
  if (!meal) return 'light';
  const explicit = (meal.category || '').trim().toLowerCase();
  if (explicit) {
    if (explicit.includes('drink') || explicit.includes('beverage')) return 'drinks';
    if (explicit.includes('fruit')) return 'fruits';
    if (explicit.includes('african') || explicit.includes('traditional') || explicit.includes('cuisine')) return 'african';
    if (explicit.includes('light') || explicit.includes('snack') || explicit.includes('fast')) return 'light';
    if (explicit.includes('full') || explicit.includes('main')) return 'all';
  }

  const text = `${meal.name || ''} ${meal.description || ''} ${meal.tag || ''}`.toLowerCase();

  // 1. Soft drinks
  if (/\b(drink|drinks|soft\s*drink|soft\s*drinks|coke|coca-cola|fanta|sprite|pepsi|stoney|spar-letta|twist|water|juice|soda|beverage|cold\s*drink|milkshake|freezo|cordial|ginger\s*beer|mazoe)\b/i.test(text)) {
    return 'drinks';
  }

  // 2. Fruits
  if (/\b(fruit|fruits|apple|banana|orange|mango|grapes|pineapple|watermelon|peach|fruit\s*salad|fruit\s*bowl|fresh\s*fruit|berries)\b/i.test(text)) {
    return 'fruits';
  }

  // 3. African Cuisines: Pap, stews, mogodu, mala, samp, dombolo, hardbody, traditional
  if (/\b(pap|mogodu|mala|tripe|samp|dombolo|hardbody|stew|curry|morogo|ting|phutu|beef\s*and\s*pap|chicken\s*and\s*pap|wors\s*and\s*pap|african|traditional|seshego\s*special|braai|t-bone|giblets)\b/i.test(text) && !/\b(kota|kots|burger|sandwich|wrap)\b/i.test(meal.name || '')) {
    return 'african';
  }

  // 4. Light Food: Salad, burger, pie, kota, chips, toastie, sandwich, wrap, roll, boerewors roll, vetkoek, magwinya
  if (/\b(salad|burger|pie|kota|kots|quarter|dagwood|sphatlo|chips|fries|sandwich|toastie|wrap|roll|boerewors\s*roll|vetkoek|magwinya|hot\s*dog|light\s*food|snack)\b/i.test(text)) {
    return 'light';
  }

  if (/\b(beef|chicken|pork|steak|wors|meat)\b/i.test(text)) {
    return 'african';
  }

  return 'light';
};

export const getCategoryBadge = (meal) => {
  const cat = detectMealCategory(meal);
  return FOOD_CATEGORIES.find(c => c.id === cat) || { id: 'light', name: 'Light Food', icon: '🥗' };
};

export const VENDOR_DEFAULT_SIDES = [
  'Chakalaka',
  'Potatoes',
  'Spinach',
  'Sweet Potato',
  'Beets',
  'Cabbage',
  'Pumpkin',
  'Atchar',
  'Pap',
  'Salad'
];

// Returns sides only when explicitly added by the vendor or detected in the meal description.
// Never falls back to default sides — items like kotas, drinks, and chips have zero sides unless specified.
export const getAvailableSides = (meal) => {
  if (!meal) return [];
  // 1. Explicit sides provided in meal.sides
  if (Array.isArray(meal.sides) && meal.sides.length > 0) {
    return meal.sides.filter(Boolean);
  }

  const name = (meal.name || '').toLowerCase();
  const tag = (meal.tag || '').toLowerCase();

  // Beverages never have sides
  if (tag === 'drinks' || /\b(juice|coke|fanta|sprite|pepsi|water|soda|milkshake|ginger\s*beer|mazoe|freezo|cold\s*drink)\b/i.test(name)) {
    return [];
  }

  // 2. Only detect sides if the vendor explicitly added them in the description
  const desc = (meal.description || '').trim();
  if (!desc) return [];

  // Standalone kotas / slap chips already have fillings or chips, only show sides if "sides:" is explicitly mentioned in description
  if (/\b(kota|sphatlo|dagwood|slap\s*chips|chips?\s*(large|small|only)?)\b/i.test(name) && !/sides?:/i.test(desc)) {
    return [];
  }

  const found = new Set();
  const sideMatchers = [
    { name: 'Spinach', pattern: /\b(spinach|morogo)\b/i },
    { name: 'Beets', pattern: /\b(beet|beetroot|bedro[ts])\b/i },
    { name: 'Cabbage', pattern: /\bcabbage\b/i },
    { name: 'Pumpkin', pattern: /\bpumpkin\b/i },
    { name: 'Sweet Potatoes', pattern: /\bsweet\s*potato(?:es)?\b/i },
    { name: 'Mash Potatoes', pattern: /\bmash(?:ed)?\s*potato(?:es)?\b/i },
    { name: 'Potatoes', pattern: /\b(?:roast\s*)?potato(?:es)?\b/i },
    { name: 'Chakalaka', pattern: /\bch[au]k[au]laka\b/i },
    { name: 'Atchar', pattern: /\bat?char\b/i },
    { name: 'Salad', pattern: /\b(green\s*salad|garden\s*salad|fresh\s*salad|salad)\b/i },
    { name: 'Coleslaw', pattern: /\bcoleslaw\b/i },
    { name: 'Pap', pattern: /\b(pap|phutu|stywe\s*pap)\b/i },
    { name: 'Rice', pattern: /\b(yellow\s*rice|savory\s*rice|steamed\s*rice|rice)\b/i }
  ];

  sideMatchers.forEach((m) => {
    if (m.pattern.test(desc)) found.add(m.name);
  });

  return Array.from(found);
};

export const getMaxSides = (meal) => {
  if (!meal) return 0;
  const name = (meal.name || '').toLowerCase();
  const tag  = (meal.tag  || '').toLowerCase();
  // No sides for drinks
  if (tag === 'drinks' || /\b(juice|coke|fanta|sprite|pepsi|water|soda|milkshake|ginger\s*beer|mazoe|freezo|cold\s*drink)\b/i.test(name)) return 0;
  // No sides for standalone snacks / kotas / chips unless sides are explicitly present
  const sides = getAvailableSides(meal);
  if (!sides || sides.length === 0) return 0;

  if (/\b(kota|sphatlo|dagwood|slap\s*chips|chips?\s*(large|small|only)?|onion\s*rings|magwinya|vetkoek|boerewors\s*roll|fried\s*egg\s*roll)\b/i.test(name)) {
    if (!meal.sides?.length && !/sides?:/i.test(meal.description || '')) return 0;
  }

  const text = (name + ' ' + (meal.description || '')).toLowerCase();
  if (/(?:four|4)\s*sides?/i.test(text)) return Math.min(4, sides.length);
  if (/(?:two|2)\s*sides?/i.test(text)) return Math.min(2, sides.length);
  if (/(?:one|1)\s*side\b/i.test(text)) return 1;
  return Math.min(3, sides.length);
};

const SHOP_THEMES = [
  {
    id: 'amber',
    badge: 'bg-amber-500 text-white',
    badgeLight: 'bg-amber-100 text-amber-900 border border-amber-300',
    cardActive: 'border-amber-500 bg-gradient-to-br from-amber-50 via-white to-orange-50 ring-2 ring-amber-400 shadow-amber-500/25 shadow-lg',
    cardNormal: 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-amber-300',
    heroBg: 'from-amber-500 via-orange-500 to-rose-600 border-amber-400/50 text-white',
    heroGlow: 'bg-amber-300/35',
    btnPrimary: 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white hover:from-amber-600 hover:to-rose-600 shadow-amber-500/30',
    tabActive: 'bg-amber-500 text-white shadow-md',
    accentText: 'text-amber-600',
    priceText: 'text-amber-700 font-black',
    accentBg: 'bg-amber-500'
  },
  {
    id: 'emerald',
    badge: 'bg-emerald-600 text-white',
    badgeLight: 'bg-emerald-100 text-emerald-900 border border-emerald-300',
    cardActive: 'border-emerald-500 bg-gradient-to-br from-emerald-50 via-white to-teal-50 ring-2 ring-emerald-400 shadow-emerald-500/25 shadow-lg',
    cardNormal: 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-emerald-300',
    heroBg: 'from-emerald-600 via-teal-600 to-cyan-600 border-emerald-400/50 text-white',
    heroGlow: 'bg-emerald-300/35',
    btnPrimary: 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:from-emerald-600 hover:to-teal-600 shadow-emerald-500/30',
    tabActive: 'bg-emerald-600 text-white shadow-md',
    accentText: 'text-emerald-600',
    priceText: 'text-emerald-700 font-black',
    accentBg: 'bg-emerald-500'
  },
  {
    id: 'rose',
    badge: 'bg-rose-600 text-white',
    badgeLight: 'bg-rose-100 text-rose-900 border border-rose-300',
    cardActive: 'border-rose-500 bg-gradient-to-br from-rose-50 via-white to-orange-50 ring-2 ring-rose-400 shadow-rose-500/25 shadow-lg',
    cardNormal: 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-rose-300',
    heroBg: 'from-rose-600 via-red-600 to-amber-500 border-rose-400/50 text-white',
    heroGlow: 'bg-rose-300/35',
    btnPrimary: 'bg-gradient-to-r from-rose-500 to-red-600 text-white hover:from-rose-600 hover:to-red-700 shadow-rose-500/30',
    tabActive: 'bg-rose-600 text-white shadow-md',
    accentText: 'text-rose-600',
    priceText: 'text-rose-700 font-black',
    accentBg: 'bg-rose-500'
  },
  {
    id: 'purple',
    badge: 'bg-purple-600 text-white',
    badgeLight: 'bg-purple-100 text-purple-900 border border-purple-300',
    cardActive: 'border-purple-500 bg-gradient-to-br from-purple-50 via-white to-pink-50 ring-2 ring-purple-400 shadow-purple-500/25 shadow-lg',
    cardNormal: 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-purple-300',
    heroBg: 'from-purple-600 via-indigo-600 to-rose-500 border-purple-400/50 text-white',
    heroGlow: 'bg-purple-300/35',
    btnPrimary: 'bg-gradient-to-r from-purple-500 to-pink-600 text-white hover:from-purple-600 hover:to-pink-700 shadow-purple-500/30',
    tabActive: 'bg-purple-600 text-white shadow-md',
    accentText: 'text-purple-600',
    priceText: 'text-purple-700 font-black',
    accentBg: 'bg-purple-500'
  },
  {
    id: 'cyan',
    badge: 'bg-cyan-600 text-white',
    badgeLight: 'bg-cyan-100 text-cyan-900 border border-cyan-300',
    cardActive: 'border-cyan-500 bg-gradient-to-br from-cyan-50 via-white to-sky-50 ring-2 ring-cyan-400 shadow-cyan-500/25 shadow-lg',
    cardNormal: 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 hover:border-cyan-300',
    heroBg: 'from-sky-500 via-blue-600 to-teal-500 border-sky-400/50 text-white',
    heroGlow: 'bg-sky-300/35',
    btnPrimary: 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700 shadow-cyan-500/30',
    tabActive: 'bg-cyan-600 text-white shadow-md',
    accentText: 'text-cyan-600',
    priceText: 'text-cyan-700 font-black',
    accentBg: 'bg-cyan-500'
  }
];

function getShopTheme(shop) {
  if (!shop) return SHOP_THEMES[0];
  const str = String(shop.id || shop.name || 'default');
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash += str.charCodeAt(i);
  return SHOP_THEMES[hash % SHOP_THEMES.length];
}

// Visual Picture / Avatar resolver for Food Items on Receipts
export const getItemVisual = (it) => {
  if (!it) return { emoji: '🍱', isImage: false, src: '' };

  const resolveFallbackEmoji = () => {
    if (it.image && typeof it.image === 'string' && it.image.length <= 4 && !it.image.startsWith('/') && !it.image.startsWith('http')) {
      return it.image;
    }
    const name = String(it.name || '').toLowerCase();
    if (name.includes('kota') || name.includes('quarter') || name.includes('sphatlo') || name.includes('sandwich') || name.includes('dagwood')) {
      return '🥪';
    }
    if (name.includes('burger') || name.includes('patty') || name.includes('cheeseburger')) {
      return '🍔';
    }
    if (name.includes('pizza') || name.includes('slice')) {
      return '🍕';
    }
    if (name.includes('wing') || name.includes('chicken') || name.includes('drumstick') || name.includes('grilled chicken')) {
      return '🍗';
    }
    if (name.includes('chip') || name.includes('fries') || name.includes('slap chips')) {
      return '🍟';
    }
    if (name.includes('wrap') || name.includes('shawarma') || name.includes('burrito')) {
      return '🌯';
    }
    if (name.includes('drink') || name.includes('coke') || name.includes('soda') || name.includes('juice') || name.includes('beverage') || name.includes('water')) {
      return '🥤';
    }
    if (name.includes('steak') || name.includes('beef') || name.includes('ribs') || name.includes('pork') || name.includes('wors') || name.includes('braai')) {
      return '🥩';
    }
    if (name.includes('fish') || name.includes('hake') || name.includes('seafood') || name.includes('prawn')) {
      return '🐟';
    }
    if (name.includes('pap') || name.includes('stew') || name.includes('curry') || name.includes('mogodu') || name.includes('mala') || name.includes('samp')) {
      return '🍲';
    }
    if (name.includes('salad') || name.includes('greens') || name.includes('veg')) {
      return '🥗';
    }
    if (name.includes('cake') || name.includes('dessert') || name.includes('ice cream') || name.includes('waffle') || name.includes('donut')) {
      return '🍰';
    }
    return '🍱';
  };

  const fallbackEmoji = resolveFallbackEmoji();

  if (it.image && (typeof it.image === 'string') && (it.image.startsWith('http') || it.image.startsWith('/') || it.image.startsWith('data:'))) {
    return { emoji: fallbackEmoji, isImage: true, src: it.image };
  }
  if (it.imageUrl && (typeof it.imageUrl === 'string') && (it.imageUrl.startsWith('http') || it.imageUrl.startsWith('/'))) {
    return { emoji: fallbackEmoji, isImage: true, src: it.imageUrl };
  }
  return { emoji: fallbackEmoji, isImage: false, src: '' };
};

// Dynamic Receipt Themes (Distinct colored paper backgrounds for receipts)
export const RECEIPT_THEMES = [
  {
    id: 'amber',
    bg: 'bg-gradient-to-b from-[#fffbf2] via-[#ffffff] to-[#fff7e6] dark:from-[#211a10] dark:via-[#19150e] dark:to-[#14100b]',
    border: 'border-amber-400/90 dark:border-amber-700/80',
    barcodeText: 'text-amber-900/60 dark:text-amber-300/60',
    accentText: 'text-amber-950 dark:text-amber-200',
    stampBg: 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950/80 dark:text-amber-300 dark:border-amber-700',
    codeBg: 'from-amber-600 via-orange-500 to-amber-600',
    headerBg: 'bg-amber-100/90 dark:bg-amber-900/40 text-amber-950 dark:text-amber-200 border-amber-300/60',
    priceText: 'text-amber-700 dark:text-amber-400',
    pill: 'bg-amber-500 text-white',
    ring: 'ring-amber-400/40'
  },
  {
    id: 'emerald',
    bg: 'bg-gradient-to-b from-[#f3fbf7] via-[#ffffff] to-[#e7f8ef] dark:from-[#0d1f16] dark:via-[#091710] dark:to-[#07130d]',
    border: 'border-emerald-400/90 dark:border-emerald-700/80',
    barcodeText: 'text-emerald-900/60 dark:text-emerald-300/60',
    accentText: 'text-emerald-950 dark:text-emerald-200',
    stampBg: 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950/80 dark:text-emerald-300 dark:border-emerald-700',
    codeBg: 'from-emerald-600 via-teal-500 to-emerald-600',
    headerBg: 'bg-emerald-100/90 dark:bg-emerald-900/40 text-emerald-950 dark:text-emerald-200 border-emerald-300/60',
    priceText: 'text-emerald-700 dark:text-emerald-400',
    pill: 'bg-emerald-600 text-white',
    ring: 'ring-emerald-400/40'
  },
  {
    id: 'terracotta',
    bg: 'bg-gradient-to-b from-[#fff6f0] via-[#ffffff] to-[#ffede0] dark:from-[#24150e] dark:via-[#1a0e08] dark:to-[#140b06]',
    border: 'border-orange-400/90 dark:border-orange-700/80',
    barcodeText: 'text-orange-900/60 dark:text-orange-300/60',
    accentText: 'text-orange-950 dark:text-orange-200',
    stampBg: 'bg-orange-100 text-orange-900 border-orange-300 dark:bg-orange-950/80 dark:text-orange-300 dark:border-orange-700',
    codeBg: 'from-orange-600 via-rose-500 to-orange-600',
    headerBg: 'bg-orange-100/90 dark:bg-orange-900/40 text-orange-950 dark:text-orange-200 border-orange-300/60',
    priceText: 'text-orange-700 dark:text-orange-400',
    pill: 'bg-orange-500 text-white',
    ring: 'ring-orange-400/40'
  },
  {
    id: 'violet',
    bg: 'bg-gradient-to-b from-[#fbf5ff] via-[#ffffff] to-[#f4e8ff] dark:from-[#1b1026] dark:via-[#130b1c] dark:to-[#0d0714]',
    border: 'border-purple-400/90 dark:border-purple-700/80',
    barcodeText: 'text-purple-900/60 dark:text-purple-300/60',
    accentText: 'text-purple-950 dark:text-purple-200',
    stampBg: 'bg-purple-100 text-purple-900 border-purple-300 dark:bg-purple-950/80 dark:text-purple-300 dark:border-purple-700',
    codeBg: 'from-purple-600 via-indigo-500 to-purple-600',
    headerBg: 'bg-purple-100/90 dark:bg-purple-900/40 text-purple-950 dark:text-purple-200 border-purple-300/60',
    priceText: 'text-purple-700 dark:text-purple-400',
    pill: 'bg-purple-600 text-white',
    ring: 'ring-purple-400/40'
  },
  {
    id: 'cyan',
    bg: 'bg-gradient-to-b from-[#f0faff] via-[#ffffff] to-[#e0f4ff] dark:from-[#0e1d24] dark:via-[#09151c] dark:to-[#060f14]',
    border: 'border-sky-400/90 dark:border-sky-700/80',
    barcodeText: 'text-sky-900/60 dark:text-sky-300/60',
    accentText: 'text-sky-950 dark:text-sky-200',
    stampBg: 'bg-sky-100 text-sky-900 border-sky-300 dark:bg-sky-950/80 dark:text-sky-300 dark:border-sky-700',
    codeBg: 'from-sky-600 via-blue-500 to-sky-600',
    headerBg: 'bg-sky-100/90 dark:bg-sky-900/40 text-sky-950 dark:text-sky-200 border-sky-300/60',
    priceText: 'text-sky-700 dark:text-sky-400',
    pill: 'bg-sky-600 text-white',
    ring: 'ring-sky-400/40'
  }
];

export const getReceiptTheme = (ord) => {
  if (!ord) return RECEIPT_THEMES[0];
  const str = String(ord.id || ord._id || ord.orderCode || 'receipt');
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash += str.charCodeAt(i);
  return RECEIPT_THEMES[hash % RECEIPT_THEMES.length];
};

// 1-Hour Preparation Countdown for Kitchen & Store Owner
export const isOneHourPrepRush = (ord) => {
  if (!ord || ord.status === 'Completed' || ord.status === 'Cancelled') return false;
  const now = Date.now();
  if (ord.scheduledFor) {
    const scheduledTime = new Date(ord.scheduledFor).getTime();
    if (!Number.isNaN(scheduledTime)) {
      const diffMinutes = (scheduledTime - now) / (1000 * 60);
      return diffMinutes <= 60 && diffMinutes >= -30;
    }
  }
  const createdTime = new Date(ord.createdAt || ord.date || now).getTime();
  const elapsedMinutes = (now - createdTime) / (1000 * 60);
  return ord.status === 'Pending' || (ord.status === 'Preparing' && elapsedMinutes >= 15);
};

// Overdue Collection Reminder (Customer collection prompt)
export const isCollectionOverdue = (ord) => {
  if (!ord || ord.status === 'Completed' || ord.status === 'Cancelled') return false;
  const now = Date.now();
  if (ord.scheduledFor) {
    const scheduledTime = new Date(ord.scheduledFor).getTime();
    if (!Number.isNaN(scheduledTime) && now > scheduledTime) {
      return true;
    }
  }
  if (ord.status === 'Ready for Collection') {
    const readyTime = new Date(ord.updatedAt || ord.createdAt || now).getTime();
    const elapsedMinutes = (now - readyTime) / (1000 * 60);
    return elapsedMinutes > 15;
  }
  return false;
};

// Formats Collection Date, Collection Time, and Placed Date/Time for receipts
export const formatCollectionDateTime = (ord) => {
  if (!ord) {
    return {
      dateStr: 'Today',
      timeStr: 'ASAP',
      placedStr: 'Recently',
      full: 'Today ASAP',
      label: 'Collection Time',
      badgeTone: 'bg-amber-100 text-amber-900 border-amber-300',
      isScheduled: false
    };
  }

  // If customer scheduled a specific future date and time
  if (ord.scheduledFor) {
    const scheduledDate = new Date(ord.scheduledFor);
    if (!Number.isNaN(scheduledDate.getTime())) {
      const dateStr = scheduledDate.toLocaleDateString('en-ZA', {
        weekday: 'short',
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
      const timeStr = scheduledDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const placedStr = ord.createdAt
        ? new Date(ord.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
        : 'Earlier';

      return {
        dateStr,
        timeStr,
        placedStr,
        full: `${dateStr} at ${timeStr}`,
        label: 'Scheduled Collection',
        badgeTone: 'bg-purple-100 text-purple-900 border-purple-300 dark:bg-purple-950 dark:text-purple-200',
        isScheduled: true
      };
    }
  }

  // Default immediate pickup (calc ~20-30 min prep)
  const created = new Date(ord.createdAt || ord.date || Date.now());
  const dateStr = created.toLocaleDateString('en-ZA', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
  const estPickup = new Date(created.getTime() + 25 * 60 * 1000);
  const timeStr = `~${estPickup.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  const placedStr = `${dateStr}, ${created.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

  return {
    dateStr,
    timeStr,
    placedStr,
    full: `${dateStr} at ${timeStr} (Est. ~25 min prep)`,
    label: 'Estimated Collection',
    badgeTone: 'bg-emerald-100 text-emerald-900 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-200',
    isScheduled: false
  };
};

export default function LunchComingSoon() {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser } = useSelector((state) => state.user || {});

  // Track whether we've auto-set the initial shop selection (prevents stale-closure reset)
  const hasInitializedShopRef = useRef(false);

  // Ref for the horizontal meals/menu slider
  const menuSliderRef = useRef(null);
  const scrollMenu = (dir) => {
    if (menuSliderRef.current) {
      menuSliderRef.current.scrollBy({ left: dir * 260, behavior: 'smooth' });
    }
  };

  // ── 3 Primary Navigation Tabs: 'orders' (Customer Order Food Manager) | 'my-menu' (Your Menus) | 'other-shops' (Other Shops & Menus)
  const [activeTab, setActiveTab] = useState(() => {
    if (location.state?.tab) return location.state.tab;
    if (location.state?.selectedShopId) return 'other-shops';
    return 'explore'; // Default: Customer-first food browsing & ordering!
  });

  // Filter & Search states for orders & menus
  const [orderFilterTab, setOrderFilterTab] = useState('all'); // 'all' | 'pending' | 'preparing' | 'ready' | 'completed'
  const [ownerFoodTab, setOwnerFoodTab] = useState('kitchen'); // 'kitchen' | 'menu'
  const [orderSearchText, setOrderSearchText] = useState('');
  const [myMenuSearchText, setMyMenuSearchText] = useState('');
  const [myMenuTagFilter, setMyMenuTagFilter] = useState('All');

  // Customer state
  const [orderMode, setOrderMode] = useState('order'); // 'order' or 'table'
  const [fulfilment] = useState('pickup');
  const [shops, setShops] = useState([]);
  // Authoritative list of this user's shops, fetched from the server using the JWT.
  // Used instead of client-side UID filtering to prevent ownership mismatches
  // when the persisted Redux currentUser._id is stale.
  const [serverMyShops, setServerMyShops] = useState(null); // null = not yet loaded
  const [selectedShopId, setSelectedShopId] = useState('');
  const [allFoodSearch, setAllFoodSearch] = useState('');
  const [isShopDetailOpen, setIsShopDetailOpen] = useState(Boolean(location.state?.selectedShopId));
  const [cart, setCart] = useState([]);
  const [selectedMealSides, setSelectedMealSides] = useState({});
  const [orders, setOrders] = useState([]);
  const [notice, setNotice] = useState(null);

  // AI Matchmaker states
  const [showAiLunchSection, setShowAiLunchSection] = useState(false);
  const [selectedMood, setSelectedMood] = useState('quick');
  const [customFoodQuery, setCustomFoodQuery] = useState('');
  const [aiMealMatches, setAiMealMatches] = useState([]);
  const [aiRecommendationIndex, setAiRecommendationIndex] = useState(0);

  const handleRunAiMatchmaker = (mood, query = '') => {
    setSelectedMood(mood);
    if (query) setCustomFoodQuery(query);
    setAiRecommendationIndex(0);
  };

  // Form states for checkout & delivery
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showBasketPreview, setShowBasketPreview] = useState(false);
  const [selectedFeaturedMeal, setSelectedFeaturedMeal] = useState(null);
  const [zoomedFoodImage, setZoomedFoodImage] = useState(null);
  const [checkoutData, setCheckoutData] = useState({
    customerName: currentUser?.username || currentUser?.name || '',
    customerPhone: currentUser?.phone || '',
    deliveryAddress: currentUser?.address || '',
    deliveryNotes: '',
    orderComments: '',
    scheduledFor: '',
    paymentMethod: 'counter' // 'counter' | 'delivery' | 'online'
  });

  // Table booking state
  const [booking, setBooking] = useState({ date: '', time: '12:30', guests: '2', name: currentUser?.username || '', phone: '' });

  // Shop Owner Modals
  const [showAddShopModal, setShowAddShopModal] = useState(false);
  const [newShopForm, setNewShopForm] = useState({
    name: '',
    cuisine: '',
    distance: '1.5 km',
    time: '20–30 min',
    image: '🥙',
    address: '',
    phone: '',
    whatsapp: '',
    operatingHours: {
      openTime: '08:00',
      closeTime: '20:00',
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
    },
    isOpen: true
  });

  const [showAddMealModal, setShowAddMealModal] = useState(false);
  const [newMealForm, setNewMealForm] = useState({
    name: '',
    description: '',
    price: '',
    tag: 'Popular',
    category: 'Full Menu',
    itemType: 'meal',
    image: '🍱',
    sides: [],
    portions: []
  });
  const [selectedPortionName, setSelectedPortionName] = useState('');

  // Edit states
  const [showEditShopModal, setShowEditShopModal] = useState(false);
  const [editShopForm, setEditShopForm] = useState({
    id: '',
    name: '',
    cuisine: '',
    distance: '',
    time: '',
    image: '',
    address: '',
    phone: '',
    whatsapp: '',
    operatingHours: {
      openTime: '08:00',
      closeTime: '20:00',
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
    },
    isOpen: true
  });

  const [showEditMealModal, setShowEditMealModal] = useState(false);
  const [editMealForm, setEditMealForm] = useState({
    id: '',
    name: '',
    description: '',
    price: '',
    tag: 'Popular',
    category: 'Full Menu',
    itemType: 'meal',
    image: '🍱',
    sides: [],
    portions: []
  });

  // Selected Order for Receipt Modal
  const [activeReceiptOrder, setActiveReceiptOrder] = useState(null);

  // Contact Card Modal
  const [showContactCard, setShowContactCard] = useState(false);

  // Rating states
  const [showRateModal, setShowRateModal] = useState(false);
  const [ratingTargetOrder, setRatingTargetOrder] = useState(null);
  const [shopRating, setShopRating] = useState(5);
  const [itemRatings, setItemRatings] = useState({});
  const [ratingComment, setRatingComment] = useState('');
  const [showReviewsTab, setShowReviewsTab] = useState(false);

  // "View More" toggles for orders
  const [showAllKitchenQueue, setShowAllKitchenQueue] = useState(false);
  const [showAllCompletedOrders, setShowAllCompletedOrders] = useState(false);
  const [showAllCustomerReceipts, setShowAllCustomerReceipts] = useState(false);
  const [showPastCustomerReceipts, setShowPastCustomerReceipts] = useState(false);

  // Customer menu discovery controls
  const [shopSearch, setShopSearch] = useState('');
  const [menuSearch, setMenuSearch] = useState('');
  const [menuTagFilter, setMenuTagFilter] = useState('All');
  const [selectedFoodCategory, setSelectedFoodCategory] = useState('all'); // 'all' | 'african' | 'light' | 'drinks' | 'fruits'

  const handleAiAutoFillMeal = (isEdit = false) => {
    const targetForm = isEdit ? editMealForm : newMealForm;
    const aiResult = generateVendorMealAI(targetForm.name);
    if (isEdit) {
      setEditMealForm(prev => ({
        ...prev,
        name: aiResult.name,
        description: aiResult.description,
        price: aiResult.price,
        tag: aiResult.tag,
        category: aiResult.category || 'Full Menu',
        image: aiResult.image
      }));
    } else {
      setNewMealForm(prev => ({
        ...prev,
        name: aiResult.name,
        description: aiResult.description,
        price: aiResult.price,
        tag: aiResult.tag,
        category: aiResult.category || 'Full Menu',
        image: aiResult.image
      }));
    }
  };

  // Handle Submit Rating
  const handleRatingSubmit = async (e) => {
    e.preventDefault();
    if (!ratingTargetOrder) return;
    const orderId = ratingTargetOrder.id || ratingTargetOrder._id;
    if (ratingTargetOrder.status !== 'Completed') {
      setNotice({ type: 'error', message: 'Confirm that you received your order before rating the shop.' });
      return;
    }
    const itemsToRate = ratingTargetOrder.items || [];
    const itemRatingsPayload = itemsToRate.map((item, itemIndex) => ({
      itemIndex,
      mealId: item.id || '',
      mealName: item.name || 'Food item',
      rating: Number(itemRatings[itemIndex]) || 0
    }));
    if (!itemsToRate.length || itemRatingsPayload.some((item) => item.rating < 1 || item.rating > 5)) {
      setNotice({ type: 'error', message: 'Please rate every food item in this order before submitting.' });
      return;
    }
    const foodRating = Math.round(itemRatingsPayload.reduce((total, item) => total + item.rating, 0) / itemRatingsPayload.length);
    const submittedRating = { shopRating, foodRating, itemRatings: itemRatingsPayload, comment: ratingComment };
    try {
      await rateShop(ratingTargetOrder.shopId, {
        orderId: orderId,
        shopRating,
        foodRating,
        itemRatings: itemRatingsPayload,
        comment: ratingComment,
        userName: currentUser?.username || currentUser?.name || 'Valued Customer'
      });
      setShowRateModal(false);
      setOrders(prev => prev.map(o => (o.id === orderId || o._id === orderId) ? {
        ...o,
        isRated: true,
        status: 'Completed',
        ratingDetails: submittedRating
      } : o));
      // Close receipt modal so it completely disappears from the screen
      setActiveReceiptOrder(null);
      setNotice({ type: 'success', message: '⭐ Thank you for rating! Receipt archived to Dashboard & Order History.' });
      setRatingComment('');
    } catch (err) {
      console.error("Rate shop error:", err);
      setNotice({ type: 'error', message: err.message || 'We could not save your review. Please try again.' });
    }
  };

  // Only the customer confirms receipt. A pickup order left ready will be closed by the server after two hours.
  const handleStatusUpdate = async (orderId, newStatus) => {
    if (!orderId) return;
    try {
      const savedOrder = await updateOrderStatus(orderId, newStatus);
      // Optimistically update orders in local state
      setOrders((prev) =>
        prev.map((o) =>
          (o.id === orderId || o._id === orderId)
            ? { ...o, status: newStatus, updatedAt: new Date().toISOString() }
            : o
        )
      );
      if (activeReceiptOrder && (activeReceiptOrder.id === orderId || activeReceiptOrder._id === orderId)) {
        setActiveReceiptOrder((prev) =>
          prev ? { ...prev, status: newStatus, updatedAt: new Date().toISOString() } : null
        );
      }
      if (newStatus === 'Completed') {
        setNotice({
          type: 'success',
          message: 'Order completed. You can now rate the shop and your meal.'
        });
        const target = orders.find((o) => o.id === orderId || o._id === orderId) || activeReceiptOrder;
        if (target && !target.isRated) {
          setShopRating(5);
          setItemRatings(Object.fromEntries((target.items || []).map((_, index) => [index, 0])));
          setRatingComment('');
          setRatingTargetOrder({ ...target, ...savedOrder, status: 'Completed' });
          setShowRateModal(true);
        }
      } else {
        setNotice({
          type: 'success',
          message: `Order status updated to "${newStatus}".`
        });
      }
    } catch (err) {
      console.error("Update order status error:", err);
      setNotice({ type: 'error', message: err.message || 'Could not update this order. Please try again.' });
    }
  };

  // Public menu polling and authenticated, private order polling.
  useEffect(() => {
    const unsubscribeShops = subscribeToShops((fetchedShops) => {
      setShops(fetchedShops);
      // Only auto-select the first shop once on initial load.
      // Using a ref avoids the stale-closure bug where selectedShopId
      // would always read '' inside this callback, resetting the user's pick.
      if (fetchedShops.length > 0 && !hasInitializedShopRef.current) {
        hasInitializedShopRef.current = true;
        const targetId = location.state?.selectedShopId;
        const matched = targetId && fetchedShops.find(s => String(s.id || s._id) === String(targetId));
        setSelectedShopId(matched ? (matched.id || matched._id) : (fetchedShops[0].id || fetchedShops[0]._id));
      }
    });

    // Fetch authoritative owned shops for the authenticated user using JWT
    if (currentUser) {
      getMyShops()
        .then((owned) => setServerMyShops(Array.isArray(owned) ? owned : []))
        .catch((err) => {
          console.warn("Could not fetch server-owned shops, falling back to client-side filter:", err);
          setServerMyShops(null);
        });
    } else {
      setServerMyShops(null);
    }

    const unsubscribeOrders = currentUser ? subscribeToOrders((fetchedOrders) => setOrders(fetchedOrders)) : () => setOrders([]);

    return () => {
      unsubscribeShops();
      unsubscribeOrders();
    };
  }, [currentUser?._id]);

  // Sync default user details when available
  useEffect(() => {
    if (currentUser) {
      setCheckoutData((prev) => ({
        ...prev,
        customerName: prev.customerName || currentUser.username || currentUser.name || 'Valued Customer',
        customerPhone: prev.customerPhone || currentUser.phone || ''
      }));
      setBooking((prev) => ({
        ...prev,
        name: prev.name || currentUser.username || currentUser.name || ''
      }));
    }
  }, [currentUser?._id]);

  // Handle direct navigation to register route or action parameter
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const isRegister =
      location.pathname.endsWith('/register') ||
      searchParams.get('action') === 'register' ||
      searchParams.get('register') === 'true';

    if (isRegister) {
      if (canCreateFor(currentUser, 'food')) {
        setShowAddShopModal(true);
      } else {
        navigate('/food', { replace: true });
        setNotice({
          type: 'error',
          message: 'Only accounts registered as a food shop owner on sign-up can register a shop. You can browse menus and order food.'
        });
      }
    }
  }, [location.pathname, location.search, currentUser, navigate]);

  // Selected active shop
  const currentShop = useMemo(() => {
    return shops.find((shop) => String(shop.id || shop._id) === String(selectedShopId)) || shops[0] || null;
  }, [shops, selectedShopId]);

  const visibleShops = useMemo(() => {
    const query = shopSearch.trim().toLowerCase();
    if (!query) return shops;
    return shops.filter((shop) => {
      const menuText = (shop.meals || []).map((meal) => `${meal.name || ''} ${meal.description || ''} ${meal.category || ''}`).join(' ');
      const searchableText = [shop.name, shop.cuisine, shop.description, shop.address, shop.location, shop.ownerName, menuText]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return searchableText.includes(query);
    });
  }, [shops, shopSearch]);

  const allFoodItems = useMemo(() => {
    const query = allFoodSearch.trim().toLowerCase();
    return shops.flatMap((shop) => (shop.meals || []).map((meal) => ({ shop, meal })))
      .filter(({ shop, meal }) => {
        if (!query) return true;
        return [meal.name, meal.description, meal.category, meal.tag, shop.name, shop.cuisine]
          .filter(Boolean)
          .join(' ')
          .toLowerCase()
          .includes(query);
      });
  }, [shops, allFoodSearch]);

  // A closed shop remains visible, but customers cannot change or submit an order.
  const isCurrentShopClosed = currentShop?.isOpen === false;
  const shopCommentReviews = (currentShop?.reviews || []).filter((review) => String(review.comment || '').trim().length > 0);

  const menuTags = useMemo(() => ['All', ...new Set((currentShop?.meals || []).map((meal) => meal.tag).filter(Boolean))], [currentShop]);

  const visibleMeals = useMemo(() => {
    const search = menuSearch.trim().toLowerCase();
    return (currentShop?.meals || []).filter((meal) => {
      const mealCat = detectMealCategory(meal);
      const matchesCategory = selectedFoodCategory === 'all' || mealCat === selectedFoodCategory;
      const matchesTag = menuTagFilter === 'All' || meal.tag === menuTagFilter;
      const matchesSearch = !search || `${meal.name || ''} ${meal.description || ''} ${meal.tag || ''}`.toLowerCase().includes(search);
      return matchesCategory && matchesTag && matchesSearch;
    });
  }, [currentShop, selectedFoodCategory, menuSearch, menuTagFilter]);

  // Unique Color Theme for the active selected shop
  const activeTheme = useMemo(() => {
    return getShopTheme(currentShop);
  }, [currentShop]);

  // Total cart calculation
  const totalCartPrice = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [cart]);

  // Shops that belong to the currently logged-in user
  const myShops = useMemo(() => {
    if (!currentUser) return [];
    // Prefer server-authoritative list (fetched via JWT) to avoid stale-Redux-state mismatches
    if (serverMyShops !== null) {
      const ownedIds = new Set(serverMyShops.map((s) => String(s.id || s._id)));
      const matchingLiveShops = shops.filter((s) => ownedIds.has(String(s.id || s._id)));
      return matchingLiveShops.length > 0 ? matchingLiveShops : serverMyShops;
    }
    const uid = String(currentUser._id || currentUser.id || 'guest');
    return shops.filter((s) => String(s.ownerId || '') === uid);
  }, [shops, currentUser, serverMyShops]);

  // Whether the current user owns at least one shop
  const isShopOwner = myShops.length > 0;

  // The shop selected on the dashboard (only owner's shops if owner, else fallback to selected or first shop)
  const dashboardShop = useMemo(() => {
    if (myShops.length > 0) {
      return myShops.find((s) => (s.id || s._id) === selectedShopId) || myShops[0];
    }
    return shops.find((s) => (s.id || s._id) === selectedShopId) || shops[0] || null;
  }, [myShops, selectedShopId, shops]);

  // Whether the current user is the owner/manager of the active dashboard shop
  const isCurrentShopOwner = useMemo(() => {
    if (!currentUser || !dashboardShop) return false;
    const uid = String(currentUser._id || currentUser.id || '');
    const inMyShops = myShops.some(
      (s) => String(s.id || s._id) === String(dashboardShop.id || dashboardShop._id)
    );
    return Boolean(
      inMyShops ||
      (uid && String(dashboardShop.ownerId || '') === uid) ||
      currentUser.isAdmin ||
      currentUser.role === 'admin'
    );
  }, [currentUser, dashboardShop, myShops]);

  // Other shops (excluding the current user's active dashboard shop)
  const otherShops = useMemo(() => {
    if (!dashboardShop) return shops;
    const shopIdStr = String(dashboardShop.id || dashboardShop._id || '');
    const filtered = shops.filter((s) => String(s.id || s._id || '') !== shopIdStr);
    return filtered.length > 0 ? filtered : shops;
  }, [shops, dashboardShop]);

  // Filter active (uncompleted) orders for customer view receipt section
  const myCustomerOrders = useMemo(() => {
    if (!currentUser) return [];
    const uid = String(currentUser?._id || currentUser?.id || '');
    return orders.filter((o) => {
      const matchId = uid && String(o.customerId || o.customer?._id || o.userId || '') === uid;
      const matchPhone = currentUser?.phone && o.customerPhone && o.customerPhone === currentUser.phone;
      return (matchId || matchPhone) && o.status !== 'Completed';
    });
  }, [orders, currentUser]);

  // Completed orders for customer past history / receipts
  const myCompletedCustomerOrders = useMemo(() => {
    if (!currentUser) return [];
    const uid = String(currentUser?._id || currentUser?.id || '');
    return orders.filter((o) => {
      const matchId = uid && String(o.customerId || o.customer?._id || o.userId || '') === uid;
      const matchPhone = currentUser?.phone && o.customerPhone && o.customerPhone === currentUser.phone;
      return (matchId || matchPhone) && o.status === 'Completed';
    });
  }, [orders, currentUser]);

  // All orders for the current dashboard shop
  const activeShopOrders = useMemo(() => {
    if (!dashboardShop) return [];
    const shopIdStr = String(dashboardShop.id || dashboardShop._id || '');
    return orders.filter((o) => String(o.shopId || '') === shopIdStr);
  }, [orders, dashboardShop]);

  const pendingOrders = useMemo(() => activeShopOrders.filter((o) => o.status === 'Pending'), [activeShopOrders]);
  const preparingOrders = useMemo(() => activeShopOrders.filter((o) => o.status === 'Preparing'), [activeShopOrders]);
  const readyOrders = useMemo(() => activeShopOrders.filter((o) => o.status === 'Ready for Collection'), [activeShopOrders]);
  const completedOrders = useMemo(() => activeShopOrders.filter((o) => o.status === 'Completed'), [activeShopOrders]);

  const pendingOrdersCount = pendingOrders.length;
  const preparingOrdersCount = preparingOrders.length;
  const readyOrdersCount = readyOrders.length;
  const completedOrdersCount = completedOrders.length;

  const filteredShopOrders = useMemo(() => {
    let list = activeShopOrders;
    if (orderFilterTab === 'pending') {
      list = pendingOrders;
    } else if (orderFilterTab === 'preparing') {
      list = preparingOrders;
    } else if (orderFilterTab === 'ready') {
      list = readyOrders;
    } else if (orderFilterTab === 'completed') {
      list = completedOrders;
    }
    if (orderSearchText.trim()) {
      const q = orderSearchText.toLowerCase();
      list = list.filter((o) =>
        (o.orderCode || '').toLowerCase().includes(q) ||
        (o.customerName || '').toLowerCase().includes(q) ||
        (o.customerPhone || '').toLowerCase().includes(q) ||
        (o.items || []).some((it) => (it.name || '').toLowerCase().includes(q))
      );
    }
    return list;
  }, [activeShopOrders, orderFilterTab, orderSearchText, pendingOrders, preparingOrders, readyOrders, completedOrders]);

  const myMenuTags = useMemo(() => {
    const tags = new Set((dashboardShop?.meals || []).map((m) => m.tag).filter(Boolean));
    return ['All', ...tags];
  }, [dashboardShop]);

  const visibleMyMeals = useMemo(() => {
    const search = myMenuSearchText.trim().toLowerCase();
    return (dashboardShop?.meals || []).filter((meal) => {
      const matchesTag = myMenuTagFilter === 'All' || meal.tag === myMenuTagFilter;
      const matchesSearch = !search || `${meal.name || ''} ${meal.description || ''} ${meal.tag || ''}`.toLowerCase().includes(search);
      return matchesTag && matchesSearch;
    });
  }, [dashboardShop, myMenuSearchText, myMenuTagFilter]);

  // Live kitchen queue for shop owner (uncompleted orders)
  const liveKitchenQueue = useMemo(() => {
    return activeShopOrders.filter((o) => o.status !== 'Completed');
  }, [activeShopOrders]);

  // Active kitchen queue for currently selected shop (visible to all customers)
  const activeKitchenOrders = useMemo(() => {
    if (!currentShop) return [];
    const shopId = String(currentShop.id || currentShop._id || '');
    return orders.filter((o) => String(o.shopId || '') === shopId && o.status !== 'Completed');
  }, [orders, currentShop]);

  const popularShopMeals = useMemo(() => {
    if (!currentShop) return [];
    const shopId = String(currentShop.id || currentShop._id || '');
    const salesByName = orders
      .filter((order) => String(order.shopId || '') === shopId && order.status === 'Completed')
      .flatMap((order) => order.items || [])
      .reduce((sales, item) => {
        const name = String(item.name || '').trim().toLowerCase();
        if (name) sales[name] = (sales[name] || 0) + Number(item.quantity || 1);
        return sales;
      }, {});
    const meals = currentShop.meals || [];
    const bestSellers = meals
      .map((meal) => ({ ...meal, completedSales: salesByName[String(meal.name || '').trim().toLowerCase()] || 0 }))
      .filter((meal) => meal.completedSales > 0)
      .sort((a, b) => b.completedSales - a.completedSales)
      .slice(0, 3);
    const taggedPicks = meals
      .filter((meal) => meal.isPopular || meal.isFeatured || meal.isSpecial || ['combo', 'special'].includes(String(meal.itemType || '').toLowerCase()) || /popular|special|combo|meal deal|bundle/i.test(`${meal.name || ''} ${meal.tag || ''} ${meal.category || ''} ${meal.description || ''}`))
      .map((meal) => ({ ...meal, completedSales: 0 }));
    const bestSellerNames = new Set(bestSellers.map((meal) => String(meal.name || '').trim().toLowerCase()));
    return [
      ...bestSellers.slice(0, 2),
      ...taggedPicks.filter((meal) => !bestSellerNames.has(String(meal.name || '').trim().toLowerCase()))
    ].slice(0, 3);
  }, [currentShop, orders]);

  // Completed orders history for shop owner
  const completedStoreOrders = completedOrders;

  // 1-Hour Preparation Rush Orders for Chef & Store Owner
  const rushOrdersCount = useMemo(() => {
    return liveKitchenQueue.filter(isOneHourPrepRush).length;
  }, [liveKitchenQueue]);

  // Customer orders waiting at counter past collection time
  const customerOverdueOrders = useMemo(() => {
    return myCustomerOrders.filter(isCollectionOverdue);
  }, [myCustomerOrders]);

  // Turn the owner's real menu, order and review data into a short, actionable plan.
  const shopInsights = useMemo(() => {
    if (!dashboardShop) return [];

    const meals = dashboardShop.meals || [];
    const completedOrders = activeShopOrders.filter((order) => order.status === 'Completed');
    const mealSales = completedOrders.flatMap((order) => order.items || []).reduce((totals, item) => {
      totals[item.name] = (totals[item.name] || 0) + Number(item.quantity || 0);
      return totals;
    }, {});
    const bestSeller = Object.entries(mealSales).sort(([, a], [, b]) => b - a)[0];
    const reviews = dashboardShop.reviews || [];
    const averageRating = reviews.length
      ? reviews.reduce((total, review) => total + Number(review.shopRating || review.rating || 0), 0) / reviews.length
      : Number(dashboardShop.rating || 0);
    const insights = [];

    if (dashboardShop.isOpen === false) {
      insights.push({ title: 'Reopen when you can serve orders', detail: 'Your menu remains visible, but customers cannot buy while the shop is closed.', tone: 'amber' });
    }
    if (meals.length < 4) {
      insights.push({ title: 'Expand your menu to at least 4 choices', detail: 'Add a value meal, a popular main, a vegetarian option and a drink or side so more customers find something suitable.', tone: 'violet' });
    }
    if (meals.some((meal) => !meal.description?.trim())) {
      insights.push({ title: 'Add descriptions to every menu item', detail: 'Briefly name the key ingredients, portion or heat level to make customers more confident before ordering.', tone: 'sky' });
    }
    if (bestSeller) {
      insights.push({ title: `Promote ${bestSeller[0]}`, detail: `It is your top completed-order item (${bestSeller[1]} sold). Feature it as “Popular” and pair it with a drink or side.`, tone: 'emerald' });
    } else {
      insights.push({ title: 'Create your first repeatable bestseller', detail: 'Start with one clearly priced signature meal, keep it available daily and ask early customers for feedback.', tone: 'emerald' });
    }
    if (!reviews.length) {
      insights.push({ title: 'Ask customers for a quick review', detail: 'After each completed order, invite feedback. Reviews build trust and show what to improve next.', tone: 'rose' });
    } else if (averageRating > 0 && averageRating < 4) {
      insights.push({ title: 'Follow up on customer feedback', detail: `Your average rating is ${averageRating.toFixed(1)}/5. Check recent comments for recurring issues with quality, portions or delivery time.`, tone: 'rose' });
    }

    return insights.slice(0, 4);
  }, [dashboardShop, activeShopOrders]);

  // Revenue belongs only to the selected shop and is counted when an order is completed.
  const revenueSummary = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now);
    startOfToday.setHours(0, 0, 0, 0);

    // Weeks run Monday through Sunday.
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setDate(startOfWeek.getDate() - ((startOfWeek.getDay() + 6) % 7));

    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const revenueSince = (startDate) => completedStoreOrders.reduce((total, order) => {
      const completedAt = new Date(order.completedAt || order.updatedAt || order.createdAt);
      return !Number.isNaN(completedAt.getTime()) && completedAt >= startDate
        ? total + Number(order.total || 0)
        : total;
    }, 0);

    return {
      daily: revenueSince(startOfToday),
      weekly: revenueSince(startOfWeek),
      monthly: revenueSince(startOfMonth)
    };
  }, [completedStoreOrders]);


  // Sides operations
  const getActiveSides = (meal, availableSides, maxSides = 3) => {
    if (!maxSides || !availableSides?.length) return [];
    if (selectedMealSides[meal.id] !== undefined) {
      return selectedMealSides[meal.id];
    }
    return availableSides.slice(0, maxSides);
  };

  const toggleSideForMeal = (mealId, side, availableSides, maxSides = 3) => {
    setSelectedMealSides((prev) => {
      const current = prev[mealId] !== undefined ? prev[mealId] : availableSides.slice(0, maxSides);
      if (current.includes(side)) {
        return { ...prev, [mealId]: current.filter((s) => s !== side) };
      }
      if (current.length < maxSides) {
        return { ...prev, [mealId]: [...current, side] };
      }
      return { ...prev, [mealId]: [...current.slice(1), side] };
    });
  };

  // Cart operations
  const addToCart = (meal, portionName = '') => {
    if (currentShop?.isOpen === false) {
      setNotice({ type: 'error', message: `${currentShop.name} is currently closed and cannot accept orders.` });
      return;
    }
    if (meal.isAvailable === false) {
      setNotice({ type: 'error', message: `${meal.name} is sold out.` });
      return;
    }

    const availableSides = getAvailableSides(meal);
    const maxSides = getMaxSides(meal);
    const chosenSides = availableSides.length > 0 && maxSides > 0
      ? getActiveSides(meal, availableSides, maxSides)
      : [];
    const chosenPortion = meal.portions?.find((portion) => portion.name === portionName);
    if (meal.portions?.length && !chosenPortion) {
      setNotice({ type: 'error', message: 'Choose a serving size before adding this meal.' });
      return;
    }
    const orderedMeal = chosenPortion
      ? { ...meal, price: Number(chosenPortion.price), portionName: chosenPortion.name }
      : { ...meal, portionName: '' };

    const cartKey = meal.id + (chosenPortion ? `-${chosenPortion.name}` : '') + (chosenSides.length ? '-' + chosenSides.slice().sort().join('-') : '');

    setCart((items) => {
      const existingIndex = items.findIndex((item) => (item.cartKey && item.cartKey === cartKey) || (!item.cartKey && item.id === meal.id && item.portionName === orderedMeal.portionName && JSON.stringify(item.sides || []) === JSON.stringify(chosenSides)));
      if (existingIndex > -1) {
        return items.map((item, idx) => idx === existingIndex ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...items, { ...orderedMeal, shopId: currentShop.id || currentShop._id, sides: chosenSides, cartKey, quantity: 1 }];
    });
    // Auto-show basket preview popup
    setShowBasketPreview(true);
  };

  const openFoodDetails = (meal) => {
    setSelectedPortionName('');
    setSelectedFeaturedMeal(meal);
  };

  const updateQuantity = (cartKeyOrId, change) => {
    if (isCurrentShopClosed) return;

    setCart((items) =>
      items
        .map((item) => {
          const isMatch = item.cartKey ? item.cartKey === cartKeyOrId : item.id === cartKeyOrId;
          return isMatch ? { ...item, quantity: item.quantity + change } : item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  // Submit Food Order to Firestore
  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (!cart.length || !currentShop) return;
    if (!currentUser) { navigate('/sign-in'); return; }

    if (currentShop.isOpen === false) {
      setNotice({ type: 'error', message: `${currentShop.name} is currently closed and cannot accept orders.` });
      setShowCheckoutModal(false);
      return;
    }
    const unavailableItem = cart.find((item) =>
      currentShop.meals?.find((meal) => meal.id === item.id)?.isAvailable === false
    );
    if (unavailableItem) {
      setNotice({ type: 'error', message: `${unavailableItem.name} is sold out. Remove it from your basket before ordering.` });
      setShowCheckoutModal(false);
      return;
    }

    if (!checkoutData.customerPhone) {
      alert("Please provide a contact phone number so the shop and delivery driver can reach you.");
      return;
    }

    try {
      const orderPayload = {
        customerName: checkoutData.customerName || 'Valued Customer',
        customerPhone: checkoutData.customerPhone,
        shopId: currentShop.id,
        shopName: currentShop.name,
        shopImage: currentShop.image || '🍱',
        items: cart,
        total: totalCartPrice,
        fulfilment,
        orderComments: checkoutData.orderComments,
        scheduledFor: checkoutData.scheduledFor || null
      };

      const created = await createLunchOrder(orderPayload);
      setCart([]);
      setCheckoutData((previous) => ({ ...previous, orderComments: '' }));
      setShowCheckoutModal(false);
      setActiveReceiptOrder(created);

      setNotice({
        type: 'success',
        message: `Order #${created.orderCode} placed successfully! ${'Pay at the store counter upon pickup.'
          }`
      });
    } catch (err) {
      console.error("Order error:", err);
      alert("Failed to place order. Please try again.");
    }
  };

  // Submit Table Reservation
  const handleTableBooking = async (e) => {
    e.preventDefault();
    if (!booking.name || !booking.date || !currentShop) return;
    if (!currentUser) { navigate('/sign-in'); return; }
    if (isCurrentShopClosed) {
      setNotice({ type: 'error', message: `${currentShop.name} is currently closed and cannot accept table requests.` });
      return;
    }
    try {
      await createTableBooking({
        ...booking,
        shopId: currentShop.id,
        shopName: currentShop.name,
      });
      setNotice({
        type: 'success',
        message: `Table request submitted to ${currentShop.name} for ${booking.guests} guests on ${booking.date} at ${booking.time}.`
      });
      setBooking({ date: '', time: '12:30', guests: '2', name: currentUser?.username || '', phone: '' });
    } catch (err) {
      console.error("Booking error:", err);
    }
  };

  // Handle Add Shop Modal Submit
  const handleCreateShopSubmit = async (e) => {
    e.preventDefault();
    if (!newShopForm.name) return;
    if (!canCreateFor(currentUser, 'food')) {
      setShowAddShopModal(false);
      setNotice({
        type: 'error',
        message: 'Only accounts registered as a food shop owner on sign-up can register a shop. You can browse and order food.'
      });
      return;
    }
    try {
      const newShopId = await createShop({
        ...newShopForm,
        ownerName: currentUser?.username || 'Store Manager'
      });
      setShowAddShopModal(false);
      setSelectedShopId(newShopId);
      if (currentUser) {
        getMyShops()
          .then((owned) => setServerMyShops(Array.isArray(owned) ? owned : []))
          .catch(() => {});
      }
      setNotice({ type: 'success', message: `Shop "${newShopForm.name.trim()}" created successfully!` });
      setNewShopForm({ name: '', cuisine: '', distance: '1.5 km', time: '20–30 min', image: '🥙', address: '', phone: '', whatsapp: '' });
    } catch (err) {
      console.error("Create shop error:", err);
      setNotice({
        type: 'error',
        message: err.message || `A shop with the name "${newShopForm.name}" already exists.`
      });
    }
  };

  // Handle Add Meal Modal Submit
  const handleAddMealSubmit = async (e) => {
    e.preventDefault();
    const targetShopId = dashboardShop ? (dashboardShop.id || dashboardShop._id) : selectedShopId;
    const configuredPrices = (newMealForm.portions || []).map((portion) => Number(portion.price)).filter((price) => Number.isFinite(price) && price > 0);
    const fallbackPrice = configuredPrices.length ? Math.min(...configuredPrices) : Number(newMealForm.price);
    if (!newMealForm.name || !Number.isFinite(fallbackPrice) || fallbackPrice <= 0 || !targetShopId) {
      setNotice({ type: 'error', message: 'Add a valid base price or at least one serving size price.' });
      return;
    }
    try {
      const added = await addMealToShop(targetShopId, { ...newMealForm, price: fallbackPrice });
      if (added) {
        setShops((prev) =>
          prev.map((s) => {
            if ((s.id || s._id) === targetShopId) {
              return {
                ...s,
                meals: [...(s.meals || []), added]
              };
            }
            return s;
          })
        );
      }
      setShowAddMealModal(false);
      setNewMealForm({ name: '', description: '', price: '', tag: 'Popular', category: 'Full Menu', itemType: 'meal', image: '🍱', sides: [], portions: [] });
      setNotice({ type: 'success', message: `Meal "${newMealForm.name}" added to menu!` });
    } catch (err) {
      console.error("Add meal error:", err);
      setNotice({ type: 'error', message: err.message || 'Error adding meal' });
    }
  };

  const openShopEditor = (shop) => {
    if (!shop) return;
    setEditShopForm({
      id: shop.id || shop._id,
      name: shop.name || '',
      cuisine: shop.cuisine || '',
      distance: shop.distance || '',
      time: shop.time || '',
      image: shop.image || '🏪',
      address: shop.address || '',
      phone: shop.phone || '',
      whatsapp: shop.whatsapp || '',
      operatingHours: shop.operatingHours || { openTime: '08:00', closeTime: '20:00', days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'] },
      isOpen: shop.isOpen !== false
    });
    setShowEditShopModal(true);
  };

  // Handle Edit Shop Submit
  const handleEditShopSubmit = async (e) => {
    e.preventDefault();
    if (!editShopForm.name || !editShopForm.id) return;
    try {
      await updateShop(editShopForm.id, editShopForm);
      setShops((prev) =>
        prev.map((s) => (s.id || s._id) === editShopForm.id ? { ...s, ...editShopForm } : s)
      );
      setShowEditShopModal(false);
      setNotice({ type: 'success', message: `Shop "${editShopForm.name}" updated successfully!` });
    } catch (err) {
      console.error("Edit shop error:", err);
      setNotice({ type: 'error', message: err.message || 'Error updating shop' });
    }
  };

  // Handle Edit Meal Submit
  const handleEditMealSubmit = async (e) => {
    e.preventDefault();
    const targetShopId = dashboardShop ? (dashboardShop.id || dashboardShop._id) : selectedShopId;
    if (!editMealForm.name || !editMealForm.id || !targetShopId) return;
    try {
      await updateMealInShop(targetShopId, editMealForm.id, editMealForm);
      setShops((prev) =>
        prev.map((s) => {
          if ((s.id || s._id) === targetShopId) {
            return {
              ...s,
              meals: (s.meals || []).map((m) =>
                m.id === editMealForm.id ? { ...m, ...editMealForm } : m
              )
            };
          }
          return s;
        })
      );
      setShowEditMealModal(false);
      setNotice({ type: 'success', message: `Meal "${editMealForm.name}" updated successfully!` });
    } catch (err) {
      console.error("Edit meal error:", err);
      setNotice({ type: 'error', message: err.message || 'Error updating meal' });
    }
  };

  // Handle Delete Meal
  const handleDeleteMeal = async (mealId, mealName) => {
    if (!window.confirm(`Are you sure you want to delete "${mealName}" from the menu?`)) return;
    const targetShopId = dashboardShop ? (dashboardShop.id || dashboardShop._id) : selectedShopId;
    try {
      await deleteMealFromShop(targetShopId, mealId);
      setShops((prev) =>
        prev.map((s) => {
          if ((s.id || s._id) === targetShopId) {
            return {
              ...s,
              meals: (s.meals || []).filter((m) => m.id !== mealId)
            };
          }
          return s;
        })
      );
      setNotice({ type: 'success', message: `Meal "${mealName}" deleted from menu.` });
    } catch (err) {
      console.error("Delete meal error:", err);
      setNotice({ type: 'error', message: err.message || 'Error deleting meal' });
    }
  };

  // Toggle meal availability (In Stock / Sold Out)
  const handleToggleMealAvailability = async (meal) => {
    if (!dashboardShop || !meal) return;
    const newIsAvailable = meal.isAvailable === false;
    const shopId = dashboardShop.id || dashboardShop._id;
    try {
      await updateMealInShop(shopId, meal.id, {
        isAvailable: newIsAvailable
      });
      setShops((prev) =>
        prev.map((s) => {
          if ((s.id || s._id) === shopId) {
            return {
              ...s,
              meals: (s.meals || []).map((m) =>
                m.id === meal.id ? { ...m, isAvailable: newIsAvailable } : m
              )
            };
          }
          return s;
        })
      );
      setNotice({
        type: 'success',
        message: `Meal "${meal.name}" marked as ${newIsAvailable ? 'Available' : 'Sold Out'}.`
      });
    } catch (err) {
      console.error('Toggle meal availability error:', err);
      setNotice({ type: 'error', message: 'Failed to update meal availability.' });
    }
  };

  // Toggle shop Open / Closed
  const handleToggleShopOpen = async (shop) => {
    if (!shop) return;
    const uid = String(currentUser?._id || currentUser?.id || '');
    const inMyShops = myShops.some(
      (s) => String(s.id || s._id) === String(shop.id || shop._id)
    );
    const isOwnerOfShop = Boolean(
      inMyShops ||
      (uid && (String(shop.ownerId || '') === uid || currentUser?.isAdmin || currentUser?.role === 'admin'))
    );
    if (!isOwnerOfShop) {
      setNotice({
        type: 'error',
        message: `You do not manage "${shop.name || 'this shop'}". Only the registered owner can change its open/closed status.`
      });
      return;
    }

    const shopId = shop.id || shop._id;
    // Existing shops without an explicit value are treated as open by the UI.
    const newIsOpen = shop.isOpen === false;
    try {
      await updateShop(shopId, { isOpen: newIsOpen });
      setShops((prev) =>
        prev.map((s) => ((s.id || s._id) === shopId ? { ...s, isOpen: newIsOpen } : s))
      );
      setNotice({
        type: 'success',
        message: newIsOpen
          ? `✅ ${shop.name} is now OPEN — customers can place orders!`
          : `🔴 ${shop.name} is now CLOSED — orders paused.`
      });
    } catch (err) {
      console.error('Toggle open error:', err);
      setNotice({ type: 'error', message: err.message || 'Failed to update shop status. Please try again.' });
    }
  };

  const handleToggleShopPromotion = async (shop) => {
    if (!shop) return;
    const uid = String(currentUser?._id || currentUser?.id || '');
    const shopId = shop.id || shop._id;
    const isOwnerOfShop = myShops.some((entry) => String(entry.id || entry._id) === String(shopId)) ||
      Boolean(uid && String(shop.ownerId || '') === uid) ||
      currentUser?.isAdmin === true || currentUser?.role === 'admin';
    if (!isOwnerOfShop) {
      setNotice({ type: 'error', message: 'Only this shop’s owner can manage its home promotion.' });
      return;
    }

    const isPromoted = shop.isPromoted !== true;
    try {
      await updateShop(shopId, { isPromoted });
      setShops((prev) => prev.map((entry) =>
        String(entry.id || entry._id) === String(shopId) ? { ...entry, isPromoted } : entry
      ));
      setNotice({
        type: 'success',
        message: isPromoted
          ? `${shop.name} is now promoted in the home food row for free. It will be labeled Sponsored.`
          : `Home promotion turned off for ${shop.name}.`
      });
    } catch (err) {
      console.error('Toggle shop promotion error:', err);
      setNotice({ type: 'error', message: err.message || 'Could not update the shop promotion.' });
    }
  };

  const selectedFoodSides = selectedFeaturedMeal ? getAvailableSides(selectedFeaturedMeal) : [];
  const selectedFoodMaxSides = selectedFeaturedMeal ? getMaxSides(selectedFeaturedMeal) : 0;
  const selectedFoodActiveSides = selectedFeaturedMeal
    ? getActiveSides(selectedFeaturedMeal, selectedFoodSides, selectedFoodMaxSides)
    : [];
  const selectedFoodPortion = selectedFeaturedMeal?.portions?.find((portion) => portion.name === selectedPortionName);
  const selectedFoodPrice = selectedFoodPortion?.price ?? getStartingMealPrice(selectedFeaturedMeal);

  return (
    <main className={`app-safe-top min-h-screen app-safe-content-bottom ${cart.length > 0 ? 'pb-28 sm:pb-24' : 'pb-12 sm:pb-8'} bg-gray-50 dark:bg-gray-950 px-3 py-4 sm:px-6 w-full max-w-full overflow-x-hidden`}>
      <div className="mx-auto max-w-5xl w-full">

        {/* ── CLEAN HEADER ── */}
        <div className="mb-4 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
            <button
              type="button"
              onClick={() => isShopDetailOpen ? setIsShopDetailOpen(false) : navigate(-1)}
              aria-label={isShopDetailOpen && activeTab !== 'all-food' ? 'Back to all food shops' : 'Go back'}
              className="inline-flex h-9 w-9 items-center justify-self-start justify-center rounded-full bg-white text-gray-600 shadow-sm ring-1 ring-gray-200 transition hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-300 dark:ring-gray-700 dark:hover:bg-gray-700"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div className="min-w-0 text-center">
              {isShopDetailOpen && currentShop && activeTab !== 'all-food' ? (
                <>
                  <ShopImage image={currentShop.image} className="mx-auto mb-1 h-9 w-9 rounded-lg bg-amber-50 object-cover text-2xl dark:bg-gray-800" />
                  <h1 className="truncate text-base font-bold text-gray-900 dark:text-white">{currentShop.name || 'Food shop'}</h1>
                  {(currentShop.address || currentShop.location || currentShop.distance) && (
                    <p className="mt-0.5 flex items-center justify-center gap-1 truncate text-[10px] text-gray-500 dark:text-gray-400">
                      <MapPin className="h-3 w-3 shrink-0 text-amber-500" /> {currentShop.address || currentShop.location || currentShop.distance}
                    </p>
                  )}
                  <div className="mt-0.5 flex flex-wrap items-center justify-center gap-x-2 gap-y-0.5 text-[10px] text-gray-500 dark:text-gray-400">
                    {(currentShop.contactName || currentShop.ownerName) && <span>Contact: {currentShop.contactName || currentShop.ownerName}</span>}
                    {(currentShop.phone || currentShop.whatsapp) && (
                      <button type="button" onClick={() => setShowContactCard(true)} className="inline-flex items-center gap-1 font-semibold text-amber-700 dark:text-amber-400">
                        <Phone className="h-3 w-3" /> Contact shop
                      </button>
                    )}
                    <span className={isCurrentShopClosed ? 'font-semibold text-rose-600 dark:text-rose-400' : 'font-semibold text-emerald-700 dark:text-emerald-400'}>
                      {isCurrentShopClosed ? 'Closed' : 'Open'}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <h1 className="flex items-center justify-center gap-2 text-xl font-bold text-gray-900 dark:text-white">
                    <UtensilsCrossed className="h-5 w-5 text-amber-500" /> Food Hub
                  </h1>
                  <p className="text-[11px] font-medium text-gray-400 dark:text-gray-500">Browse menus · Order food · Track orders</p>
                </>
              )}
            </div>
          {canCreateFor(currentUser, 'food') ? (
            <button
              type="button"
              onClick={() => setShowAddShopModal(true)}
              className="inline-flex items-center justify-self-end gap-1.5 rounded-full bg-amber-500 px-3 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-amber-600"
            >
              <PlusCircle className="h-3.5 w-3.5" /> Register Shop
            </button>
          ) : <span aria-hidden="true" className="w-9 justify-self-end" />}
        </div>

        {/* ── NOTICE BANNER ── */}
        <AnimatePresence>
          {notice && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className={`mb-4 flex items-center justify-between gap-3 rounded-xl p-3 text-sm font-medium shadow-sm ring-1 ${
                notice.type === 'error'
                  ? 'bg-red-50 text-red-800 ring-red-200 dark:bg-red-950 dark:text-red-200 dark:ring-red-800'
                  : notice.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 ring-emerald-200 dark:bg-emerald-950 dark:text-emerald-200 dark:ring-emerald-800'
                    : 'bg-blue-50 text-blue-800 ring-blue-200 dark:bg-blue-950 dark:text-blue-200 dark:ring-blue-800'
              }`}
            >
              <div className="flex items-center gap-2">
                {notice.type === 'error' ? <AlertCircle className="h-4 w-4 shrink-0" /> : <CheckCircle2 className="h-4 w-4 shrink-0" />}
                <span>{notice.message}</span>
              </div>
              <button type="button" onClick={() => setNotice(null)} className="rounded-full p-1 hover:bg-black/5 dark:hover:bg-white/10">
                <X className="h-3.5 w-3.5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── TAB NAVIGATION ── */}
        <div className="flex items-center gap-1.5 bg-white dark:bg-gray-900 rounded-xl p-1 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800 mb-5 overflow-x-auto">
          {[
            { key: 'explore', label: 'Browse Food', icon: <Store className="h-4 w-4" /> },
            { key: 'all-food', label: 'All Food', icon: <UtensilsCrossed className="h-4 w-4" /> },
            { key: 'orders', label: 'My Orders', icon: <ShoppingBag className="h-4 w-4" />, badge: myCustomerOrders.length || null },
            ...(isShopOwner ? [{ key: 'my-shop', label: 'My Shop', icon: <ChefHat className="h-4 w-4" />, badge: liveKitchenQueue.length || null }] : [])
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setActiveTab(tab.key)}
              className={`flex-1 min-w-0 flex items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 text-xs font-semibold transition whitespace-nowrap ${
                activeTab === tab.key
                  ? 'bg-amber-500 text-white shadow-md'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.badge > 0 && (
                <span className={`ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold ${
                  activeTab === tab.key ? 'bg-white/25 text-white' : 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-200'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {activeTab === 'all-food' && (
          <section aria-labelledby="all-food-heading" className="space-y-4">
            <div>
              <div className="flex items-center justify-between gap-3">
                <h2 id="all-food-heading" className="flex items-center gap-2 text-base font-bold text-gray-900 dark:text-white">
                  <UtensilsCrossed className="h-5 w-5 text-amber-500" /> All Food
                  <span className="rounded-full bg-gray-100 px-2 py-0.5 text-[10px] font-semibold text-gray-500 dark:bg-gray-800 dark:text-gray-400">{allFoodItems.length}</span>
                </h2>
                <button type="button" onClick={() => setActiveTab('explore')} className="text-xs font-bold text-amber-700 hover:text-amber-800 dark:text-amber-400">Browse shops</button>
              </div>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">See menu items from every food shop. Tap an item to open its shop and order.</p>
            </div>
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input type="text" value={allFoodSearch} onChange={(event) => setAllFoodSearch(event.target.value)} placeholder="Search dishes, shops or cuisine..." aria-label="Search all food" className="w-full rounded-xl border border-gray-200 bg-white py-3 pl-10 pr-10 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white" />
              {allFoodSearch && <button type="button" onClick={() => setAllFoodSearch('')} aria-label="Clear all food search" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800"><X className="h-4 w-4" /></button>}
            </label>
            {allFoodItems.length > 0 ? (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {allFoodItems.map(({ shop, meal }) => {
                  const soldOut = meal.isAvailable === false;
                  const isClosed = shop.isOpen === false;
                  const shopId = String(shop.id || shop._id);
                  return (
                    <button key={`${shopId}-${meal.id}`} type="button" onClick={() => {
                      setSelectedShopId(shopId);
                      setMenuSearch('');
                      setSelectedFoodCategory('all');
                      setMenuTagFilter('All');
                      setIsShopDetailOpen(true);
                      setActiveTab('explore');
                    }} aria-label={`View ${meal.name} at ${shop.name}`} className="flex w-full min-w-0 items-center gap-3 overflow-hidden rounded-xl bg-white p-3 text-left shadow-sm ring-1 ring-gray-200 transition hover:shadow-md focus:outline-none focus:ring-2 focus:ring-amber-400 dark:bg-gray-900 dark:ring-gray-800">
                      <span className="h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-800">
                        <FoodVisual visual={getItemVisual(meal)} alt={meal.name} className="h-full w-full object-cover" emojiClassName="flex h-full w-full items-center justify-center text-3xl" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-start justify-between gap-2">
                          <span className="truncate text-sm font-bold text-gray-900 dark:text-white">{meal.name}</span>
                          <span className="shrink-0 text-xs font-bold text-amber-700 dark:text-amber-400">{formatMealPrice(meal)}</span>
                        </span>
                        <span className="mt-1 block truncate text-[11px] font-semibold text-gray-600 dark:text-gray-300">{shop.name} · {shop.cuisine || 'Food shop'}</span>
                        {meal.description && <span className="mt-1 block line-clamp-2 text-[10px] text-gray-500 dark:text-gray-400">{meal.description}</span>}
                        <span className={`mt-1.5 block text-[10px] font-bold ${soldOut || isClosed ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-700 dark:text-emerald-400'}`}>{soldOut ? 'Sold out' : isClosed ? 'Shop closed' : 'Tap to view shop & order'}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-gray-300 px-4 py-10 text-center dark:border-gray-700">
                <p className="text-sm font-semibold text-gray-700 dark:text-gray-200">{allFoodSearch ? `No food matches “${allFoodSearch.trim()}”` : 'No menu items available yet'}</p>
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{allFoodSearch ? 'Try a dish name, shop or cuisine.' : 'Check back soon for menus from local shops.'}</p>
              </div>
            )}
          </section>
        )}

        {/* ══════════════════════════════════════════════════════ */}
        {/* TAB: BROWSE FOOD (explore / other-shops)             */}
        {/* ══════════════════════════════════════════════════════ */}
        {(activeTab === 'explore' || activeTab === 'other-shops') && (
          <div className="space-y-5">

            {/* Browse shops first; opening a card shows only that shop's menu. */}
            {shops.length > 0 && !isShopDetailOpen && (
              <section aria-labelledby="food-shops-heading">
                <div className="mb-3">
                  <h2 id="food-shops-heading" className="flex items-center gap-2 text-base font-bold text-gray-900 dark:text-white">
                    <Store className="h-5 w-5 text-amber-500" /> Food shops near you
                    <span className="rounded-full bg-gray-100 px-2 py-0.5 text-[10px] font-semibold text-gray-500 dark:bg-gray-800 dark:text-gray-400">{visibleShops.length}{shopSearch.trim() ? ` of ${shops.length}` : ''}</span>
                  </h2>
                  <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Choose a shop to see its menu and place an order.</p>
                </div>
                <label className="relative mb-3 block">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    value={shopSearch}
                    onChange={(event) => setShopSearch(event.target.value)}
                    placeholder="Search shops, food or location..."
                    aria-label="Search food shops by name, menu or location"
                    className="w-full rounded-xl border border-gray-200 bg-white py-3 pl-10 pr-10 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 dark:border-gray-700 dark:bg-gray-900 dark:text-white"
                  />
                  {shopSearch && <button type="button" onClick={() => setShopSearch('')} aria-label="Clear shop search" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800"><X className="h-4 w-4" /></button>}
                </label>
                <div className="space-y-2.5">
                  {visibleShops.map((shop) => {
                    const shopId = shop.id || shop._id;
                    const isClosed = shop.isOpen === false;
                    const mealCount = Array.isArray(shop.meals) ? shop.meals.length : 0;
                    const shopAddress = shop.address || shop.location || shop.distance;
                    const shopContactName = shop.contactName || shop.ownerName;
                    const shopContactNumber = shop.phone || shop.whatsapp;
                    const shopReviews = Array.isArray(shop.reviews) ? shop.reviews : [];
                    const reviewRatings = shopReviews
                      .map((review) => Number(review.shopRating ?? review.rating))
                      .filter((rating) => Number.isFinite(rating) && rating > 0 && rating <= 5);
                    const foodReviewRatings = shopReviews
                      .map((review) => Number(review.foodRating))
                      .filter((rating) => Number.isFinite(rating) && rating > 0 && rating <= 5);
                    const averageFoodRating = foodReviewRatings.length
                      ? foodReviewRatings.reduce((total, rating) => total + rating, 0) / foodReviewRatings.length
                      : null;
                    const rawRating = Number(shop.averageRating ?? shop.rating);
                    const shopRating = Number.isFinite(rawRating) && rawRating > 0
                      ? rawRating
                      : reviewRatings.length
                        ? reviewRatings.reduce((total, rating) => total + rating, 0) / reviewRatings.length
                        : null;
                    const shopReviewCount = Number(shop.reviewCount ?? shop.ratingsCount ?? shopReviews.length) || 0;
                    const uid = String(currentUser?._id || currentUser?.id || '');
                    const canManageThisShop = Boolean(
                      myShops.some((ownedShop) => String(ownedShop.id || ownedShop._id) === String(shopId)) ||
                      (uid && String(shop.ownerId || '') === uid) ||
                      currentUser?.isAdmin || currentUser?.role === 'admin'
                    );
                    return (
                      <div key={shopId} className="flex w-full items-center gap-2 rounded-2xl border border-gray-200 bg-white p-3 shadow-sm transition hover:border-amber-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900 dark:hover:border-amber-700">
                        <button
                          type="button"
                          onClick={() => {
                            const currentCartShopId = cart[0]?.shopId || currentShop?.id || currentShop?._id;
                            if (cart.length > 0 && String(currentCartShopId) !== String(shopId)) {
                              setNotice({ type: 'error', message: 'Finish or clear your current shop basket before switching shops.' });
                              return;
                            }
                            setSelectedShopId(shopId);
                            setSelectedFoodCategory('all');
                            setMenuSearch('');
                            setMenuTagFilter('All');
                            setIsShopDetailOpen(true);
                          }}
                          className="flex min-w-0 flex-1 items-center gap-3 rounded-xl text-left focus:outline-none focus:ring-2 focus:ring-amber-400"
                          aria-label={`Open ${shop.name || 'food shop'} menu`}
                        >
                          <ShopImage image={shop.image} className="h-16 w-16 shrink-0 rounded-xl bg-amber-50 object-cover text-3xl dark:bg-gray-800" />
                          <span className="min-w-0 flex-1">
                            <span className="flex items-center justify-between gap-2">
                              <span className="truncate text-sm font-bold text-gray-900 dark:text-white">{shop.name || 'Food shop'}</span>
                              <span className={`shrink-0 rounded-full px-2 py-1 text-[9px] font-bold ${isClosed ? 'bg-red-50 text-red-600 dark:bg-red-950/60 dark:text-red-300' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'}`}>
                                {isClosed ? 'Closed' : 'Open'}
                              </span>
                            </span>
                            <span className="mt-1 block truncate text-xs text-gray-500 dark:text-gray-400">
                              {shop.cuisine || shop.description || 'Local food and favourites'}
                            </span>
                            {shopAddress && (
                              <span className="mt-1 flex min-w-0 items-center gap-1 text-[10px] text-gray-500 dark:text-gray-400">
                                <MapPin className="h-3 w-3 shrink-0 text-amber-500" />
                                <span className="truncate">{shopAddress}</span>
                              </span>
                            )}
                            {(shopContactName || shopContactNumber) && (
                              <span className="mt-1 flex min-w-0 flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] text-gray-500 dark:text-gray-400">
                                {shopContactName && <span className="truncate">Owner: <span className="font-semibold text-gray-700 dark:text-gray-200">{shopContactName}</span></span>}
                                {shopContactNumber && <span className="inline-flex items-center gap-1"><Phone className="h-3 w-3 shrink-0" />{shopContactNumber}</span>}
                              </span>
                            )}
                            <span className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px] font-semibold text-gray-600 dark:text-gray-300">
                              <span className="inline-flex items-center gap-1">
                                <Star className={`h-3.5 w-3.5 ${shopRating ? 'fill-amber-400 text-amber-400' : 'text-gray-400 dark:text-gray-500'}`} />
                                <span className="text-gray-900 dark:text-white">{shopRating ? shopRating.toFixed(1) : 'New'}</span>
                                <span className="font-medium text-gray-500 dark:text-gray-400">Shop</span>
                              </span>
                              {averageFoodRating && (
                                <span className="inline-flex items-center gap-1">
                                  <UtensilsCrossed className="h-3 w-3 text-amber-500" />
                                  <span className="text-gray-900 dark:text-white">{averageFoodRating.toFixed(1)}</span>
                                  <span className="font-medium text-gray-500 dark:text-gray-400">Food</span>
                                </span>
                              )}
                              <span className="font-medium text-gray-500 dark:text-gray-400">
                                {shopReviewCount ? `(${shopReviewCount} ${shopReviewCount === 1 ? 'review' : 'reviews'})` : 'No reviews yet'}
                              </span>
                            </span>
                            <span className="mt-1 block text-[10px] font-semibold text-amber-700 dark:text-amber-400">
                              {mealCount} menu item{mealCount === 1 ? '' : 's'} · Tap to view menu
                            </span>
                          </span>
                        </button>
                        {canManageThisShop && (
                          <div className="flex shrink-0 flex-col gap-1.5">
                            <button
                              type="button"
                              onClick={() => openShopEditor(shop)}
                              aria-label={`Edit ${shop.name || 'shop'}`}
                              className="inline-flex min-h-8 items-center justify-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2.5 text-[10px] font-bold text-slate-700 transition hover:border-slate-300 hover:bg-slate-100 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
                            >
                              <Edit3 className="h-3 w-3" /> Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => handleToggleShopOpen(shop)}
                              aria-label={`${isClosed ? 'Open' : 'Close'} ${shop.name || 'shop'}`}
                              className={`inline-flex min-h-8 items-center justify-center rounded-full px-2.5 text-[10px] font-bold text-white shadow-sm transition ${isClosed ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'}`}
                            >
                              {isClosed ? 'Open shop' : 'Close shop'}
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
                {visibleShops.length === 0 && (
                  <div className="rounded-xl border border-dashed border-gray-300 px-4 py-8 text-center dark:border-gray-700">
                    <p className="text-sm font-semibold text-gray-700 dark:text-gray-200">No shops match “{shopSearch.trim()}”</p>
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Try a shop name, dish, cuisine or area.</p>
                    <button type="button" onClick={() => setShopSearch('')} className="mt-3 rounded-full bg-amber-500 px-4 py-2 text-xs font-bold text-white hover:bg-amber-600">Clear search</button>
                  </div>
                )}
              </section>
            )}

            {/* Empty state */}
            {shops.length === 0 && (
              <div className="text-center py-16">
                <div className="text-5xl mb-3">🍽️</div>
                <h3 className="text-lg font-bold text-gray-700 dark:text-gray-300">No food shops yet</h3>
                <p className="text-sm text-gray-400 mt-1 max-w-xs mx-auto">
                  {canCreateFor(currentUser, 'food')
                    ? 'Be the first to register your food business and start receiving orders.'
                    : 'Check back soon for delicious meals from local food shops.'}
                </p>
                {canCreateFor(currentUser, 'food') && (
                  <button
                    type="button"
                    onClick={() => setShowAddShopModal(true)}
                    className="mt-4 inline-flex items-center gap-2 rounded-lg bg-amber-500 hover:bg-amber-600 px-5 py-2.5 text-sm font-bold text-white shadow transition"
                  >
                    <PlusCircle className="h-4 w-4" /> Register Your Shop
                  </button>
                )}
              </div>
            )}

            {/* Popular food from the selected shop */}
            {currentShop && isShopDetailOpen && (
              popularShopMeals.length > 0 ? (
                <section aria-label={`Popular food at ${currentShop.name}`} className="rounded-xl bg-white p-3 shadow-sm ring-1 ring-gray-200 dark:bg-gray-900 dark:ring-gray-800">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <h2 className="text-xs font-bold text-gray-800 dark:text-gray-100">Popular & special picks</h2>
                    <span className="text-[10px] text-gray-500 dark:text-gray-400">From this shop</span>
                  </div>
                  <div className="flex snap-x snap-mandatory gap-2 overflow-x-auto pb-1 scrollbar-hide" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
                    {popularShopMeals.map((meal, index) => (
                      <button
                        key={meal.id || meal._id || `${meal.name}-${index}`}
                        type="button"
                        onClick={() => openFoodDetails(meal)}
                        aria-label={`View details for ${meal.name}`}
                        className="flex min-w-[220px] snap-start items-center gap-2 rounded-lg bg-gray-50 p-2 text-left transition hover:bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-400 sm:min-w-[250px] dark:bg-gray-800/60 dark:hover:bg-gray-800"
                      >
                        {(() => {
                          const mealRating = getFoodRatingSummary(currentShop, meal);
                          return (
                            <>
                        <div className="h-10 w-10 shrink-0 overflow-hidden rounded-md bg-white dark:bg-gray-700">
                          <FoodVisual visual={getItemVisual(meal)} alt={meal.name} className="h-full w-full object-cover" emojiClassName="text-xl" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[11px] font-semibold text-gray-800 dark:text-gray-100">{meal.name}</p>
                          {mealRating.count > 0 && <p className="flex items-center gap-0.5 text-[10px] font-semibold text-gray-600 dark:text-gray-300"><Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {mealRating.average.toFixed(1)} · {mealRating.count} {mealRating.count === 1 ? 'rating' : 'ratings'}</p>}
                          <p className="text-[10px] font-semibold text-amber-700 dark:text-amber-400">
                            {formatMealPrice(meal)} · {meal.completedSales > 0 ? `${meal.completedSales} sold` : meal.itemType === 'combo' ? 'Combo' : meal.itemType === 'special' || meal.isSpecial ? 'Special' : 'Popular'}
                          </p>
                          {meal.itemType === 'combo' && meal.description && <p className="truncate text-[10px] text-gray-500 dark:text-gray-400">{meal.description}</p>}
                        </div>
                        <span className="ml-auto shrink-0 text-[10px] font-semibold text-amber-700 dark:text-amber-400">Details</span>
                            </>
                          );
                        })()}
                      </button>
                    ))}
                  </div>
                </section>
              ) : null
            )}

            {/* Active Customer Orders (on browse tab) */}
            {myCustomerOrders.length > 0 && !isShopDetailOpen && (
              <div className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800">
                <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-2">
                  <Bell className="h-4 w-4 text-amber-500" /> Active Orders
                  <span className="bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full">{myCustomerOrders.length}</span>
                </h3>
                <div className="space-y-2">
                  {(showAllCustomerReceipts ? myCustomerOrders : myCustomerOrders.slice(0, 3)).map((order) => {
                    const statusColors = {
                      'Pending': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
                      'Preparing': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
                      'Ready for Collection': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
                    };
                    return (
                      <button
                        key={order.id || order._id}
                        type="button"
                        onClick={() => setActiveReceiptOrder(order)}
                        className="w-full flex items-center justify-between gap-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 p-3 hover:bg-gray-100 dark:hover:bg-gray-800 transition text-left"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                            <ShopImage image={order.shopImage} className="w-full h-full object-cover text-xl" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate">
                              #{order.orderCode} · {order.shopName || 'Food Order'}
                            </p>
                            <p className="text-[10px] text-gray-400 dark:text-gray-500">
                              {(order.items || []).length} item{(order.items || []).length !== 1 ? 's' : ''} · {formatPrice(order.total)}
                            </p>
                          </div>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-1 rounded-full whitespace-nowrap ${statusColors[order.status] || 'bg-gray-100 text-gray-600'}`}>
                          {order.status}
                        </span>
                      </button>
                    );
                  })}
                  {myCustomerOrders.length > 3 && (
                    <button
                      type="button"
                      onClick={() => setShowAllCustomerReceipts(!showAllCustomerReceipts)}
                      className="w-full text-center text-xs font-semibold text-amber-600 dark:text-amber-400 hover:text-amber-700 py-1.5"
                    >
                      {showAllCustomerReceipts ? 'Show less' : `View all ${myCustomerOrders.length} orders`}
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Order / Table Mode Toggle */}
            {currentShop && isShopDetailOpen && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOrderMode('order')}
                  className={`flex-1 rounded-lg px-3 py-2 text-xs font-semibold transition ${
                    orderMode === 'order'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400 ring-1 ring-gray-200 dark:ring-gray-800 hover:bg-gray-50'
                  }`}
                >
                  🍔 Order Food
                </button>
                <button
                  type="button"
                  onClick={() => setOrderMode('table')}
                  className={`flex-1 rounded-lg px-3 py-2 text-xs font-semibold transition ${
                    orderMode === 'table'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400 ring-1 ring-gray-200 dark:ring-gray-800 hover:bg-gray-50'
                  }`}
                >
                  🪑 Book Table
                </button>
                <button
                  type="button"
                  onClick={() => setOrderMode('reviews')}
                  className={`flex-1 rounded-lg px-3 py-2 text-xs font-semibold transition ${
                    orderMode === 'reviews'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400 ring-1 ring-gray-200 dark:ring-gray-800 hover:bg-gray-50'
                  }`}
                >
                  ⭐ Reviews{shopCommentReviews.length ? ` (${shopCommentReviews.length})` : ''}
                </button>
              </div>
            )}

            {/* ── MENU GRID (Order Mode) ── */}
            {currentShop && isShopDetailOpen && orderMode === 'order' && (
              <div>
                {/* Search & Tag Filter */}
                <div className="mb-3 flex min-w-0 items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                    <input
                      type="text"
                      value={menuSearch}
                      onChange={(e) => setMenuSearch(e.target.value)}
                      placeholder="Search meals, kotas, pap, drinks..."
                      className="w-full rounded-lg bg-white dark:bg-gray-900 pl-9 pr-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-800 focus:ring-amber-400 focus:outline-none transition placeholder:text-gray-400"
                    />
                  </div>
                  <select
                    aria-label="Filter menu by food category"
                    value={selectedFoodCategory}
                    onChange={(e) => setSelectedFoodCategory(e.target.value)}
                    className="max-w-[112px] rounded-lg bg-white px-2.5 py-2 text-xs text-gray-700 ring-1 ring-gray-200 focus:outline-none focus:ring-amber-400 dark:bg-gray-900 dark:text-gray-200 dark:ring-gray-800"
                  >
                    {FOOD_CATEGORIES.map((category) => (
                      <option key={category.id} value={category.id}>{category.name}</option>
                    ))}
                  </select>
                  {menuTags.length > 2 && (
                    <select
                      aria-label="Filter menu by tag"
                      value={menuTagFilter}
                      onChange={(e) => setMenuTagFilter(e.target.value)}
                      className="max-w-[92px] rounded-lg bg-white px-2.5 py-2 text-xs ring-1 ring-gray-200 focus:outline-none focus:ring-amber-400 dark:bg-gray-900 dark:ring-gray-800"
                    >
                      {menuTags.map((tag) => <option key={tag} value={tag}>{tag}</option>)}
                    </select>
                  )}
                </div>

                {/* Menu Items Grid */}
                {visibleMeals.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {visibleMeals.map((meal) => {
                      const soldOut = meal.isAvailable === false;
                      const visual = getItemVisual(meal);
                      const catBadge = getCategoryBadge(meal);
                      const mealRating = getFoodRatingSummary(currentShop, meal);
                      return (
                        <button
                          key={meal.id}
                          type="button"
                          onClick={() => openFoodDetails(meal)}
                          aria-label={`View ${meal.name} details and order options`}
                          className={`relative w-full rounded-xl bg-white p-3.5 text-left shadow-sm ring-1 ring-gray-200 transition hover:shadow-md focus:outline-none focus:ring-2 focus:ring-amber-400 dark:bg-gray-900 dark:ring-gray-800 ${soldOut ? 'opacity-75' : ''}`}
                        >
                          <div className="flex items-start gap-3">
                            <div className="shrink-0 h-14 w-14 rounded-lg bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden">
                              <FoodVisual visual={visual} alt={meal.name} className="h-full w-full object-cover rounded-lg" emojiClassName="text-2xl" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-start justify-between gap-2">
                                <div className="min-w-0">
                                  <h4 className="text-sm font-bold text-gray-900 dark:text-white truncate">{meal.name}</h4>
                                  <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                                    <span className="inline-flex items-center gap-1 text-[9px] font-bold px-2 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60">
                                      <span>{catBadge.icon}</span>
                                      <span>{catBadge.name}</span>
                                    </span>
                                    {['combo', 'special'].includes(String(meal.itemType || '').toLowerCase()) && (
                                      <span className="rounded-full bg-rose-50 px-2 py-0.5 text-[9px] font-bold text-rose-700 dark:bg-rose-950/50 dark:text-rose-300">
                                        {meal.itemType === 'combo' ? 'Combo' : 'Special'}
                                      </span>
                                    )}
                                    {meal.tag && (
                                      <span className="text-[9px] font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">{meal.tag}</span>
                                    )}
                                  </div>
                                </div>
                                <span className="text-sm font-bold text-amber-600 dark:text-amber-400 whitespace-nowrap">{formatMealPrice(meal)}</span>
                              </div>
                              {meal.description && (
                                <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-1 line-clamp-2">{meal.description}</p>
                              )}
                              {mealRating.count > 0 && (
                                <span className="mt-1 inline-flex items-center gap-1 text-[10px] font-semibold text-gray-600 dark:text-gray-300">
                                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {mealRating.average.toFixed(1)} <span className="font-normal text-gray-400">({mealRating.count})</span>
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="mt-2.5 flex items-center justify-between border-t border-gray-100 pt-2 dark:border-gray-800">
                            <span className={`text-[10px] font-semibold ${soldOut ? 'text-rose-600 dark:text-rose-400' : 'text-gray-500 dark:text-gray-400'}`}>
                              {soldOut ? 'Sold out' : isCurrentShopClosed ? 'Shop closed' : 'Tap for details & order'}
                            </span>
                            {!soldOut && <ShoppingBag className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-white dark:bg-gray-900 rounded-xl p-6 border border-gray-200 dark:border-gray-800 shadow-sm">
                    <span className="text-4xl block mb-2">{FOOD_CATEGORIES.find((c) => c.id === selectedFoodCategory)?.icon || '🍽️'}</span>
                    <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">
                      {menuSearch
                        ? 'No menu items match your search'
                        : `No ${FOOD_CATEGORIES.find((c) => c.id === selectedFoodCategory)?.name || 'items'} in this shop yet`}
                    </h4>
                    <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto">
                      {selectedFoodCategory !== 'all'
                        ? `Switch back to Full Menu to view all ${(currentShop?.meals || []).length} available meals & items.`
                        : 'Try searching with different keywords.'}
                    </p>
                    {selectedFoodCategory !== 'all' && (
                      <button
                        type="button"
                        onClick={() => { setSelectedFoodCategory('all'); setMenuSearch(''); setMenuTagFilter('All'); }}
                        className="mt-3.5 inline-flex items-center gap-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 px-4 py-2 text-xs font-bold text-white shadow transition"
                      >
                        🍽️ View Full Menu ({(currentShop?.meals || []).length})
                      </button>
                    )}
                  </div>
                )}

                {/* Kitchen Queue (visible to customers) */}
                {activeKitchenOrders.length > 0 && (
                  <div className="mt-4 bg-amber-50/80 dark:bg-amber-950/20 rounded-xl p-3.5 ring-1 ring-amber-200/60 dark:ring-amber-800/40">
                    <h4 className="text-xs font-bold text-amber-700 dark:text-amber-300 flex items-center gap-1.5 mb-2">
                      <Clock3 className="h-3.5 w-3.5" /> Kitchen Queue ({activeKitchenOrders.length} order{activeKitchenOrders.length !== 1 ? 's' : ''})
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {activeKitchenOrders.slice(0, 8).map((o) => (
                        <span key={o.id || o._id} className="text-[10px] font-mono font-bold bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-400 px-2 py-1 rounded-md ring-1 ring-gray-200 dark:ring-gray-800">
                          #{o.orderCode} · {o.status}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

              </div>
            )}

            {/* ── TABLE BOOKING MODE ── */}
            {currentShop && isShopDetailOpen && orderMode === 'table' && (
              <div className="space-y-4">
                <div className="bg-white dark:bg-gray-900 rounded-xl p-5 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800">
                  <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-4 flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-amber-500" /> Reserve a Table at {currentShop.name}
                  </h3>
                  <form onSubmit={handleTableBooking} className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Date</label>
                      <input
                        type="date"
                        value={booking.date}
                        onChange={(e) => setBooking({...booking, date: e.target.value})}
                        required
                        className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Time</label>
                      <input
                        type="time"
                        value={booking.time}
                        onChange={(e) => setBooking({...booking, time: e.target.value})}
                        className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Guests</label>
                      <select
                        value={booking.guests}
                        onChange={(e) => setBooking({...booking, guests: e.target.value})}
                        className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                      >
                        {[1,2,3,4,5,6,7,8,10,12].map((n) => <option key={n} value={n}>{n} {n === 1 ? 'Guest' : 'Guests'}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Your Name</label>
                      <input
                        type="text"
                        value={booking.name}
                        onChange={(e) => setBooking({...booking, name: e.target.value})}
                        required
                        className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={isCurrentShopClosed}
                    className="w-full rounded-lg bg-amber-500 hover:bg-amber-600 disabled:bg-gray-300 disabled:cursor-not-allowed px-4 py-2.5 text-sm font-bold text-white shadow transition"
                  >
                    {isCurrentShopClosed ? 'Shop is Closed' : 'Request Table'}
                  </button>
                  </form>
                </div>

              </div>
            )}

            {/* ── SHOP REVIEWS MODE ── */}
            {currentShop && isShopDetailOpen && orderMode === 'reviews' && (
              <section aria-label={`Reviews for ${currentShop.name}`} className="rounded-xl bg-white p-4 shadow-sm ring-1 ring-gray-200 dark:bg-gray-900 dark:ring-gray-800">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <h3 className="flex items-center gap-1.5 text-sm font-bold text-gray-800 dark:text-gray-100">
                    <Star className="h-4 w-4 fill-amber-400 text-amber-400" /> Guest reviews
                  </h3>
                  <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
                    {shopCommentReviews.length} {shopCommentReviews.length === 1 ? 'review' : 'reviews'}
                  </span>
                </div>
                {shopCommentReviews.length ? (
                  <div className="space-y-2.5">
                    {shopCommentReviews.map((review, index) => {
                      const shopScore = Math.max(0, Math.min(5, Number(review.shopRating || review.rating || 0)));
                      const foodScore = Math.max(0, Math.min(5, Number(review.foodRating || 0)));
                      return (
                        <article key={review._id || review.id || index} className="rounded-lg bg-gray-50 p-3 dark:bg-gray-800/60">
                          <div className="flex items-center justify-between gap-2">
                            <p className="truncate text-xs font-semibold text-gray-700 dark:text-gray-200">{review.userName || 'Customer'}</p>
                            <div className="flex shrink-0 items-center gap-2 text-[10px] font-bold text-gray-700 dark:text-gray-200">
                              <span className="inline-flex items-center gap-0.5" title="Shop rating"><Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {shopScore ? shopScore.toFixed(1) : '—'}</span>
                              {foodScore > 0 && <span className="inline-flex items-center gap-0.5" title="Food rating"><UtensilsCrossed className="h-3 w-3 text-amber-500" /> {foodScore.toFixed(1)}</span>}
                            </div>
                          </div>
                          <p className="mt-1.5 text-xs leading-relaxed text-gray-600 dark:text-gray-300">{String(review.comment).trim()}</p>
                          {review.itemRatings?.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {review.itemRatings.map((itemRating, itemIndex) => (
                                <span key={`${itemRating.mealId || itemRating.mealName}-${itemIndex}`} className="inline-flex items-center gap-1 rounded-full bg-white px-2 py-1 text-[10px] font-medium text-gray-600 dark:bg-gray-900 dark:text-gray-300">
                                  <span className="max-w-32 truncate">{itemRating.mealName}</span>
                                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" /> {itemRating.rating}/5
                                </span>
                              ))}
                            </div>
                          )}
                        </article>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-gray-500 dark:text-gray-400">No written reviews yet.</p>
                )}
              </section>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════ */}
        {/* TAB: MY ORDERS (Customer order history)              */}
        {/* ══════════════════════════════════════════════════════ */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
              <ShoppingBag className="h-4 w-4 text-amber-500" /> My Orders
            </h2>

            {/* Active orders */}
            {myCustomerOrders.length > 0 && (
              <div className="space-y-2.5">
                <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Active</h3>
                {myCustomerOrders.map((order) => {
                  const statusColors = {
                    'Pending': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
                    'Preparing': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
                    'Ready for Collection': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
                  };
                  const collectionInfo = formatCollectionDateTime(order);
                  return (
                    <motion.div
                      key={order.id || order._id}
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800 cursor-pointer hover:shadow-md transition"
                      onClick={() => setActiveReceiptOrder(order)}
                    >
                      <div className="flex items-center justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-md bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                            <ShopImage image={order.shopImage} className="w-full h-full object-cover text-xl" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-gray-800 dark:text-gray-200">#{order.orderCode}</p>
                            <p className="text-[10px] text-gray-400">{order.shopName}</p>
                          </div>
                        </div>
                        <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${statusColors[order.status] || 'bg-gray-100 text-gray-600'}`}>
                          {order.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-gray-400">{(order.items || []).length} item{(order.items || []).length !== 1 ? 's' : ''}</span>
                        <span className="font-bold text-amber-600">{formatPrice(order.total)}</span>
                      </div>
                      <div className="mt-2 text-[10px] text-gray-400 flex items-center gap-1">
                        <Clock3 className="h-3 w-3" /> {collectionInfo.label}: {collectionInfo.full}
                      </div>
                      {order.status === 'Ready for Collection' && (
                        <div className="mt-3 space-y-2 border-t border-gray-100 pt-3 dark:border-gray-800">
                          <p className="text-[10px] text-gray-500 dark:text-gray-400">
                            {order.fulfilment === 'delivery'
                              ? 'Confirm once your delivery has arrived.'
                              : 'Confirm after you collect your order. Unconfirmed pickup orders close automatically after 2 hours.'}
                          </p>
                          {String(order.customerId || '') === String(currentUser?._id || currentUser?.id || '') && <button
                            type="button"
                            onClick={(event) => {
                              event.stopPropagation();
                              handleStatusUpdate(order.id || order._id, 'Completed');
                            }}
                            className="w-full rounded-lg bg-emerald-600 px-3 py-2 text-xs font-bold text-white shadow-sm transition hover:bg-emerald-700"
                          >
                            {order.fulfilment === 'delivery' ? 'Confirm received & complete' : 'I collected it — complete order'}
                          </button>}
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* Completed orders */}
            {myCompletedCustomerOrders.length > 0 && (
              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={() => setShowPastCustomerReceipts(!showPastCustomerReceipts)}
                  className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200 flex items-center gap-1"
                >
                  Completed ({myCompletedCustomerOrders.length})
                  <span className="text-[10px]">{showPastCustomerReceipts ? '▲' : '▼'}</span>
                </button>
                {showPastCustomerReceipts && myCompletedCustomerOrders.map((order) => (
                  <div
                    key={order.id || order._id}
                    className="bg-white dark:bg-gray-900 rounded-xl p-3 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800 cursor-pointer hover:shadow-md transition opacity-70"
                    onClick={() => setActiveReceiptOrder(order)}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-md bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                          <ShopImage image={order.shopImage} className="w-full h-full object-cover text-lg" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-gray-700 dark:text-gray-300">#{order.orderCode} · {order.shopName}</p>
                          <p className="text-[10px] text-gray-400">{(order.items || []).length} items · {formatPrice(order.total)}</p>
                          {Number(order.ratingDetails?.foodRating) > 0 && (
                            <p className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-amber-700 dark:text-amber-400">
                              <UtensilsCrossed className="h-3 w-3" /> Food rating: {Number(order.ratingDetails.foodRating).toFixed(1)}/5
                            </p>
                          )}
                          {order.ratingDetails?.itemRatings?.length > 0 && (
                            <div className="mt-1.5 flex flex-wrap gap-1">
                              {order.ratingDetails.itemRatings.map((itemRating, itemIndex) => (
                                <span key={`${itemRating.mealId || itemRating.mealName}-${itemIndex}`} className="inline-flex items-center gap-0.5 rounded-full bg-amber-50 px-1.5 py-0.5 text-[9px] font-medium text-gray-600 dark:bg-amber-950/30 dark:text-gray-300">
                                  <span className="max-w-24 truncate">{itemRating.mealName}</span>
                                  <Star className="h-2.5 w-2.5 fill-amber-400 text-amber-400" /> {itemRating.rating}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      <span className="text-[10px] font-bold bg-gray-100 dark:bg-gray-800 text-gray-500 px-2 py-1 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" /> Done
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* No orders */}
            {myCustomerOrders.length === 0 && myCompletedCustomerOrders.length === 0 && (
              <div className="text-center py-12">
                <span className="text-4xl">📋</span>
                <h3 className="text-sm font-bold text-gray-600 dark:text-gray-400 mt-3">No orders yet</h3>
                <p className="text-xs text-gray-400 mt-1">Browse food shops and place your first order!</p>
                <button
                  type="button"
                  onClick={() => setActiveTab('explore')}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 px-4 py-2 text-xs font-bold text-white shadow transition"
                >
                  <Store className="h-3.5 w-3.5" /> Browse Food
                </button>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════ */}
        {/* TAB: MY SHOP (Vendor Dashboard — orders + menu)      */}
        {/* ══════════════════════════════════════════════════════ */}
        {(activeTab === 'my-shop' || activeTab === 'my-menu') && isShopOwner && (
          <div className="space-y-5">

            {/* Shop Header Card */}
            <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl p-4 text-white shadow-md">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <ShopImage image={dashboardShop?.image} className="h-14 w-14 shrink-0 rounded-xl bg-white/20 flex items-center justify-center text-3xl" />
                  <div className="min-w-0">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-amber-100">Your Shop</p>
                    <h3 className="text-lg font-bold truncate">{dashboardShop?.name || 'My Shop'}</h3>
                    {dashboardShop?.cuisine && <p className="text-xs text-amber-100">{dashboardShop.cuisine}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {isCurrentShopOwner && dashboardShop && (
                    <button
                      type="button"
                      onClick={() => handleToggleShopPromotion(dashboardShop)}
                      aria-pressed={dashboardShop.isPromoted === true}
                      title={dashboardShop.isPromoted === true ? 'Turn off free home promotion' : 'Promote your shop in the home food row for free'}
                      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[10px] font-bold transition ${
                        dashboardShop.isPromoted === true
                          ? 'bg-white text-amber-700'
                          : 'bg-white/20 text-white hover:bg-white/30'
                      }`}
                    >
                      <Megaphone className="h-3 w-3" />
                      {dashboardShop.isPromoted === true ? 'Sponsored' : 'Promote free'}
                    </button>
                  )}
                  {isCurrentShopOwner && dashboardShop && (
                    <button
                      type="button"
                      onClick={() => handleToggleShopOpen(dashboardShop)}
                      className={`text-[10px] font-bold px-3 py-1.5 rounded-full transition ${
                        dashboardShop.isOpen !== false
                          ? 'bg-white/20 text-white hover:bg-white/30'
                          : 'bg-red-600/80 text-white hover:bg-red-700'
                      }`}
                    >
                      {dashboardShop.isOpen !== false ? '🟢 Open' : '🔴 Closed'}
                    </button>
                  )}
                  {canCreateFor(currentUser, 'food') && <button
                    type="button"
                    onClick={() => {
                      if (dashboardShop) {
                        setEditShopForm({
                          id: dashboardShop.id || dashboardShop._id,
                          name: dashboardShop.name || '',
                          cuisine: dashboardShop.cuisine || '',
                          distance: dashboardShop.distance || '',
                          time: dashboardShop.time || '',
                          image: dashboardShop.image || '🏪',
                          address: dashboardShop.address || '',
                          phone: dashboardShop.phone || '',
                          whatsapp: dashboardShop.whatsapp || '',
                          operatingHours: dashboardShop.operatingHours || { openTime: '08:00', closeTime: '20:00', days: ['Mon','Tue','Wed','Thu','Fri'] },
                          isOpen: dashboardShop.isOpen !== false
                        });
                        setShowEditShopModal(true);
                      }
                    }}
                    className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                  </button>}
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { label: 'Today', value: formatPrice(revenueSummary.daily), sub: 'Revenue' },
                { label: 'This Week', value: formatPrice(revenueSummary.weekly), sub: 'Revenue' },
                { label: 'Queue', value: liveKitchenQueue.length, sub: `order${liveKitchenQueue.length !== 1 ? 's' : ''}` }
              ].map((stat) => (
                <div key={stat.label} className="bg-white dark:bg-gray-900 rounded-xl p-3 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800 text-center">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-gray-400">{stat.label}</p>
                  <p className="text-base font-bold text-gray-900 dark:text-white mt-0.5">{stat.value}</p>
                  <p className="text-[10px] text-gray-400">{stat.sub}</p>
                </div>
              ))}
            </div>

            {/* Owner workspace tabs */}
            <div className="grid grid-cols-2 gap-2 rounded-xl bg-gray-100 dark:bg-gray-800 p-1.5" role="tablist" aria-label="Shop management">
              <button
                type="button"
                role="tab"
                aria-selected={ownerFoodTab === 'kitchen'}
                onClick={() => setOwnerFoodTab('kitchen')}
                className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold transition ${ownerFoodTab === 'kitchen' ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}
              >
                <Bell className="h-4 w-4 text-amber-500" />
                Kitchen Queue
                <span className={`rounded-full px-2 py-0.5 text-xs ${ownerFoodTab === 'kitchen' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-200' : 'bg-gray-200 dark:bg-gray-700'}`}>{liveKitchenQueue.length}</span>
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={ownerFoodTab === 'menu'}
                onClick={() => setOwnerFoodTab('menu')}
                className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-sm font-semibold transition ${ownerFoodTab === 'menu' ? 'bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}
              >
                <UtensilsCrossed className="h-4 w-4 text-amber-500" />
                Your Menu
                <span className={`rounded-full px-2 py-0.5 text-xs ${ownerFoodTab === 'menu' ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-200' : 'bg-gray-200 dark:bg-gray-700'}`}>{(dashboardShop?.meals || []).length}</span>
              </button>
            </div>

            {/* Kitchen Queue (Live Orders) */}
            {ownerFoodTab === 'kitchen' && (
            <div className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                  <Bell className="h-4 w-4 text-amber-500" /> Kitchen Queue
                  {liveKitchenQueue.length > 0 && (
                    <span className="bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">{liveKitchenQueue.length}</span>
                  )}
                </h3>
                {/* Search */}
                <div className="relative w-40">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-gray-400" />
                  <input
                    type="text"
                    value={orderSearchText}
                    onChange={(e) => setOrderSearchText(e.target.value)}
                    placeholder="Search orders..."
                    className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 pl-7 pr-2 py-1.5 text-[10px] ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Filter Tabs */}
              <div className="flex gap-1 mb-3 overflow-x-auto">
                {[
                  { key: 'all', label: 'All', count: activeShopOrders.length },
                  { key: 'pending', label: 'Pending', count: pendingOrdersCount },
                  { key: 'preparing', label: 'Preparing', count: preparingOrdersCount },
                  { key: 'ready', label: 'Ready', count: readyOrdersCount },
                  { key: 'completed', label: 'Done', count: completedOrdersCount }
                ].map((f) => (
                  <button
                    key={f.key}
                    type="button"
                    onClick={() => setOrderFilterTab(f.key)}
                    className={`text-[10px] font-semibold px-2.5 py-1 rounded-full whitespace-nowrap transition ${
                      orderFilterTab === f.key
                        ? 'bg-amber-500 text-white'
                        : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200'
                    }`}
                  >
                    {f.label} {f.count > 0 ? `(${f.count})` : ''}
                  </button>
                ))}
              </div>

              {/* Order List */}
              {filteredShopOrders.length > 0 ? (
                <div className="space-y-2">
                  {(showAllKitchenQueue ? filteredShopOrders : filteredShopOrders.slice(0, 8)).map((order) => {
                    const statusConfig = {
                      'Pending': { color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200', next: 'Preparing', label: 'Start Preparing' },
                      'Preparing': { color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200', next: 'Ready for Collection', label: order.fulfilment === 'delivery' ? 'Ready for delivery' : 'Ready for pickup' },
                      'Ready for Collection': { color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200', next: null, label: 'Waiting for customer' },
                      'Completed': { color: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400', next: null, label: 'Done' }
                    };
                    const config = statusConfig[order.status] || statusConfig['Pending'];
                    return (
                      <div key={order.id || order._id} className="flex items-center justify-between gap-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                        <div className="flex items-center gap-2.5 min-w-0" onClick={() => setActiveReceiptOrder(order)} style={{ cursor: 'pointer' }}>
                          <div className="w-6 h-6 rounded-md bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                            <ShopImage image={order.shopImage} className="w-full h-full object-cover text-lg" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate">
                              #{order.orderCode} · {order.customerName || 'Customer'}
                            </p>
                            <p className="text-[10px] text-gray-400">
                              {(order.items || []).map(i => i.name).join(', ')} · {formatPrice(order.total)}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`text-[9px] font-bold px-2 py-1 rounded-full ${config.color}`}>
                            {order.status}
                          </span>
                          {config.next && isCurrentShopOwner && (
                            <button
                              type="button"
                              onClick={() => handleStatusUpdate(order.id || order._id, config.next)}
                              className="text-[10px] font-bold bg-amber-500 hover:bg-amber-600 text-white px-2.5 py-1 rounded-lg transition"
                            >
                              {config.label}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  {filteredShopOrders.length > 8 && (
                    <button
                      type="button"
                      onClick={() => setShowAllKitchenQueue(!showAllKitchenQueue)}
                      className="w-full text-center text-xs font-semibold text-amber-600 py-1.5"
                    >
                      {showAllKitchenQueue ? 'Show less' : `View all ${filteredShopOrders.length} orders`}
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-center py-6">
                  <span className="text-2xl">✅</span>
                  <p className="text-xs text-gray-400 mt-1.5">No orders in queue</p>
                </div>
              )}
            </div>
            )}

            {/* Menu Management */}
            {ownerFoodTab === 'menu' && (
            <div className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                  <UtensilsCrossed className="h-4 w-4 text-amber-500" /> Your Menu
                  <span className="text-[10px] text-gray-400">({(dashboardShop?.meals || []).length} items)</span>
                </h3>
                {canCreateFor(currentUser, 'food') && <button
                  type="button"
                  onClick={() => setShowAddMealModal(true)}
                  className="inline-flex items-center gap-1 rounded-lg bg-amber-500 hover:bg-amber-600 px-3 py-1.5 text-[11px] font-bold text-white shadow-sm transition"
                >
                  <Plus className="h-3 w-3" /> Add Meal
                </button>}
              </div>

              {/* Search & Tags */}
              <div className="flex items-center gap-2 mb-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3 w-3 text-gray-400" />
                  <input
                    type="text"
                    value={myMenuSearchText}
                    onChange={(e) => setMyMenuSearchText(e.target.value)}
                    placeholder="Search your menu..."
                    className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 pl-8 pr-3 py-1.5 text-[11px] ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                  />
                </div>
                {myMenuTags.length > 2 && (
                  <select
                    value={myMenuTagFilter}
                    onChange={(e) => setMyMenuTagFilter(e.target.value)}
                    className="rounded-lg bg-gray-50 dark:bg-gray-800 px-2 py-1.5 text-[11px] ring-1 ring-gray-200 dark:ring-gray-700"
                  >
                    {myMenuTags.map((tag) => <option key={tag} value={tag}>{tag}</option>)}
                  </select>
                )}
              </div>

              {/* Meal Items */}
              {visibleMyMeals.length > 0 ? (
                <div className="space-y-2">
                  {visibleMyMeals.map((meal) => {
                    const visual = getItemVisual(meal);
                    return (
                      <div key={meal.id} className="flex items-center justify-between gap-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="shrink-0 h-10 w-10 rounded-lg bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden">
                            <FoodVisual visual={visual} alt={meal.name} className="h-full w-full object-cover rounded-lg" emojiClassName="text-xl" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate">{meal.name}</p>
                            <div className="flex flex-wrap items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                              <span className="font-bold text-amber-600">{formatPrice(meal.price)}</span>
                              {(() => {
                                const cat = getCategoryBadge(meal);
                                return (
                                  <span className="inline-flex items-center gap-0.5 font-medium text-gray-500 dark:text-gray-400">
                                    <span>{cat.icon}</span> {cat.name}
                                  </span>
                                );
                              })()}
                              {meal.tag && <span>· {meal.tag}</span>}
                              <span className={meal.isAvailable === false ? 'text-red-500 font-bold' : 'text-emerald-500'}>{meal.isAvailable === false ? 'Sold Out' : 'In Stock'}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleMealAvailability(meal)}
                            className={`p-1.5 rounded-lg transition ${meal.isAvailable === false ? 'bg-red-100 text-red-500 hover:bg-red-200' : 'bg-emerald-100 text-emerald-500 hover:bg-emerald-200'}`}
                            title={meal.isAvailable === false ? 'Mark Available' : 'Mark Sold Out'}
                          >
                            {meal.isAvailable === false ? <X className="h-3 w-3" /> : <Check className="h-3 w-3" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditMealForm({ ...meal, id: meal.id, category: meal.category || detectMealCategory(meal), itemType: meal.itemType || 'meal', portions: meal.portions || [] });
                              setShowEditMealModal(true);
                            }}
                            className="p-1.5 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-500 hover:text-amber-500 hover:bg-amber-50 transition"
                          >
                            <Edit3 className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteMeal(meal.id, meal.name)}
                            className="p-1.5 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-500 hover:text-red-500 hover:bg-red-50 transition"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-6">
                  <span className="text-2xl">🍽️</span>
                  <p className="text-xs text-gray-400 mt-1.5">No menu items yet. Add your first meal!</p>
                </div>
              )}
            </div>
            )}

            {/* Shop Insights */}
            {ownerFoodTab === 'menu' && shopInsights.length > 0 && (
              <div className="bg-white dark:bg-gray-900 rounded-xl p-4 shadow-sm ring-1 ring-gray-200 dark:ring-gray-800">
                <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300 flex items-center gap-2 mb-3">
                  <Lightbulb className="h-4 w-4 text-amber-500" /> Tips to Grow
                </h3>
                <div className="space-y-2">
                  {shopInsights.map((insight, i) => (
                    <div key={i} className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                      <p className="text-xs font-bold text-gray-700 dark:text-gray-300">{insight.title}</p>
                      <p className="text-[10px] text-gray-400 mt-0.5">{insight.detail}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════ */}
        {/* MODALS                                                */}
        {/* ══════════════════════════════════════════════════════ */}

        {/* CHECKOUT MODAL */}
        {showCheckoutModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowCheckoutModal(false)}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4 text-amber-500" /> Checkout
                </h3>
                <button type="button" onClick={() => setShowCheckoutModal(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <X className="h-5 w-5 text-gray-400" />
                </button>
              </div>
              <form onSubmit={handlePlaceOrder} className="p-4 space-y-4">
                {/* Cart Items */}
                <div className="space-y-2">
                  {cart.map((item) => (
                    <div key={item.cartKey || item.id} className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-2.5 space-y-1.5">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-8 h-8 rounded-md bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                            <FoodVisual visual={getItemVisual(item)} alt={item.name} className="h-full w-full object-cover" emojiClassName="text-lg" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate">{item.name}{item.portionName ? ` · ${item.portionName}` : ''}</p>
                            <p className="text-[10px] text-gray-400">{formatPrice(item.price)} × {item.quantity}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button type="button" onClick={() => updateQuantity(item.cartKey || item.id, -1)} className="p-1 bg-gray-200 dark:bg-gray-700 rounded text-gray-600 dark:text-gray-300 hover:bg-red-100 hover:text-red-500">
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="text-xs font-bold min-w-[16px] text-center text-gray-700 dark:text-gray-200">{item.quantity}</span>
                          <button type="button" onClick={() => updateQuantity(item.cartKey || item.id, 1)} className="p-1 bg-gray-200 dark:bg-gray-700 rounded text-gray-600 dark:text-gray-300 hover:bg-emerald-100 hover:text-emerald-500">
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                      {item.sides && item.sides.length > 0 && (
                        <div className="flex flex-wrap gap-1 pt-0.5">
                          {item.sides.map((side) => (
                            <span key={side} className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-700 border border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800">
                              <Check className="h-2 w-2" />
                              {side}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                  <div className="flex justify-between items-center pt-2 border-t border-gray-200 dark:border-gray-800">
                    <span className="text-sm font-bold text-gray-700 dark:text-gray-300">Total</span>
                    <span className="text-lg font-bold text-amber-600">{formatPrice(totalCartPrice)}</span>
                  </div>
                </div>

                {/* Customer Details */}
                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Your Name</label>
                    <input
                      type="text"
                      value={checkoutData.customerName}
                      onChange={(e) => setCheckoutData({...checkoutData, customerName: e.target.value})}
                      className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      value={checkoutData.customerPhone}
                      onChange={(e) => setCheckoutData({...checkoutData, customerPhone: e.target.value})}
                      required
                      className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                      placeholder="0XX XXX XXXX"
                    />
                  </div>
                  <p className="rounded-lg bg-emerald-50 px-3 py-2.5 text-xs text-emerald-900 dark:bg-emerald-950/30 dark:text-emerald-200">
                    We’ll notify you in LoopOut when your order is ready for collection.
                  </p>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Order Notes (Optional)</label>
                    <textarea
                      value={checkoutData.orderComments}
                      onChange={(e) => setCheckoutData({...checkoutData, orderComments: e.target.value})}
                      className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none resize-none"
                      rows={2}
                      placeholder="Any special requests..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Schedule for Later (Optional)</label>
                    <input
                      type="datetime-local"
                      value={checkoutData.scheduledFor}
                      onChange={(e) => setCheckoutData({...checkoutData, scheduledFor: e.target.value})}
                      className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="bg-amber-50 dark:bg-amber-950/30 rounded-lg p-3 text-center">
                  <p className="text-xs font-semibold text-amber-700 dark:text-amber-300 flex items-center justify-center gap-1.5">
                    <CreditCard className="h-3.5 w-3.5" /> Pay at counter when you collect
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={!cart.length || isCurrentShopClosed}
                  className="w-full rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-gray-300 disabled:cursor-not-allowed py-3 text-sm font-bold text-white shadow-md transition"
                >
                  {isCurrentShopClosed ? 'Shop is Closed' : `Place Order · ${formatPrice(totalCartPrice)}`}
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {/* ORDER RECEIPT MODAL */}
        {activeReceiptOrder && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setActiveReceiptOrder(null)}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800"
              onClick={(e) => e.stopPropagation()}
            >
              {(() => {
                const ord = activeReceiptOrder;
                const ordId = ord.id || ord._id;
                const collectionInfo = formatCollectionDateTime(ord);
                const statusColors = {
                  'Pending': 'bg-yellow-100 text-yellow-800',
                  'Preparing': 'bg-blue-100 text-blue-800',
                  'Ready for Collection': 'bg-emerald-100 text-emerald-800',
                  'Completed': 'bg-gray-200 text-gray-600',
                };
                const isMyOrder = currentUser && String(ord.customerId || ord.userId || '') === String(currentUser._id || currentUser.id || '');
                const ownsShopOrder = isCurrentShopOwner && String(ord.shopId || '') === String(dashboardShop?.id || dashboardShop?._id || '');

                return (
                  <div className="p-5 space-y-4">
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <h3 className="text-base font-bold text-gray-900 dark:text-white">Order Receipt</h3>
                      <button type="button" onClick={() => setActiveReceiptOrder(null)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                        <X className="h-5 w-5 text-gray-400" />
                      </button>
                    </div>

                    {/* Order Code */}
                    <div className="text-center py-3 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl text-white">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-amber-100">Order Code</p>
                      <p className="text-3xl font-black tracking-widest mt-1">{ord.orderCode || '----'}</p>
                      <p className="text-[10px] text-amber-100 mt-1">Show this code at pickup</p>
                    </div>

                    {/* Status */}
                    <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                      <span className="text-xs font-semibold text-gray-600 dark:text-gray-400">Status</span>
                      <span className={`text-xs font-bold px-3 py-1 rounded-full ${statusColors[ord.status] || 'bg-gray-100 text-gray-600'}`}>
                        {ord.status}
                      </span>
                    </div>

                    {/* Shop & Customer */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Restaurant</p>
                        <p className="text-xs font-bold text-gray-700 dark:text-gray-300 mt-0.5">{ord.shopName || 'Food Shop'}</p>
                      </div>
                      <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Customer</p>
                        <p className="text-xs font-bold text-gray-700 dark:text-gray-300 mt-0.5">{ord.customerName || 'Customer'}</p>
                        {ord.customerPhone && <p className="text-[10px] text-gray-400 font-mono">{ord.customerPhone}</p>}
                      </div>
                    </div>

                    {/* Collection */}
                    <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{collectionInfo.label}</p>
                      <p className="text-xs font-bold text-gray-700 dark:text-gray-300 mt-0.5">{collectionInfo.full}</p>
                    </div>

                    {/* Items */}
                    <div className="space-y-1.5">
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Items</p>
                      {(ord.items || []).map((item, i) => {
                        const iv = getItemVisual(item);
                        return (
                          <div key={i} className="flex items-center justify-between bg-gray-50 dark:bg-gray-800/50 rounded-lg p-2.5">
                            <div className="flex items-center gap-2">
                              <div className="w-6 h-6 rounded-md bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                                <FoodVisual visual={iv} alt={item.name} className="h-full w-full object-cover" emojiClassName="text-base" />
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">{item.name}</p>
                                <p className="text-[10px] text-gray-400">× {item.quantity}</p>
                              </div>
                            </div>
                            <span className="text-xs font-bold text-amber-600">{formatPrice((item.price || 0) * (item.quantity || 1))}</span>
                          </div>
                        );
                      })}
                      <div className="flex justify-between items-center pt-2 border-t border-gray-200 dark:border-gray-800">
                        <span className="text-sm font-bold text-gray-700 dark:text-gray-300">Total</span>
                        <span className="text-lg font-bold text-amber-600">{formatPrice(ord.total)}</span>
                      </div>
                    </div>

                    {/* Order Notes */}
                    {ord.orderComments && (
                      <div className="bg-amber-50 dark:bg-amber-950/30 rounded-lg p-3">
                        <p className="text-[10px] font-bold text-amber-600 uppercase tracking-wider">Notes</p>
                        <p className="text-xs text-gray-700 dark:text-gray-300 mt-0.5">{ord.orderComments}</p>
                      </div>
                    )}

                    {/* Status Update Buttons (Shop Owner) */}
                    {ownsShopOrder && ord.status !== 'Completed' && (
                      <div className="flex gap-2">
                        {ord.status === 'Pending' && (
                          <button type="button" onClick={() => handleStatusUpdate(ordId, 'Preparing')} className="flex-1 rounded-lg bg-blue-500 hover:bg-blue-600 py-2 text-xs font-bold text-white shadow transition">
                            Start Preparing
                          </button>
                        )}
                        {ord.status === 'Preparing' && (
                          <button type="button" onClick={() => handleStatusUpdate(ordId, 'Ready for Collection')} className="flex-1 rounded-lg bg-emerald-500 hover:bg-emerald-600 py-2 text-xs font-bold text-white shadow transition">
                            {ord.fulfilment === 'delivery' ? 'Ready for delivery' : 'Ready for pickup'}
                          </button>
                        )}
                        {ord.status === 'Ready for Collection' && (
                          <p className="flex-1 rounded-lg bg-emerald-50 px-3 py-2 text-center text-[11px] font-semibold text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-200">
                            Waiting for the customer to confirm collection. Pickup orders auto-close after 2 hours.
                          </p>
                        )}
                      </div>
                    )}

                    {isMyOrder && ord.status === 'Ready for Collection' && (
                      <button
                        type="button"
                        onClick={() => handleStatusUpdate(ordId, 'Completed')}
                        className="w-full rounded-lg bg-emerald-600 py-2.5 text-xs font-bold text-white shadow transition hover:bg-emerald-700"
                      >
                        {ord.fulfilment === 'delivery' ? 'Confirm delivery received' : 'I collected it — complete order'}
                      </button>
                    )}

                    {isMyOrder && ['Pending', 'Preparing'].includes(ord.status) && (
                      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-slate-50 px-3 py-2.5 dark:bg-gray-800/70">
                        <p className="text-xs text-gray-600 dark:text-gray-300">Cancel before the shop marks your order ready.</p>
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm('Cancel this food order? You can cancel before the shop marks it ready.')) handleStatusUpdate(ordId, 'Cancelled');
                          }}
                          className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-rose-300 hover:bg-rose-50 hover:text-rose-700 dark:border-gray-600 dark:text-gray-200 dark:hover:bg-rose-950/30"
                        >
                          Cancel order
                        </button>
                      </div>
                    )}

                    {/* Rate Button (Customer, Completed) */}
                    {isMyOrder && ord.status === 'Completed' && !ord.isRated && (
                      <button
                        type="button"
                        onClick={() => {
                          setShopRating(5);
                          setItemRatings(Object.fromEntries((ord.items || []).map((_, index) => [index, 0])));
                          setRatingComment('');
                          setRatingTargetOrder(ord);
                          setShowRateModal(true);
                        }}
                        className="w-full rounded-lg bg-amber-500 hover:bg-amber-600 py-2.5 text-xs font-bold text-white shadow transition flex items-center justify-center gap-1.5"
                      >
                        <Star className="h-3.5 w-3.5" /> Rate this Order
                      </button>
                    )}
                  </div>
                );
              })()}
            </motion.div>
          </div>
        )}

        {/* CONTACT CARD MODAL */}
        {showContactCard && currentShop && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowContactCard(false)}>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-sm max-h-[90vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800 p-5"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Phone className="h-4 w-4 text-amber-500" /> Contact
                </h3>
                <button type="button" onClick={() => setShowContactCard(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <X className="h-5 w-5 text-gray-400" />
                </button>
              </div>
              <div className="text-center mb-4">
                <ShopImage image={currentShop.image} className="mx-auto h-16 w-16 rounded-xl bg-amber-50 dark:bg-gray-800 flex items-center justify-center text-4xl" />
                <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200 mt-2">{currentShop.name}</h4>
                {currentShop.address && <p className="text-xs text-gray-400 mt-0.5">{currentShop.address}</p>}
              </div>
              <div className="space-y-2.5">
                {currentShop.phone && (
                  <a
                    href={`tel:${currentShop.phone}`}
                    className="flex items-center gap-3 w-full rounded-xl bg-blue-50 dark:bg-blue-950/30 p-3 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-950/50 transition"
                  >
                    <FaPhone className="h-4 w-4" />
                    <div>
                      <p className="text-xs font-bold">Call</p>
                      <p className="text-[11px] font-mono">{currentShop.phone}</p>
                    </div>
                  </a>
                )}
                {currentShop.whatsapp && (
                  <a
                    href={`https://wa.me/${(currentShop.whatsapp || '').replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 w-full rounded-xl bg-green-50 dark:bg-green-950/30 p-3 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-950/50 transition"
                  >
                    <FaWhatsapp className="h-4 w-4" />
                    <div>
                      <p className="text-xs font-bold">WhatsApp</p>
                      <p className="text-[11px] font-mono">{currentShop.whatsapp}</p>
                    </div>
                  </a>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {/* ADD SHOP MODAL */}
        {showAddShopModal && canCreateFor(currentUser, 'food') && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowAddShopModal(false)}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-amber-500" /> Register Food Shop
                </h3>
                <button type="button" onClick={() => setShowAddShopModal(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <X className="h-5 w-5 text-gray-400" />
                </button>
              </div>
              <form onSubmit={handleCreateShopSubmit} className="p-4 space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Shop Name *</label>
                  <input type="text" required value={newShopForm.name} onChange={(e) => setNewShopForm({...newShopForm, name: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="e.g. Mama's Kitchen" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Cuisine Type</label>
                    <input type="text" value={newShopForm.cuisine} onChange={(e) => setNewShopForm({...newShopForm, cuisine: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="e.g. Traditional" />
                  </div>
                </div>
                <FoodImageField label="Shop logo" value={newShopForm.image} onChange={(image) => setNewShopForm((form) => ({ ...form, image }))} />
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Address</label>
                  <input type="text" value={newShopForm.address} onChange={(e) => setNewShopForm({...newShopForm, address: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="Street address" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Phone</label>
                    <input type="tel" value={newShopForm.phone} onChange={(e) => setNewShopForm({...newShopForm, phone: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="0XX XXX XXXX" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">WhatsApp</label>
                    <input type="tel" value={newShopForm.whatsapp} onChange={(e) => setNewShopForm({...newShopForm, whatsapp: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="27XX XXX XXXX" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Distance</label>
                    <input type="text" value={newShopForm.distance} onChange={(e) => setNewShopForm({...newShopForm, distance: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="e.g. 1.5 km" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Prep Time</label>
                    <input type="text" value={newShopForm.time} onChange={(e) => setNewShopForm({...newShopForm, time: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="e.g. 20-30 min" />
                  </div>
                </div>
                <button type="submit" className="w-full rounded-xl bg-amber-500 hover:bg-amber-600 py-3 text-sm font-bold text-white shadow-md transition">
                  Register Shop
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {/* ADD MEAL MODAL */}
        {showAddMealModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowAddMealModal(false)}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <UtensilsCrossed className="h-4 w-4 text-amber-500" /> Add Menu Item
                </h3>
                <div className="flex items-center gap-2">
                  <button type="button" onClick={() => handleAiAutoFillMeal(false)} className="text-[10px] font-bold bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 px-2.5 py-1 rounded-full hover:bg-purple-200 transition flex items-center gap-1">
                    <Sparkles className="h-3 w-3" /> AI Fill
                  </button>
                  <button type="button" onClick={() => setShowAddMealModal(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                    <X className="h-5 w-5 text-gray-400" />
                  </button>
                </div>
              </div>
              <form onSubmit={handleAddMealSubmit} className="p-4 space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Meal Name *</label>
                  <input type="text" required value={newMealForm.name} onChange={(e) => setNewMealForm({...newMealForm, name: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="e.g. Grilled Chicken Pap" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Description</label>
                  <textarea value={newMealForm.description} onChange={(e) => setNewMealForm({...newMealForm, description: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none resize-none" rows={2} placeholder="Brief description..." />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Menu item type</label>
                  <select value={newMealForm.itemType} onChange={(e) => setNewMealForm({ ...newMealForm, itemType: e.target.value })} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
                    <option value="meal">Regular menu item</option>
                    <option value="combo">Combo meal</option>
                    <option value="special">Shop special</option>
                  </select>
                  {newMealForm.itemType === 'combo' && <p className="mt-1 text-[10px] text-gray-500 dark:text-gray-400">List everything included in the combo in the description or sides.</p>}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Base price (R) · optional with sizes</label>
                    <input type="number" min="0.01" max="10000" step="0.01" value={newMealForm.price} onChange={(e) => setNewMealForm({...newMealForm, price: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" placeholder="55.00" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Category *</label>
                    <select value={newMealForm.category} onChange={(e) => setNewMealForm({...newMealForm, category: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
                      <option value="African Cuisines">🍲 African Cuisines</option>
                      <option value="Light Food">🥗 Light Food</option>
                      <option value="Soft Drinks">🥤 Soft Drinks</option>
                      <option value="Fruits">🍎 Fruits</option>
                      <option value="Full Menu">🍽️ Full Menu / Other</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Tag</label>
                    <select value={newMealForm.tag} onChange={(e) => setNewMealForm({...newMealForm, tag: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
                      {['🔥 Hot Seller', 'Popular', 'Top Rated', 'New', 'Spicy', 'Healthy', 'Value', 'Special', 'Vegetarian', 'Vegan'].map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </div>
                <PortionPriceFields portions={newMealForm.portions || []} onChange={(update) => setNewMealForm((form) => ({ ...form, portions: update(form.portions || []) }))} />
                <FoodImageField label="Food photo" value={newMealForm.image} onChange={(image) => setNewMealForm((form) => ({ ...form, image }))} />
                {/* Sides */}
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Sides (comma separated)</label>
                  <input
                    type="text"
                    value={(newMealForm.sides || []).join(', ')}
                    onChange={(e) => setNewMealForm({...newMealForm, sides: e.target.value.split(',').map(s => s.trim()).filter(Boolean)})}
                    className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                    placeholder="Pap, Chakalaka, Salad..."
                  />
                </div>
                <button type="submit" className="w-full rounded-xl bg-amber-500 hover:bg-amber-600 py-3 text-sm font-bold text-white shadow-md transition">
                  Add to Menu
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {/* EDIT SHOP MODAL */}
        {showEditShopModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowEditShopModal(false)}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Edit3 className="h-4 w-4 text-amber-500" /> Edit Shop
                </h3>
                <button type="button" onClick={() => setShowEditShopModal(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <X className="h-5 w-5 text-gray-400" />
                </button>
              </div>
              <form onSubmit={handleEditShopSubmit} className="p-4 space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Shop Name *</label>
                  <input type="text" required value={editShopForm.name} onChange={(e) => setEditShopForm({...editShopForm, name: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Cuisine</label>
                    <input type="text" value={editShopForm.cuisine} onChange={(e) => setEditShopForm({...editShopForm, cuisine: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                  </div>
                </div>
                <FoodImageField label="Shop logo" value={editShopForm.image || '🏪'} onChange={(image) => setEditShopForm((form) => ({ ...form, image }))} />
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Address</label>
                  <input type="text" value={editShopForm.address} onChange={(e) => setEditShopForm({...editShopForm, address: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Phone</label>
                    <input type="tel" value={editShopForm.phone} onChange={(e) => setEditShopForm({...editShopForm, phone: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">WhatsApp</label>
                    <input type="tel" value={editShopForm.whatsapp} onChange={(e) => setEditShopForm({...editShopForm, whatsapp: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Distance</label>
                    <input type="text" value={editShopForm.distance} onChange={(e) => setEditShopForm({...editShopForm, distance: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Prep Time</label>
                    <input type="text" value={editShopForm.time} onChange={(e) => setEditShopForm({...editShopForm, time: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                  </div>
                </div>
                <button type="submit" className="w-full rounded-xl bg-amber-500 hover:bg-amber-600 py-3 text-sm font-bold text-white shadow-md transition">
                  Save Changes
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {/* EDIT MEAL MODAL */}
        {showEditMealModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowEditMealModal(false)}>
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md max-h-[85vh] overflow-y-auto bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Edit3 className="h-4 w-4 text-amber-500" /> Edit Meal
                </h3>
                <div className="flex items-center gap-2">
                  <button type="button" onClick={() => handleAiAutoFillMeal(true)} className="text-[10px] font-bold bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 px-2.5 py-1 rounded-full hover:bg-purple-200 transition flex items-center gap-1">
                    <Sparkles className="h-3 w-3" /> AI Fill
                  </button>
                  <button type="button" onClick={() => setShowEditMealModal(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                    <X className="h-5 w-5 text-gray-400" />
                  </button>
                </div>
              </div>
              <form onSubmit={handleEditMealSubmit} className="p-4 space-y-3">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Meal Name *</label>
                  <input type="text" required value={editMealForm.name} onChange={(e) => setEditMealForm({...editMealForm, name: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Description</label>
                  <textarea value={editMealForm.description} onChange={(e) => setEditMealForm({...editMealForm, description: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none resize-none" rows={2} />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Menu item type</label>
                  <select value={editMealForm.itemType || 'meal'} onChange={(e) => setEditMealForm({ ...editMealForm, itemType: e.target.value })} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
                    <option value="meal">Regular menu item</option>
                    <option value="combo">Combo meal</option>
                    <option value="special">Shop special</option>
                  </select>
                  {editMealForm.itemType === 'combo' && <p className="mt-1 text-[10px] text-gray-500 dark:text-gray-400">List everything included in the combo in the description or sides.</p>}
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Price (R) *</label>
                    <input type="number" required step="0.01" value={editMealForm.price} onChange={(e) => setEditMealForm({...editMealForm, price: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Category *</label>
                    <select value={editMealForm.category} onChange={(e) => setEditMealForm({...editMealForm, category: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
                      <option value="African Cuisines">🍲 African Cuisines</option>
                      <option value="Light Food">🥗 Light Food</option>
                      <option value="Soft Drinks">🥤 Soft Drinks</option>
                      <option value="Fruits">🍎 Fruits</option>
                      <option value="Full Menu">🍽️ Full Menu / Other</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Tag</label>
                    <select value={editMealForm.tag} onChange={(e) => setEditMealForm({...editMealForm, tag: e.target.value})} className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none">
                      {['🔥 Hot Seller', 'Popular', 'Top Rated', 'New', 'Spicy', 'Healthy', 'Value', 'Special', 'Vegetarian', 'Vegan'].map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                </div>
                <PortionPriceFields portions={editMealForm.portions || []} onChange={(update) => setEditMealForm((form) => ({ ...form, portions: update(form.portions || []) }))} />
                <FoodImageField label="Food photo" value={editMealForm.image || '🍱'} onChange={(image) => setEditMealForm((form) => ({ ...form, image }))} />
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Sides (comma separated)</label>
                  <input
                    type="text"
                    value={(editMealForm.sides || []).join(', ')}
                    onChange={(e) => setEditMealForm({...editMealForm, sides: e.target.value.split(',').map(s => s.trim()).filter(Boolean)})}
                    className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none"
                  />
                </div>
                <button type="submit" className="w-full rounded-xl bg-amber-500 hover:bg-amber-600 py-3 text-sm font-bold text-white shadow-md transition">
                  Save Changes
                </button>
              </form>
            </motion.div>
          </div>
        )}

        {/* RATE MODAL */}
        {showRateModal && ratingTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-sm" onClick={() => setShowRateModal(false)}>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-sm bg-white dark:bg-gray-900 rounded-2xl shadow-2xl ring-1 ring-gray-200 dark:ring-gray-800 p-5"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <Star className="h-4 w-4 text-amber-500" /> Rate Your Experience
                </h3>
                <button type="button" onClick={() => setShowRateModal(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <X className="h-5 w-5 text-gray-400" />
                </button>
              </div>
              <form onSubmit={handleRatingSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Shop Rating</label>
                  <div className="flex gap-1">
                    {[1,2,3,4,5].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setShopRating(s)}
                        className="p-1 transition hover:scale-110"
                      >
                        <Star className={`h-7 w-7 ${s <= shopRating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="mb-2 block text-[10px] font-bold uppercase tracking-wider text-gray-500">Rate each food item</label>
                  <div className="max-h-56 space-y-2 overflow-y-auto pr-1">
                    {(ratingTargetOrder.items || []).map((item, itemIndex) => (
                      <div key={`${item.id || item.name}-${itemIndex}`} className="flex items-center justify-between gap-2 rounded-lg bg-gray-50 p-2.5 dark:bg-gray-800/60">
                        <div className="min-w-0">
                          <p className="truncate text-xs font-semibold text-gray-800 dark:text-gray-100">{item.name || 'Food item'}</p>
                          <p className="text-[10px] text-gray-500 dark:text-gray-400">Quantity: {item.quantity || 1}</p>
                        </div>
                        <div className="flex shrink-0 items-center gap-0.5">
                          {[1, 2, 3, 4, 5].map((score) => (
                            <button
                              key={score}
                              type="button"
                              onClick={() => setItemRatings((previous) => ({ ...previous, [itemIndex]: score }))}
                              aria-label={`Rate ${item.name || 'food item'} ${score} out of 5`}
                              className="p-0.5 transition hover:scale-110"
                            >
                              <Star className={`h-4 w-4 ${score <= (itemRatings[itemIndex] || 0) ? 'fill-amber-400 text-amber-400' : 'text-gray-300 dark:text-gray-600'}`} />
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Comment (Optional)</label>
                  <textarea
                    value={ratingComment}
                    onChange={(e) => setRatingComment(e.target.value)}
                    className="w-full rounded-lg bg-gray-50 dark:bg-gray-800 px-3 py-2 text-xs ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-amber-400 focus:outline-none resize-none"
                    rows={3}
                    placeholder="How was your experience?"
                  />
                </div>
                <button type="submit" className="w-full rounded-xl bg-amber-500 hover:bg-amber-600 py-3 text-sm font-bold text-white shadow-md transition flex items-center justify-center gap-1.5">
                  <Star className="h-4 w-4" /> Submit Rating
                </button>
              </form>
            </motion.div>
          </div>
        )}

        <AnimatePresence>
          {selectedFeaturedMeal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-4"
              onClick={() => setSelectedFeaturedMeal(null)}
            >
              <motion.section
                role="dialog"
                aria-modal="true"
                aria-label={`${selectedFeaturedMeal.name} details`}
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: 40, opacity: 0 }}
                transition={{ type: 'spring', damping: 28, stiffness: 300 }}
                onClick={(event) => event.stopPropagation()}
                className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white shadow-2xl dark:bg-gray-900 sm:rounded-3xl"
              >
                <div className="relative flex h-56 items-center justify-center bg-amber-50 dark:bg-gray-800 sm:h-64">
                  <button
                    type="button"
                    onClick={() => setZoomedFoodImage(selectedFeaturedMeal)}
                    aria-label={`Zoom image of ${selectedFeaturedMeal.name}`}
                    className="h-full w-full cursor-zoom-in p-3"
                  >
                    <FoodVisual visual={getItemVisual(selectedFeaturedMeal)} alt={selectedFeaturedMeal.name} className="h-full w-full object-contain" emojiClassName="flex h-full w-full items-center justify-center text-7xl" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedFeaturedMeal(null)}
                    aria-label="Close food details"
                    className="absolute right-3 top-3 inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-gray-700 shadow-sm transition hover:bg-white dark:bg-gray-950/90 dark:text-gray-200"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="space-y-3 p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                        {selectedFeaturedMeal.itemType === 'combo' ? 'Combo meal' : selectedFeaturedMeal.itemType === 'special' || selectedFeaturedMeal.isSpecial ? 'Shop special' : 'Popular pick'}
                      </p>
                      <h2 className="mt-1 text-xl font-bold text-gray-900 dark:text-white">{selectedFeaturedMeal.name}</h2>
                      {(() => {
                        const mealRating = getFoodRatingSummary(currentShop, selectedFeaturedMeal);
                        return mealRating.count > 0 ? (
                          <p className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-gray-600 dark:text-gray-300">
                            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" /> {mealRating.average.toFixed(1)} <span className="font-normal text-gray-400">({mealRating.count} {mealRating.count === 1 ? 'rating' : 'ratings'} for this food)</span>
                          </p>
                        ) : null;
                      })()}
                    </div>
                    <span className="shrink-0 text-lg font-black text-amber-600 dark:text-amber-400">{formatPrice(selectedFoodPrice)}</span>
                  </div>
                  {selectedFeaturedMeal.description && <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-300">{selectedFeaturedMeal.description}</p>}
                  {selectedFeaturedMeal.portions?.length > 0 && (
                    <fieldset>
                      <legend className="mb-2 text-xs font-bold text-gray-800 dark:text-gray-100">Choose a serving size</legend>
                      <div className="grid grid-cols-2 gap-2">
                        {selectedFeaturedMeal.portions.map((portion) => (
                          <button key={portion.name} type="button" aria-pressed={selectedPortionName === portion.name} onClick={() => setSelectedPortionName(portion.name)} className={`flex min-h-11 items-center justify-between rounded-xl border px-3 py-2 text-xs font-semibold transition ${selectedPortionName === portion.name ? 'border-amber-500 bg-amber-50 text-amber-800 dark:bg-amber-950/30 dark:text-amber-200' : 'border-gray-200 text-gray-700 dark:border-gray-700 dark:text-gray-200'}`}>
                            <span>{portion.name}</span><span>{formatPrice(portion.price)}</span>
                          </button>
                        ))}
                      </div>
                    </fieldset>
                  )}
                  {selectedFeaturedMeal.itemType === 'combo' && selectedFeaturedMeal.sides?.length > 0 && (
                    <div>
                      <h3 className="mb-1.5 text-xs font-bold text-gray-700 dark:text-gray-200">Included in this combo</h3>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedFeaturedMeal.sides.map((side) => (
                          <span key={side} className="rounded-full bg-gray-100 px-2.5 py-1 text-[11px] font-medium text-gray-700 dark:bg-gray-800 dark:text-gray-300">{side}</span>
                        ))}
                      </div>
                    </div>
                  )}
                  {selectedFeaturedMeal.itemType !== 'combo' && selectedFoodSides.length > 0 && selectedFoodMaxSides > 0 && selectedFeaturedMeal.isAvailable !== false && (
                    <div>
                      <h3 className="mb-1.5 text-xs font-bold text-gray-700 dark:text-gray-200">
                        Choose sides <span className="font-medium text-gray-500 dark:text-gray-400">({selectedFoodActiveSides.length}/{selectedFoodMaxSides})</span>
                      </h3>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedFoodSides.map((side) => {
                          const isSelected = selectedFoodActiveSides.includes(side);
                          return (
                            <button
                              key={side}
                              type="button"
                              onClick={() => toggleSideForMeal(selectedFeaturedMeal.id, side, selectedFoodSides, selectedFoodMaxSides)}
                              className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold transition ${isSelected ? 'border-amber-500 bg-amber-500 text-white' : 'border-gray-200 bg-white text-gray-600 hover:border-amber-300 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300'}`}
                            >
                              {isSelected && <Check className="h-3 w-3" />}{side}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      const mealToOrder = selectedFeaturedMeal;
                      setSelectedFeaturedMeal(null);
                      addToCart(mealToOrder, selectedPortionName);
                    }}
                    disabled={isCurrentShopClosed || selectedFeaturedMeal.isAvailable === false || Boolean(selectedFeaturedMeal.portions?.length && !selectedFoodPortion)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-amber-600 disabled:cursor-not-allowed disabled:bg-gray-300 dark:disabled:bg-gray-700"
                  >
                    <ShoppingBag className="h-4 w-4" />
                    {selectedFeaturedMeal.isAvailable === false ? 'Sold out' : isCurrentShopClosed ? 'Shop is closed' : selectedFeaturedMeal.portions?.length && !selectedFoodPortion ? 'Choose a serving size' : `Order · ${formatPrice(selectedFoodPrice)}`}
                  </button>
                </div>
              </motion.section>
            </motion.div>
          )}
        </AnimatePresence>

      </div>

      {/* ── BASKET PREVIEW POPUP (auto-shows on add) ── */}
      <AnimatePresence>
        {showBasketPreview && cart.length > 0 && (
          <motion.div
            key="basket-preview"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
            onClick={() => setShowBasketPreview(false)}
          >
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 80, opacity: 0 }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="relative z-10 w-full max-w-md mx-0 sm:mx-4 bg-white dark:bg-gray-950 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden"
            >
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-1 sm:hidden">
                <div className="w-10 h-1 rounded-full bg-gray-200 dark:bg-gray-700" />
              </div>

              {/* Header */}
              <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <ShoppingBag className="h-5 w-5 text-amber-500" />
                    <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-white text-[9px] font-black min-w-[16px] h-[16px] rounded-full flex items-center justify-center">
                      {cart.reduce((s, i) => s + i.quantity, 0)}
                    </span>
                  </div>
                  <h3 className="text-sm font-black text-gray-900 dark:text-white">Your Basket</h3>
                  {currentShop && (
                    <span className="text-[10px] text-gray-400 font-semibold">· {currentShop.name}</span>
                  )}
                </div>
                <button onClick={() => setShowBasketPreview(false)} className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <X className="h-4 w-4 text-gray-400" />
                </button>
              </div>

              {/* Cart items list */}
              <div className="px-5 py-3 space-y-3 max-h-60 overflow-y-auto">
                {cart.map((item) => (
                  <div key={item.cartKey || item.id} className="space-y-1">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-gray-100 dark:bg-gray-800 flex items-center justify-center overflow-hidden shrink-0">
                          <FoodVisual visual={getItemVisual(item)} alt={item.name} className="h-full w-full object-cover" emojiClassName="text-xl shrink-0" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-gray-900 dark:text-white truncate">{item.name}</p>
                          <p className="text-[10px] text-gray-400">{item.portionName ? `${item.portionName} · ` : ''}{formatPrice(item.price)} × {item.quantity}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button type="button" onClick={() => updateQuantity(item.cartKey || item.id, -1)} className="w-6 h-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-red-100 hover:text-red-500 transition">
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="text-xs font-black text-gray-900 dark:text-white min-w-[16px] text-center">{item.quantity}</span>
                        <button type="button" onClick={() => updateQuantity(item.cartKey || item.id, 1)} className="w-6 h-6 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-emerald-100 hover:text-emerald-500 transition">
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                    {item.sides && item.sides.length > 0 && (
                      <div className="flex flex-wrap gap-1 pl-8">
                        {item.sides.map((side) => (
                          <span key={side} className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-700 border border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800">
                            <Check className="h-2 w-2" />
                            {side}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Total + Confirm button */}
              <div className="px-5 pb-6 pt-3 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-bold text-gray-600 dark:text-gray-400">Total</span>
                  <span className="text-xl font-black text-amber-600">{formatPrice(totalCartPrice)}</span>
                </div>
                <button
                  type="button"
                  disabled={isCurrentShopClosed}
                  onClick={() => {
                    setShowBasketPreview(false);
                    currentUser ? setShowCheckoutModal(true) : navigate('/sign-in');
                  }}
                  className="w-full rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-white py-3.5 text-sm font-black shadow-lg hover:from-amber-600 hover:to-orange-600 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="h-4 w-4" />
                  {isCurrentShopClosed ? 'Shop Closed' : currentUser ? `Confirm Order · ${formatPrice(totalCartPrice)}` : 'Sign in to Order'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowBasketPreview(false)}
                  className="w-full mt-2 text-center text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 font-semibold py-1"
                >
                  Continue browsing
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

        <AnimatePresence>
          {zoomedFoodImage && (
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label={`Image of ${zoomedFoodImage.name}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setZoomedFoodImage(null)}
              className="fixed inset-0 z-[100] flex cursor-zoom-out items-center justify-center bg-black/90 p-4"
            >
              <button
                type="button"
                onClick={() => setZoomedFoodImage(null)}
                aria-label="Close zoomed food image"
                className="absolute right-4 top-4 z-10 rounded-full bg-white/15 p-3 text-white backdrop-blur hover:bg-white/25"
              >
                <X className="h-5 w-5" />
              </button>
              <div className="flex h-full max-h-[90vh] w-full max-w-5xl flex-col items-center justify-center gap-3" onClick={(event) => event.stopPropagation()}>
                <FoodVisual visual={getItemVisual(zoomedFoodImage)} alt={zoomedFoodImage.name} className="max-h-[78vh] max-w-full rounded-xl object-contain" emojiClassName="text-8xl sm:text-9xl" />
                <p className="max-w-full truncate text-center text-sm font-semibold text-white">{zoomedFoodImage.name}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      {/* ── FLOATING CART BAR ── */}
      {cart.length > 0 && (activeTab === 'explore' || activeTab === 'other-shops') && (
        <div className="fixed bottom-0 left-0 right-0 z-40 p-3 bg-gradient-to-t from-gray-950/90 to-transparent backdrop-blur-md safe-area-bottom mobile-booking-bar">
          <div className="mx-auto max-w-3xl rounded-2xl bg-amber-500 p-3 text-white shadow-xl flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="relative bg-white/20 p-2 rounded-xl backdrop-blur-md">
                <ShoppingBag className="h-5 w-5 text-white" />
                <span className="absolute -top-1.5 -right-1.5 flex h-[18px] w-[18px] items-center justify-center rounded-full bg-gray-900 text-[10px] font-bold text-amber-300 shadow">
                  {cart.reduce((sum, i) => sum + i.quantity, 0)}
                </span>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-100 block">Your Basket</span>
                <span className="text-base font-bold">{formatPrice(totalCartPrice)}</span>
              </div>
            </div>
            <button
              type="button"
              disabled={isCurrentShopClosed}
              onClick={() => {
                currentUser ? setShowBasketPreview(true) : navigate('/sign-in');
              }}
              className="rounded-xl bg-gray-900 px-4 py-2.5 text-xs font-bold text-amber-300 hover:bg-gray-800 transition shadow-lg flex items-center gap-1.5 disabled:bg-gray-600 disabled:text-gray-300 disabled:cursor-not-allowed"
            >
              <span>{isCurrentShopClosed ? 'Closed' : currentUser ? 'View Basket' : 'Sign in'}</span>
              <span>→</span>
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
