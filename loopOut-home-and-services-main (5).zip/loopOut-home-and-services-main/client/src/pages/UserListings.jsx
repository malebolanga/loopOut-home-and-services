import { useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Edit2, Trash2, X, Check } from 'lucide-react';
import { FaPlus, FaSpinner } from 'react-icons/fa';
import { canCreateListings, getCreationRoute } from '../utils/offeringPermissions';
import { authenticatedFetch } from '../utils/authenticatedFetch';

/* ─── helpers ────────────────────────────────────────────────────────────────── */
const getItemPath = (listing) =>
  listing.category === 'stays' || listing.category === 'property' ? `/listing/${listing._id}`
  : listing.category === 'experiences' ? `/service/${listing._id}`
  : listing.category === 'selling'     ? `/sell-item/${listing._id}`
  : `/helper/${listing._id}`;

const getEditPath = (listing) =>
  listing.category === 'stays' || listing.category === 'property' ? `/update-listing/${listing._id}`
  : listing.category === 'experiences' ? `/update-service/${listing._id}`
  : listing.category === 'selling'     ? `/sell-item/${listing._id}`
  : `/update-helper/${listing._id}`;

const formatDate = (dateStr) => {
  if (!dateStr) return null;
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    return d.toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch { return null; }
};

const CATEGORY_LABELS = {
  stays: 'Stay', property: 'Property', experiences: 'Service', online: 'Helper', selling: 'Item for Sale',
};

/* ─── Listing card ────────────────────────────────────────────────────────────── */
function ListingCard({ listing, onEdit, onDelete, deletingId, navigate }) {
  const [imgError, setImgError] = useState(false);
  const imgSrc    = listing.imageUrls?.[0] || listing.images?.[0] || null;
  const title     = listing.name || listing.title || 'Untitled';
  const location  = listing.address || listing.location || null;
  const uploaded  = formatDate(listing.createdAt);
  const typeLabel = CATEGORY_LABELS[listing.category] || listing.category || '';
  const isDeleting = deletingId === listing._id;

  return (
    <div className="relative cursor-pointer" onClick={() => navigate(getItemPath(listing))}>
      {/* Image – 3:2 */}
      <div className="relative w-full rounded-2xl overflow-hidden bg-gray-200" style={{ aspectRatio: '3/2' }}>
        {imgSrc && !imgError ? (
          <img
            src={imgSrc}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.04] transition-transform duration-500"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <FaPlus className="w-7 h-7 text-gray-300" />
          </div>
        )}

        {/* Category badge – top left */}
        {typeLabel && (
          <span className="absolute top-3 left-3 text-[10px] font-bold uppercase tracking-wide px-2.5 py-1 rounded-full bg-white/90 text-gray-800 shadow-sm">
            {typeLabel}
          </span>
        )}

        {/* Edit / Delete – top right */}
        <div
          className="absolute top-3 right-3 flex gap-1.5 opacity-100 transition-opacity md:opacity-0 md:group-hover:opacity-100 md:group-focus-within:opacity-100"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={() => onEdit(listing)}
            aria-label="Edit"
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white shadow text-gray-600 hover:text-rose-500 transition-colors"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDelete(listing._id, listing.category)}
            disabled={isDeleting}
            aria-label="Delete"
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white shadow text-gray-600 hover:text-rose-500 transition-colors"
          >
            {isDeleting
              ? <FaSpinner className="w-3.5 h-3.5 animate-spin" />
              : <Trash2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Text below – WishList style */}
      <div className="mt-2 px-0.5 space-y-0.5">
        <p className="text-[14px] font-semibold text-gray-900 truncate leading-snug">{title}</p>
        {location && <p className="text-[13px] text-gray-500 truncate">{location}</p>}
        {uploaded && <p className="text-[12px] text-gray-400">Uploaded {uploaded}</p>}
      </div>
    </div>
  );
}

/* ─── Main component ─────────────────────────────────────────────────────────── */
export default function UserListings() {
  const navigate = useNavigate();
  const { currentUser } = useSelector((state) => state.user);
  const [deletingId,    setDeletingId]    = useState(null);
  const [userListings,  setUserListings]  = useState([]);
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [confirmTarget, setConfirmTarget] = useState(null); // { id, category, title }
  const [deleteError,   setDeleteError]   = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', price: '', category: 'furniture', condition: '', contact: '', address: '' });
  const [savingEdit, setSavingEdit] = useState(false);
  const [editError, setEditError] = useState('');
  const userId = currentUser?._id || currentUser?.id;

  useEffect(() => {
    if (!currentUser) navigate('/sign-in');
  }, [currentUser?._id, navigate]);

  const fetchListings = async () => {
    setLoading(true);
    try {
      const isServicesProvider = currentUser?.offeringType === 'services';
      const token = localStorage.getItem('access_token') || localStorage.getItem('token') || currentUser?.token || '';
      const authHeaders = {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      };

      const [listingsData, servicesData, helpersData, sellsData] = await Promise.all([
        !isServicesProvider 
          ? fetch(`/api/user/listings/${userId}`, { headers: authHeaders, credentials: 'include' }).then(r => r.json()).catch(() => [])
          : Promise.resolve([]),
        fetch(`/api/user/services/${userId}`, { headers: authHeaders, credentials: 'include' }).then(r => r.json()).catch(() => []),
        fetch(`/api/user/helpers/${userId}`, { headers: authHeaders, credentials: 'include' }).then(r => r.json()).catch(() => []),
        fetch(`/api/user/sell/${userId}`, { headers: authHeaders, credentials: 'include' }).then(r => r.json()).catch(() => []),
      ]);
      const allItems = [
        ...(Array.isArray(listingsData) ? listingsData : (listingsData.listings || [])).map(l => ({ ...l, category: 'stays' })),
        ...(Array.isArray(servicesData) ? servicesData : (servicesData.services || [])).map(s => ({ ...s, category: 'experiences' })),
        ...(Array.isArray(helpersData)  ? helpersData  : (helpersData.helpers   || [])).map(h => ({ ...h, category: 'online' })),
        ...(Array.isArray(sellsData)    ? sellsData    : (sellsData.data || sellsData.sells || [])).map(g => ({ ...g, itemCategory: g.category || g.itemCategory || 'furniture', category: 'selling' })),
      ].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      setUserListings(allItems);
    } catch (err) {
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id, category) => {
    setConfirmTarget(null);
    setDeletingId(id);
    setDeleteError(null);
    try {
      const endpoint =
        category === 'stays'       ? `/api/listing/delete/${id}`
        : category === 'experiences' ? `/api/service/delete/${id}`
        : category === 'selling'     ? `/api/sell/${id}`
        : `/api/helper/delete/${id}`;
      const res = await authenticatedFetch(endpoint, {
        method: 'DELETE',
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || 'Failed to delete');
      setUserListings(prev => prev.filter(l => l._id !== id));
    } catch (err) {
      setDeleteError(err.message || 'Failed to delete. Please try again.');
    } finally {
      setDeletingId(null);
    }
  };

  useEffect(() => {
    if (userId) fetchListings();
  }, [userId]);

  const startEdit = (listing) => {
    if (listing.category === 'selling') {
      setEditError('');
      setEditingItem(listing);
      setEditForm({
        title: listing.title || listing.name || '',
        description: listing.description || '',
        price: listing.price ?? '',
        category: listing.categoryType || listing.itemCategory || listing.productCategory || 'furniture',
        condition: listing.condition || '',
        contact: listing.contact || '',
        address: listing.address || '',
      });
      return;
    }
    navigate(getEditPath(listing));
  };

  const saveSellEdit = async (event) => {
    event.preventDefault();
    if (!editingItem) return;
    setSavingEdit(true);
    setEditError('');
    try {
      const response = await authenticatedFetch(`/api/sell/${editingItem._id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...editForm, price: Number(editForm.price) }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.message || 'Could not update this item.');
      const updated = payload.data || payload;
      setUserListings((items) => items.map((item) => item._id === editingItem._id ? { ...item, ...updated, itemCategory: updated.category || editForm.category, category: 'selling' } : item));
      setEditingItem(null);
    } catch (error) {
      setEditError(error.message || 'Could not update this item. Please try again.');
    } finally {
      setSavingEdit(false);
    }
  };

  const FILTERS = [
    { key: 'stays',       label: 'Stays' },
    { key: 'experiences', label: 'Services' },
    { key: 'online',      label: 'Helpers' },
    { key: 'selling',     label: 'Goods' },
  ].filter(f => {
    if (!currentUser?.offeringType) return true;
    if (currentUser.offeringType === 'services') return f.key === 'experiences' || f.key === 'online';
    if (currentUser.offeringType === 'property') return f.key === 'stays';
    if (currentUser.offeringType === 'goods') return f.key === 'selling';
    return true;
  });

  const filtered = selectedTypes.length > 0
    ? userListings.filter(l => selectedTypes.includes(l.category))
    : userListings;

  /* ── Loading skeleton ── */
  if (loading) {
    return (
      <div className="min-h-screen bg-white" style={{ fontFamily: "'Inter','Helvetica Neue',sans-serif" }}>
        <header className="app-safe-top sticky top-0 z-30 bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-[72px] flex items-center gap-3">
            <div className="w-9 h-9 bg-gray-100 rounded-full" />
            <div className="h-5 w-32 bg-gray-100 rounded-full" />
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-6 pt-8">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-8">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="w-full bg-gray-200 rounded-2xl" style={{ aspectRatio: '3/2' }} />
                <div className="mt-2 space-y-1.5">
                  <div className="h-3.5 bg-gray-200 rounded-full w-3/4" />
                  <div className="h-3 bg-gray-100 rounded-full w-1/2" />
                  <div className="h-3 bg-gray-100 rounded-full w-1/3" />
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white app-safe-content-bottom pb-20" style={{ fontFamily: "'Inter','Helvetica Neue',sans-serif" }}>
      {/* Sticky header */}
      <header className="app-safe-top sticky top-0 z-30 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-[72px] flex items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => navigate(-1)}
              aria-label="Go back"
              className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors flex-shrink-0"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M10 13L5 8L10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <div className="min-w-0">
              <h1 className="text-[18px] sm:text-[20px] font-semibold text-gray-900 tracking-tight leading-tight truncate">Manage listings</h1>
              <p className="text-[12px] sm:text-[13px] text-gray-400 leading-tight">{userListings.length} {userListings.length === 1 ? 'post' : 'posts'}</p>
            </div>
          </div>
          {currentUser && canCreateListings(currentUser) && currentUser.offeringType !== 'viewer' ? (
            <Link
              to={getCreationRoute(currentUser) || `/${currentUser._id}/create-listing`}
              className="flex-shrink-0 inline-flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow transition-all duration-200"
            >
              <FaPlus className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              <span>New Post</span>
            </Link>
          ) : (
            <Link
              to="/become"
              className="flex-shrink-0 inline-flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-2 sm:py-2.5 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white text-xs sm:text-sm font-semibold rounded-xl shadow transition-all duration-200"
            >
              <span>Become a Host</span>
            </Link>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 pt-8">
        {/* Filter pills */}
        <div className="flex gap-2 mb-8 flex-wrap">
          {FILTERS.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setSelectedTypes(prev => prev.includes(key) ? prev.filter(t => t !== key) : [...prev, key])}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold border transition-all ${
                selectedTypes.includes(key)
                  ? 'bg-gray-900 text-white border-gray-900'
                  : 'bg-white text-gray-700 border-gray-200 hover:border-gray-400'
              }`}
            >
              {label}
            </button>
          ))}
          {selectedTypes.length > 0 && (
            <button
              onClick={() => setSelectedTypes([])}
              className="px-4 py-1.5 rounded-full text-sm font-medium text-gray-400 hover:text-gray-700 transition-colors"
            >
              Clear
            </button>
          )}
        </div>

        {/* Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-8">
            {filtered.map(listing => (
              <ListingCard
                key={listing._id}
                listing={listing}
                onEdit={startEdit}
                onDelete={(id, cat) => {
                  const item = userListings.find(l => l._id === id);
                  setConfirmTarget({ id, category: cat, title: item?.name || item?.title || 'this item' });
                }}
                deletingId={deletingId}
                navigate={navigate}
              />
            ))}
          </div>
        ) : (
          /* Empty state */
          <div className="py-24 flex flex-col items-center text-center max-w-sm mx-auto">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6" style={{ background: 'rgba(225,29,72,0.08)' }}>
              <FaPlus className="w-7 h-7 text-rose-500" />
            </div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-3">
              {userListings.length === 0 ? 'Ready to become a host or provider?' : 'No matches'}
            </h2>
            <p className="text-gray-500 text-[15px] leading-relaxed mb-8">
              {userListings.length === 0
                ? (currentUser?.offeringType === 'viewer'
                    ? 'Your account is currently set up for browsing and booking. Learn how to convert your account into a host, service provider, or shop owner.'
                    : 'Create your first listing and start earning.')
                : 'Try a different filter or clear all.'}
            </p>
            {userListings.length === 0 ? (
              currentUser?.offeringType === 'viewer' ? (
                <Link
                  to="/become"
                  className="px-6 py-3 text-[15px] font-semibold text-white rounded-xl hover:opacity-90 transition-opacity shadow-md"
                  style={{ background: 'linear-gradient(to right, #f59e0b, #e11d48)' }}
                >
                  Learn How to Become a Host
                </Link>
              ) : (
                <Link
                  to="/create-listing"
                  className="px-6 py-3 text-[15px] font-semibold text-white rounded-xl hover:opacity-90 transition-opacity"
                  style={{ background: 'linear-gradient(to right, #e11d48, #be123c)' }}
                >
                  Create Listing
                </Link>
              )
            ) : (
              <button
                onClick={() => setSelectedTypes([])}
                className="px-6 py-3 text-[15px] font-semibold text-gray-700 border border-gray-300 rounded-xl hover:border-gray-500 transition-colors"
              >
                Clear Filters
              </button>
            )}
          </div>
        )}
      </main>

      {/* ── Delete error banner ── */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/50 p-0 backdrop-blur-sm sm:items-center sm:p-4" onClick={() => !savingEdit && setEditingItem(null)}>
          <form onSubmit={saveSellEdit} onClick={(event) => event.stopPropagation()} className="max-h-[92dvh] w-full max-w-lg space-y-4 overflow-y-auto rounded-t-3xl bg-white p-5 shadow-2xl dark:bg-gray-900 sm:rounded-3xl sm:p-6">
            <div className="flex items-start justify-between gap-4">
              <div><h2 className="text-xl font-bold text-gray-900 dark:text-white">Edit item for sale</h2><p className="mt-1 text-sm text-gray-500">Update the details buyers see.</p></div>
              <button type="button" onClick={() => setEditingItem(null)} disabled={savingEdit} aria-label="Close editor" className="rounded-full p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800"><X className="h-5 w-5" /></button>
            </div>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Item name<input required maxLength={120} value={editForm.title} onChange={(event) => setEditForm((form) => ({ ...form, title: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800" /></label>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Description<textarea required rows={4} maxLength={3000} value={editForm.description} onChange={(event) => setEditForm((form) => ({ ...form, description: event.target.value }))} className="mt-1.5 w-full resize-y rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800" /></label>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Price (R)<input required type="number" min="0" step="0.01" value={editForm.price} onChange={(event) => setEditForm((form) => ({ ...form, price: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800" /></label>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Condition<input maxLength={60} value={editForm.condition} onChange={(event) => setEditForm((form) => ({ ...form, condition: event.target.value }))} placeholder="New, excellent, used…" className="mt-1.5 w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800" /></label>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Category<select value={editForm.category} onChange={(event) => setEditForm((form) => ({ ...form, category: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800"><option value="furniture">Furniture</option><option value="electronics">Electronics</option><option value="clothes">Clothes</option><option value="universities">University items</option><option value="books">Books</option><option value="other">Other items</option></select></label>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Contact number<input required type="tel" value={editForm.contact} onChange={(event) => setEditForm((form) => ({ ...form, contact: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800" /></label>
            </div>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Location<input value={editForm.address} onChange={(event) => setEditForm((form) => ({ ...form, address: event.target.value }))} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 font-normal dark:border-gray-700 dark:bg-gray-800" /></label>
            {editError && <p role="alert" className="rounded-xl bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:bg-rose-950/30 dark:text-rose-300">{editError}</p>}
            <div className="flex gap-3 pt-1"><button type="button" onClick={() => setEditingItem(null)} disabled={savingEdit} className="flex-1 rounded-xl border border-gray-200 px-4 py-3 text-sm font-semibold text-gray-700 dark:border-gray-700 dark:text-gray-200">Cancel</button><button type="submit" disabled={savingEdit} className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-rose-600 px-4 py-3 text-sm font-semibold text-white hover:bg-rose-700 disabled:opacity-60">{savingEdit ? <FaSpinner className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Save changes</button></div>
          </form>
        </div>
      )}

      {deleteError && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 bg-red-600 text-white px-5 py-3 rounded-2xl shadow-xl text-sm font-medium max-w-sm w-full mx-4">
          <span className="flex-1">{deleteError}</span>
          <button onClick={() => setDeleteError(null)} aria-label="Dismiss" className="text-white/70 hover:text-white">✕</button>
        </div>
      )}

      {/* ── Delete confirm modal ── */}
      {confirmTarget && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-4"
          onClick={() => setConfirmTarget(null)}
        >
          <div
            className="bg-white rounded-3xl shadow-2xl w-full max-w-sm p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-50 flex items-center justify-center mb-1">
              <Trash2 className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <h3 className="text-[17px] font-semibold text-gray-900">Delete listing?</h3>
              <p className="text-[14px] text-gray-500 mt-1">
                "<span className="font-medium text-gray-700">{confirmTarget.title}</span>" will be permanently removed. This cannot be undone.
              </p>
            </div>
            <div className="flex gap-2 pt-1">
              <button
                onClick={() => setConfirmTarget(null)}
                className="flex-1 py-2.5 text-[14px] font-semibold text-gray-700 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(confirmTarget.id, confirmTarget.category)}
                disabled={deletingId === confirmTarget.id}
                className="flex-1 py-2.5 text-[14px] font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {deletingId === confirmTarget.id ? <FaSpinner className="w-3.5 h-3.5 animate-spin" /> : null}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

