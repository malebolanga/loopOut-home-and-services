/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import ListingPhotoGallery from '../components/ListingPhotoGallery';
import ListingDetailShell from '../components/ListingDetailShell';
import ServiceDetailsModal from '../components/ServiceDetailsModal';
import { motion, AnimatePresence } from 'framer-motion';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { getDownloadURL, getStorage, ref, uploadBytesResumable } from "firebase/storage";
import { app } from "../firebase";
import OperatingSchedule from '../components/OperatingSchedule';
import { useWishlist } from '../hooks/useWishlist';
import { pushPhoneNotification } from '../components/PhoneNotificationManager';
import { authenticatedFetch } from '../utils/authenticatedFetch';
import { Link } from "react-router-dom";
import {
  StarIcon,
  HomeIcon,
  UserIcon,
  PhoneIcon,
  EnvelopeIcon,
  BoltIcon,
  ShieldCheckIcon,
  FlagIcon,
  CheckCircleIcon,
  ArrowLeftIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronDownIcon,
  XMarkIcon,
  CameraIcon,
  PhotoIcon,
  WifiIcon,
  TruckIcon,
  KeyIcon,
  HeartIcon,
  ShareIcon,
  InformationCircleIcon,
  PaperAirplaneIcon,
  ClockIcon,
  CurrencyDollarIcon,
  TagIcon,
  UserGroupIcon,
  ChatBubbleLeftRightIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  PlusCircleIcon,
  MapPinIcon,
  CheckIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline';
import { 
  StarIcon as StarIconSolid, 
  HeartIcon as HeartIconSolid,
  CheckBadgeIcon
} from '@heroicons/react/24/solid';
import { Sparkles } from 'lucide-react';
import { 
  FaTshirt, FaBroom, FaFire, FaBaby, FaGlassCheers, FaEllipsisH, FaPalette,
  FaSpa, FaStar, FaCut, FaGraduationCap, FaChalkboardTeacher, FaBook, FaLanguage,
  FaPencilAlt, FaHandsWash, FaToolbox, FaWrench, FaTools, FaScrewdriver,
  FaSnowflake, FaPlug, FaInstagram, FaFacebook, FaTwitter, FaLinkedin, FaTiktok,
  FaCamera, FaAward, FaBuilding, FaMapMarkerAlt, FaFileAlt, FaBriefcase, FaUserGraduate,
  FaTrophy, FaCertificate, FaHandSparkles, FaClock, FaCheckCircle, FaTrashAlt, FaLeaf,
  FaTruck, FaUser, FaPhone, FaWhatsapp, FaInfoCircle, FaShieldAlt,
  FaHandHoldingHeart, FaRing, FaBrush, FaSmile, FaUtensils, FaCookie, FaShoppingBasket,
  FaShoePrints, FaSoap, FaTint, FaWater, FaCogs, FaBath, FaSun, FaDog, FaPaw, FaFish,
  FaUserFriends, FaHome, FaCat, FaDove, FaHorse, FaArrowRight, FaSprayCan, FaWind, FaCar,
  FaExclamationTriangle, FaHeart, FaSpinner
} from 'react-icons/fa';
import { FiShare2, FiMessageSquare, FiMapPin, FiHeart, FiClock, FiStar, FiChevronRight, FiChevronLeft } from 'react-icons/fi';
import { MdCleanHands, MdOutlineGppGood, MdLogin, MdChat, MdLocationOn, MdAttachMoney, MdVerified } from 'react-icons/md';
import { hasProfanity } from '../utils/profanityFilter';

// Some icons might be double defined in Fi or Md, so I adjusted the list.
// FaBroomClean doesn't exist in standard Fa, likely was a typo or specialized set. Using FaBroom.


import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Zoom, Thumbs, Pagination, FreeMode } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/zoom';
import 'swiper/css/thumbs';
import 'swiper/css/pagination';
import 'swiper/css/free-mode';

// Swiper styles already imported above

import ImageWithFallback from '../components/ImageWithFallback';
import GoogleMapComponent from '../components/GoogleMapComponent';
import HelperComments from '../components/HelperComments';
import CommentsSidePanelHelper from '../components/CommentsSidePanelHelper';
import HelperItem from '../components/HelperItem';
import BookingHistory from '../components/BookingHistory';
import BookingProgress from '../components/BookingProgress';
import { useBookedSlots } from '../hooks/useBookedSlots';
import BookingTimeSlots from '../components/BookingTimeSlots';
import HelperBookingSheet from '../components/HelperBookingSheet';

export default function HelperPage() {
  const [selectedModalService, setSelectedModalService] = useState(null);
  const { currentUser } = useSelector((state) => state.user);
  const [helper, setHelper] = useState(null);
  const [loading, setLoading] = useState(true);

  const params = useParams();
  const isPhaleaddiListing = String(params.id || params.helperId || '') === '6a889887ad769bb5a3e6c341';
  const providerDisplayName = isPhaleaddiListing ? 'Phaleaddi' : helper?.name;
  const accountOwnerName = helper?.userRef?.username || helper?.userRef?.name || helper?.userRef?.fullName || 'Account owner';
  const accountOwnerId = helper?.userRef?._id || helper?.userRef;
  const description = isPhaleaddiListing
    ? 'Phaleaddi offers domestic support for South African homes, including tidying, laundry, kitchen upkeep, and guest-ready living areas. Confirm the service scope, schedule, and final price with the provider before reserving.'
    : helper?.description || '';
  const { bookedDates, isTimeSlotBooked, isDateFullyBooked } = useBookedSlots(helper?._id || params.id || params.helperId);
  const [error, setError] = useState('');
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [showCommentsPanel, setShowCommentsPanel] = useState(false);
  const [showAllReviewsPanel, setShowAllReviewsPanel] = useState(false);
  const [commentCount, setCommentCount] = useState(0);
  const [showBookingBelt, setShowBookingBelt] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [dislikeCount, setDislikeCount] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const [ratings, setRatings] = useState(null);
  
  const { isFavorite, toggleFavorite } = useWishlist(helper, 'helper');
  const [shareCopied, setShareCopied] = useState(false);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: providerDisplayName || 'Helper Profile',
        text: helper?.description,
        url: window.location.href,
      }).catch((err) => console.error('Error sharing:', err));
    } else {
      navigator.clipboard.writeText(window.location.href);
      setShareCopied(true);
      setTimeout(() => setShareCopied(false), 2000);
    }
  };
  const [topComments, setTopComments] = useState([]);
  const [similarHelpers, setSimilarHelpers] = useState([]);
  const [bookingSummary, setBookingSummary] = useState({ count: 0, recentBookers: [] });
  const [zoomedImage, setZoomedImage] = useState(null);

  // Performer Rating States
  const [userBookings, setUserBookings] = useState([]);
  const [showPerformerRatingModal, setShowPerformerRatingModal] = useState(false);
  const [selectedPerformerToRate, setSelectedPerformerToRate] = useState(null);
  const [performerRating, setPerformerRating] = useState(5);
  const [hoveredPerformerRating, setHoveredPerformerRating] = useState(0);
  const [ratingError, setRatingError] = useState('');
  const [ratingSuccess, setRatingSuccess] = useState(false);
  const [submittingRating, setSubmittingRating] = useState(false);
  const [ratingInfoMessage, setRatingInfoMessage] = useState(null);

  const RECENTLY_VIEWED_KEY = 'recentlyViewed';

  useEffect(() => {
    if (helper) {
      fetchSimilarHelpers();
      fetchBookingSummary();
      saveToHistory(helper);
    }
  }, [helper]);

  const fetchBookingSummary = async () => {
    try {
      const res = await authenticatedFetch(`/api/bookings/helper-summary/${helper._id}`);
      if (res.ok) {
        const data = await res.json();
        setBookingSummary(data);
      }
    } catch (error) {
      console.error('Error fetching booking summary:', error);
    }
  };

  const fetchSimilarHelpers = async () => {
    try {
      const res = await fetch(`/api/helper/similar/${helper._id}`);
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setSimilarHelpers(data);
    } catch (error) {
      console.error('Error fetching similar helpers:', error);
    }
  };

  const saveToHistory = (item) => {
    try {
      const stored = localStorage.getItem(RECENTLY_VIEWED_KEY);
      let history = stored ? JSON.parse(stored) : [];
      history = history.filter(h => h._id !== item._id);
      history.unshift({
        ...item,
        itemType: 'helper',
        viewedAt: new Date().toISOString()
      });
      localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(history.slice(0, 20)));
    } catch (error) {
      console.error('Error saving history:', error);
    }
  };

  // ==================== SERVICE CONFIGURATION (MOVED UP) ====================

  // Service options for different helper types
  const getServiceOptions = (type) => {
    const baseOptions = [
      { id: 'laundry', name: 'Laundry', icon: <FaTshirt className="text-blue-500" /> },
      { id: 'ironing', name: 'Ironing', icon: <FaTshirt className="text-purple-500" /> },
      { id: 'houseCleaning', name: 'Cleaning the House', icon: <FaBroom className="text-green-500" /> },
      { id: 'yardCleaning', name: 'Cleaning the Yard', icon: <FaLeaf className="text-lime-600" /> },
      { id: 'fullHouseCleaning', name: 'Full House Cleaning', icon: <FaHome className="text-emerald-600" /> },
      { id: 'springCleaning', name: 'Spring Cleaning', icon: <FaHandSparkles className="text-amber-500" /> },
      { id: 'curtainWashing', name: 'Washing Curtains', icon: <FaSprayCan className="text-indigo-500" /> },
      { id: 'windowWashing', name: 'Windows Wash', icon: <FaWater className="text-cyan-500" /> },
      { id: 'cooking', name: 'Cooking / Meal Prep', icon: <FaFire className="text-red-500" /> },
      { id: 'babysitting', name: 'Child Care', icon: <FaBaby className="text-pink-500" /> },
      { id: 'eventCleaning', name: 'Event Cleanup', icon: <FaGlassCheers className="text-purple-500" /> },
      { id: 'other', name: 'Other Helper Services', icon: <FaEllipsisH className="text-gray-500" /> }
    ];

    const beautyOptions = [
      { id: 'makeup', name: 'Makeup', icon: <FaPalette className="text-pink-500" /> },
      { id: 'skincare', name: 'Facials', icon: <FaSpa className="text-purple-400" /> },
      { id: 'nails', name: 'Nails', icon: <FaHandSparkles className="text-red-400" /> },
      { id: 'hair', name: 'Hair Styling', icon: <FaCut className="text-blue-400" /> },
      { id: 'facial', name: 'Skin Therapy', icon: <FaStar className="text-yellow-500" /> },
      { id: 'waxing', name: 'Waxing', icon: <FaFire className="text-orange-500" /> },
      { id: 'massage', name: 'Massage', icon: <FaHandHoldingHeart className="text-green-400" /> },
      { id: 'bridal', name: 'Bridal', icon: <FaRing className="text-rose-500" /> }
    ];

    const barberOptions = [
      { id: 'haircut', name: 'Haircut', icon: <FaCut className="text-blue-600" /> },
      { id: 'beardTrim', name: 'Beard Trim', icon: <FaUser className="text-gray-700" /> },
      { id: 'shave', name: 'Razor Shave', icon: <FaTools className="text-gray-900" /> },
      { id: 'fade', name: 'Fade', icon: <FaCut className="text-indigo-600" /> },
      { id: 'coloring', name: 'Coloring', icon: <FaBrush className="text-purple-500" /> },
      { id: 'styling', name: 'Styling', icon: <FaSprayCan className="text-yellow-600" /> },
      { id: 'kidsCut', name: 'Kids Cut', icon: <FaSmile className="text-green-500" /> },
      { id: 'consultation', name: 'Consult', icon: <FaUser className="text-teal-500" /> }
    ];

    const chefOptions = [
      { id: 'breakfast', name: 'Breakfast & Brunch Menu', icon: <FaUtensils className="text-amber-500" />, description: 'Artisanal eggs benedict, fluffy pancakes, fresh pastries, seasonal fruit, premium coffee & juices', price: 180 },
      { id: 'desserts', name: 'Desserts & High Tea', icon: <FaCookie className="text-pink-500" />, description: 'Gourmet dessert station, custom cakes, delicate pastries, mousses & high-tea sweet delicacies', price: 160 },
      { id: 'full-course', name: 'Full Course Menu / Tasting Menu', icon: <FaUtensils className="text-purple-600" />, description: 'Complete multi-course gourmet dining experience: welcome amuse-bouche, starter, signature main & dessert', price: 450 },
      { id: 'privateDining', name: 'Private Dinner Experience', icon: <FaUtensils className="text-red-500" />, description: 'Intimate fine-dining dinner experience crafted with exquisite seasonal ingredients', price: 380 },
      { id: 'lunch', name: 'Lunch Feast Banquet', icon: <FaUtensils className="text-blue-500" />, description: 'Plated 2-course hearty lunch or corporate banquet prepared and plated fresh on-site', price: 280 },
      { id: 'braaiService', name: 'Braai / BBQ Master', icon: <FaFire className="text-orange-600" />, description: 'Professional braai master service with full setup, gourmet grilled cuts & fresh sides', price: 300 },
      { id: 'eventCatering', name: 'Event & Function Catering', icon: <FaGlassCheers className="text-purple-500" />, description: 'Full-service catering buffet or plated service for milestone parties, functions & celebrations', price: 350 },
      { id: 'functionParty', name: 'Function Party Spread', icon: <FaGlassCheers className="text-pink-500" />, description: 'Catering for large function parties, celebrations and social events', price: 320 },
      { id: 'babyShower', name: 'Baby / Bridal Shower Spread', icon: <FaBaby className="text-blue-400" />, description: 'Delightful finger foods, savory platters, mini sliders, macarons & mocktails', price: 260 },
      { id: 'mealPrep', name: 'Weekly Meal Prep', icon: <FaUtensils className="text-emerald-500" />, description: 'Weekly nutrition-focused meal preparation, portioned & stored for effortless healthy eating', price: 250 },
      { id: 'veganVeg', name: 'Vegan / Plant-Based Feast', icon: <FaLeaf className="text-emerald-500" />, description: '100% gourmet plant-based fine dining packed with vibrant flavors & balanced nutrition', price: 300 },
      { id: 'baking', name: 'Baking & Celebration Cakes', icon: <FaCookie className="text-yellow-500" />, description: 'Bespoke custom cakes, artisan sourdough, tarts & baked confectioneries for any celebration', price: 220 },
      { id: 'kidsMeals', name: "Kids' Party Menu", icon: <FaSmile className="text-yellow-500" />, description: 'Tasty, nutritious and fun kid-approved meals, sliders, mini pizzas and dessert treats', price: 150 },
      { id: 'cookingClasses', name: 'Private Cooking Masterclass', icon: <FaGraduationCap className="text-green-500" />, description: 'Interactive hands-on cooking masterclass tailored to your cuisine of choice', price: 500 },
      { id: 'menuPlanning', name: 'Menu Planning & Consulting', icon: <FaUtensils className="text-indigo-500" />, description: 'Personalised weekly or monthly menu design for households', price: 200 },
      { id: 'dietMeals', name: 'Diet & Health Meal Plan', icon: <FaLeaf className="text-green-400" />, description: 'Nutritious, balanced meals tailored to dietary goals and health needs', price: 280 },
      { id: 'weddingCatering', name: 'Wedding Catering Banquet', icon: <FaRing className="text-rose-500" />, description: 'Luxury culinary experience for weddings, plated multi-course or grand buffet banquet', price: 650 },
    ];

    const tattooOptions = [
      { id: 'custom', name: 'Custom Art', icon: <FaPalette className="text-gray-800" /> },
      { id: 'coverup', name: 'Cover-up', icon: <FaBrush className="text-purple-600" /> },
      { id: 'touchup', name: 'Touch-up', icon: <FaTools className="text-blue-600" /> },
      { id: 'consultation', name: 'Design', icon: <FaUser className="text-teal-500" /> }
    ];

    const tutorOptions = [
      { id: 'math', name: 'Mathematics', icon: <FaGraduationCap className="text-blue-600" /> },
      { id: 'science', name: 'Science', icon: <FaGraduationCap className="text-green-600" /> },
      { id: 'language', name: 'Languages', icon: <FaGraduationCap className="text-yellow-600" /> },
      { id: 'music', name: 'Music', icon: <FaGraduationCap className="text-purple-600" /> },
      { id: 'art', name: 'Art', icon: <FaPalette className="text-pink-600" /> },
      { id: 'testPrep', name: 'Test Prep', icon: <FaGraduationCap className="text-red-600" /> }
    ];

    const photographyOptions = [
      { id: 'portrait', name: 'Portrait', icon: <FaUser className="text-blue-500" /> },
      { id: 'event', name: 'Events', icon: <FaGlassCheers className="text-purple-500" /> },
      { id: 'product', name: 'Product', icon: <FaShoppingBasket className="text-green-500" /> },
      { id: 'wedding', name: 'Wedding', icon: <FaRing className="text-pink-500" /> },
      { id: 'family', name: 'Family', icon: <FaUserFriends className="text-orange-500" /> },
      { id: 'commercial', name: 'Commercial', icon: <FaBriefcase className="text-indigo-500" /> },
      { id: 'realestate', name: 'Real Estate', icon: <FaHome className="text-yellow-600" /> },
      { id: 'landscape', name: 'Landscape', icon: <FaMapMarkerAlt className="text-teal-500" /> }
    ];

    const sneakerOptions = [
      { id: 'basicClean', name: 'Basic Clean', icon: <FaShoePrints className="text-indigo-500" /> },
      { id: 'deepClean', name: 'Deep Clean', icon: <FaSoap className="text-purple-500" /> },
      { id: 'stainRemoval', name: 'Stain Removal', icon: <FaTint className="text-blue-500" /> },
      { id: 'whitening', name: 'Whitening', icon: <FaStar className="text-yellow-500" /> },
      { id: 'restoration', name: 'Restoration', icon: <FaTools className="text-gray-600" /> },
      { id: 'waterproofing', name: 'Waterproofing', icon: <FaWater className="text-cyan-500" /> },
      { id: 'soleRepair', name: 'Sole Repair', icon: <FaCogs className="text-gray-700" /> },
      { id: 'colorRestore', name: 'Color Restore', icon: <FaPalette className="text-pink-500" /> }
    ];

    const washingmatOptions = [
      { id: 'basicWash', name: 'Basic Wash', icon: <FaWater className="text-blue-500" /> },
      { id: 'deepClean', name: 'Deep Clean', icon: <FaBath className="text-purple-500" /> },
      { id: 'stainRemoval', name: 'Stain Removal', icon: <FaTint className="text-red-500" /> },
      { id: 'sanitizing', name: 'Sanitizing', icon: <FaShieldAlt className="text-green-500" /> },
      { id: 'deodorizing', name: 'Deodorizing', icon: <FaWind className="text-teal-500" /> },
      { id: 'steamCleaning', name: 'Steam Cleaning', icon: <FaFire className="text-orange-500" /> },
      { id: 'drying', name: 'Drying Service', icon: <FaSun className="text-yellow-500" /> },
      { id: 'pickupDelivery', name: 'Pickup & Delivery', icon: <FaTruck className="text-gray-600" /> }
    ];

    const animalOptions = [
      { id: 'dogWalking', name: 'Dog Walking', icon: <FaDog className="text-amber-600" /> },
      { id: 'petSitting', name: 'Pet Sitting', icon: <FaPaw className="text-amber-500" /> },
      { id: 'grooming', name: 'Grooming', icon: <FaCut className="text-purple-500" /> },
      { id: 'bathing', name: 'Bathing', icon: <FaBath className="text-blue-500" /> },
      { id: 'feeding', name: 'Feeding', icon: <FaFish className="text-green-500" /> },
      { id: 'medication', name: 'Medication', icon: <FaShieldAlt className="text-red-500" /> },
      { id: 'training', name: 'Training', icon: <FaGraduationCap className="text-indigo-500" /> },
      { id: 'vetVisits', name: 'Vet Visits', icon: <FaTruck className="text-gray-600" /> },
      { id: 'catCare', name: 'Cat Care', icon: <FaCat className="text-amber-400" /> },
      { id: 'birdCare', name: 'Bird Care', icon: <FaDove className="text-sky-500" /> },
      { id: 'horseCare', name: 'Horse Care', icon: <FaHorse className="text-brown-500" /> }
    ];

    const transportOptions = [
      { id: 'schoolTransport', name: 'School Transport', icon: <FaCar className="text-yellow-500" /> },
      { id: 'privateRide', name: 'Private Ride', icon: <FaCar className="text-blue-500" /> },
      { id: 'furnitureRemoval', name: 'Furniture Removal', icon: <FaTruck className="text-orange-500" /> },
      { id: 'delivery', name: 'Delivery', icon: <FaBriefcase className="text-green-500" /> },
      { id: 'intercity', name: 'Inter-city Trip', icon: <FaArrowRight className="text-indigo-500" /> }
    ];

    const handymanOptions = [
      { id: 'generalRepairs', name: 'General Repairs', icon: <FaWrench className="text-zinc-600" /> },
      { id: 'plumbing', name: 'Plumbing', icon: <FaTools className="text-blue-500" /> },
      { id: 'electrical', name: 'Electrical', icon: <FaTools className="text-yellow-500" /> },
      { id: 'painting', name: 'Painting', icon: <FaPalette className="text-purple-500" /> },
      { id: 'gardening', name: 'Gardening & Landscaping', icon: <FaTools className="text-green-500" /> },
      { id: 'carpentry', name: 'Carpentry', icon: <FaTools className="text-amber-600" /> },
      { id: 'tiling', name: 'Tiling', icon: <FaTools className="text-stone-500" /> },
      { id: 'roofing', name: 'Roofing', icon: <FaHome className="text-red-500" /> }
    ];

    switch (type) {
      case 'handyman':
      case 'maintenance':
        return handymanOptions;
      case 'beauty':
      case 'spa':
        return beautyOptions;
      case 'barber':
      case 'barbar':
        return barberOptions;
      case 'chef':
      case 'cooking':
        return chefOptions;
      case 'tattoo':
        return tattooOptions;
      case 'tutor':
        return tutorOptions;
      case 'photography':
        return photographyOptions;
      case 'domestic':
      case 'maid':
        return baseOptions;
      case 'sneaker':
        return sneakerOptions;
      case 'washingmat':
        return washingmatOptions;
      case 'animals':
        return animalOptions;
      case 'transport':
        return transportOptions;
      default:
        return [];
    }
  };

  // Prefer the provider's saved menu. This specific domestic-work listing
  // describes these services but has no saved serviceList, so show its stated
  // scope as quote-based options instead of leaving the section empty.
  const savedServiceOptions = (helper?.serviceList && helper.serviceList.length > 0)
    ? helper.serviceList.map((s, index) => ({ 
        id: s._id ? String(s._id) : (s.id ? String(s.id) : `${s.name || 'service'}-${index}`), 
        name: s.name, 
        type: s.type,
        description: s.description,
        price: s.price,
        image: s.image,
        icon: <FaCheckCircle className="text-rose-500" /> 
      }))
    : [];
  const domesticWorkOptions = isPhaleaddiListing ? [
    { id: 'ironing', name: 'Ironing', type: 'Home care', description: 'Ironing for everyday clothing and household linen.', icon: <FaTshirt className="text-purple-500" /> },
    { id: 'laundry', name: 'Laundry', type: 'Home care', description: 'Laundry support for your household.', icon: <FaTshirt className="text-blue-500" /> },
    { id: 'houseCleaning', name: 'House cleaning', type: 'Cleaning', description: 'Tidying and cleaning for living areas.', icon: <FaBroom className="text-emerald-500" /> },
    { id: 'kitchenUpkeep', name: 'Kitchen upkeep', type: 'Home care', description: 'Help keeping kitchen areas clean and organised.', icon: <FaUtensils className="text-amber-500" /> },
  ] : [];
  const serviceOptions = savedServiceOptions.length > 0 ? savedServiceOptions : domesticWorkOptions;

  // Full page overlay state for booking form
  const [showBookingFormOverlay, setShowBookingFormOverlay] = useState(false);
  const [bookingStep, setBookingStep] = useState(1);

  // Full screen gallery states
  const [showFullScreenGallery, setShowFullScreenGallery] = useState(false);
  const [currentGalleryIndex, setCurrentGalleryIndex] = useState(0);

  // ==================== HELPER FUNCTIONS & STATIC DATA (MOVED UP) ====================

  // Helper function to get professional title
  const getProfessionalTitle = (type) => {
    const titles = {
      chef: 'Private Chef',
      barber: 'Barber',
      barbar: 'Barber',
      beauty: 'Beauty Professional',
      spa: 'Spa Professional',
      maid: 'Housekeeper',
      domestic: 'Domestic Helper',
      tattoo: 'Tattoo Artist',
      tutor: 'Private Tutor',
      photography: 'Photographer',
      sneaker: 'Sneaker Cleaner',
      washingmat: 'Mat Washer',
      animals: 'Animal Care Professional',
      carwash: 'Car Wash Professional',
      moving: 'Moving Service',
      other: 'Other Service Provider',
      transport: 'Transport Service',
      handyman: 'Handyman Service',
      maintenance: 'Handyman Service'
    };
    return titles[type] || 'Professional';
  };

  // Get theme color based on helper type
  const getThemeColor = (type) => {
    const themes = {
      beauty: 'pink',
      spa: 'purple',
      domestic: 'red',
      maid: 'red',
      barber: 'blue',
      barbar: 'blue',
      chef: 'orange',
      cooking: 'orange',
      tattoo: 'gray',
      tutor: 'green',
      photography: 'purple',
      sneaker: 'indigo',
      washingmat: 'cyan',
      animals: 'amber',
      carwash: 'cyan',
      moving: 'orange',
      other: 'red',
      transport: 'orange',
      handyman: 'amber',
      maintenance: 'amber',
      default: 'red'
    };
    return themes[type] || themes.default;
  };

  const themeColor = helper ? getThemeColor(helper.type) : 'red';
  const galleryImages = Array.isArray(helper?.imageUrls)
    ? helper.imageUrls.filter((url) => typeof url === 'string' && url.trim())
    : [];
  const storedRating = Number(helper?.rating);
  const computedRating = Number(ratings?.overall);
  const ratingValue = computedRating > 0 ? computedRating : (storedRating > 0 ? storedRating : null);
  const hasRating = ratingValue !== null;
  const isVerifiedProvider = Boolean(
    helper?.isVerified || helper?.verified || helper?.userRef?.isVerified || helper?.userRef?.verified
  );
  const isSuperhelper = Boolean(helper?.isSuperhelper || helper?.userRef?.isSuperhost);
  const hasBookings = Number(bookingSummary?.count) > 0;

  // Haircut styles for barbers
  const haircutStyles = [
    { id: 'classic-crew', name: 'Classic Crew Cut', description: 'Timeless short cut' },
    { id: 'fade-cut', name: 'Fade Cut', description: 'Gradual length transition' },
    { id: 'pompadour', name: 'Pompadour', description: 'Voluminous classic style' },
    { id: 'undercut', name: 'Undercut', description: 'Sharp contrast cut' },
    { id: 'buzz-cut', name: 'Buzz Cut', description: 'Uniform short length' },
    { id: 'afro-style', name: 'Afro Style', description: 'Natural texture styling' },
    { id: 'textured-crop', name: 'Textured Crop', description: 'Modern layered cut' },
    { id: 'slick-back', name: 'Slick Back', description: 'Sleek polished look' }
  ];

  // Beard styles for barbers
  const beardStyles = [
    { id: 'stubble', name: 'Stubble', description: 'Short maintained beard' },
    { id: 'short-beard', name: 'Short Beard', description: 'Neat trimmed beard' },
    { id: 'medium-beard', name: 'Medium Beard', description: 'Fuller beard style' },
    { id: 'long-beard', name: 'Long Beard', description: 'Extended beard care' },
    { id: 'goatee', name: 'Goatee', description: 'Chin focused style' },
    { id: 'van-dyke', name: 'Van Dyke', description: 'Mustache and goatee combo' },
    { id: 'circle-beard', name: 'Circle Beard', description: 'Rounded beard style' },
    { id: 'clean-shave', name: 'Clean Shave', description: 'Complete beard removal' }
  ];

  const cleaningTypes = [
    { id: 'gentle', name: 'Gentle Clean' },
    { id: 'standard', name: 'Standard Clean' },
    { id: 'deep', name: 'Deep Clean' }
  ];

  const matSizes = [
    { id: 'small', name: 'Small (Under 1.5m)' },
    { id: 'medium', name: 'Medium (1.5m - 2.5m)' },
    { id: 'large', name: 'Large (Over 2.5m)' }
  ];

  const matMaterials = [
    { id: 'synthetic', name: 'Synthetic Fiber' },
    { id: 'wool', name: 'Wool' },
    { id: 'cotton', name: 'Cotton' },
    { id: 'other', name: 'Other' }
  ];

  const stainLevels = [
    { id: 'light', name: 'Light Soiling' },
    { id: 'medium', name: 'Visible Stains' },
    { id: 'heavy', name: 'Heavy Deep-set Stains' }
  ];

  const dryingPreferences = [
    { id: 'air', name: 'Natural Air Dry' },
    { id: 'machine', name: 'Fast Machine Dry' }
  ];

  const animalSizes = [
    { id: 'small', name: 'Small (under 10kg)' },
    { id: 'medium', name: 'Medium (10-25kg)' },
    { id: 'large', name: 'Large (25-45kg)' },
    { id: 'xlarge', name: 'Extra Large (over 45kg)' }
  ];

  const animalAgeRanges = [
    { id: 'puppy', name: 'Puppy/Kitten' },
    { id: 'young', name: 'Young' },
    { id: 'adult', name: 'Adult' },
    { id: 'senior', name: 'Senior' }
  ];

  const serviceDurations = [
    { id: '30min', name: '30 minutes' },
    { id: '1hour', name: '1 hour' },
    { id: '2hours', name: '2 hours' },
    { id: '4hours', name: '4 hours' },
    { id: '8hours', name: 'Full day (8 hours)' },
    { id: 'overnight', name: 'Overnight' },
    { id: '24hours', name: '24 hours' },
    { id: 'weekly', name: 'Weekly' }
  ];

  // Equipment options for different services
  const equipmentOptions = {
    chef: [
      'Professional knives',
      'Cooking utensils',
      'Portable stove',
      'Baking equipment',
      'Serving platters',
      'Kitchen thermometer',
      'Mixer/blender',
      'Food processor'
    ],
    barber: [
      'Professional clippers',
      'Hair scissors',
      'Beard trimmers',
      'Sterilization equipment',
      'Hair styling tools',
      'Barber cape',
      'Shaving supplies',
      'Sanitizing spray'
    ],
    beauty: [
      'Makeup kit',
      'Skincare tools',
      'Sterilization equipment',
      'Nail care tools',
      'Facial steamer',
      'Beauty lights',
      'Massage oils',
      'Hot towels'
    ],
    domestic: [
      'Vacuum cleaner',
      'Mop & bucket',
      'Cleaning supplies',
      'Iron & board',
      'Window cleaning tools',
      'Garden tools',
      'Broom & dustpan',
      'Polishing cloths'
    ],
    tutor: [
      'Textbooks',
      'Stationery kits',
      'Whiteboard/Markers',
      'Educational software',
      'Reference materials',
      'Practice tests',
      'Calculator',
      'Laptop/Tablet'
    ],
    photography: [
      'Professional DSLR/Mirrorless',
      'Variety of lenses',
      'External flashes',
      'Tripods',
      'Reflectors/Diffusers',
      'Editing software',
      'Memory cards',
      'Lighting equipment'
    ],
    sneaker: [
      'Premium brushes',
      'Eco-friendly cleaners',
      'Microfiber towels',
      'Shoe trees',
      'Waterproof sprays',
      'Odor eliminators',
      'Paint touch-up kits'
    ],
    washingmat: [
      'Industrial washers',
      'Large dryers',
      'Specialist detergents',
      'Stain removers',
      'Fabric softeners',
      'Drying racks',
      'Packing materials'
    ],
    animals: [
      'Leashes/Harnesses',
      'Pet carriers',
      'Grooming brushes',
      'Pet first-aid kit',
      'Treats/Food bowls',
      'Waste bags',
      'Animal shampoo',
      'Training clicks'
    ],
    default: [
      'Professional kit',
      'Safety equipment',
      'ID verification',
      'Communication device'
    ]
  };

  // Chef-specific options
  const mealTypes = [
    { id: 'breakfast', name: 'Breakfast & Brunch', icon: '🥞', description: 'Artisanal eggs benedict, fluffy pancakes, fresh pastries, seasonal fruit, premium coffee & juices' },
    { id: 'desserts', name: 'Desserts & High Tea', icon: '🍰', description: 'Gourmet dessert station, custom cakes, delicate pastries, mousses & high-tea sweet delicacies' },
    { id: 'full-course', name: 'Full Course Menu / Tasting Menu', icon: '👑', description: 'Multi-course fine dining: starter, palate cleanser, gourmet main & decadent dessert' },
    { id: 'lunch', name: 'Lunch Feast Banquet', icon: '🍱', description: 'Plated 2-course hearty lunch or corporate feast with fresh salads and sides' },
    { id: 'dinner', name: 'Private Dinner Experience', icon: '🍷', description: 'Intimate evening fine-dining experience cooked and plated fresh at your table' },
    { id: 'braai', name: 'Braai / BBQ Smokehouse', icon: '🥩', description: 'Braai master experience with premium meats, gourmet marinades and fresh sides' },
    { id: 'buffet', name: 'Buffet Spread', icon: '🍲', description: 'Generous hot and cold buffet spread for gatherings, functions and parties' },
    { id: 'appetizers', name: 'Canapés & Finger Food', icon: '🍢', description: 'Cocktail finger foods, gourmet skewers, sliders & elegant bite-sized platters' },
    { id: 'meal-prep', name: 'Meal Prep / Batch Cooking', icon: '🥗', description: 'Weekly portioned and packaged meal prep designed for healthy home dining' },
    { id: 'vegan', name: 'Vegan / Plant-Based Feast', icon: '🥑', description: '100% gourmet plant-based fine dining packed with vibrant flavors & balanced nutrition' }
  ];

  const cuisineTypes = [
    { id: 'italian', name: 'Italian' },
    { id: 'french', name: 'French' },
    { id: 'asian', name: 'Asian Fusion' },
    { id: 'mediterranean', name: 'Mediterranean' },
    { id: 'mexican', name: 'Mexican' },
    { id: 'indian', name: 'Indian' },
    { id: 'american', name: 'American' },
    { id: 'vegetarian', name: 'Vegetarian' },
    { id: 'vegan', name: 'Vegan' },
    { id: 'seafood', name: 'Seafood' },
    { id: 'bbq', name: 'BBQ & Grilling' },
    { id: 'custom', name: 'Custom Menu' }
  ];

  // Sneaker cleaner specific options
  const shoeBrands = [
    { id: 'nike', name: 'Nike' },
    { id: 'adidas', name: 'Adidas' },
    { id: 'jordan', name: 'Jordan' },
    { id: 'newbalance', name: 'New Balance' },
    { id: 'puma', name: 'Puma' },
    { id: 'reebok', name: 'Reebok' },
    { id: 'vans', name: 'Vans' },
    { id: 'converse', name: 'Converse' },
    { id: 'yeezy', name: 'Yeezy' },
    { id: 'other', name: 'Other' }
  ];

  const shoeConditions = [
    { id: 'lightlyWorn', name: 'Lightly Worn' },
    { id: 'moderatelyWorn', name: 'Moderately Worn' },
    { id: 'heavilyWorn', name: 'Heavily Worn' },
    { id: 'veryDirty', name: 'Very Dirty' },
    { id: 'stained', name: 'Stained' },
    { id: 'damaged', name: 'Damaged' }
  ];

  // Animal care specific options
  const animalTypes = [
    { id: 'dog', name: 'Dog', icon: <FaDog /> },
    { id: 'cat', name: 'Cat', icon: <FaCat /> },
    { id: 'bird', name: 'Bird', icon: <FaDove /> },
    { id: 'fish', name: 'Fish', icon: <FaFish /> },
    { id: 'horse', name: 'Horse', icon: <FaHorse /> },
    { id: 'rabbit', name: 'Rabbit', icon: <FaPaw /> },
    { id: 'hamster', name: 'Hamster', icon: <FaPaw /> },
    { id: 'reptile', name: 'Reptile', icon: <FaPaw /> },
    { id: 'multiple', name: 'Multiple Animals', icon: <FaUserFriends /> }
  ];

  // Override these with more detailed versions if needed
  const washingMatSizes = [
    { id: 'small', name: 'Small (under 2x3 ft)' },
    { id: 'medium', name: 'Medium (2x3 to 4x6 ft)' },
    { id: 'large', name: 'Large (4x6 to 6x9 ft)' },
    { id: 'xlarge', name: 'Extra Large (over 6x9 ft)' }
  ];

  const washingMatMaterials = [
    { id: 'cotton', name: 'Cotton' },
    { id: 'synthetic', name: 'Synthetic' },
    { id: 'rubber', name: 'Rubber Backed' },
    { id: 'wool', name: 'Wool' },
    { id: 'coconut', name: 'Coconut Fiber' },
    { id: 'microfiber', name: 'Microfiber' }
  ];

  const genericStainLevels = [
    { id: 'light', name: 'Light Stains' },
    { id: 'moderate', name: 'Moderate Stains' },
    { id: 'heavy', name: 'Heavy Stains' },
    { id: 'setIn', name: 'Set-in Stains' }
  ];

  // Enhanced Location States
  const [locationData, setLocationData] = useState({
    latitude: null,
    longitude: null,
    formattedAddress: '',
    placeId: '',
    city: '',
    province: '',
    postalCode: '',
    country: 'South Africa'
  });
  const [bookingData, setBookingData] = useState({
    name: '',
    phone: '',
    selectedServices: [],
    serviceDescription: '',
    serviceFrequency: '',
    locationOption: 'comeToYou',
    address: '',
    dogsAtProperty: '',
    date: '',
    time: '',
    durationHours: '',
    bringFood: 'no',
    message: '',
    selectedHaircut: '',
    beardStyle: '',
    hairLength: '',
    specialRequirements: '',
    mealType: '',
    cuisinePreference: '',
    numberOfGuests: '',
    functionType: '',
    dietaryRestrictions: '',
    cookingEquipment: '',
    ingredientsProvided: 'no',
    // Photography-specific fields
    photographyType: '',
    sessionDuration: '',
    numberOfPeople: '',
    photographyRequirements: '',
    deliveryFormat: '',
    // Service provider fields
    addressProvided: '',
    foodProvided: 'no',
    electricityProvided: 'no',
    cleaningArrengement: 'no',
    equipmentProvided: 'no',
    otherDetails: '',
    // Sneaker cleaner specific fields
    shoeBrands: '',
    shoeCondition: '',
    cleaningType: '',
    restorationNeeded: false,
    waterproofing: false,
    // Washing mat specific fields
    matSize: '',
    matMaterial: '',
    stainLevel: '',
    dryingPreference: '',
    pickupDelivery: false,
    // Animal care specific fields
    animalType: '',
    animalSize: '',
    animalAge: '',
    animalBreed: '',
    serviceDuration: '',
    vaccinationStatus: '',
    specialNeeds: '',
    ownSupplies: false,
    selectedPerformer: '',
    handymanJobType: '',
    handymanJobDescription: '',
    handymanMaterialsRequired: '',
    handymanUrgency: 'normal',
    // Domestic helper / maid specific fields
    houseSize: '',
    numberOfBedrooms: '',
    numberOfBathrooms: '',
    cleaningSuppliesProvided: 'yes',
    hasPets: 'no',
    ironingLoad: ''
  });
  const [totalPrice, setTotalPrice] = useState(0);

  const { id } = useParams();
  const navigate = useNavigate();

  // Business Hours Logic
  const getOperatingStatus = () => {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const now = new Date();
    const currentDay = days[now.getDay()];
    
    // Default schedule: 08:00 - 19:00, closed on Sunday
    const defaultSchedule = { open: '08:00', close: '19:00', closed: currentDay === 'sunday' };
    const schedule = helper?.operatingHours?.[currentDay] || defaultSchedule;

    if (!schedule || schedule.closed) return { isClosed: true, reason: 'Closed today' };

    const currentTime = now.getHours() * 60 + now.getMinutes();
    const [openH, openM] = schedule.open.split(':').map(Number);
    const [closeH, closeM] = (schedule.close || '19:00').split(':').map(Number);
    const openTime = openH * 60 + openM;
    const closeTime = closeH * 60 + closeM;

    if (currentTime < openTime) return { isClosed: true, reason: `Opens at ${schedule.open}` };
    if (currentTime >= closeTime) return { isClosed: true, reason: `Closed at ${schedule.close || '19:00'}` };

    return { isClosed: false };
  };

  const operatingStatus = getOperatingStatus();

  const isSelectedTimeClosed = () => {
    if (!bookingData.time || !bookingData.date) return false;
    const date = new Date(bookingData.date);
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const dayName = days[date.getDay()];
    
    const defaultSchedule = { open: '08:00', close: '19:00', closed: dayName === 'sunday' };
    const schedule = helper?.operatingHours?.[dayName] || defaultSchedule;
    
    if (!schedule || schedule.closed) return true;

    const [selH, selM] = bookingData.time.split(':').map(Number);
    const selectedTime = selH * 60 + selM;
    const durationHours = bookingData.durationHours === 'all-day' ? 8 : Math.max(1, Number(bookingData.durationHours) || 1);
    const [openH, openM] = schedule.open.split(':').map(Number);
    const [closeH, closeM] = (schedule.close || '19:00').split(':').map(Number);
    const openTime = openH * 60 + openM;
    const closeTime = closeH * 60 + closeM;

    return selectedTime < openTime || selectedTime + durationHours * 60 > closeTime;
  };

  const getSelectedDurationHours = () => bookingData.durationHours === 'all-day' ? 8 : Math.max(1, Number(bookingData.durationHours) || 1);
  const getSelectedDurationLabel = () => bookingData.durationHours === 'all-day'
    ? 'All day (8 hours)'
    : `${getSelectedDurationHours()} ${getSelectedDurationHours() === 1 ? 'hour' : 'hours'}`;
  const getBookingEndDateTime = () => {
    const start = new Date(`${bookingData.date || '2000-01-01'}T${bookingData.time || '00:00'}`);
    const end = new Date(start.getTime() + getSelectedDurationHours() * 60 * 60 * 1000);
    const pad = (value) => String(value).padStart(2, '0');
    return `${end.getFullYear()}-${pad(end.getMonth() + 1)}-${pad(end.getDate())}T${pad(end.getHours())}:${pad(end.getMinutes())}`;
  };

  // Calculate total price with per-guest multiplier for chef/catering
  useEffect(() => {
    if (helper) {
      const isChef = helper.type === 'chef' || helper.type === 'cooking';
      const rawGuests = parseInt(bookingData.numberOfGuests);
      const guestCount = isChef ? (Number.isInteger(rawGuests) && rawGuests > 0 ? rawGuests : 1) : 1;
      
      const basePrice = parseInt(helper.regularPrice) || (isChef ? 250 : 0);
      const travelFee = bookingData.locationOption === 'comeToYou' ? (parseInt(helper.travelFee) || 0) : 0;
      
      // Calculate selected services price
      let selectedServicesPrice = 0;
      bookingData.selectedServices.forEach(serviceId => {
        const option = serviceOptions.find(opt => String(opt.id) === String(serviceId));
        if (option && option.price) {
          // Handle "R450" or "450" format
          const price = parseFloat(String(option.price).replace(/[^\d.]/g, '')) || 0;
          selectedServicesPrice += price;
        }
      });

      let totalBase = 0;
      if (isChef) {
        const perGuestRate = selectedServicesPrice > 0 
          ? selectedServicesPrice 
          : basePrice;
        totalBase = perGuestRate * guestCount;
      } else {
        totalBase = selectedServicesPrice > 0 ? selectedServicesPrice : basePrice;
      }

      const serviceFee = Math.round(totalBase * 0.1);
      setTotalPrice(totalBase + travelFee + serviceFee);
    }
  }, [helper, bookingData.selectedServices, bookingData.numberOfGuests, bookingData.mealType, serviceOptions]);




  // Scroll detection for navigation transparency
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);


  // Get relative time from timestamp
  const getRelativeTime = (dateString) => {
    const diffInMs = new Date() - new Date(dateString);
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    if (diffInDays < 1) return 'Today';
    if (diffInDays < 7) return `${diffInDays} day${diffInDays === 1 ? '' : 's'} ago`;
    const diffInWeeks = Math.floor(diffInDays / 7);
    if (diffInWeeks < 4) return `${diffInWeeks} week${diffInWeeks > 1 ? 's' : ''} ago`;
    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths < 12) return `${diffInMonths} month${diffInMonths > 1 ? 's' : ''} ago`;
    const diffInYears = Math.floor(diffInDays / 365);
    return `${diffInYears} year${diffInYears > 1 ? 's' : ''} ago`;
  };

  // Fetch comment ratings and total count on load
  useEffect(() => {
    const fetchRatings = async () => {
      if (helper && helper._id) {
        try {
          const res = await fetch(`/api/helper-comments/${helper._id}?limit=6`, { cache: 'no-store' });
          const data = await res.json();
          if (res.ok) {
            setCommentCount(data.totalComments || 0);
            setTopComments(data.comments || []);
            if (data.ratings) {
              setRatings({
                cleanliness: data.ratings.cleanliness || 0,
                communication: data.ratings.staff || 0,
                punctuality: data.ratings.punctuality || 0,
                quality: data.ratings.quality || 0,
                respectfulness: data.ratings.respectfulness || 0,
                value: data.ratings.value || 0,
                recommendation: data.ratings.recommendation || 0,
                overall: data.ratings.overall || 0
              });
            }
          }
        } catch (error) {
          console.error('Error fetching ratings:', error);
        }
      }
    };
    fetchRatings();
  }, [helper]);

  // Toggle favorite function is now handled by useWishlist hook

  const handleHostRate = async (action) => {
    if (!currentUser) {
      navigate('/sign-in');
      return;
    }
    if (ratingLoading) return;
    
    const helperUserId = helper.userRef?._id || helper.userRef;
    
    if (currentUser._id === helperUserId) {
      alert("You cannot rate yourself!");
      return;
    }

    try {
      setRatingLoading(true);
      const res = await fetch(`/api/user/rate-host/${helperUserId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentUser.token}`
        },
        body: JSON.stringify({ action }),
      });

      const data = await res.json();
      if (res.ok) {
        setLikeCount(data.likeCount);
        setDislikeCount(data.dislikeCount);
        setIsLiked(data.userAction === 'like');
        setIsDisliked(data.userAction === 'dislike');
      }
    } catch (error) {
      console.error('Error rating host:', error);
    } finally {
      setRatingLoading(false);
    }
  };

  // Location type classification
  const locationTypes = {
    COME_TO_CLIENT: 'comeToYou',
    PROVIDER_LOCATION: 'goToThem',
    NEUTRAL_VENUE: 'neutralVenue'
  };

  // Enhanced location validation and formatting
  const validateAndFormatAddress = (address) => {
    if (!address) {
      throw new Error('Please provide a complete address');
    }

    // Basic validation for required components
    const addressStr = address.trim();
    if (addressStr.length < 10) {
      throw new Error('Please provide a more detailed address');
    }

    // Accept common address formats such as "27 Somerset Road, Cape Town",
    // "House 14, Madiba Park, Polokwane", and extensions/stands.
    const addressWords = addressStr.match(/[A-Za-zÀ-ÿ]+/g) || [];
    const hasStreetNumber = /\b\d+[A-Za-z]?\b/.test(addressStr);
    const hasStreetAndCityDetail = addressWords.length >= 2;

    if (!hasStreetNumber || !hasStreetAndCityDetail) {
      throw new Error('Please include street number, street name, and city');
    }

    return addressStr;
  };

  // Generate comprehensive map links
  const generateMapLink = (address) => {
    if (!address) return '';
    const encodedAddress = encodeURIComponent(address);
    // Official Google Maps Search URL format for better cross-platform reliability
    return `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;
  };

  // Enhanced location handler
  const handleLocationInfo = (bookingData, provider) => {
    const locationInfo = {
      type: bookingData.locationOption,
      displayName: '',
      address: '',
      instructions: '',
      travelFee: 0,
      mapLink: '',
      coordinates: null
    };

    switch (bookingData.locationOption) {
      case locationTypes.COME_TO_CLIENT:
        locationInfo.displayName = 'Client Address';
        locationInfo.address = bookingData.address;
        locationInfo.travelFee = provider.travelFee || 0;
        locationInfo.instructions = bookingData.specialInstructions || '';
        locationInfo.mapLink = generateMapLink(bookingData.address);
        break;

      case locationTypes.PROVIDER_LOCATION:
        locationInfo.displayName = getProviderLocationName(provider.type);
        locationInfo.address = provider.businessAddress || provider.address || 'Address not specified';
        locationInfo.instructions = provider.locationInstructions || '';
        locationInfo.mapLink = generateMapLink(locationInfo.address, provider.type);
        break;

      default:
        locationInfo.displayName = `${getProfessionalTitle(provider.type)}'s Location`;
        locationInfo.address = provider.address || 'Address not specified';
        locationInfo.mapLink = generateMapLink(locationInfo.address, provider.type);
    }

    return locationInfo;
  };

  // Get provider-specific location names
  const getProviderLocationName = (serviceType) => {
    const locationNames = {
      chef: "Chef's Kitchen",
      barber: "Barber Shop",
      barbar: "Barber Shop",
      tattoo: "Tattoo Studio",
      beauty: "Beauty Salon",
      spa: "Spa Center",
      photography: "Photography Studio",
      massage: "Massage Studio",
      tutor: "Tutoring Center",
      sneaker: "Sneaker Cleaning Studio",
      washingmat: "Mat Washing Facility",
      animals: "Animal Care Center",
      default: "Professional's Location"
    };

    return locationNames[serviceType] || locationNames.default;
  };

  // Enhanced location-specific messaging
  const getLocationSpecificMessage = (bookingData, provider) => {
    const locationInfo = handleLocationInfo(bookingData, provider);

    let locationMessage = `📍 *Location Details:*%0A`;
    locationMessage += `• Type: ${locationInfo.displayName}%0A`;

    if (locationInfo.address) {
      locationMessage += `• Address: ${locationInfo.address}%0A`;
      if (locationInfo.mapLink && locationInfo.mapLink !== '#') {
        locationMessage += `• Navigation: ${locationInfo.mapLink}%0A`;
      }
    }

    if (locationInfo.instructions) {
      locationMessage += `• Instructions: ${locationInfo.instructions}%0A`;
    }

    if (locationInfo.travelFee > 0) {
      locationMessage += `• Travel Fee: R${locationInfo.travelFee}%0A`;
    }

    return locationMessage;
  };

  // ==================== END ENHANCED LOCATION FUNCTIONS ====================
  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };



  useEffect(() => {
    const fetchHelper = async () => {
      if (!id) { // Guard against missing helper ID
        setLoading(false);
        setError('Helper ID is missing.');
        return;
      }
      try {
        setLoading(true);
        const res = await fetch(`/api/helper/get/${id}`);

        if (!res.ok) {
          throw new Error('Failed to fetch helper details');
        }

        const data = await res.json();
        setHelper(data);

        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchHelper();
  }, [id]);

  useEffect(() => {
    const fetchUserBookings = async () => {
      if (!currentUser?._id || !helper?._id) return;
      try {
        const res = await fetch(`/api/bookings/user/${currentUser._id}`);
        if (res.ok) {
          const data = await res.json();
          // Filter bookings that are for this helper
          const filtered = data.filter(b => {
            const hId = b.helper?._id || b.helper;
            return hId === helper._id;
          });
          setUserBookings(filtered);
        }
      } catch (error) {
        console.error('Error fetching user bookings:', error);
      }
    };
    fetchUserBookings();
  }, [currentUser?._id, helper]);

  const handleRatePerformerSubmit = async (e) => {
    e.preventDefault();
    if (!selectedPerformerToRate) return;
    try {
      setSubmittingRating(true);
      setRatingError('');
      setRatingSuccess(false);

      const res = await fetch(`/api/helper/${helper._id}/performer/rate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          performerName: selectedPerformerToRate.name,
          rating: performerRating
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'Failed to submit rating');
      }

      setRatingSuccess(true);
      
      // Update helper state locally to reflect the new performer rating dynamically
      setHelper(prev => {
        if (!prev) return prev;
        const updatedPerformers = prev.performers.map(p => {
          if (p.name === selectedPerformerToRate.name) {
            return {
              ...p,
              rating: data.performer.rating,
              ratingsCount: data.performer.ratingsCount
            };
          }
          return p;
        });
        return {
          ...prev,
          performers: updatedPerformers
        };
      });

      setTimeout(() => {
        setShowPerformerRatingModal(false);
        setSelectedPerformerToRate(null);
        setRatingSuccess(false);
      }, 1500);

    } catch (err) {
      setRatingError(err.message || 'Something went wrong');
    } finally {
      setSubmittingRating(false);
    }
  };

  useEffect(() => {
    const fetchStatuses = async () => {
      if (!helper || !currentUser) return;

      const helperUserId = helper.userRef?._id || helper.userRef;
      if (!helperUserId) return;

      try {
        // Fetch Host Ratings
        const ratingRes = await fetch(`/api/user/host-ratings/${helperUserId}`, {
            headers: { 'Authorization': `Bearer ${currentUser.token}` }
        });
        if (ratingRes.ok) {
          const ratingData = await ratingRes.json();
          setLikeCount(ratingData.likeCount);
          setDislikeCount(ratingData.dislikeCount);
          setIsLiked(ratingData.userAction === 'like');
          setIsDisliked(ratingData.userAction === 'dislike');
        }


      } catch (error) {
        console.error('Error fetching statuses:', error);
      }
    };

    if (helper && currentUser) {
      fetchStatuses();
    }
  }, [helper, currentUser?._id, id]);

  // Scroll detection for booking belt
  useEffect(() => {
    const handleScroll = () => {
      const scrollThreshold = 600;
      setShowBookingBelt(window.scrollY > scrollThreshold);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Format phone numbers for WhatsApp
  const formatContactForWhatsApp = (contact) => {
    if (!contact) return null;
    const contactStr = String(contact);
    const digitsOnly = contactStr.replace(/\D/g, '');
    if (digitsOnly.startsWith('0')) {
      return '27' + digitsOnly.substring(1);
    }
    return digitsOnly;
  };

  const handleBookingChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBookingData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  // Handle service selection
  const handleServiceSelection = (serviceId) => {
    setBookingData(prev => {
      const selectedServices = [...prev.selectedServices];
      const serviceIndex = selectedServices.indexOf(serviceId);

      if (serviceIndex > -1) {
        selectedServices.splice(serviceIndex, 1);
      } else {
        selectedServices.push(serviceId);
      }

      return { ...prev, selectedServices };
    });
  };

  // Handle equipment selection
  const handleEquipmentSelection = (equipment) => {
    const currentEquipment = bookingData.cookingEquipment ? bookingData.cookingEquipment.split(',') : [];
    const index = currentEquipment.indexOf(equipment);

    if (index > -1) {
      currentEquipment.splice(index, 1);
    } else {
      currentEquipment.push(equipment);
    }

    setBookingData({
      ...bookingData,
      cookingEquipment: currentEquipment.join(',')
    });
  };

  // Handle file attachments
  const handleAttachmentChange = (e) => {
    const files = Array.from(e.target.files);

    // Validate files
    const validFiles = files.filter(file => {
      const isImage = file.type.startsWith('image/');
      const isPDF = file.type === 'application/pdf';
      const isSizeValid = file.size <= 5 * 1024 * 1024; // 5MB

      return (isImage || isPDF) && isSizeValid;
    });

    // Limit to 2 files
    const newAttachments = [...attachments, ...validFiles].slice(0, 2);
    setAttachments(newAttachments);
  };

  // Remove attachment
  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  // Upload files to cloud storage (Firebase Storage)
  const uploadFilesToCloud = async (files) => {
    setIsUploading(true);
    try {
      const storage = getStorage(app);
      const uploadPromises = files.map(file => {
        return new Promise((resolve, reject) => {
          const cleanFileName = file.name.replace(/[^a-zA-Z0-9.]/g, '');
          const fileName = `${new Date().getTime()}_${cleanFileName}`;
          const storageRef = ref(storage, `attachments/${fileName}`);
          const uploadTask = uploadBytesResumable(storageRef, file);

          uploadTask.on(
            "state_changed",
            null, // Could add progress tracking here if needed
            (error) => reject(error),
            async () => {
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              resolve({
                name: file.name,
                url: downloadURL,
                type: file.type.startsWith('image/') ? 'image' : 'pdf',
                size: file.size
              });
            }
          );
        });
      });

      return await Promise.all(uploadPromises);
    } catch (error) {
      console.error('File upload error:', error);
      throw error;
    } finally {
      setIsUploading(false);
    }
  };

  // ================================ BOOKING START HERE================

  // Enhanced helper function to get location requirements
  const getLocationRequirements = (serviceType) => {
    const requirements = {
      chef: {
        comeToYou: [
          'kitchenAccess',
          'cookingEquipment',
          'diningSpace',
          'powerOutlets'
        ],
        goToThem: [
          'professionalKitchen',
          'diningFacilities'
        ]
      },
      barber: {
        comeToYou: [
          'workspace',
          'powerSource',
          'mirrorAccess'
        ],
        goToThem: [
          'professionalSetup',
          'sanitation'
        ]
      },
      photography: {
        comeToYou: [
          'shootingSpace',
          'naturalLight',
          'powerOutlets'
        ],
        goToThem: [
          'studioSpace',
          'lightingEquipment'
        ]
      },
      beauty: {
        comeToYou: [
          'cleanSpace',
          'powerSource',
          'mirrorAccess'
        ],
        goToThem: [
          'sanitizedStation',
          'professionalTools'
        ]
      },
      domestic: {
        comeToYou: [
          'cleanSpace',
          'waterAccess',
          'powerOutlets'
        ],
        goToThem: [
          'professionalEquipment'
        ]
      },
      sneaker: {
        comeToYou: [
          'workSurface',
          'waterAccess',
          'powerOutlets'
        ],
        goToThem: [
          'professionalCleaningStation'
        ]
      },
      washingmat: {
        comeToYou: [
          'waterAccess',
          'outdoorSpace',
          'dryingArea'
        ],
        goToThem: [
          'industrialWasher',
          'dryingFacility'
        ]
      },
      animals: {
        comeToYou: [
          'secureSpace',
          'waterAccess',
          'outdoorArea'
        ],
        goToThem: [
          'professionalFacility',
          'outdoorRuns'
        ]
      }
    };

    return requirements[serviceType] || {
      comeToYou: ['cleanWorkspace', 'powerOutlets'],
      goToThem: ['professionalEnvironment']
    };
  };


  // Enhanced WhatsApp booking function with all form data
  const handleQuickBooking = () => {
    if (!helper?.contact) {
      alert(`${getProfessionalTitle(helper?.type)} contact information is missing.`);
      return;
    }

    // Basic validation
    if (!bookingData.name || !bookingData.phone) {
      alert("Please fill in your name and phone number first.");
      return;
    }

    if (hasProfanity(bookingData.specialRequirements || '') || hasProfanity(bookingData.message || '')) {
      alert("Your message contains inappropriate language. Please revise it before submitting.");
      return;
    }

    // Business hours validation
    if (isSelectedTimeClosed()) {
      alert("The selected time falls outside of this professional's operating hours. Please check their schedule and select another time.");
      return;
    }

    // Enhanced location validation for quick booking
    if (bookingData.locationOption === 'comeToYou' && !bookingData.address) {
      alert("Please provide your address for home service in the booking form.");
      return;
    }

    const clientPhone = formatContactForWhatsApp(bookingData.phone);
    const acceptMessage = `Accept the service ${bookingData.name}, I accept your booking for ${providerDisplayName}. See you then!`;
    const declineMessage = `Decline the service ${bookingData.name}, I'm unable to accept this booking. Can we try another time?`;

    const acceptLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(acceptMessage)}` : '';
    const declineLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(declineMessage)}` : '';

    // Enhanced location handling for quick booking
    const locationInfo = handleLocationInfo(bookingData, helper);

    let message = `*📅 QUICK BOOKING REQUEST*%0A`;
    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `*👤 CLIENT DETAILS*%0A`;
    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `👤 *Name:* ${bookingData.name}%0A`;
    message += `📞 *Phone:* ${bookingData.phone || 'Not provided'}%0A`;
    if (bookingData.date) message += `📅 *Date:* ${bookingData.date}%0A`;
    if (bookingData.time) message += `⏰ *Time:* ${bookingData.time}%0A%0A`;

    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `*💼 SERVICE SUMMARY*%0A`;
    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `⚒️ *Provider:* ${providerDisplayName}%0A`;
    if (bookingData.selectedServices.length > 0) {
      bookingData.selectedServices.forEach(id => {
        const s = serviceOptions.find(opt => opt.id === id);
        if (s) {
          const priceStr = (s.price != null && !isNaN(s.price)) ? `R${s.price}` : 'Included in daily rate';
          message += `📜 *${s.name}:* ${priceStr}%0A`;
        } else {
          message += `📜 *${id}*%0A`;
        }
      });
    }
    message += `💵 *TOTAL: R${totalPrice}*%0A%0A`;

    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `*📍 LOCATION*%0A`;
    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `📌 *Type:* ${locationInfo.displayName}%0A`;
    if (locationInfo.address) {
      message += `🏠 *Address:* ${locationInfo.address}%0A`;
      const mapLink = generateMapLink(locationInfo.address);
      if (mapLink) message += `🗺️ *Navigate:* ${mapLink}%0A`;
    }
    message += `%0A`;

    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    message += `*⚡ QUICK ACTIONS*%0A`;
    message += `━━━━━━━━━━━━━━━━━━━━%0A`;
    if (acceptLink) message += `✅ *ACCEPT:*%0A${acceptLink}%0A%0A`;
    if (declineLink) message += `❌ *REJECT:*%0A${declineLink}%0A%0A`;

    message += `_Sent via loopOut_`;

    const whatsappUrl = `https://wa.me/${formatContactForWhatsApp(helper.contact)}?text=${message}`;
    
    // Determine device type
    const deviceType = /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(navigator.userAgent) ? 'Mobile' : 'Desktop';
    const requestLocation = bookingData.locationOption === 'comeToYou'
      ? (bookingData.address || locationInfo.address || '')
      : (bookingData.address || '');

    const bookingToSave = {
      userId: currentUser?._id || "guest",
      helperId: helper._id,
      startDate: bookingData.date + "T" + (bookingData.time || "00:00"),
      endDate: bookingData.date + "T" + (bookingData.time || "00:00"),
      totalPrice: totalPrice,
      selectedServices: (bookingData.selectedServices || []).map((id) => serviceOptions.find((option) => String(option.id) === String(id))?.name).filter((name) => name && helper?.serviceList?.some((service) => service.name === name)),
      phone: bookingData.phone,
      message: message,
      subtype: helper.type,
      vehicleType: bookingData.vehicleType || undefined,
      vehicleMake: bookingData.vehicleMake || undefined,
      vehicleModel: bookingData.vehicleModel || undefined,
      deviceType,
      requestLocation,
      locationOption: bookingData.locationOption || 'comeToYou',
      status: 'pending',
      type: 'helper'
    };


    const token = localStorage.getItem('access_token') || localStorage.getItem('token') || currentUser?.token || currentUser?.access_token;
    fetch('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      credentials: 'include',
      body: JSON.stringify(bookingToSave)
    }).then(async (res) => {
      if (res.ok) {
        pushPhoneNotification({
          title: '🎉 Booking Request Sent',
          message: `Your booking with ${providerDisplayName || 'the provider'} has been placed. Check notifications for updates!`,
          type: 'success',
          link: '/notifications'
        });
      } else {
        const err = await res.json().catch(() => ({}));
        console.error('Booking save failed:', err?.error || res.status);
      }
    }).catch(err => console.error('Failed to save quick booking:', err));

    window.open(whatsappUrl, '_blank');
  };

  // ==================== ENHANCED BOOKING SUBMIT FUNCTION ====================
  
  const handleEscrowCheckout = async () => {
    if (!currentUser) {
      window.location.href = '/sign-in';
      return;
    }
    try {
      setIsUploading(true);
      const res = await fetch('/api/payment/escrow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
           userId: currentUser._id,
           amount: totalPrice,
           name: currentUser.username,
           email: currentUser.email,
           serviceId: helper ? helper._id : (service ? service._id : ''),
           providerName: helper ? providerDisplayName : (service ? service.name : '')
        })
      });
      const data = await res.json();
      if (data.success && data.payfast) {
         const form = document.createElement('form');
         form.method = 'POST';
         form.action = data.payfast.url;
         Object.keys(data.payfast.fields).forEach(key => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = data.payfast.fields[key];
            form.appendChild(input);
         });
         document.body.appendChild(form);
         form.submit();
      } else {
         console.error(data.message);
         setIsUploading(false);
      }
    } catch(err) {
      console.error(err);
      setIsUploading(false);
    }
  };

  const handleBookingSubmit =async (e) => {
    e.preventDefault();

    if (!helper?.contact) {
      alert(`${getProfessionalTitle(helper?.type)} contact information is missing. Please try another contact method.`);
      return;
    }

    if (!bookingData.date || !bookingData.time || !bookingData.durationHours) {
      alert("Please choose a booking date, start time, and service duration.");
      return;
    }

    const durationMinutes = getSelectedDurationHours() * 60;
    if (isTimeSlotBooked(bookingData.date, bookingData.time, durationMinutes)) {
      alert("That time overlaps another booking for the selected duration. Please choose another time.");
      return;
    }

    // Business hours validation
    if (isSelectedTimeClosed()) {
      alert("The selected time falls outside of this professional's operating hours. Please check their schedule and select another time.");
      return;
    }

    // Enhanced location validation
    if (bookingData.locationOption === 'comeToYou' && !bookingData.address) {
      alert("Please provide your address for home service.");
      return;
    }
    if (bookingData.locationOption === 'comeToYou' && !bookingData.dogsAtProperty) {
      alert("Please let the provider know whether there are dogs at the property.");
      return;
    }

    if (hasProfanity(bookingData.specialRequirements || '') || hasProfanity(bookingData.message || '')) {
      alert("Your request contains inappropriate language. Please revise it before submitting.");
      return;
    }

    try {
      // Validate and format address
      if (bookingData.locationOption === 'comeToYou') {
        const formattedAddress = validateAndFormatAddress(bookingData.address);
        setBookingData(prev => ({ ...prev, address: formattedAddress }));
      }
    } catch (error) {
      alert(error.message);
      return;
    }

    // Validate service selection
    if (
      (helper.type === 'domestic' || helper.type === 'maid' || helper.type === 'beauty' || helper.type === 'spa' || helper.type === 'barber' || helper.type === 'barbar' || helper.type === 'chef' || helper.type === 'cooking' || helper.type === 'tattoo' || helper.type === 'tutor' || helper.type === 'photography' || helper.type === 'sneaker' || helper.type === 'washingmat' || helper.type === 'animals' || helper.type === 'transport') &&
      bookingData.selectedServices.length === 0
    ) {
      alert("Please select at least one service you need.");
      return;
    }

    // Chef-specific required validations
    if (helper.type === 'chef' || helper.type === 'cooking') {
      if (!bookingData.functionType) {
        alert("Please select the type of function (e.g., Function Party, Baby Shower, Small Party, etc.) before booking.");
        return;
      }
      if (!bookingData.numberOfGuests) {
        alert("Please select or enter the number of guests who will attend (e.g. 50 guests).");
        return;
      }
    }

    if (helper.type === 'handyman' || helper.type === 'maintenance') {
      if (!bookingData.handymanJobType) {
        alert("Please select a trade/job type (e.g. Plumber, Electrician).");
        return;
      }
      if (!bookingData.handymanJobDescription) {
        alert("Please describe the problem/job.");
        return;
      }
    }

    let uploadedFiles = [];

    if (attachments.length > 0) {
      setIsUploading(true);
      try {
        uploadedFiles = await uploadFilesToCloud(attachments);
      } catch (error) {
        console.error("File upload failed:", error);
        alert("Failed to upload attachments. Please try again without files or contact support.");
        setIsUploading(false);
        return;
      }
      setIsUploading(false);
    }

    // Format the client's phone number for the reply link
    const clientPhone = bookingData.phone ? formatContactForWhatsApp(bookingData.phone) : '';

    // Define the accept and decline messages and their corresponding links
    const acceptMessage = `Accept the service ${bookingData.name}, I accept your booking for ${providerDisplayName} on ${bookingData.date} at ${bookingData.time}. See you then!`;
    const declineMessage = `Decline the service ${bookingData.name}, I'm unable to accept ${bookingData.date} at ${bookingData.time}. Can we try another time?`;

    const acceptLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(acceptMessage)}` : '';
    const declineLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(declineMessage)}` : '';

    // Enhanced location handling
    const locationInfo = handleLocationInfo(bookingData, helper);

    // Generate verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000);

    // Keep the WhatsApp message plain and readable on mobile clients.
    let message = `*New ${getProfessionalTitle(helper.type)} booking request*\n\n`;
    message += `*Client details*\n`;
    message += `Name: ${bookingData.name}\n`;
    message += `Phone: ${bookingData.phone || 'Not provided'}\n`;
    message += `Date: ${bookingData.date || 'Not specified'}\n`;
    message += `Time: ${bookingData.time || 'Not specified'}\n`;
    message += `Duration: ${getSelectedDurationLabel()}\n`;
    if (bookingData.serviceFrequency) message += `Frequency: ${bookingData.serviceFrequency}\n`;
    if (bookingData.selectedPerformer) message += `Selected member: ${bookingData.selectedPerformer}\n`;

    message += `\n*Service summary*\n`;
    message += `Provider: ${providerDisplayName}\n`;
    message += `Service type: ${getProfessionalTitle(helper.type)}\n`;

    // Add selected services
    if (bookingData.selectedServices.length > 0) {
      bookingData.selectedServices.forEach(id => {
        const s = serviceOptions.find(opt => opt.id === id);
        if (s) {
          const priceStr = (s.price != null && !isNaN(s.price)) ? `R${s.price}` : 'Included in daily rate';
          message += `${s.name}: ${priceStr}\n`;
        } else {
          message += `${id}\n`;
        }
      });
      message += `Total price: R${totalPrice}\n`;
    } else {
      message += `Base price: R${helper.regularPrice}\n`;
      message += `Total price: R${totalPrice}\n`;
    }

    // Add service-specific details (Barber, Chef, etc.)
    if (helper.type === 'barber' || helper.type === 'barbar') {
      if (bookingData.selectedHaircut) message += `Haircut style: ${haircutStyles.find(h => h.id === bookingData.selectedHaircut)?.name || bookingData.selectedHaircut}\n`;
      if (bookingData.beardStyle) message += `Beard style: ${beardStyles.find(b => b.id === bookingData.beardStyle)?.name || bookingData.beardStyle}\n`;
    } else if (helper.type === 'chef' || helper.type === 'cooking') {
      message += `\n*Event and function details*\n`;
      if (bookingData.functionType) message += `Function type: ${bookingData.functionType}\n`;
      if (bookingData.numberOfGuests) message += `Number of guests: ${bookingData.numberOfGuests}\n`;
      if (bookingData.mealType) message += `Meal type: ${mealTypes.find(m => m.id === bookingData.mealType)?.name || bookingData.mealType}\n`;
      if (bookingData.cuisinePreference) message += `Cuisine preference: ${cuisineTypes.find(c => c.id === bookingData.cuisinePreference)?.name || bookingData.cuisinePreference}\n`;
      if (bookingData.dietaryRestrictions) message += `Dietary requirements or allergies: ${bookingData.dietaryRestrictions}\n`;
      if (bookingData.cookingEquipment) message += `Kitchen available: ${bookingData.cookingEquipment}\n`;
      if (bookingData.ingredientsProvided) message += `Ingredients: ${bookingData.ingredientsProvided === 'yes' ? 'Provided by client' : 'Provided by chef'}\n`;
    } else if (helper.type === 'maid' || helper.type === 'domestic' || !helper.type || helper.type === 'cleaning') {
      message += `\n*Housekeeping details*\n`;
      if (bookingData.houseSize) message += `Property size: ${bookingData.houseSize}\n`;
      if (bookingData.numberOfBedrooms) message += `Bedrooms: ${bookingData.numberOfBedrooms}\n`;
      if (bookingData.numberOfBathrooms) message += `Bathrooms: ${bookingData.numberOfBathrooms}\n`;
      if (bookingData.cleaningSuppliesProvided) message += `Cleaning supplies: ${bookingData.cleaningSuppliesProvided === 'yes' ? 'Provided by client' : 'Helper to bring supplies'}\n`;
      if (bookingData.hasPets) message += `Other pets in the home: ${bookingData.hasPets === 'yes' ? 'Yes' : 'No'}\n`;
      if (bookingData.ironingLoad) message += `Ironing and laundry load: ${bookingData.ironingLoad}\n`;
    } else if (helper.type === 'handyman' || helper.type === 'maintenance') {
      if (bookingData.handymanJobType) message += `Job type: ${bookingData.handymanJobType}\n`;
      if (bookingData.handymanMaterialsRequired) message += `Materials: ${bookingData.handymanMaterialsRequired}\n`;
      message += `Urgency: ${bookingData.handymanUrgency === 'urgent' ? 'Urgent' : bookingData.handymanUrgency === 'flexible' ? 'Flexible' : 'Normal'}\n`;
      if (bookingData.handymanJobDescription) message += `Job description: ${bookingData.handymanJobDescription}\n`;
    } else if (helper.type === 'carwash') {
      if (bookingData.vehicleType) message += `🚗 *Vehicle Type:* ${bookingData.vehicleType}\n`;
      if (bookingData.vehicleMake) message += `🔖 *Vehicle Make:* ${bookingData.vehicleMake}\n`;
      if (bookingData.vehicleModel) message += `🚘 *Vehicle Model:* ${bookingData.vehicleModel}\n`;
    }
    message += `\n*Location*\n`;
    message += `Service location: ${locationInfo.displayName}\n`;
    if (bookingData.locationOption === 'comeToYou') {
      message += `Dogs at the property: ${bookingData.dogsAtProperty === 'yes' ? 'Yes' : 'No'}\n`;
    }
    if (locationInfo.address && locationInfo.address !== 'Address not specified') {
      message += `Address: ${locationInfo.address}\n`;
      const mapLink = generateMapLink(locationInfo.address);
      if (mapLink) message += `Map: ${mapLink}\n`;
    }
    if (locationInfo.travelFee > 0) message += `Travel fee: R${locationInfo.travelFee}\n`;
    message += `\n*Provisions*\n`;
    message += `Food provided: ${bookingData.foodProvided === 'yes' ? 'Yes' : 'No'}\n`;
    message += `Electricity available: ${bookingData.electricityProvided === 'yes' ? 'Yes' : 'No'}\n`;
    message += `\n*Notes*\n`;
    message += `${bookingData.specialRequirements || 'No special requirements'}\n`;

    // Add attachments if they exist
    if (uploadedFiles.length > 0) {
      message += `\n*Attachments*\n`;
      uploadedFiles.forEach((file) => {
        message += `${file.name}: ${file.url}\n`;
      });
    }

    message += `\n*Booking actions*\n`;
    if (acceptLink) message += `Accept: ${acceptLink}\n`;
    if (declineLink) message += `Decline: ${declineLink}\n`;
    message += `Verification code: ${verificationCode}\n`;
    message += `Sent via LoopOut`;

    // Open WhatsApp with properly encoded message
    const whatsappUrl = `https://wa.me/${formatContactForWhatsApp(helper.contact)}?text=${encodeURIComponent(message)}`;
    
    // Save to Database first
    // Create a very descriptive subtype for the dashboard/cart
    let bookingSubtype = helper.type;
    if (helper.type === 'handyman' || helper.type === 'maintenance') {
      bookingSubtype = bookingData.handymanJobType || 'Handyman Job';
    } else if (bookingData.selectedServices.length > 0) {
      bookingSubtype = bookingData.selectedServices.map(s => {
        // Find the service name from options
        const opt = serviceOptions.find(o => o.id === s);
        return opt ? opt.name : s;
      }).join(', ');
    }
    
    // Add specific transport details if available
    if (helper.type === 'transport' && bookingData.specialRequirements) {
      const requirements = bookingData.specialRequirements.toLowerCase();
      if (requirements.includes('pretor') && requirements.includes('johan')) {
        bookingSubtype = `Route: Pretoria ↔ JHB`;
      }
    }

    // Determine device type
    const deviceType = /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(navigator.userAgent) ? 'Mobile' : 'Desktop';
    const requestLocation = bookingData.locationOption === 'comeToYou'
      ? (bookingData.address || locationInfo.address || '')
      : (bookingData.address || '');

    const bookingToSave = {
      userId: currentUser?._id || "guest",
      helperId: helper._id,
      startDate: (bookingData.date || "2000-01-01") + "T" + (bookingData.time || "00:00"),
      endDate: getBookingEndDateTime(),
      totalPrice: totalPrice,
      selectedServices: (bookingData.selectedServices || []).map((id) => serviceOptions.find((option) => String(option.id) === String(id))?.name).filter((name) => name && helper?.serviceList?.some((service) => service.name === name)),
      phone: bookingData.phone,
      message: message, // Save full structured message preserving client details, services, location, provisions, and comments & notes
      subtype: bookingSubtype,
      numberOfGuests: bookingData.numberOfGuests || undefined,
      functionType: bookingData.functionType || undefined,
      selectedPerformer: bookingData.selectedPerformer,
      performerExperience: helper.performers?.find(p => p.name === bookingData.selectedPerformer)?.experience,
      performerImage: helper.performers?.find(p => p.name === bookingData.selectedPerformer)?.image,
      vehicleType: bookingData.vehicleType || undefined,
      vehicleMake: bookingData.vehicleMake || undefined,
      vehicleModel: bookingData.vehicleModel || undefined,
      deviceType,
      requestLocation,
      locationOption: bookingData.locationOption || 'comeToYou',
      status: 'pending',
      type: 'helper'
    };

    const token = localStorage.getItem('access_token') || localStorage.getItem('token') || currentUser?.token || currentUser?.access_token;
    fetch('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      credentials: 'include',
      body: JSON.stringify(bookingToSave)
    }).then(async (res) => {
      if (res.ok) {
        pushPhoneNotification({
          title: '🎉 Booking Request Sent',
          message: `Your booking with ${providerDisplayName || 'the provider'} has been placed. Check notifications for updates!`,
          type: 'success',
          link: '/notifications'
        });
      } else {
        const err = await res.json().catch(() => ({}));
        console.error('Booking save failed:', err?.error || res.status);
      }
    }).catch(err => console.error('Failed to save booking:', err));

    window.open(whatsappUrl, '_blank');

    // Close the booking form overlay after sending
    closeBookingFormOverlay();

    // Reset attachments after sending
    setAttachments([]);
  };
  // ==================== END ENHANCED BOOKING SUBMIT FUNCTION ====================

  // Function to open full-page booking form overlay
  const openBookingFormOverlay = () => {
    setBookingStep(1);
    setShowBookingFormOverlay(true);
    // Prevent body scrolling when overlay is open
    document.body.style.overflow = 'hidden';
  };

  // Function to close full-page booking form overlay
  const closeBookingFormOverlay = () => {
    setShowBookingFormOverlay(false);
    setBookingStep(1);
    // Restore body scrolling
    document.body.style.overflow = 'auto';
  };

  // Full screen gallery functions
  const openFullScreenGallery = (index = 0) => {
    setCurrentGalleryIndex(index);
    setShowFullScreenGallery(true);
    document.body.style.overflow = 'hidden';
  };

  const closeFullScreenGallery = () => {
    setShowFullScreenGallery(false);
    document.body.style.overflow = 'auto';
  };

  const nextImage = () => {
    if (galleryImages.length > 0) {
      setCurrentGalleryIndex((prevIndex) =>
        prevIndex === galleryImages.length - 1 ? 0 : prevIndex + 1
      );
    }
  };

  const prevImage = () => {
    if (galleryImages.length > 0) {
      setCurrentGalleryIndex((prevIndex) =>
        prevIndex === 0 ? galleryImages.length - 1 : prevIndex - 1
      );
    }
  };

  const whatsappNumber = helper ? formatContactForWhatsApp(helper.contact) : null;
  const whatsappLink = whatsappNumber
    ? `https://wa.me/${whatsappNumber}?text=Hi ${providerDisplayName}, I'm interested in your ${getProfessionalTitle(helper.type).toLowerCase()} services.`
    : null;

  const handleInternalMessage = async () => {
    if (!currentUser) {
      navigate('/sign-in');
      return;
    }
    
    // Check if the user is trying to message themselves
    if (String(currentUser._id) === String(accountOwnerId)) {
      alert("You cannot message yourself.");
      return;
    }

    try {
      // Create/Get conversation by sending an initial message
      const res = await fetch('/api/messages/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receiverId: accountOwnerId,
          content: `Hi ${providerDisplayName}, I'm interested in your ${getProfessionalTitle(helper.type).toLowerCase()} services.`,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        navigate(`/messages/${data.conversationId || data._id}`);
      } else {
        alert(data.message || 'Failed to start conversation');
      }
    } catch (error) {
      console.error('Error starting conversation:', error);
      alert('An error occurred. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-rose-500 mx-auto"></div>
          <p className="mt-4 text-lg text-gray-600 font-medium">Loading professional details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 p-6 rounded-2xl">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <ExclamationTriangleIcon className="h-6 w-6 text-red-500" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-red-800">Error loading profile</h3>
              <p className="mt-2 text-red-600">{error}</p>
              <div className="mt-4 flex gap-3">
                <button
                  onClick={() => window.location.reload()}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Try Again
                </button>
                <button
                  onClick={() => navigate(-1)}
                  className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Go Back
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!helper) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold text-gray-800 mb-3">Professional not found</h2>
          <p className="text-gray-600 mb-6">The professional you're looking for doesn't exist or may have been removed.</p>
          <button
            onClick={() => navigate('/helper-home-page')}
            className="px-6 py-3 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors font-medium"
          >
            Browse Professionals
          </button>
        </div>
      </div>
    );
  }

  const displayText = showFullDescription
    ? description
    : description.slice(0, 300) + (description.length > 300 ? "..." : "");

  const serviceEquipmentOptions = equipmentOptions[helper.type] || equipmentOptions.default;

  const getCategoryIcon = (type) => {
    switch (type) {
      case 'sneaker': return <FaShoePrints className="w-4 h-4 text-rose-500" />;
      case 'barber':
      case 'barbar': return <FaCut className="w-4 h-4 text-rose-500" />;
      case 'chef':
      case 'cooking': return <FaUtensils className="w-4 h-4 text-rose-500" />;
      case 'beauty':
      case 'spa': return <FaSpa className="w-4 h-4 text-rose-500" />;
      case 'tutor': return <FaGraduationCap className="w-4 h-4 text-rose-500" />;
      case 'domestic':
      case 'maid': return <FaBroom className="w-4 h-4 text-rose-500" />;
      default: return <FaBriefcase className="w-4 h-4 text-rose-500" />;
    }
  };

  return (
    <div className="min-h-screen app-safe-content-bottom pb-36 lg:pb-0 bg-white text-slate-900">
      {/* Navigation - Transparent on top of image */}
      <nav className={`app-safe-top fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 dark:bg-gray-900/95 backdrop-blur-md shadow-sm border-b border-slate-200/50 dark:border-gray-800' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <button
               onClick={() => navigate(-1)}
               aria-label="Go back"
               className={`flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 ${isScrolled ? 'border-slate-200 bg-white dark:bg-gray-800 text-slate-900 dark:text-white shadow-sm' : 'border-white/50 bg-black/30 text-white shadow-lg backdrop-blur-md hover:bg-black/50'}`}
             >
               <ArrowLeftIcon className="w-5 h-5" />
             </button>

             <div className="flex items-center gap-2">
               <div className="relative">
                 <button
                   onClick={handleShare}
                   aria-label="Share professional profile"
                   className={`flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 ${isScrolled ? 'border-slate-200 bg-white dark:bg-gray-800 text-slate-900 dark:text-white shadow-sm' : 'border-white/50 bg-black/30 text-white shadow-lg backdrop-blur-md hover:bg-black/50'}`}
                 >
                   <ShareIcon className="w-5 h-5" />
                 </button>
                 {shareCopied && (
                   <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-slate-900/90 px-2.5 py-1 text-[11px] font-semibold text-white shadow-lg backdrop-blur-sm">
                     Link copied!
                   </span>
                 )}
               </div>
              <button
                onClick={toggleFavorite}
                aria-label={isFavorite ? "Remove from wishlist" : "Add to wishlist"}
                className={`flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 ${isScrolled ? 'border-slate-200 bg-white dark:bg-gray-800 text-slate-900 dark:text-white shadow-sm' : 'border-white/50 bg-black/30 text-white shadow-lg backdrop-blur-md hover:bg-black/50'}`}
              >
                {isFavorite ?
                  <HeartIconSolid className="w-5 h-5 text-rose-500" /> :
                  <HeartIcon className={`w-5 h-5 ${isScrolled ? 'text-slate-900 dark:text-white' : 'text-white'}`} />
                }
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Image Gallery - Full Width */}
      <ListingPhotoGallery images={galleryImages} alt={providerDisplayName} onOpen={openFullScreenGallery} emptyEmoji="🧰" emptyTitle="Photos coming soon" emptyDescription="This provider has not added portfolio photos yet." />

      <ListingDetailShell>
        {/* Content Section */}
        <div className="mb-8 border-b border-slate-200 pb-7 pt-7">
          <div className="mb-3 -mt-12 flex h-16 w-16 items-center justify-center overflow-hidden rounded-full border-4 border-white bg-slate-100 shadow-sm">
            {helper.imageUrls?.[0] ? <img src={helper.imageUrls[0]} alt={providerDisplayName} className="h-full w-full object-cover" /> : <FaUser className="text-xl text-slate-400" />}
          </div>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-rose-600">{getCategoryIcon(helper.type)}<span>{getProfessionalTitle(helper.type)}</span></div>
          <h1 className="mb-3 max-w-4xl text-2xl font-semibold leading-tight tracking-tight text-slate-900 sm:text-3xl lg:text-4xl">
            {providerDisplayName}
          </h1>
          <p className="mb-4 max-w-3xl text-sm leading-6 text-slate-600">{displayText.split('\n')[0] || `Professional services in ${helper.address || 'your area'}`}</p>
          <div className="flex flex-wrap items-center gap-2.5 text-sm text-slate-600">
            <span className="inline-flex items-center gap-2 rounded-full bg-amber-50 px-3.5 py-2 text-slate-800">
              <StarIconSolid className="text-amber-400 w-4 h-4" />
              <span className="font-semibold">{hasRating ? ratingValue.toFixed(1) : 'New'}</span>
              <span className="text-slate-500">{commentCount} {commentCount === 1 ? 'review' : 'reviews'}</span>
            </span>
            {hasBookings && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 dark:border-gray-700 px-3.5 py-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <PlusCircleIcon className="text-indigo-500 w-4 h-4" />
                Booked {bookingSummary.count} {bookingSummary.count === 1 ? 'time' : 'times'}
              </span>
            )}
            {helper.address && (
              <span className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-slate-200 dark:border-gray-700 px-3.5 py-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                <MapPinIcon className="shrink-0 text-slate-400 w-4 h-4" />
                <span className="truncate">{helper.address}</span>
              </span>
            )}
            {helper.regularPrice > 0 && (
              <span className="inline-flex items-center rounded-full border border-rose-100 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-800">
                From R{helper.regularPrice}
              </span>
            )}
            <span className="inline-flex items-center rounded-full border border-emerald-100 bg-emerald-50 px-3.5 py-2 text-xs font-medium text-emerald-800">
              Cancel up to 48 hours before the service
            </span>
            {operatingStatus?.isClosed ? (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-600">
                <ClockIcon className="w-3.5 h-3.5" /> Closed
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-semibold text-emerald-700">
                <ClockIcon className="w-3.5 h-3.5" /> Open
              </span>
            )}
            <button onClick={() => document.getElementById('helper-review-cards')?.scrollIntoView({ behavior: 'smooth', block: 'center' })} className="text-sm text-rose-500 underline hover:text-rose-700 ml-1 font-medium">
              Browse reviews
            </button>
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mt-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Host row: account owner is the host; named worker is shown separately. */}
            <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-6">
              <Link
                to={accountOwnerId ? `/user-profile/${accountOwnerId}` : '#'}
                onClick={(event) => { if (!accountOwnerId) event.preventDefault(); }}
                className="flex min-w-0 items-center gap-4 rounded-xl focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                aria-label={`View host profile: ${accountOwnerName}`}
              >
                <span className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full bg-slate-100 text-slate-400 ring-1 ring-slate-200">
                  {helper.userRef?.avatar ? (
                    <img src={helper.userRef.avatar} alt="" className="h-full w-full object-cover" />
                  ) : <FaUser className="text-xl" />}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-base font-semibold text-slate-900">Hosted by {accountOwnerName}</span>
                  <span className="mt-1 block text-sm text-slate-500">Account owner · Worker: {providerDisplayName}</span>
                </span>
              </Link>
              <button
                type="button"
                onClick={handleInternalMessage}
                aria-label={`Chat with host ${accountOwnerName}`}
                title="Chat with host"
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-slate-300 bg-white text-slate-800 transition hover:border-slate-500 hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
              >
                <ChatBubbleLeftRightIcon className="h-5 w-5" />
              </button>
            </div>

            {(isSuperhelper || isVerifiedProvider || helper.operatingHours) && (
              <div className="space-y-6 pb-8 border-b border-slate-100 dark:border-gray-800">
                {isSuperhelper && (
                  <div className="flex items-start gap-4">
                    <Sparkles className="w-6 h-6 text-rose-500 mt-1" />
                    <div><p className="font-black uppercase tracking-widest text-xs text-gray-950 dark:text-white">Highly rated provider</p><p className="text-gray-500 dark:text-gray-400 text-xs font-medium mt-1">Earned from real customer feedback on LoopOut.</p></div>
                  </div>
                )}
                {isVerifiedProvider && (
                  <div className="flex items-start gap-4">
                    <ShieldCheckIcon className="w-6 h-6 text-blue-500 mt-1" />
                    <div><p className="font-black uppercase tracking-widest text-xs text-gray-950 dark:text-white">Verified provider</p><p className="text-gray-500 dark:text-gray-400 text-xs font-medium mt-1">LoopOut has verified this provider's account.</p></div>
                  </div>
                )}
                {helper.operatingHours && (
                  <div className="flex items-start gap-4">
                    <ClockIcon className="w-6 h-6 text-teal-500 mt-1" />
                    <div><p className="font-black uppercase tracking-widest text-xs text-gray-950 dark:text-white">Availability</p><p className="text-gray-500 dark:text-gray-400 text-xs font-medium mt-1">Check the schedule below to choose an available time.</p></div>
                  </div>
                )}
              </div>
            )}

            {/* Description */}
            <div className="pb-6 border-b border-gray-200 dark:border-gray-800">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">About this professional</h2>
              <div className="text-gray-700 dark:text-gray-300 leading-relaxed space-y-4">
                {displayText.split('\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
              {description.length > 300 && (
                <button
                  onClick={toggleDescription}
                  className="mt-6 text-rose-500 hover:text-rose-600 transition-colors font-black uppercase tracking-[0.2em] text-[10px] flex items-center gap-2"
                >
                  {showFullDescription ? 'Show less' : 'Show more'}
                  {showFullDescription ? <ArrowUpIcon className="w-3 h-3" /> : <ArrowDownIcon className="w-3 h-3" />}
                </button>
              )}
            </div>

            <section className="border-b border-slate-200 pb-7" aria-labelledby="helper-qualifications-title">
              <h2 id="helper-qualifications-title" className="mb-4 text-xl font-semibold text-slate-900">My qualifications</h2>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-rose-50 text-rose-600"><CheckBadgeIcon className="h-5 w-5" /></span>
                  <div className="space-y-2 whitespace-pre-line text-sm leading-6 text-slate-600">
                    {[helper.experience, helper.education, helper.training, helper.certifications].filter((item) => typeof item === 'string' && item.trim()).slice(0, 6).map((item, index) => <p key={`qualification-${index}`}>{item}</p>)}
                    {!helper.experience && !helper.education && !helper.training && !helper.certifications && <p>Message the provider to ask about experience and training.</p>}
                  </div>
                </div>
              </div>
            </section>

            {helper.type === 'carwash' && (helper.vehicleTypes || helper.serviceDuration || helper.carWashPackages) && (
              <section className="border-b border-slate-200 pb-7" aria-labelledby="helper-carwash-title">
                <h2 id="helper-carwash-title" className="mb-4 text-xl font-semibold text-slate-900">Car wash details</h2>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {helper.vehicleTypes && <div className="rounded-2xl border border-cyan-100 bg-cyan-50/70 p-4"><p className="text-xs font-bold uppercase tracking-wide text-cyan-700">Vehicles serviced</p><p className="mt-1 text-sm text-slate-700">{helper.vehicleTypes}</p></div>}
                  {helper.serviceDuration && <div className="rounded-2xl border border-cyan-100 bg-cyan-50/70 p-4"><p className="text-xs font-bold uppercase tracking-wide text-cyan-700">Typical duration</p><p className="mt-1 text-sm text-slate-700">{helper.serviceDuration}</p></div>}
                  {helper.mobileService && <div className="rounded-2xl border border-cyan-100 bg-cyan-50/70 p-4"><p className="text-sm font-semibold text-slate-700">🚗 Mobile service available</p></div>}
                </div>
              </section>
            )}

            {helper.type === 'moving' && (
              <section className="border-b border-slate-200 pb-7" aria-labelledby="helper-moving-title">
                <h2 id="helper-moving-title" className="mb-4 text-xl font-semibold text-slate-900">Moving rates</h2>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {[
                    ['By box', helper.moveCostPerBox], ['By kilo', helper.moveCostPerKilo], ['Van', helper.movePriceVan],
                    ['Van with trailer', helper.movePriceVanTrailer], ['Mini truck', helper.movePriceMiniTruck],
                    ['Other truck', helper.movePriceOtherTruck], ['Big truck with trailer', helper.movePriceBigTruckTrailer],
                  ].filter(([, price]) => Number(price) > 0).map(([label, price]) => (
                    <div key={label} className="rounded-2xl border border-amber-100 bg-amber-50/70 p-4"><p className="text-xs font-bold uppercase tracking-wide text-amber-700">{label}</p><p className="mt-1 text-sm font-semibold text-slate-800">R{Number(price).toLocaleString()}</p></div>
                  ))}
                </div>
              </section>
            )}

            {/* Sneaker Cleaning Details */}
            {helper.type === 'sneaker' && (helper.shoeTypes || helper.cleaningMethod || helper.turnaroundTime) && (
              <div className="pb-6 border-b border-gray-200 dark:border-gray-800">
                <div className="flex items-center gap-3 mb-5">
                  <FaShoePrints className="text-indigo-500 text-xl" />
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Sneaker Cleaning Details</h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {helper.shoeTypes && (
                    <div className="bg-indigo-50/70 dark:bg-indigo-950/30 rounded-2xl p-4 border border-indigo-100 dark:border-indigo-900/50">
                      <p className="text-[10px] font-black uppercase tracking-widest text-indigo-500 dark:text-indigo-400 mb-1">Types of Sneakers</p>
                      <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">{helper.shoeTypes}</p>
                    </div>
                  )}
                  {helper.cleaningMethod && (
                    <div className="bg-purple-50/70 dark:bg-purple-950/30 rounded-2xl p-4 border border-purple-100 dark:border-purple-900/50">
                      <p className="text-[10px] font-black uppercase tracking-widest text-purple-500 dark:text-purple-400 mb-1">Cleaning Method</p>
                      <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">{helper.cleaningMethod}</p>
                    </div>
                  )}
                  {helper.turnaroundTime && (
                    <div className="bg-blue-50/70 dark:bg-blue-950/30 rounded-2xl p-4 border border-blue-100 dark:border-blue-900/50">
                      <p className="text-[10px] font-black uppercase tracking-widest text-blue-500 dark:text-blue-400 mb-1">Turnaround Time</p>
                      <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">{helper.turnaroundTime}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Services Offered */}
            {serviceOptions.length > 0 && (
              <div className="border-b border-slate-200 pb-7">
                <h2 className="mb-4 text-xl font-semibold text-slate-900">Choose a service</h2>
                <div className="grid grid-cols-1 gap-3">
                  {serviceOptions.map((service) => {
                    const isSelected = bookingData.selectedServices.includes(service.id);
                    return (
                      <button key={service.id} type="button" onClick={() => setSelectedModalService(service)} aria-pressed={isSelected} className={`flex w-full items-center justify-between gap-3 rounded-2xl border p-3.5 text-left transition-all ${isSelected ? 'border-rose-500 bg-rose-50 shadow-sm' : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'}`}>
                        <div className="flex min-w-0 items-start gap-3">
                          {service.image ? <img src={service.image} alt={service.name} className="h-16 w-16 shrink-0 rounded-xl border border-slate-100 bg-white object-cover" /> : <div className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-xl ${isSelected ? 'text-rose-500' : 'text-slate-400'}`}>{service.icon}</div>}
                          <div className="min-w-0">
                            {service.type && <span className={`mb-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${isSelected ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-500'}`}>{service.type}</span>}
                            <p className={`font-semibold ${isSelected ? 'text-rose-700' : 'text-slate-900'}`}>{service.name}</p>
                            {service.description && <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-slate-500">{service.description}</p>}
                          </div>
                        </div>
                        <span className={`shrink-0 text-right font-semibold ${isSelected ? 'text-rose-600' : 'text-slate-900'}`}>
                          {service.price ? `R${service.price}` : 'Quote'}<span className="block text-[11px] font-normal text-slate-500">{service.price ? 'per service' : 'ask for pricing'}</span>
                        </span>
                        {isSelected && <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-rose-500"><CheckIcon className="h-3 w-3 text-white" /></span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Service Providers Section */}
            {helper.performers && helper.performers.length > 0 && (
              <div className="py-6 border-b border-gray-200 dark:border-gray-800">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Service Providers</h2>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-widest bg-slate-100 dark:bg-gray-800 px-3 py-1 rounded-full">
                    {helper.performers.length} {helper.performers.length === 1 ? 'Specialist' : 'Specialists'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {helper.performers.map((performer, idx) => {
                    const hasBookedPerformer = userBookings.some(b => b.selectedPerformer === performer.name);
                    const perfRating = Number(performer.rating);
                    const perfRatingsCount = performer.ratingsCount || 0;
                    const hasPerformerRating = perfRating > 0;

                    return (
                      <div key={idx} className="flex items-center justify-between p-4 rounded-2xl bg-white dark:bg-gray-900 border border-slate-100 dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex items-center gap-4">
                          <div 
                            onClick={() => performer.image && setZoomedImage(performer.image)}
                            className={`w-16 h-16 rounded-full overflow-hidden bg-slate-100 dark:bg-gray-800 flex-shrink-0 ${performer.image ? 'cursor-pointer hover:ring-2 hover:ring-rose-500 transition-all' : ''}`}
                          >
                            {performer.image ? (
                              <img src={performer.image} alt={performer.name} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-slate-400">
                                <FaUser />
                              </div>
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-slate-900 dark:text-white">{performer.name}</h4>
                              {hasPerformerRating ? (
                                <div className="flex items-center gap-0.5 bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded-full text-rose-600 dark:text-rose-400">
                                  <StarIconSolid className="w-3.5 h-3.5 text-rose-500" />
                                  <span className="text-[11px] font-black">{perfRating.toFixed(1)}</span>
                                </div>
                              ) : (
                                <span className="text-[11px] font-black text-slate-400">New</span>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 dark:text-gray-400">{performer.experience} experience</p>
                            {perfRatingsCount > 0 && (
                              <p className="text-[10px] text-slate-400 font-medium">({perfRatingsCount} {perfRatingsCount === 1 ? 'rating' : 'ratings'})</p>
                            )}
                          </div>
                        </div>

                        {/* Premium Rating Button or Tooltip */}
                        <div className="relative">
                          {hasBookedPerformer ? (
                            <button
                              onClick={() => {
                                setSelectedPerformerToRate(performer);
                                setPerformerRating(hasPerformerRating ? perfRating : 0);
                                setShowPerformerRatingModal(true);
                              }}
                              className="px-3.5 py-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all hover:scale-105 active:scale-95 shadow-md shadow-rose-200"
                            >
                              Rate
                            </button>
                          ) : (
                            <div className="relative">
                              <button
                                onClick={() => {
                                  setRatingInfoMessage(performer.name);
                                  setTimeout(() => setRatingInfoMessage(null), 3000);
                                }}
                                className="px-3.5 py-1.5 bg-slate-100 dark:bg-gray-800 hover:bg-slate-200 dark:hover:bg-gray-700 text-slate-400 dark:text-slate-300 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                              >
                                Rate
                              </button>
                              {ratingInfoMessage === performer.name && (
                                <div className="absolute right-0 bottom-full mb-2 w-48 bg-slate-900 text-white text-[10px] p-2 rounded-xl shadow-xl z-10 animate-fade-in font-medium">
                                  You can rate {performer.name} after booking their service!
                                  <div className="absolute top-full right-4 border-4 border-transparent border-t-slate-900" />
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {galleryImages.length > 0 && (
              <section className="border-b border-slate-200 pb-7" aria-labelledby="helper-portfolio-title">
                <div className="mb-4 flex items-end justify-between gap-4">
                  <div><h2 id="helper-portfolio-title" className="text-xl font-semibold text-slate-900">My portfolio</h2><p className="mt-1 text-sm text-slate-500">A selection of this provider's work</p></div>
                  <button type="button" onClick={() => openFullScreenGallery(0)} className="shrink-0 text-sm font-semibold text-slate-700 underline underline-offset-4 hover:text-rose-600">View all {galleryImages.length}</button>
                </div>
                <div className="grid aspect-[1.8/1] grid-cols-[1.25fr_1fr] grid-rows-2 gap-1 overflow-hidden rounded-2xl bg-white sm:aspect-[2.15/1]">
                  {galleryImages.slice(0, 3).map((url, index) => (
                    <button key={`portfolio-${url}-${index}`} type="button" onClick={() => openFullScreenGallery(index)} aria-label={`View portfolio photo ${index + 1}`} className={`group relative overflow-hidden bg-slate-100 focus:outline-none focus-visible:z-10 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-rose-500 ${index === 0 ? 'row-span-2' : ''}`}>
                      <img src={url} alt={`${providerDisplayName} portfolio work ${index + 1}`} className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105" />
                    </button>
                  ))}
                </div>
              </section>
            )}

            {/* Operating Schedule */}
            <OperatingSchedule 
              operatingHours={helper.operatingHours} 
              isClosedToday={operatingStatus.isClosed}
              reason={operatingStatus.reason}
            />

            {/* Location */}
            {helper.address && (
              <section className="overflow-hidden rounded-[2rem] border border-slate-100 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm">
                <div className="flex items-center justify-between gap-4 p-6">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-rose-500">Service location</p>
                    <h2 className="mt-1 text-lg font-black text-gray-900 dark:text-white">Where you'll find us</h2>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{helper.address}</p>
                  </div>
                  <MapPinIcon className="shrink-0 text-rose-500 w-8 h-8" />
                </div>
                <div className="h-[360px] sm:h-[420px] border-t border-slate-100 dark:border-gray-800 bg-slate-950">
                  <GoogleMapComponent
                    address={helper.address}
                    title={`${providerDisplayName}'s Location`}
                  />
                </div>
                {helper.near && (
                  <div className="p-6 border-t border-slate-100 dark:border-gray-800 bg-slate-50/50 dark:bg-gray-900/50">
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2 text-sm">What's nearby</h3>
                    <div className="text-gray-600 dark:text-gray-400 text-xs sm:text-sm space-y-1">
                      {(helper.near || '').split('\n').slice(0, 4).map((item, i) => (
                        <p key={i}>{item}</p>
                      ))}
                    </div>
                  </div>
                )}
              </section>
            )}

            {/* Reviews Summary */}
            <div className="pb-6 border-b border-gray-200 dark:border-gray-800">
              <button type="button" onClick={() => document.getElementById('helper-review-cards')?.scrollIntoView({ behavior: 'smooth', block: 'center' })} className="mb-5 flex w-full items-center gap-3 rounded-2xl border border-slate-200 px-4 py-4 text-left transition hover:bg-slate-50 dark:border-gray-700 dark:hover:bg-gray-900" aria-label="Browse client reviews">
                <StarIconSolid className="text-[#FFB400] text-2xl drop-shadow-sm w-6 h-6" />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-white">
                    <span>{hasRating ? ratingValue.toFixed(1) : 'New'}</span>
                    <span className="text-slate-400" aria-hidden="true">&middot;</span>
                    <span>{commentCount} {commentCount === 1 ? 'review' : 'reviews'}</span>
                  </span>
                  <span className="mt-0.5 block text-xs text-slate-500 dark:text-gray-400">Swipe through client reviews</span>
                </span>
                <ChevronRightIcon className="h-5 w-5 text-slate-400" aria-hidden="true" />
              </button>

              <Swiper
                aria-label="Average ratings by category"
                slidesPerView={3.15}
                spaceBetween={8}
                breakpoints={{ 640: { slidesPerView: 5.2 }, 1024: { slidesPerView: 7 } }}
                freeMode={true}
                modules={[FreeMode]}
                className="mb-6 -mx-4 px-4 sm:mx-0 sm:px-0"
              >
                {[
                  ['⏱️', 'Punctual & on time', ratings?.punctuality],
                  ['✨', 'Exceptional quality', ratings?.quality],
                  ['💬', 'Great communication', ratings?.communication],
                  ['🧹', 'Clean & organised', ratings?.cleanliness],
                  ['🤝', 'Friendly & respectful', ratings?.respectfulness],
                  ['💰', 'Great value', ratings?.value],
                  ['⭐', 'Highly recommended', ratings?.recommendation]
                ].map(([emoji, label, rawScore]) => {
                  const score = Number(rawScore) || 0;
                  return <SwiperSlide key={label} className="h-auto"><div title={label} className="flex min-h-16 flex-col items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-1.5 py-2 text-center dark:border-gray-700 dark:bg-gray-900"><span aria-hidden="true" className="text-lg">{emoji}</span><span className="text-[10px] font-bold tabular-nums text-slate-800 dark:text-gray-100">{score ? `${score.toFixed(1)}/5` : '—/5'}</span><span className="sr-only">{label}</span></div></SwiperSlide>;
                })}
              </Swiper>

              {commentCount > 0 ? (
                <>
                  {/* Fade-in comment cards */}
                  {topComments.length > 0 && (
                    <>
                    <Swiper
                      id="helper-review-cards"
                      spaceBetween={16}
                      slidesPerView={1.08}
                      breakpoints={{ 640: { slidesPerView: 2.1 }, 1024: { slidesPerView: 2.4 } }}
                      freeMode={true}
                      modules={[FreeMode]}
                      className="mb-8 -mx-4 px-4 scroll-mt-24 sm:mx-0 sm:px-0"
                    >
                      {topComments.map((comment, idx) => {
                        const commentRatingFields = ['cleanlinessRating', 'communicationRating', 'punctualityRating', 'qualityRating', 'respectfulnessRating', 'valueRating', 'recommendationRating'];
                        const commentRatings = commentRatingFields.map((field) => Number(comment[field])).filter((value) => Number.isFinite(value) && value >= 1 && value <= 5);
                        const rating = commentRatings.length ? commentRatings.reduce((sum, value) => sum + value, 0) / commentRatings.length : 0;

                        return (
                          <SwiperSlide key={comment._id} className="h-auto">
                          <motion.div
                            initial={{ opacity: 0, y: 24 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, margin: '-40px' }}
                            transition={{ duration: 0.45, delay: idx * 0.07, ease: 'easeOut' }}
                            className="h-full rounded-2xl border border-[#EBEBEB] dark:border-gray-700 bg-white dark:bg-gray-900 p-5 shadow-sm"
                          >
                            {/* Header */}
                            <div className="flex items-center gap-3 mb-3">
                              <img
                                src={comment.userAvatar || '/default-avatar.jpg'}
                                alt={comment.userName}
                                className="w-10 h-10 rounded-full object-cover border border-gray-100 dark:border-gray-700 shadow-sm flex-shrink-0"
                                onError={(e) => { e.target.src = '/default-avatar.jpg'; }}
                              />
                              <div className="min-w-0 flex-1">
                                <p className="font-semibold text-sm text-gray-900 dark:text-white truncate">{comment.userName}</p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <div className="flex items-center">
                                    {[...Array(5)].map((_, i) => (
                                      <FaStar
                                        key={i}
                                        className={`text-[10px] ${i < Math.round(rating) ? 'text-[#FFB400]' : 'text-gray-200 dark:text-gray-700'}`}
                                      />
                                    ))}
                                  </div>
                                  <span className="text-xs text-gray-400 dark:text-gray-500">{getRelativeTime(comment.createdAt)}</span>
                                </div>
                              </div>
                            </div>
                              <div className="mb-3 flex items-center gap-2">
                                <div className="flex items-center">
                                  {[...Array(5)].map((_, i) => <FaStar key={i} className={`text-[10px] ${i < Math.round(rating) ? 'text-[#FFB400]' : 'text-gray-200 dark:text-gray-700'}`} />)}
                                </div>
                                <span className="text-xs font-bold text-slate-700 dark:text-gray-200">{rating ? `${rating.toFixed(1)} / 5` : 'Review'}</span>
                              </div>
                            {/* Comment text only */}
                            <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-line line-clamp-5">
                              {comment.content}
                            </p>
                          </motion.div>
                          </SwiperSlide>
                        );
                      })}
                    </Swiper>
                    {commentCount >= 10 && (
                      <button type="button" onClick={() => setShowAllReviewsPanel(true)} className="mt-2 inline-flex min-h-11 w-full items-center justify-center rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 dark:border-gray-700 dark:bg-gray-900 dark:text-white dark:hover:bg-gray-800 sm:w-auto">
                        See all {commentCount} reviews
                      </button>
                    )}
                    </>
                  )}
                </>
              ) : (
                <p className="text-gray-600 dark:text-gray-400 mb-6">No reviews yet. Be the first to leave a review!</p>
              )}

            </div>

          </div>

          {/* Right Column - Booking Card */}
          <div className="hidden lg:block lg:col-span-1">
            <div className="top-24 py-12">
              {/* Masterpiece Booking Card */}
              <div className="rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.06)] p-8 bg-white dark:bg-gray-900 sticky top-24 border border-slate-200/70 dark:border-gray-800 mb-12 lg:mb-0">
                <div className="flex items-end justify-between mb-8 pb-6 border-b border-gray-100 dark:border-gray-800">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 block mb-1">Service Rate</span>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-black text-gray-950 dark:text-white tracking-tighter">R{helper.regularPrice}</span>
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">/ service</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 bg-rose-50 dark:bg-rose-950/40 px-3 py-2 rounded-2xl">
                    <StarIconSolid className="w-4 h-4 text-rose-500" />
                    <span className="text-xs font-black text-rose-700 dark:text-rose-400">{hasRating ? ratingValue.toFixed(1) : 'New'}</span>
                  </div>
                </div>

                {/* Quick Booking Options */}
                <div className="space-y-4 mb-8">
                  <div className="grid grid-cols-2 border-b border-gray-200 dark:border-gray-800">
                    <div className="p-3 border-r border-gray-200 dark:border-gray-800">
                      <label className="block text-xs font-bold text-gray-900 dark:text-white uppercase">Date</label>
                      <input
                        type="date"
                        className="w-full text-sm text-gray-700 dark:text-gray-200 outline-none bg-transparent"
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => setBookingData(prev => ({ ...prev, date: e.target.value }))}
                      />
                    </div>
                    <div className="p-3">
                      <label className="block text-xs font-bold text-gray-900 dark:text-white uppercase">Time</label>
                      <input
                        type="time"
                        className="w-full text-sm text-gray-700 dark:text-gray-200 outline-none bg-transparent"
                        onChange={(e) => setBookingData(prev => ({ ...prev, time: e.target.value }))}
                      />
                    </div>
                  </div>

                  {/* Performer Selection in Card */}
                  {helper.performers && helper.performers.length > 0 && (
                    <div className="p-3 border-b border-gray-200 dark:border-gray-800">
                      <label className="block text-xs font-bold text-gray-900 dark:text-white uppercase">Select Performer</label>
                      <select
                        name="selectedPerformer"
                        value={bookingData.selectedPerformer}
                        onChange={handleBookingChange}
                        className="w-full text-sm text-gray-700 dark:text-gray-200 outline-none bg-transparent"
                      >
                        <option value="" className="dark:bg-gray-900">Any available member</option>
                        {helper.performers.map((p, i) => (
                          <option key={i} value={p.name} className="dark:bg-gray-900">{p.name} ({p.experience})</option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-transparent hover:border-gray-200 dark:hover:border-gray-700 transition-all">
                    <label className="block text-[9px] font-black text-gray-900 dark:text-white uppercase tracking-widest mb-1.5">Personnel Name</label>
                    <input
                      type="text"
                      name="name"
                      value={bookingData.name}
                      onChange={handleBookingChange}
                      placeholder="Full Designation"
                      className="w-full bg-transparent text-xs font-bold text-gray-900 dark:text-white outline-none placeholder-gray-400"
                    />
                  </div>
                </div>

                <div className="space-y-3 mb-8">
                  <button
                    onClick={openBookingFormOverlay}
                    className="w-full py-5 bg-rose-500 hover:bg-rose-600 text-white text-[11px] font-black uppercase tracking-[0.2em] rounded-[1.5rem] transition-all shadow-xl shadow-rose-200 dark:shadow-none active:scale-95"
                  >
                    Check Availability
                  </button>

                  <button
                    onClick={handleInternalMessage}
                    className="w-full py-4 bg-white dark:bg-gray-800 border border-slate-200 dark:border-gray-700 text-gray-950 dark:text-white text-[10px] font-black uppercase tracking-widest rounded-2xl hover:border-slate-300 dark:hover:border-gray-600 transition-all flex items-center justify-center gap-3 shadow-sm"
                  >
                    <ChatBubbleLeftRightIcon className="w-4 h-4 text-rose-500" /> Secure Message
                  </button>
                </div>

                <div className="text-center text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-8 italic">
                   loopOut Promise: Zero Upfront Charge
                </div>

                <div className="space-y-4 pt-6 border-t border-gray-100 dark:border-gray-800">
                  {bookingData.selectedServices.length > 0 ? (
                    bookingData.selectedServices.map(id => {
                      const s = serviceOptions.find(opt => opt.id === id);
                      return s ? (
                        <div key={id} className="flex justify-between items-center">
                          <span className="text-xs font-bold text-gray-500 dark:text-gray-400">{s.name}</span>
                          <span className="text-xs font-black text-gray-950 dark:text-white">R{s.price}</span>
                        </div>
                      ) : null;
                    })
                  ) : (
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400">Base service</span>
                      <span className="text-xs font-black text-gray-950 dark:text-white">R{helper.regularPrice}</span>
                    </div>
                  )}
                  {helper.travelFee > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-gray-500 dark:text-gray-400 italic">Deployment Fee</span>
                      <span className="text-xs font-black text-gray-950 dark:text-white">R{helper.travelFee}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-gray-500 dark:text-gray-400">Service Fee (10%)</span>
                    <span className="text-xs font-black text-gray-950 dark:text-white">R{Math.round((totalPrice - (helper.travelFee || 0)) / 1.1 * 0.1)}</span>
                  </div>
                  <div className="mt-4 p-4 bg-gray-900 dark:bg-gray-950 rounded-2xl flex justify-between items-center border border-gray-800">
                    <span className="text-[10px] font-black text-white uppercase tracking-widest">Total Estimate</span>
                    <span className="text-lg font-black text-rose-500 italic tracking-tighter">R{totalPrice}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 text-center py-14">
                <button className="text-gray-400 text-[10px] font-black uppercase tracking-widest underline underline-offset-8 hover:text-rose-500 transition-colors flex items-center justify-center gap-2 mx-auto">
                  <FlagIcon className="w-4 h-4" />
                  Report this listing
                </button>
              </div>
            </div>
          </div>
        </div>



        {/* Recent Bookers Section */}
        <BookingHistory 
          bookingSummary={bookingSummary} 
          providerName={providerDisplayName}
          providerType={helper?.type || 'domestic'} 
          providerImage={helper?.imageUrls?.[0]} 
          providerId={helper?._id} 
        />



        {/* Similar Helpers */}
          {similarHelpers.length > 0 && (
            <div className="mt-12 md:mt-16 border-t border-slate-200/50 pt-10 md:pt-12">
              <h2 className="text-xl md:text-2xl font-black text-gray-900 mb-6 md:mb-8 flex items-center gap-3 tracking-tighter  uppercase">
                <MapPinIcon className="text-rose-500 w-6 h-6" />
                More helpers nearby
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {similarHelpers.map((item) => (
                  <HelperItem key={item._id} helper={item} />
                ))}
              </div>
            </div>
          )}
      </ListingDetailShell>

      {/* Full Screen Gallery Overlay */}
      {showFullScreenGallery && galleryImages.length > 0 && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <div className="flex items-center justify-between p-4 text-white">
            <button
              onClick={closeFullScreenGallery}
              className="p-2.5 bg-white/10 hover:bg-white/20 rounded-full transition-all text-white backdrop-blur-md"
            >
              <XMarkIcon className="w-6 h-6" />
            </button>
            <span className="font-medium">
              {currentGalleryIndex + 1} / {galleryImages.length}
            </span>
            <div className="w-10" /> {/* Spacer for centering */}
          </div>

          <div className="flex-1 flex items-center justify-center p-4 relative">
            <button
              onClick={prevImage}
              className="absolute left-4 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
            >
              <ChevronLeftIcon className="w-6 h-6" />
            </button>

            <img
              src={galleryImages[currentGalleryIndex]}
              alt={`Gallery ${currentGalleryIndex + 1}`}
              className="max-h-full max-w-full object-contain rounded-lg"
            />

            <button
              onClick={nextImage}
              className="absolute right-4 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
            >
              <ChevronRightIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}

      {/* Helper Booking Sheet Popout */}
      <HelperBookingSheet
        isOpen={showBookingFormOverlay}
        onClose={closeBookingFormOverlay}
        helper={helper}
        bookingData={bookingData}
        handleBookingChange={handleBookingChange}
        setBookingData={setBookingData}
        serviceOptions={serviceOptions}
        handleServiceSelection={handleServiceSelection}
        totalPrice={totalPrice}
        handleBookingSubmit={handleBookingSubmit}
        handleEscrowCheckout={handleEscrowCheckout}
        isUploading={isUploading}
        isTimeSlotBooked={isTimeSlotBooked}
        isDateFullyBooked={isDateFullyBooked}
      />

      {/* Mobile Bottom Bar - 100% Width & Flush to Bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-slate-200 dark:border-gray-800 p-4 lg:hidden z-[1100] shadow-[0_-10px_30px_rgba(0,0,0,0.05)] safe-area-bottom mobile-booking-bar">
        <div className="flex items-center justify-between">
          <div className="flex-1 mr-4">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-black text-slate-900 tracking-tighter">R{totalPrice}</span>
              <span className="text-slate-400 text-[9px] font-black uppercase tracking-widest">Est. total incl. 10% fee</span>
            </div>
            <div className="text-rose-600 text-[10px] font-black uppercase tracking-widest truncate max-w-[160px] opacity-80">
              {providerDisplayName}
            </div>
          </div>
          <button
            onClick={() => setShowBookingFormOverlay(true)}
            className="px-5 py-3 bg-rose-500 hover:bg-rose-600 text-white text-[10px] font-black uppercase tracking-[0.12em] rounded-xl transition-all active:scale-95"
          >
            Book
          </button>
        </div>
      </div>

      {/* Comments Side Panel */}
      {showCommentsPanel && (
        <CommentsSidePanelHelper
          helperId={helper._id}
          onClose={() => setShowCommentsPanel(false)}
          totalComments={commentCount}
          onTotalComments={setCommentCount}
          onRatingsChange={setRatings}
        />
      )}
      {showAllReviewsPanel && (
        <CommentsSidePanelHelper
          helperId={helper._id}
          onClose={() => setShowAllReviewsPanel(false)}
          totalComments={commentCount}
          onTotalComments={setCommentCount}
          onRatingsChange={setRatings}
          presentation="bottom"
        />
      )}

      {/* Zoomed Performer Image Modal */}
      <AnimatePresence>
        {zoomedImage && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setZoomedImage(null)}
              className="fixed inset-0 bg-black/90 backdrop-blur-md z-[2000] cursor-zoom-out"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              className="fixed inset-0 z-[2001] flex items-center justify-center p-4 pointer-events-none"
            >
              <div className="relative max-w-4xl w-full max-h-[90vh] flex flex-col items-center pointer-events-auto">
                <button
                  onClick={() => setZoomedImage(null)}
                  className="absolute -top-12 right-0 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all border border-white/20 "
                >
                  <XMarkIcon className="w-6 h-6 group-hover:rotate-90 transition-transform" />
                </button>
                <img
                  src={zoomedImage}
                  alt="Zoomed Performer"
                  className="w-full h-full object-contain rounded-3xl shadow-2xl border border-white/10"
                />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Performer Rating Modal */}
      <AnimatePresence>
        {showPerformerRatingModal && selectedPerformerToRate && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPerformerRatingModal(false)}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[2050]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="fixed inset-0 z-[2051] flex items-center justify-center p-4"
            >
              <div className="relative w-full max-w-md bg-white/80 backdrop-blur-xl border border-white/20 rounded-[2.5rem] shadow-2xl p-8 flex flex-col items-center text-center overflow-hidden">
                {/* Decorative gradients */}
                <div className="absolute -top-10 -right-10 w-32 h-32 bg-rose-300 rounded-full blur-3xl opacity-30 pointer-events-none" />
                <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-blue-300 rounded-full blur-3xl opacity-30 pointer-events-none" />

                <button
                  onClick={() => setShowPerformerRatingModal(false)}
                  className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 text-slate-400 rounded-full transition-all "
                >
                  <XMarkIcon className="w-5 h-5 group-hover:rotate-90 transition-transform" />
                </button>

                <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-rose-100 shadow-md mb-4 bg-slate-100">
                  {selectedPerformerToRate.image ? (
                    <img src={selectedPerformerToRate.image} alt={selectedPerformerToRate.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-400 text-2xl">
                      <FaUser />
                    </div>
                  )}
                </div>

                <p className="text-[10px] text-rose-600 font-black uppercase tracking-[0.2em] mb-1">Rate Service Performer</p>
                <h3 className="text-xl font-black text-slate-900 mb-1">{selectedPerformerToRate.name}</h3>
                <p className="text-xs text-slate-500 mb-6">{selectedPerformerToRate.experience} experience</p>

                {ratingSuccess ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center py-6"
                  >
                    <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center text-white mb-3 shadow-lg shadow-emerald-100">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-6 h-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                      </svg>
                    </div>
                    <p className="text-sm font-bold text-slate-800">Rating Submitted successfully!</p>
                    <p className="text-xs text-slate-400 mt-1">Thank you for your feedback.</p>
                  </motion.div>
                ) : (
                  <form onSubmit={handleRatePerformerSubmit} className="w-full flex flex-col items-center">
                    {/* Stars Selection */}
                    <div className="flex items-center gap-2 mb-6">
                      {[1, 2, 3, 4, 5].map((star) => {
                        const isFilled = hoveredPerformerRating ? star <= hoveredPerformerRating : star <= performerRating;
                        return (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setPerformerRating(star)}
                            onMouseEnter={() => setHoveredPerformerRating(star)}
                            onMouseLeave={() => setHoveredPerformerRating(0)}
                            className="p-1 transition-all hover:scale-125 duration-150 active:scale-95 cursor-pointer"
                          >
                            {isFilled ? (
                              <StarIconSolid className="w-9 h-9 text-yellow-400 fill-yellow-400 drop-shadow-sm" />
                            ) : (
                              <StarIcon className="w-9 h-9 text-slate-300 hover:text-yellow-400 transition-colors" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {ratingError && (
                      <p className="text-xs text-red-500 font-bold mb-4 bg-red-50 px-4 py-2 rounded-xl border border-red-100">{ratingError}</p>
                    )}

                    <div className="w-full flex gap-3 mt-2">
                      <button
                        type="button"
                        onClick={() => setShowPerformerRatingModal(false)}
                        className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl text-sm font-black uppercase tracking-wider transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={submittingRating}
                        className="flex-1 py-3 bg-rose-500 hover:bg-rose-600 text-white rounded-2xl text-sm font-black uppercase tracking-wider shadow-lg shadow-rose-200 transition-all hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50"
                      >
                        {submittingRating ? 'Submitting...' : 'Submit'}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </motion.div>
          </>
        )}
      
      <ServiceDetailsModal
        service={selectedModalService}
        isSelected={selectedModalService && bookingData.selectedServices.includes(selectedModalService.id)}
        onClose={() => setSelectedModalService(null)}
        onSelect={(id) => handleServiceSelection(id)}
      />
      </AnimatePresence>
    </div>
  );
}
