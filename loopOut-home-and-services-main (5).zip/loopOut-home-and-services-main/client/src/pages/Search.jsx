import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { authenticatedFetch } from '../utils/authenticatedFetch';
import { motion, AnimatePresence } from 'framer-motion';
import NeuralLoader from '../components/NeuralLoader';
import ImageWithFallback from '../components/ImageWithFallback';
import useLocationCoords from '../hooks/useGeolocation';
import MapView from '../components/MapView';
import {
  MagnifyingGlassIcon,
  AdjustmentsHorizontalIcon,
  MapIcon,
  Squares2X2Icon,
  Bars3Icon,
  ChevronUpDownIcon,
  HeartIcon,
  ShareIcon,
  PhoneIcon,
  EnvelopeIcon,
  StarIcon,
  MapPinIcon,
  HomeIcon,
  ArrowPathIcon,
  TicketIcon,
  WrenchScrewdriverIcon,
  UserGroupIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  TagIcon,
  BuildingOfficeIcon,
  ChevronDownIcon,
  XMarkIcon,
  CameraIcon,
  TruckIcon,
  WrenchIcon,
  ScissorsIcon,
  BriefcaseIcon,
  AcademicCapIcon,
  BeakerIcon,
  BoltIcon,
  MusicalNoteIcon,
  CheckIcon,
  ArrowLeftIcon,
  PuzzlePieceIcon,
  SunIcon,
  CloudIcon,
  ChatBubbleBottomCenterTextIcon,
  ClockIcon,
  HomeModernIcon
} from '@heroicons/react/24/outline';
import {
  StarIcon as StarIconSolid,
  HeartIcon as HeartIconSolid
} from '@heroicons/react/24/solid';
import {
  MapPin,
  Home,
  Tag,
  Heart,
  User,
  Sparkles,
  Key,
  Building,
  Moon,
  LayoutGrid,
  Star,
  ThumbsUp,
  ThumbsDown,
  Share2,
  BookOpen,
  Search as SearchIconLucide,
  Navigation,
  Check,
  UtensilsCrossed
} from 'lucide-react';
import NeighborhoodInsights from '../components/NeighborhoodInsights';
import { AirbnbCard, AirbnbCardSkeleton } from '../components/home/AirbnbCard';


const RECENT_SEARCHES_KEY = 'recentPropertySearches';
const MAX_RECENT_SEARCHES = 5;
const DEFAULT_LISTING_LIMIT = 12;
const QUICK_SEARCH_TYPES = [
  { id: 'all', label: 'All', icon: Sparkles },
  { id: 'properties', label: 'Stays', icon: HomeIcon },
  { id: 'helpers', label: 'Helpers', icon: UserGroupIcon },
  { id: 'food', label: 'Food', icon: UtensilsCrossed },
  { id: 'events', label: 'Events', icon: CalendarIcon },
];

// Quick search types shown in the Search page tab bar (Services removed per user request)
const VISIBLE_QUICK_SEARCH_TYPES = QUICK_SEARCH_TYPES.filter(t => t.id !== 'services');

const CITY_COORDS = {
  'polokwane': { lat: -23.9058, lng: 29.4505 },
  'sandton': { lat: -26.1076, lng: 28.0567 },
  'johannesburg': { lat: -26.2041, lng: 28.0473 },
  'cape town': { lat: -33.9249, lng: 18.4241 },
  'durban': { lat: -29.8587, lng: 31.0218 },
  'pretoria': { lat: -25.7479, lng: 28.2293 },
  'tembisa': { lat: -25.9964, lng: 28.2268 },
  'soweto': { lat: -26.2678, lng: 27.8585 }
};

// Enhanced Categories Configuration with all user requested categories
const ALL_CATEGORIES = [
  // Properties & Accommodation
  { id: 'over', label: 'Guest House & B&B', type: 'properties', icon: HomeIcon, color: 'bg-rose-100 text-rose-800', description: 'Guest houses & B&Bs (per day)' },
  { id: 'hotel', label: 'Hotel & Lodge', type: 'properties', icon: BuildingOfficeIcon, color: 'bg-emerald-100 text-emerald-800', description: 'Hotels & lodges (per day)' },
  { id: 'land', label: 'Self Catering', type: 'properties', icon: HomeIcon, color: 'bg-amber-100 text-amber-800', description: 'Self catering chalets (per day)' },
  { id: 'resort', label: 'Resort & Holiday Park', type: 'properties', icon: Sparkles, color: 'bg-cyan-100 text-cyan-800', description: 'Holiday resorts & parks (per day)' },
  { id: 'office', label: 'Room Per Hour', type: 'properties', icon: BuildingOfficeIcon, color: 'bg-purple-100 text-purple-800', description: 'Hourly rooms & short stays' },
  { id: 'rent', label: 'Room / Home to Rent', type: 'properties', icon: HomeIcon, color: 'bg-blue-100 text-blue-800', description: 'Rental properties (monthly)' },
  { id: 'apartment', label: 'Apartment', type: 'properties', icon: BuildingOfficeIcon, color: 'bg-indigo-100 text-indigo-800', description: 'Apartments, flats & complexes' },
  { id: 'full_house', label: 'Full House', type: 'properties', icon: HomeIcon, color: 'bg-emerald-100 text-emerald-800', description: 'Entire houses and homes' },
  { id: 'single_room', label: 'Single Room', type: 'properties', icon: HomeModernIcon, color: 'bg-sky-100 text-sky-800', description: 'Private rooms for rent' },
  { id: 'studio', label: 'Studio', type: 'properties', icon: BuildingOfficeIcon, color: 'bg-violet-100 text-violet-800', description: 'Studio and bachelor apartments' },
  { id: 'townhouse', label: 'Townhouse', type: 'properties', icon: HomeModernIcon, color: 'bg-teal-100 text-teal-800', description: 'Townhouses and cluster homes' },
  { id: 'loft', label: 'Loft', type: 'properties', icon: BuildingOfficeIcon, color: 'bg-slate-100 text-slate-800', description: 'Loft apartments' },
  { id: 'penthouse', label: 'Penthouse', type: 'properties', icon: BuildingOfficeIcon, color: 'bg-fuchsia-100 text-fuchsia-800', description: 'Penthouses and top-floor homes' },

  // Services
  { id: 'photography', label: 'Photography', type: 'helper', icon: CameraIcon, color: 'bg-indigo-100 text-indigo-800', description: 'Photo & video services' },
  { id: 'carwash', label: 'Car Wash', type: 'helper', icon: BoltIcon, color: 'bg-cyan-100 text-cyan-800', description: 'Vehicle cleaning' },
  { id: 'landscaping', label: 'Landscaping', type: 'services', icon: SunIcon, color: 'bg-green-100 text-green-800', description: 'Garden & lawn care' },
  { id: 'electrician', label: 'Electrician', type: 'services', icon: BoltIcon, color: 'bg-yellow-100 text-yellow-800', description: 'Electrical services' },
  { id: 'catering', label: 'Catering', type: 'services', icon: BriefcaseIcon, color: 'bg-orange-100 text-orange-800', description: 'Event catering' },
  { id: 'moving', label: 'Moving & Transport', type: 'helper', icon: TruckIcon, color: 'bg-amber-100 text-amber-800', description: 'Relocation services' },

  // Helpers
  { id: 'domestic', label: 'Domestic Help', type: 'helper', icon: HomeIcon, color: 'bg-teal-100 text-teal-800', description: 'Household assistance' },
  { id: 'tattoo', label: 'Tattoo Artist', type: 'helper', icon: PuzzlePieceIcon, color: 'bg-red-100 text-red-800', description: 'Tattoo & piercing' },
  { id: 'tutor', label: 'Private Tutor', type: 'helper', icon: AcademicCapIcon, color: 'bg-blue-100 text-blue-800', description: 'Personal teaching' },
  { id: 'hair', label: 'Hair & Beauty', type: 'helper', icon: ScissorsIcon, color: 'bg-rose-100 text-rose-800', description: 'Salon services' },
  { id: 'nail', label: 'Nail Services', type: 'helper', icon: Sparkles, color: 'bg-pink-100 text-pink-800', description: 'Manicure & pedicure' },
  { id: 'chef', label: 'Private Chef', type: 'helper', icon: BriefcaseIcon, color: 'bg-amber-100 text-amber-800', description: 'Personal cooking' },
  { id: 'barber', label: 'Barber', type: 'helper', icon: ScissorsIcon, color: 'bg-sky-100 text-sky-800', description: 'Men\'s grooming' },
  { id: 'nanny', label: 'Nanny', type: 'helper', icon: Sparkles, color: 'bg-pink-100 text-pink-800', description: 'Childcare assistance' },
  { id: 'sneaker', label: 'Sneaker Cleaner', type: 'helper', icon: BoltIcon, color: 'bg-indigo-100 text-indigo-800', description: 'Premium shoe cleaning' },
  { id: 'washingmat', label: 'Washing Mat', type: 'helper', icon: HomeModernIcon, color: 'bg-cyan-100 text-cyan-800', description: 'Expert mat cleaning' },
  { id: 'animals', label: 'Animal Care', type: 'helper', icon: Sparkles, color: 'bg-amber-100 text-amber-800', description: 'Pet & animal services' },
  { id: 'handyman', label: 'Handyman', type: 'helper', icon: WrenchIcon, color: 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white', description: 'Repair & maintenance' },
  { id: 'other', label: 'Other Services', type: 'helper', icon: Sparkles, color: 'bg-rose-100 text-rose-800', description: 'Other skills and local services' },
  { id: 'storage', label: 'Booking Storage', type: 'services', icon: BuildingOfficeIcon, color: 'bg-slate-100 text-slate-800', description: 'Secure storage units' },

  // Transport
  { id: 'transport', label: 'Transport', type: 'services', icon: TruckIcon, color: 'bg-blue-100 text-blue-800', description: 'Transportation services' },
  
  { id: 'maid', label: 'Maid Services', type: 'helper', icon: HomeModernIcon, color: 'bg-cyan-100 text-cyan-800', description: 'Cleaning & maid help' },

  // Daily Essentials (for Homepage consistency)
  { id: 'daily', label: 'Daily Loop', type: 'services', icon: Sparkles, color: 'bg-green-100 text-green-800', description: 'Essentials & daily needs' },

  // Food & Lunch
  { id: 'food', label: 'Food & Lunch', type: 'food', icon: UtensilsCrossed, color: 'bg-orange-100 text-orange-800', description: 'Local kitchens, meals & takeaways' },
  { id: 'street_food', label: 'Street Food & Kotas', type: 'food', icon: UtensilsCrossed, color: 'bg-amber-100 text-amber-800', description: 'Kotas, chips & fast bites' },
  { id: 'traditional', label: 'Traditional African', type: 'food', icon: UtensilsCrossed, color: 'bg-rose-100 text-rose-800', description: 'Pap, stew, mogodu & chakalaka' }
];

// Property Types Configuration
const PROPERTY_TYPE_CONFIG = {
  rent: { label: 'Room / Home to Rent', color: 'bg-blue-100 text-blue-800', icon: '🏠', endpoint: 'listing' },
  over: { label: 'Guest House / B&B', color: 'bg-rose-100 text-rose-800', icon: '🛌', endpoint: 'listing' },
  hotel: { label: 'Hotel / Lodge', color: 'bg-emerald-100 text-emerald-800', icon: '🏨', endpoint: 'listing' },
  land: { label: 'Self Catering', color: 'bg-amber-100 text-amber-800', icon: '🍳', endpoint: 'listing' },
  resort: { label: 'Resort & Holiday Park', color: 'bg-cyan-100 text-cyan-800', icon: '🏖️', endpoint: 'listing' },
  office: { label: 'Room Per Hour', color: 'bg-purple-100 text-purple-800', icon: '🚪', endpoint: 'listing' },
  apartment: { label: 'Apartment', color: 'bg-indigo-100 text-indigo-800', icon: '🏢', endpoint: 'listing' },
  full_house: { label: 'Full House', color: 'bg-emerald-100 text-emerald-800', icon: '🏡', endpoint: 'listing' },
  single_room: { label: 'Single Room', color: 'bg-sky-100 text-sky-800', icon: '🛏️', endpoint: 'listing' },
  studio: { label: 'Studio', color: 'bg-violet-100 text-violet-800', icon: '🪴', endpoint: 'listing' },
  townhouse: { label: 'Townhouse', color: 'bg-teal-100 text-teal-800', icon: '🏘️', endpoint: 'listing' },
  loft: { label: 'Loft', color: 'bg-slate-100 text-slate-800', icon: '🏙️', endpoint: 'listing' },
  penthouse: { label: 'Penthouse', color: 'bg-fuchsia-100 text-fuchsia-800', icon: '🌇', endpoint: 'listing' }
};

// Helper Categories Configuration
const HELPER_CATEGORY_CONFIG = {
  beauty: { label: 'Beauty & Spa', color: 'bg-pink-100 text-pink-800', icon: '💅', endpoint: 'helper' },
  spa: { label: 'Spa Services', color: 'bg-purple-100 text-purple-800', icon: '🧖', endpoint: 'helper' },
  barber: { label: 'Barber', color: 'bg-blue-100 text-blue-800', icon: '💇', endpoint: 'helper' },
  chef: { label: 'Personal Chef', color: 'bg-orange-100 text-orange-800', icon: '👨‍🍳', endpoint: 'helper' },
  cooking: { label: 'Cooking Services', color: 'bg-amber-100 text-amber-800', icon: '🍳', endpoint: 'helper' },
  tattoo: { label: 'Tattoo Artist', color: 'bg-red-100 text-red-800', icon: '💉', endpoint: 'helper' },
  tutor: { label: 'Tutoring', color: 'bg-green-100 text-green-800', icon: '📚', endpoint: 'helper' },
  photography: { label: 'Photography', color: 'bg-indigo-100 text-indigo-800', icon: '📸', endpoint: 'helper' },
  domestic: { label: 'Domestic Help', color: 'bg-teal-100 text-teal-800', icon: '🧹', endpoint: 'helper' },
  maid: { label: 'Maid Services', color: 'bg-cyan-100 text-cyan-800', icon: '🧼', endpoint: 'helper' },
  hair: { label: 'Hair & Beauty', color: 'bg-rose-100 text-rose-800', icon: '💇‍♀️', endpoint: 'helper' },
  nail: { label: 'Nail Services', color: 'bg-pink-100 text-pink-800', icon: '💅', endpoint: 'helper' },
  sneaker: { label: 'Sneaker Cleaner', color: 'bg-indigo-100 text-indigo-800', icon: '👟', endpoint: 'helper' },
  washingmat: { label: 'Washing Mat', color: 'bg-cyan-100 text-cyan-800', icon: '🧼', endpoint: 'helper' },
  animals: { label: 'Animal Care', color: 'bg-amber-100 text-amber-800', icon: '🐾', endpoint: 'helper' },
  cleaner: { label: 'Cleaning', color: 'bg-cyan-100 text-cyan-800', icon: '🧼', endpoint: 'helper' },
  handyman: { label: 'Handyman', color: 'bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-white', icon: '🔧', endpoint: 'helper' },
  carwash: { label: 'Car Wash', color: 'bg-cyan-100 text-cyan-800', icon: '🚗', endpoint: 'helper' },
  moving: { label: 'Moving & Transport', color: 'bg-amber-100 text-amber-800', icon: '🚚', endpoint: 'helper' },
  other: { label: 'Other Services', color: 'bg-rose-100 text-rose-800', icon: '✨', endpoint: 'helper' },
  maintenance: { label: 'Maintenance', color: 'bg-amber-100 text-amber-800', icon: '🔧', endpoint: 'helper' }
};

// Services Categories Configuration
const SERVICES_CATEGORY_CONFIG = {
  carwash: { label: 'Car Wash', color: 'bg-cyan-100 text-cyan-800', icon: '🚗', endpoint: 'service' },
  landscaping: { label: 'Landscaping', color: 'bg-green-100 text-green-800', icon: '🌿', endpoint: 'service' },
  electrician: { label: 'Electrician', color: 'bg-yellow-100 text-yellow-800', icon: '⚡', endpoint: 'service' },
  catering: { label: 'Catering', color: 'bg-orange-100 text-orange-800', icon: '🍽️', endpoint: 'service' },
  moving: { label: 'Moving & Transport', color: 'bg-amber-100 text-amber-800', icon: '🚚', endpoint: 'service' },
  transport: { label: 'Transport', color: 'bg-blue-100 text-blue-800', icon: '🚕', endpoint: 'service' },
  daily: { label: 'Daily Loop', color: 'bg-green-100 text-green-800', icon: '✨', endpoint: 'service' },
  schoolTransport: { label: 'School Transport', color: 'bg-amber-100 text-amber-800', icon: '🚌', endpoint: 'service' },
  daycare: { label: 'Daycare Centers', color: 'bg-pink-100 text-pink-800', icon: '🧸', endpoint: 'service' },
  storage: { label: 'Booking Storage', color: 'bg-slate-100 text-slate-800', icon: '📦', endpoint: 'service' }
};

// Events Categories Configuration
const EVENTS_CATEGORY_CONFIG = {
  music: { label: 'Music', color: 'bg-purple-100 text-purple-800', icon: '🎵', endpoint: 'event' },
  art: { label: 'Art', color: 'bg-pink-100 text-pink-800', icon: '🎨', endpoint: 'event' },
  food: { label: 'Food & Wine', color: 'bg-red-100 text-red-800', icon: '🍷', endpoint: 'event' },
  tech: { label: 'Tech', color: 'bg-blue-100 text-blue-800', icon: '💻', endpoint: 'event' },
};

// Food Categories Configuration
const FOOD_CATEGORY_CONFIG = {
  food: { label: 'All Meals', color: 'bg-orange-100 text-orange-800', icon: '🍱', endpoint: 'lunch' },
  street_food: { label: 'Street Food & Kotas', color: 'bg-amber-100 text-amber-800', icon: '🥪', endpoint: 'lunch' },
  traditional: { label: 'Traditional & Stew', color: 'bg-rose-100 text-rose-800', icon: '🍲', endpoint: 'lunch' },
  fast_food: { label: 'Burgers & Grills', color: 'bg-red-100 text-red-800', icon: '🍔', endpoint: 'lunch' }
};

// Main Search Type Configuration
const SEARCH_TYPE_CONFIG = {
  all: {
    label: 'Everything',
    icon: Sparkles,
    color: 'from-gray-900 to-gray-800',
    bgColor: 'bg-gray-900',
    textColor: 'text-gray-900 dark:text-white',
    endpoint: 'all'
  },
  food: {
    label: 'Food & Lunch',
    icon: UtensilsCrossed,
    color: 'from-orange-500 to-amber-600',
    bgColor: 'bg-orange-500',
    textColor: 'text-orange-600',
    endpoint: 'lunch',
    subTypes: FOOD_CATEGORY_CONFIG
  },
  properties: {
    label: 'Properties',
    icon: HomeIcon,
    color: 'from-rose-500 to-rose-600',
    bgColor: 'bg-rose-500',
    textColor: 'text-rose-600',
    endpoint: 'listing',
    subTypes: PROPERTY_TYPE_CONFIG
  },
  services: {
    label: 'Professional Services',
    icon: WrenchIcon,
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-blue-500',
    textColor: 'text-blue-600',
    endpoint: 'service',
    subTypes: SERVICES_CATEGORY_CONFIG
  },
  helpers: {
    label: 'Local Helper',
    icon: UserGroupIcon,
    color: 'from-amber-500 to-amber-600',
    bgColor: 'bg-amber-500',
    textColor: 'text-amber-600',
    endpoint: 'helper',
    subTypes: HELPER_CATEGORY_CONFIG
  },
  events: {
    label: 'Exclusive Events',
    icon: CalendarIcon,
    color: 'from-purple-500 to-purple-600',
    bgColor: 'bg-purple-500',
    textColor: 'text-purple-600',
    endpoint: 'event',
    subTypes: EVENTS_CATEGORY_CONFIG
  },
  'looking-for': {
    label: 'Community Needs',
    icon: ChatBubbleBottomCenterTextIcon,
    color: 'from-rose-500 to-pink-600',
    bgColor: 'bg-rose-500',
    textColor: 'text-rose-600',
    endpoint: 'looking-for'
  }
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.025 }
  }
};

const normalizeSearchType = (type) => {
  if (type === 'helper') return 'helpers';
  if (type === 'property') return 'properties';
  if (type === 'lunch') return 'food';
  return type || 'all';
};

// Keep the search page usable while API deployments roll out independently.
// Older API instances do not have /api/search, so use their existing routes on 404.
const fetchLegacySearchResults = async (urlParams, signal) => {
  const type = normalizeSearchType(urlParams.get('type'));
  const subType = urlParams.get('subType') || urlParams.get('category') || '';
  const searchTerm = urlParams.get('searchTerm') || '';
  const location = urlParams.get('location') || urlParams.get('address') || '';
  const endpoints = type === 'all'
    ? ['listing', 'service', 'helper', 'event', 'lunch']
    : [SEARCH_TYPE_CONFIG[type]?.endpoint].filter(Boolean);

  const requests = endpoints.map(async (endpoint) => {
    if (endpoint === 'lunch') {
      const response = await fetch('/api/lunch/shops', { signal });
      if (!response.ok) throw new Error(`Food search failed (${response.status}).`);
      const shops = await response.json();
      const term = searchTerm.toLowerCase().trim();
      const place = location.toLowerCase().trim();
      const categoryPatterns = {
        street_food: /street|kota|fast|chips|snack/i,
        traditional: /traditional|pap|stew|mogodu|chakalaka/i,
        fast_food: /burger|grill|fast/i,
      };
      return (Array.isArray(shops) ? shops : []).flatMap((shop) => {
        const shopMatchesTerm = !term || [shop.name, shop.cuisine, shop.address].some((value) => value?.toLowerCase().includes(term));
        const shopMatchesPlace = !place || shop.address?.toLowerCase().includes(place);
        return (shop.meals || []).filter((meal) => {
          if (meal.isAvailable === false || !shopMatchesPlace) return false;
          const mealMatchesTerm = !term || [meal.name, meal.description, meal.tag].some((value) => value?.toLowerCase().includes(term));
          const categoryPattern = type === 'food' ? categoryPatterns[subType] : null;
          return (shopMatchesTerm || mealMatchesTerm) && (!categoryPattern || categoryPattern.test(`${meal.name} ${meal.tag} ${meal.category} ${shop.cuisine}`));
        }).map((meal) => {
          const image = meal.image?.startsWith('http') ? meal.image : 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800';
          return {
            _id: `${shop.id || shop._id}_${meal.id}`,
            id: `${shop.id || shop._id}_${meal.id}`,
            name: meal.name,
            title: meal.name,
            description: `${meal.description || ''} • ${shop.name} (${shop.cuisine || 'Local Food'})`,
            regularPrice: meal.price,
            discountPrice: meal.originalPrice || meal.price,
            price: meal.price,
            address: shop.address || 'Polokwane, Limpopo',
            imageUrls: [image],
            image,
            itemType: 'food',
            type: 'food',
            subType: shop.cuisine || 'food',
            shopId: shop.id || shop._id,
            shopName: shop.name,
            rating: Number(shop.rating) || 0,
            latitude: shop.latitude,
            longitude: shop.longitude,
            badge: meal.tag || 'Popular',
            route: '/food',
          };
        });
      });
    }

    const params = new URLSearchParams({ limit: String(DEFAULT_LISTING_LIMIT) });
    if (searchTerm) params.set('searchTerm', searchTerm);
    if (location) {
      params.set('address', location);
      params.set('location', location);
    }
    ['minPrice', 'maxPrice', 'minRating', 'pricePeriod'].forEach((key) => {
      const value = urlParams.get(key) || (key === 'maxPrice' ? urlParams.get('priceMax') : '');
      if (value) params.set(key, value);
    });

    const propertyPeriodCategory = { per_day: 'day', per_month: 'month', per_hour: 'hour' }[subType];
    if (endpoint === 'listing' && propertyPeriodCategory) params.set('pricePeriod', propertyPeriodCategory);
    if (endpoint === 'listing' && ['rent', 'over', 'hotel', 'land', 'resort', 'office', 'apartment'].includes(subType)) params.set('type', subType);
    if (endpoint === 'helper' && subType && HELPER_CATEGORY_CONFIG[subType]) {
      params.set('type', ({ maid: 'domestic', nanny: 'domestic', hair: 'beauty', nail: 'beauty' })[subType] || subType);
    }
    if (endpoint === 'service' && subType && SERVICES_CATEGORY_CONFIG[subType]) {
      params.set('type', ({ electrician: 'maintenance', transport: 'moving', daily: 'other' })[subType] || subType);
    }

    const response = await fetch(`/api/${endpoint}/get?${params}`, { signal });
    if (!response.ok) throw new Error(`${endpoint} search failed (${response.status}).`);
    const data = await response.json();
    return (Array.isArray(data) ? data : []).map((item) => ({
      ...item,
      itemType: endpoint === 'helper' ? 'helper' : endpoint,
      subType: item.type || item.category || subType,
    }));
  });

  const settled = await Promise.allSettled(requests);
  const successful = settled.filter((result) => result.status === 'fulfilled');
  if (endpoints.length && !successful.length) throw settled[0]?.reason || new Error('Search is temporarily unavailable.');
  let items = successful.flatMap((result) => result.value);
  const minRating = Number(urlParams.get('minRating'));
  if (Number.isFinite(minRating) && minRating > 0) items = items.filter((item) => Number(item.rating) >= minRating);
  return { items, page: 0, hasMore: false };
};

// Category Dropdown Component (for compact view)
const CategoryDropdown = ({
  isOpen,
  onClose,
  onSelect,
  selectedCategory,
  searchQuery,
  setSearchQuery
}) => {
  const dropdownRef = useRef(null);

  // Filter categories based on search
  const filteredCategories = useMemo(() => {
    if (!searchQuery) return ALL_CATEGORIES;
    const query = searchQuery.toLowerCase();
    return ALL_CATEGORIES.filter(cat =>
      cat.label.toLowerCase().includes(query) ||
      cat.description.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  // Group by type
  const groupedCategories = useMemo(() => {
    const groups = {};
    filteredCategories.forEach(cat => {
      if (!groups[cat.type]) groups[cat.type] = [];
      groups[cat.type].push(cat);
    });
    return groups;
  }, [filteredCategories]);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        onClose();
      }
    };
    if (isOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const getGroupLabel = (type) => {
    switch (type) {
      case 'food': return '🍱 Food & Lunch';
      case 'properties': return '🏠 Properties & Accommodation';
      case 'services': return '🔧 Services';
      case 'helper': return '👤 Helper & Professionals';
      case 'events': return '🎪 Events';
      default: return 'Other';
    }
  };

  return (
    <motion.div
      ref={dropdownRef}
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 10, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 z-50 max-h-[400px] flex flex-col"
    >
      {/* Search within dropdown - Fixed */}
      <div className="flex-shrink-0 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 p-3">
        <div className="relative">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search categories..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-8 py-2 bg-gray-100 dark:bg-gray-800 border-0 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
            autoFocus
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-200 rounded-full"
            >
              <XMarkIcon className="w-3 h-3 text-gray-500 dark:text-white" />
            </button>
          )}
        </div>
      </div>

      {/* Categories list - Scrollable */}
      <div className="flex-1 overflow-y-auto p-2">
        {Object.entries(groupedCategories).map(([type, categories]) => (
          <div key={type} className="mb-4">
            <h3 className="px-3 py-2 text-xs font-bold text-gray-500 dark:text-white uppercase tracking-wider">
              {getGroupLabel(type)}
            </h3>
            <div className="space-y-1">
              {categories.map((category) => {
                const Icon = category.icon;
                const isSelected = selectedCategory === category.id;
                return (
                  <button
                    key={category.id}
                    onClick={() => onSelect(category)}
                    className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all text-left ${isSelected
                      ? 'bg-rose-50 border-rose-200 border'
                      : 'hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent'
                      }`}
                  >
                    <div className={`p-2 rounded-lg ${category.color} hover:scale-110 transition-transform flex-shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`font-semibold text-sm truncate ${isSelected ? 'text-rose-700' : 'text-gray-900 dark:text-white'}`}>
                          {category.label}
                        </span>
                        {isSelected && <CheckIcon className="w-4 h-4 text-rose-500 flex-shrink-0" />}
                      </div>
                      <p className="text-xs text-gray-500 dark:text-white truncate">{category.description}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {filteredCategories.length === 0 && (
          <div className="text-center py-8 text-gray-500 dark:text-white">
            <MagnifyingGlassIcon className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-sm">No categories found</p>
            <p className="text-xs mt-1">Try a different search term</p>
          </div>
        )}
      </div>

      {/* Quick select footer - Fixed */}
      <div className="flex-shrink-0 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-800 p-3">
        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-white">
          <span>{filteredCategories.length} categories</span>
        </div>
      </div>
    </motion.div>
  );
};

const ResultCard = ({ item, index, viewMode, onClick }) => {
  const navigate = useNavigate();

  const getItemType = () => {
    const type = item.itemType || item.type || 'properties';
    if (type === 'listing' || type === 'property') return 'properties';
    if (type === 'service') return 'services';
    if (type === 'helper') return 'helper';
    if (type === 'event') return 'events';
    return type;
  };

  const type = getItemType();

  const getPrice = () => {
    const val = item.regularPrice || item.price || item.cost || item.pricePerHour || item.ticketPrice;
    if (!val) return 'Contact';
    const formatted = typeof val === 'number' ? `R${val.toLocaleString()}` : val;
    if (type === 'properties') {
      const period = item.pricePeriod || (item.type === 'rent' ? 'month' : item.type === 'resort' ? 'day' : ['over', 'hotel', 'land'].includes(item.type) ? 'night' : '');
      if (period === 'hour') return `${formatted} / hour`;
      if (period === 'day') return `${formatted} / day`;
      if (period === 'month') return `${formatted} / month`;
      if (period === 'night') return `${formatted} / night`;
    }
    return formatted;
  };

  const getLocation = () => item.address || item.location || item.city || 'Private Location';

  const cardVariants = {
    hidden: { opacity: 0, y: 8 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.18, ease: 'easeOut' } }
  };

  if (type === 'looking-for') {
    return (
      <motion.div
        variants={cardVariants}
        whileHover={{ y: -5, scale: 1.02 }}
        onClick={onClick}
        className="relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-[2.5rem] p-8 shadow-2xl hover:shadow-[0_30px_60px_-15px_rgba(225,29,72,0.3)] transition-all duration-500 h-full flex flex-col gap-6 cursor-pointer overflow-hidden border border-gray-700"
      >
        <div className="absolute top-0 right-0 p-8 opacity-10 hover:scale-125 transition-transform duration-1000">
           <LayoutGrid className="w-32 h-32 text-white" />
        </div>
        
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md overflow-hidden border border-white/20 p-1">
              <ImageWithFallback
                src={item.userRef?.avatar}
                alt="user"
                type="avatar"
                className="w-full h-full rounded-[0.9rem]"
              />
            </div>
            <div>
              <h4 className="text-[15px] font-black text-white leading-tight truncate max-w-[150px] drop-shadow-sm">{item.userRef?.username || "Neighbor"}</h4>
              <p className="text-[10px] text-rose-300 font-bold uppercase tracking-widest mt-1">{item.category}</p>
            </div>
          </div>
          <div className="px-3 py-1.5 bg-rose-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-[0_0_15px_rgba(225,29,72,0.5)]">
             Active Pulse
          </div>
        </div>

        <div className="relative z-10 my-4 flex-1">
           <h3 className="font-black text-white text-2xl leading-tight mb-3 drop-shadow-md">{item.title}</h3>
           <p className="text-[13px] text-gray-300 line-clamp-3 font-medium leading-relaxed">{item.description}</p>
        </div>

        <div className="relative z-10 mt-auto flex items-center justify-between pt-6 border-t border-white/10">
          <div className="flex items-center gap-2 text-rose-300">
            <MapPin className="w-4 h-4" />
            <span className="text-xs font-black uppercase tracking-widest truncate max-w-[120px] drop-shadow-sm">{getLocation()}</span>
          </div>
          <div className="flex items-baseline gap-1 bg-white/10 px-4 py-2 rounded-2xl border border-white/10 backdrop-blur-md">
             <span className="text-xl font-black text-white tracking-tighter drop-shadow-md">
               {getPrice()}
             </span>
          </div>
        </div>
      </motion.div>
    );
  }

  // Convert types to what AirbnbCard expects
  const airbnbCardType = (() => {
    if (type === 'properties') return 'property';
    if (type === 'services') return 'service';
    if (type === 'helper') return 'helper';
    if (type === 'events') return 'event';
    if (type === 'food' || type === 'lunch') return 'food';
    return type;
  })();

  return (
    <motion.div variants={cardVariants}>
      <AirbnbCard
        item={item}
        type={airbnbCardType}
        onClick={(path) => {
          if (item.itemType === 'food' || item.route === '/food') {
            navigate('/');
            return;
          }
          if (onClick) {
            onClick(path);
            return;
          }
          navigate(path);
        }}
      />
    </motion.div>
  );
};

const EmptyState = ({ onClear }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    className=" rounded-[3rem] p-16 text-center border border-gray-50 shadow-2xl shadow-rose-100 max-w-2xl mx-auto"
  >
    <div className="w-24 h-24 bg-rose-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-inner">
      <MagnifyingGlassIcon className="w-10 h-10 text-rose-500" />
    </div>
    <h3 className="text-3xl font-black text-gray-900 dark:text-white mb-4 tracking-tight">No results in this loop</h3>
    <p className="text-gray-500 dark:text-white font-medium mb-10 leading-relaxed">
      We couldn't find exactly what you're looking for. <br />
      Try broadening your search or resetting your filters.
    </p>
    <button
      onClick={onClear}
      className="px-10 py-5 bg-gray-900 text-white font-black uppercase tracking-[0.2em] rounded-2xl hover:bg-rose-600 transition-all shadow-xl shadow-gray-200 active:scale-95"
    >
      Reset all filters
    </button>
  </motion.div>
);

const SkeletonCard = () => (
  <AirbnbCardSkeleton />
);

const SearchPage = () => {
  const { currentUser } = useSelector((state) => state.user);
  const navigate = useNavigate();
  const location = useLocation();

  const [searchType, setSearchType] = useState('all');
  const [searchSubType, setSearchSubType] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState('grid');
  const [loading, setLoading] = useState(false);
  const [loadingMoreResults, setLoadingMoreResults] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [listings, setListings] = useState([]);
  const [resultsPage, setResultsPage] = useState(0);
  const [hasMoreResults, setHasMoreResults] = useState(false);
  const { city: detectedCity } = useLocationCoords();
  const [filters, setFilters] = useState({
    minPrice: '',
    maxPrice: '',
    minRating: '',
    location: '',
    bedroomsMin: '',
    bathroomsMin: '',
    pricePeriod: ''
  });

  const [selectedCategory, setSelectedCategory] = useState(null);
  const [categorySearch, setCategorySearch] = useState('');

  // Map center state
  const [mapCenter, setMapCenter] = useState({ lat: -26.1076, lng: 28.0567 }); // Default Sandton

  // Recent searches and recently viewed
  const [recentSearches, setRecentSearches] = useState([]);
  const [recentlyViewedItems, setRecentlyViewedItems] = useState([]);

  useEffect(() => {
    const loadRecentlyViewed = () => {
      try {
        const stored = localStorage.getItem('recentlyViewedItems');
        if (stored) {
          const items = JSON.parse(stored);
          setRecentlyViewedItems(items.slice(0, 5));
        }
      } catch (error) { console.error('Failed to load recently viewed items:', error); }
    };
    loadRecentlyViewed();
  }, []);

  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const type = normalizeSearchType(urlParams.get('type'));
    
    const subType = urlParams.get('subType') || urlParams.get('category') || '';

    setSearchTerm(urlParams.get('searchTerm') || '');
    setSearchType(type);
    setSearchSubType(subType);
    setFilters({
      minPrice: urlParams.get('minPrice') || '',
      maxPrice: urlParams.get('maxPrice') || urlParams.get('priceMax') || '',
      minRating: urlParams.get('minRating') || '',
      location: urlParams.get('location') || urlParams.get('address') || '',
      bedroomsMin: urlParams.get('bedroomsMin') || '',
      bathroomsMin: urlParams.get('bathroomsMin') || '',
      pricePeriod: urlParams.get('pricePeriod') || '',
      center: urlParams.get('center') || '',
      distance: urlParams.get('distance') || '',
      mode: urlParams.get('mode') || ''
    });

    const modeParam = urlParams.get('mode');
    if (modeParam === 'map') {
      setViewMode('map');
    } else if (modeParam === 'grid') {
      setViewMode('grid');
    } else if (typeof window !== 'undefined' && window.innerWidth < 1024) {
      setViewMode('grid');
    }

    // Set selected category if subType matches
    if (subType) {
      const category = ALL_CATEGORIES.find(c => c.id === subType);
      if (category) setSelectedCategory(category.id);
    } else {
      setSelectedCategory(null);
    }

    // Load recent searches from localStorage
    const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse recent searches');
      }
    }

    // Save dynamic lastUserSearch for ContinueSearchingCard
    const term = urlParams.get('searchTerm') || '';
    const loc = urlParams.get('location') || urlParams.get('address') || '';
    const categoryParam = urlParams.get('category') || urlParams.get('subType') || '';
    const startDate = urlParams.get('startDate') || urlParams.get('checkIn');
    const endDate = urlParams.get('endDate') || urlParams.get('checkOut');

    if (term || loc || categoryParam || type !== 'all') {
      const searchLocation = loc || term || 'Cape Town';
      let dateRangeStr = '';
      if (startDate && endDate) {
        dateRangeStr = `${startDate} – ${endDate}`;
      } else {
        const now = new Date();
        const month = now.toLocaleString('en-US', { month: 'short' });
        const day = now.getDate();
        dateRangeStr = `${month} ${day}, ${now.getFullYear()}`;
      }

      const searchObj = {
        location: searchLocation,
        query: term || searchLocation,
        category: type === 'all' ? (categoryParam || 'homes') : type,
        dateRange: dateRangeStr,
        url: `${location.pathname}${location.search}`,
        timestamp: new Date().toISOString()
      };

      try {
        localStorage.setItem('lastUserSearch', JSON.stringify(searchObj));
        window.dispatchEvent(new Event('storage'));
      } catch (err) {
        console.error('Failed to save lastUserSearch:', err);
      }
    }

    // Set default location if not provided
    if (!urlParams.get('location') && !urlParams.get('address') && detectedCity) {
      setFilters(prev => ({ ...prev, location: detectedCity }));
    }
  }, [location.search, detectedCity]);

  const fetchData = useCallback(async (page = 0, append = false, signal) => {
    const urlParams = new URLSearchParams(location.search);
    if (append) setLoadingMoreResults(true);
    else {
      setLoading(true);
      setListings([]);
    }
    setSearchError('');

    try {
      const params = new URLSearchParams({
        type: normalizeSearchType(urlParams.get('type')),
        page: String(page),
        limit: String(DEFAULT_LISTING_LIMIT),
      });
      const subType = urlParams.get('subType') || urlParams.get('category') || '';
      const searchTerm = urlParams.get('searchTerm') || '';
      // When the user did not type a location, use the town detected from the
      // device GPS so the initial results are local as well as the filter UI.
      const locationQuery = urlParams.get('location') || urlParams.get('address') || detectedCity || '';
      const maxPrice = urlParams.get('maxPrice') || urlParams.get('priceMax') || '';

      ['minPrice', 'minRating', 'bedroomsMin', 'bathroomsMin', 'pricePeriod'].forEach((key) => {
        const value = urlParams.get(key);
        if (value) params.set(key, value);
      });
      if (searchTerm) params.set('q', searchTerm);
      if (locationQuery) params.set('location', locationQuery);
      if (maxPrice) params.set('maxPrice', maxPrice);
      if (subType) params.set('subType', subType);

      const response = await fetch(`/api/search?${params.toString()}`, { signal });
      let payload;
      if (response.status === 404) {
        payload = await fetchLegacySearchResults(urlParams, signal);
      } else {
        payload = await response.json().catch(() => ({}));
      }
      if ((response.status !== 404 && !response.ok) || payload.success === false) {
        throw new Error(payload.message || 'We could not load search results. Please try again.');
      }

      const pageResults = Array.isArray(payload.items) ? payload.items : [];
      const deduplicate = (items) => {
        const seen = new Set();
        return items.filter((item) => {
          const id = item._id || item.id;
          const key = `${item.itemType || item.type}:${id}`;
          if (!id || seen.has(key)) return false;
          seen.add(key);
          return true;
        });
      };

      if (append) setListings((current) => deduplicate([...current, ...pageResults]));
      else setListings(deduplicate(pageResults));
      setResultsPage(Number.isInteger(payload.page) ? payload.page : page);
      setHasMoreResults(Boolean(payload.hasMore));
    } catch (error) {
      if (error.name === 'AbortError') return;
      console.error('Search Database error:', error);
      if (!append) setListings([]);
      setSearchError(error.message || 'We could not load search results. Please try again.');
    } finally {
      if (!signal?.aborted) {
        setLoading(false);
        setLoadingMoreResults(false);
      }
    }
  }, [location.search, detectedCity]);

  useEffect(() => {
    const controller = new AbortController();
    setResultsPage(0);
    setHasMoreResults(false);
    fetchData(0, false, controller.signal);
    return () => controller.abort();
  }, [fetchData]);

  // Geocode and update map center whenever the location filter changes
  useEffect(() => {
    if (!filters.location) return;
    
    const lowerLoc = filters.location.toLowerCase();
    const matchedCity = Object.keys(CITY_COORDS).find(city => lowerLoc.includes(city));

    if (matchedCity) {
      setMapCenter(CITY_COORDS[matchedCity]);
    } else {
      let cancelled = false;
      const timer = window.setTimeout(async () => {
        try {
          const { geocodeAddress } = await import('../utils/geocoding');
          if (cancelled) return;
          const coords = await geocodeAddress(filters.location.trim());
          if (!cancelled && coords) setMapCenter(coords);
        } catch {
          // The map is optional; search results remain usable if geocoding fails.
        }
      }, 350);
      return () => {
        cancelled = true;
        window.clearTimeout(timer);
      };
    }
  }, [filters.location]);

  const buildSearchParams = useCallback((overrides = {}) => {
    const nextSearchTerm = overrides.searchTerm ?? searchTerm;
    const nextSearchType = normalizeSearchType(overrides.searchType ?? searchType);
    const nextSearchSubType = overrides.searchSubType ?? searchSubType;
    const nextFilters = { ...filters, ...(overrides.filters || {}) };
    const nextViewMode = overrides.viewMode ?? viewMode;
    const urlParams = new URLSearchParams();

    if (nextSearchTerm) urlParams.set('searchTerm', nextSearchTerm);
    urlParams.set('type', nextSearchType || 'all');
    if (nextSearchSubType) urlParams.set('subType', nextSearchSubType);
    if (nextFilters.location) urlParams.set('location', nextFilters.location);
    if (nextFilters.minPrice) urlParams.set('minPrice', nextFilters.minPrice);
    if (nextFilters.maxPrice) urlParams.set('maxPrice', nextFilters.maxPrice);
    if (nextFilters.minRating) urlParams.set('minRating', nextFilters.minRating);
    if (nextFilters.bedroomsMin) urlParams.set('bedroomsMin', nextFilters.bedroomsMin);
    if (nextFilters.bathroomsMin) urlParams.set('bathroomsMin', nextFilters.bathroomsMin);
    if (nextFilters.pricePeriod) urlParams.set('pricePeriod', nextFilters.pricePeriod);
    if (nextFilters.center) urlParams.set('center', nextFilters.center);
    if (nextFilters.distance) urlParams.set('distance', nextFilters.distance);
    if (nextViewMode === 'map') urlParams.set('mode', 'map');

    return urlParams;
  }, [filters, searchSubType, searchTerm, searchType, viewMode]);

  const handleSearch = useCallback(() => {
    const minPrice = Number(filters.minPrice);
    const maxPrice = Number(filters.maxPrice);
    if ((filters.minPrice && (!Number.isFinite(minPrice) || minPrice < 0)) ||
        (filters.maxPrice && (!Number.isFinite(maxPrice) || maxPrice < 0)) ||
        (filters.minPrice && filters.maxPrice && minPrice > maxPrice)) {
      setSearchError('Enter a valid price range where the minimum is not greater than the maximum.');
      return false;
    }
    setSearchError('');
    const urlParams = buildSearchParams();

    if (currentUser?._id && currentUser.shareDetailedActivityWithAdmins === true) {
      authenticatedFetch('/api/stats/activity-history', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'search_submitted', section: 'Search' }) }).catch(() => {});
    }

    navigate(`/search?${urlParams.toString()}`);

    // Save to recent searches
    if (searchTerm && !recentSearches.includes(searchTerm)) {
      const newRecent = [searchTerm, ...recentSearches.slice(0, MAX_RECENT_SEARCHES - 1)];
      setRecentSearches(newRecent);
      localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(newRecent));
    }
    return true;
  }, [buildSearchParams, currentUser?._id, currentUser?.shareDetailedActivityWithAdmins, filters.location, filters.minPrice, filters.maxPrice, navigate, recentSearches, searchTerm]);

  const clearFilters = () => {
    setSearchTerm('');
    setSearchType('all');
    setSearchSubType('');
    setSelectedCategory(null);
    setFilters({ minPrice: '', maxPrice: '', minRating: '', location: '', bedroomsMin: '', bathroomsMin: '', pricePeriod: '' });
    navigate('/search');
  };

  const addToRecentlyViewed = (item, itemType, path) => {
    const id = item._id || item.id;
    const nextItem = { ...item, itemType };
    const nextItems = [
      nextItem,
      ...recentlyViewedItems.filter((viewed) => (viewed._id || viewed.id) !== id)
    ].slice(0, 5);

    setRecentlyViewedItems(nextItems);
    localStorage.setItem('recentlyViewedItems', JSON.stringify(nextItems));
    navigate(path || `/${itemType}/${id}`);
  };

  const handleCategorySelect = (category) => {
    if (!category) {
      setSelectedCategory(null);
      setSearchType('all');
      setSearchSubType('');
      navigate(`/search?${buildSearchParams({ searchType: 'all', searchSubType: '' }).toString()}`);
      return;
    }
    const normalizedType = normalizeSearchType(category.type);
    setSelectedCategory(category.id);
    setSearchType(normalizedType);
    setSearchSubType(category.id);

    const urlParams = buildSearchParams({
      searchType: normalizedType,
      searchSubType: category.id
    });
    navigate(`/search?${urlParams.toString()}`);
  };

  const handleTypeSelect = (type) => {
    setSelectedCategory(null);
    setSearchType(type);
    setSearchSubType('');
    const params = buildSearchParams({ searchType: type, searchSubType: '' });
    navigate(`/search?${params.toString()}`);
  };

  const visibleFilterCategories = ALL_CATEGORIES.filter((category) =>
    `${category.label} ${category.description}`.toLowerCase().includes(categorySearch.trim().toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 flex flex-col relative overflow-x-hidden no-scrollbar">
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>

      {/* Clean Airbnb-style Header */}
      <div className="app-safe-top sticky top-0 z-[60] bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800">
        <div className="max-w-[2520px] mx-auto px-3 sm:px-6 py-2.5 flex items-center gap-3 sm:gap-4">

          {/* Logo */}
          <button onClick={() => navigate('/')} aria-label="Go to home" className="hidden md:flex items-center gap-2 cursor-pointer flex-shrink-0">
            <div className="w-9 h-9 bg-gray-950 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-black tracking-tighter">loopOut</span>
          </button>

          {/* Search directly from the header; filters stay one tap away. */}
          <form onSubmit={(event) => { event.preventDefault(); handleSearch(); }} className="mx-auto flex w-full max-w-2xl items-center gap-2 rounded-full border border-gray-200 bg-white p-1.5 shadow-sm transition-shadow focus-within:shadow-md dark:border-gray-700 dark:bg-gray-900">
            <SearchIconLucide className="ml-3 h-4 w-4 shrink-0 text-gray-400" aria-hidden="true" />
            <input
              type="search"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder={filters.location ? `Search near ${filters.location}` : 'Search services, places, food…'}
              aria-label="Search LoopOut"
              autoComplete="off"
              className="min-w-0 flex-1 bg-transparent px-1 py-2 text-sm text-gray-900 outline-none placeholder:text-gray-400 dark:text-white"
            />
            {searchTerm && (
              <button type="button" onClick={() => setSearchTerm('')} aria-label="Clear search" className="rounded-full p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800">
                <XMarkIcon className="h-4 w-4" />
              </button>
            )}
            <button type="submit" className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full bg-rose-600 px-4 text-xs font-bold text-white transition hover:bg-rose-700 active:scale-95">
              <SearchIconLucide className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Search</span>
            </button>
            <button type="button" onClick={() => setShowFilters(true)} aria-label="Open filters" className="mr-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gray-100 text-gray-600 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700">
              <AdjustmentsHorizontalIcon className="h-4 w-4" />
            </button>
          </form>

          {/* Map Toggle - Desktop */}
          <div className="hidden lg:flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => setViewMode(viewMode === 'map' ? 'grid' : 'map')}
              aria-label={viewMode === 'map' ? 'Hide map' : 'Show map'}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-gray-300 dark:border-gray-700 text-sm font-semibold text-gray-700 dark:text-white hover:border-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all"
            >
              <MapIcon className="w-4 h-4" />
              {viewMode === 'map' ? 'Hide map' : 'Show map'}
            </button>
          </div>
        </div>
      </div>

      {/* Simple quick categories; detailed categories remain in Filters. */}
      <div className="sticky top-[61px] z-[50] border-b border-gray-100 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="mx-auto flex max-w-[2520px] items-center gap-2 overflow-x-auto px-3 py-2.5 no-scrollbar sm:px-6">
          {VISIBLE_QUICK_SEARCH_TYPES.map(({ id, label, icon: Icon }) => {
            const isActive = searchType === id && (id !== 'all' || !selectedCategory);
            return (
              <button
                key={id}
                type="button"
                onClick={() => id === 'all' ? handleCategorySelect(null) : handleTypeSelect(id)}
                aria-pressed={isActive}
                className={`inline-flex min-h-9 shrink-0 items-center gap-2 rounded-full px-4 text-xs font-semibold transition-colors ${isActive ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900' : 'border border-gray-200 bg-white text-gray-600 hover:border-gray-400 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300'}`}
              >
                <Icon className="h-4 w-4" />{label}
              </button>
            );
          })}
          <button type="button" onClick={() => setShowFilters(true)} className="inline-flex min-h-9 shrink-0 items-center gap-2 rounded-full border border-gray-200 px-4 text-xs font-semibold text-gray-600 transition-colors hover:border-gray-400 dark:border-gray-700 dark:text-gray-300">
            <AdjustmentsHorizontalIcon className="h-4 w-4" />More categories
          </button>
        </div>
      </div>

      {/* Main Content: True Split-Screen on Desktop */}
      <main className="flex-1 flex overflow-hidden relative">

        {/* Left Column: Results List */}
        <div
          className={`overflow-y-auto no-scrollbar transition-all duration-200 ${
            viewMode === 'map'
              ? 'hidden lg:block lg:w-[45%] xl:w-[40%] flex-shrink-0'
              : 'w-full'
          }`}
        >
          <div className="px-2 md:px-10 pt-6 app-safe-content-bottom pb-36">

            {/* Results Summary */}
            <div className="mb-6 flex items-center justify-between">
              <p className="text-sm font-semibold text-gray-500 dark:text-white">
                {loading ? 'Searching...' : `${listings.length} ${searchType !== 'all' ? searchType : 'results'} loaded${hasMoreResults ? '+' : ''}${filters.location ? ` near ${filters.location}` : ''}`}
              </p>
              {/* Mobile View Toggle */}
              <div className="flex items-center gap-1 lg:hidden">
                <button
                  onClick={() => setViewMode('grid')}
                  aria-label="Show results as a grid"
                  className={`p-2 rounded-lg transition-colors ${ viewMode === 'grid' ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}
                >
                  <Squares2X2Icon className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('map')}
                  aria-label="Show results on the map"
                  className={`p-2 rounded-lg transition-colors ${ viewMode === 'map' ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}
                >
                  <MapIcon className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Lunch & Food Hub Banner */}
            {(searchType === 'food' || /lunch|food|eat|meal|burger|kota|pizza|restaurant/i.test(searchTerm)) && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-rose-500 text-white shadow-lg shadow-orange-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-xl shrink-0">
                    🍱
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-black tracking-tight leading-tight">Explore Live Local Kitchens & Menus</h3>
                    <p className="text-[11px] text-orange-100 font-medium">Order hot meals, customize sides & track live pickup at the Lunch hub.</p>
                  </div>
                </div>
                <button
                  onClick={() => navigate('/')}
                  className="px-4 py-2 bg-white text-orange-600 rounded-full font-black text-xs uppercase tracking-wider hover:bg-orange-50 transition-all shadow-md shrink-0 active:scale-95 cursor-pointer"
                >
                  Open Lunch Hub →
                </button>
              </motion.div>
            )}

            {/* Results Grid */}
            {searchError && (
              <div role="alert" className="mb-6 flex items-center justify-between gap-4 rounded-2xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm font-medium text-rose-700">
                <span>{searchError}</span>
                <button onClick={() => fetchData(0, false)} className="font-bold underline underline-offset-4">Retry</button>
              </div>
            )}
            {loading ? (
              <div className={`grid gap-x-[18px] gap-y-5 ${ viewMode === 'map' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'}`}>
                {[1,2,3,4,5,6,7,8].map(i => <SkeletonCard key={i} />)}
              </div>
            ) : listings.length > 0 ? (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className={`grid gap-x-[18px] gap-y-5 ${ viewMode === 'map' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'}`}
              >
                {listings.map((item, idx) => (
                  <ResultCard
                    key={item._id || item.id || idx}
                    item={item}
                    viewMode="grid"
                    onClick={(path) => addToRecentlyViewed(item, item.itemType, path)}
                  />
                ))}
              </motion.div>
            ) : (
              <EmptyState onClear={clearFilters} />
            )}

            {hasMoreResults && !loading && listings.length > 0 && (
              <div className="mt-8 flex justify-center">
                <button
                  type="button"
                  onClick={() => fetchData(resultsPage + 1, true)}
                  disabled={loadingMoreResults}
                  className="inline-flex items-center gap-2 rounded-full border border-gray-300 dark:border-gray-700 px-6 py-3 text-sm font-semibold text-gray-900 dark:text-white hover:border-gray-900 dark:hover:border-white disabled:cursor-wait disabled:opacity-60"
                >
                  {loadingMoreResults && <ArrowPathIcon className="h-4 w-4 animate-spin" />}
                  {loadingMoreResults ? 'Loading…' : 'Load more results'}
                </button>
              </div>
            )}

            {/* Recently Viewed */}
            {recentlyViewedItems.length > 0 && (
              <section className="mt-16 pt-10 border-t border-gray-100 dark:border-gray-800">
                <h2 className="text-base font-bold text-gray-900 dark:text-white mb-5">Recently viewed</h2>
                <div className="flex overflow-x-auto gap-4 pb-4 no-scrollbar">
                  {recentlyViewedItems.map((item) => (
                    <div
                      key={item._id || Math.random().toString()}
                      onClick={() => navigate(`/${item.itemType || item.type || 'listing'}/${item._id || item.id}`)}
                      className="flex-shrink-0 w-48 cursor-pointer"
                    >
                      <div className="aspect-square rounded-xl overflow-hidden mb-2 bg-gray-100 dark:bg-gray-800">
                        <ImageWithFallback
                          src={item.imageUrls?.[0] || item.images?.[0] || 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800'}
                          alt={item.name || item.title || 'Item'}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                      <h3 className="font-semibold text-sm text-gray-900 dark:text-white truncate">{item.name || item.title || 'Untitled'}</h3>
                      <p className="text-sm text-gray-500 dark:text-white">
                        {typeof (item.regularPrice || item.price) === 'number'
                          ? `R${(item.regularPrice || item.price).toLocaleString()}`
                          : (item.regularPrice || item.price || 'Contact')}
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>

        {/* Right Column: Map */}
        <div
          className={`transition-all duration-200 overflow-hidden relative ${
            viewMode === 'map'
              ? 'w-full lg:flex-1 fixed inset-0 lg:relative lg:inset-auto z-[150] lg:z-auto h-[100dvh] lg:h-auto'
              : 'hidden'
          }`}
        >
          {/* Back Button for Mobile full-screen map */}
          {viewMode === 'map' && (
            <motion.button
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => setViewMode('grid')}
              className="lg:hidden absolute top-6 left-6 z-[160] flex items-center gap-2 px-4 py-2.5 bg-white/95 backdrop-blur-md rounded-full shadow-xl text-sm font-semibold text-gray-900 dark:text-white active:scale-95 transition-all border border-gray-200 dark:border-gray-800 cursor-pointer"
            >
              <ArrowLeftIcon className="w-4 h-4 text-gray-700 dark:text-white" />
              <span>Show list</span>
            </motion.button>
          )}

          <div className="absolute inset-0">
            <MapView
              items={listings}
              searchType={searchType}
              location={filters.location || 'South Africa'}
              center={mapCenter}
              onItemClick={(item) => navigate(`/${item.itemType || item.type || 'listing'}/${item._id || item.id}`)}
            />
          </div>
        </div>

        {/* Floating Show Map Button (Mobile/Tablet) */}
        {viewMode !== 'map' && (
          <button
            onClick={() => setViewMode('map')}
            className="lg:hidden fixed bottom-20 left-1/2 -translate-x-1/2 z-[60] flex items-center gap-2 bg-gray-900/95 backdrop-blur-md text-white px-5 py-3 rounded-full text-sm font-semibold shadow-2xl transition-all hover:bg-gray-800 active:scale-95 border border-white/10"
          >
            <MapIcon className="w-4 h-4 text-rose-400" />
            <span>Show map</span>
          </button>
        )}
      </main>

      {/* Filter / Search Slide-over Panel */}
      <AnimatePresence>
        {showFilters && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFilters(false)}
              className="fixed inset-0 bg-black z-[100]"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 35, stiffness: 400 }}
              className="fixed bottom-0 inset-x-0 h-[85vh] md:h-full md:inset-y-0 md:right-0 md:left-auto md:w-[480px] bg-white dark:bg-gray-900 z-[101] flex flex-col shadow-2xl md:rounded-none rounded-t-3xl overflow-hidden"
            >
              {/* Header */}
              <div className="flex-shrink-0 flex items-center justify-between px-6 pt-6 pb-4 border-b border-gray-100 dark:border-gray-800">
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">Filters</h2>
                <button
                  onClick={() => setShowFilters(false)}
                  className="w-9 h-9 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center hover:bg-gray-200 transition-colors"
                >
                  <XMarkIcon className="w-5 h-5 text-gray-700 dark:text-white" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto no-scrollbar">
                <div className="p-6 space-y-8">

                  {/* What */}
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-gray-500 dark:text-white uppercase tracking-wider">Service or Venue</label>
                    <div className="relative">
                      <SearchIconLucide className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="e.g. Nails, Hair, Guest house"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 focus:border-gray-900 rounded-xl py-3.5 pl-11 pr-4 focus:ring-0 transition-all outline-none text-sm"
                      />
                    </div>
                  </div>

                  {/* Where */}
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-gray-500 dark:text-white uppercase tracking-wider">Location</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="City or neighbourhood"
                        value={filters.location}
                        onChange={(e) => setFilters(prev => ({ ...prev, location: e.target.value }))}
                        className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 focus:border-gray-900 rounded-xl py-3.5 pl-11 pr-4 focus:ring-0 transition-all outline-none text-sm"
                      />
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {['Sandton', 'Cape Town', 'Durban', 'Polokwane', 'Pretoria', 'Johannesburg'].map(loc => (
                        <button
                          key={loc}
                          onClick={() => setFilters(prev => ({ ...prev, location: loc }))}
                          className={`px-4 py-2 rounded-full border text-sm font-medium transition-all ${
                            filters.location === loc
                              ? 'bg-gray-900 text-white border-gray-900'
                              : 'bg-white dark:bg-gray-900 text-gray-700 dark:text-white border-gray-200 dark:border-gray-800 hover:border-gray-900'
                          }`}
                        >
                          {loc}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Category */}
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-gray-500 dark:text-white uppercase tracking-wider">Category</label>
                    <input
                      type="search"
                      value={categorySearch}
                      onChange={(event) => setCategorySearch(event.target.value)}
                      placeholder="Find a category"
                      className="w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-gray-400 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      {visibleFilterCategories.map(cat => (
                        <button
                          key={cat.id}
                          onClick={() => { handleCategorySelect(cat); setShowFilters(false); }}
                          className={`flex items-center gap-3 p-3.5 rounded-xl border transition-all text-left ${
                            selectedCategory === cat.id
                              ? 'bg-gray-900 text-white border-gray-900'
                              : 'bg-white dark:bg-gray-900 text-gray-700 dark:text-white border-gray-200 dark:border-gray-800 hover:border-gray-400'
                          }`}
                        >
                          <cat.icon className={`w-4 h-4 flex-shrink-0 ${ selectedCategory === cat.id ? 'text-white' : 'text-gray-400'}`} />
                          <span className="text-xs font-semibold truncate">{cat.label}</span>
                        </button>
                      ))}
                      {visibleFilterCategories.length === 0 && <p className="col-span-2 py-5 text-center text-sm text-gray-500">No categories match that search.</p>}
                    </div>
                  </div>

                  {/* Price Range */}
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-gray-500 dark:text-white uppercase tracking-wider">Price range (R)</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="number"
                        placeholder="Min"
                        value={filters.minPrice}
                        onChange={(e) => setFilters(prev => ({ ...prev, minPrice: e.target.value }))}
                        className="flex-1 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 rounded-xl py-3 px-4 focus:ring-0 outline-none text-sm"
                      />
                      <span className="text-gray-400 font-medium">-</span>
                      <input
                        type="number"
                        placeholder="Max"
                        value={filters.maxPrice}
                        onChange={(e) => setFilters(prev => ({ ...prev, maxPrice: e.target.value }))}
                        className="flex-1 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 rounded-xl py-3 px-4 focus:ring-0 outline-none text-sm"
                      />
                    </div>
                  </div>

                  {/* Property price period */}
                  {searchType === 'properties' && <div className="space-y-3">
                    <label htmlFor="property-price-period" className="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-white">Price period</label>
                    <select
                      id="property-price-period"
                      value={filters.pricePeriod}
                      onChange={(event) => setFilters((prev) => ({ ...prev, pricePeriod: event.target.value }))}
                      className="w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-gray-900 dark:border-gray-800 dark:bg-gray-800"
                    >
                      <option value="">Any period</option>
                      <option value="hour">Per hour</option>
                      <option value="day">Per day</option>
                      <option value="night">Per night</option>
                      <option value="month">Per month</option>
                    </select>
                  </div>}

                  {/* Property Basics */}
                  <div className="space-y-3">
                    <label className="text-xs font-semibold text-gray-500 dark:text-white uppercase tracking-wider">Property basics</label>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="mb-2 block text-xs font-semibold text-gray-500 dark:text-white">Bedrooms</span>
                        <select
                          value={filters.bedroomsMin}
                          onChange={(e) => setFilters(prev => ({ ...prev, bedroomsMin: e.target.value }))}
                          className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 rounded-xl py-3 px-4 focus:border-gray-900 focus:ring-0 outline-none text-sm"
                        >
                          <option value="">Any</option>
                          {[1, 2, 3, 4, 5].map(count => (
                            <option key={count} value={count}>{count}+</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <span className="mb-2 block text-xs font-semibold text-gray-500 dark:text-white">Bathrooms</span>
                        <select
                          value={filters.bathroomsMin}
                          onChange={(e) => setFilters(prev => ({ ...prev, bathroomsMin: e.target.value }))}
                          className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 rounded-xl py-3 px-4 focus:border-gray-900 focus:ring-0 outline-none text-sm"
                        >
                          <option value="">Any</option>
                          {[1, 2, 3, 4, 5].map(count => (
                            <option key={count} value={count}>{count}+</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              {/* Footer */}
              <div className="flex-shrink-0 px-6 py-5 border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 flex items-center justify-between gap-4">
                <button
                  onClick={clearFilters}
                  className="text-sm font-semibold text-gray-700 dark:text-white underline underline-offset-4 hover:text-gray-900 dark:hover:text-white transition-colors"
                >
                  Clear all
                </button>
                <button
                  onClick={() => { if (handleSearch()) setShowFilters(false); }}
                  className="flex-1 bg-gray-900 text-white py-3.5 rounded-xl font-bold text-sm shadow-md hover:bg-gray-800 transition-all active:scale-95 flex items-center justify-center gap-2"
                >
                  <SearchIconLucide className="w-4 h-4" />
                  Search
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchPage;
