/* eslint-disable no-undef */
/* eslint-disable react/prop-types */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Zoom, Thumbs, Pagination, FreeMode } from "swiper/modules";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import emailjs from "emailjs-com";

import Calendar from "react-calendar";
import CommentsSidePanel from '../components/CommentsSidePanel';
import ImageWithFallback from '../components/ImageWithFallback';
import OperatingSchedule from '../components/OperatingSchedule';
import GoogleMapComponent from '../components/GoogleMapComponent';
import { useWishlist } from '../hooks/useWishlist';
import { pushPhoneNotification } from '../components/PhoneNotificationManager';
import BookingProgress from '../components/BookingProgress';
import ListingBookingSheet from '../components/ListingBookingSheet';
import { resolveApiUrl } from '../utils/apiBaseUrl';
import ListingDetailShell from '../components/ListingDetailShell';
import ListingWeatherForecast from '../components/ListingWeatherForecast';
import { formatListingTitle, getPropertyRatePeriod } from '../utils/listingDisplay';


import { HomeIcon, HeartIcon, ShareIcon, StarIcon, MapPinIcon, XMarkIcon, ChevronLeftIcon, ChevronRightIcon, CheckCircleIcon, PhoneIcon, EnvelopeIcon, ChatBubbleLeftRightIcon, FlagIcon, UserIcon, CameraIcon, Squares2X2Icon, ArrowLeftIcon, PhotoIcon, UserGroupIcon, CalendarIcon, CalendarDaysIcon, ClockIcon, HomeModernIcon, TagIcon, ArrowPathIcon, TicketIcon, BanknotesIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid, HeartIcon as HeartIconSolid } from '@heroicons/react/24/solid';
import { FiShare2, FiHeart, FiMessageSquare } from "react-icons/fi";

// Amenity & config icons (domain-specific, no Heroicons equivalent)
import {
  FaWifi, FaParking, FaSwimmingPool, FaUtensils, FaFire, FaTv, FaWarehouse,
  FaShieldAlt, FaHotTub, FaDog, FaBolt, FaSnowflake, FaUserFriends, FaCoffee,
  FaCouch, FaShower, FaWind, FaDesktop, FaTree, FaUmbrellaBeach, FaDumbbell,
  FaSmokingBan, FaHome, FaFacebook, FaInstagram, FaTwitter, FaLinkedin, FaTiktok,
  FaHeart, FaWhatsapp, FaUsers, FaClock, FaReceipt, FaSpinner, FaBed, FaBath, FaChevronLeft, FaChevronRight, FaHotel,
  FaTimes, FaRegCommentDots, FaEnvelope, FaPhone
} from "react-icons/fa";
import { MdCleanHands, MdOutlineGppGood, MdLogin, MdChat, MdLocationOn, MdAttachMoney, MdKingBed, MdBathtub, MdClose } from "react-icons/md";
import NeuralLoader from "../components/NeuralLoader";


// Styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/zoom";
import "swiper/css/thumbs";
import "swiper/css/pagination";
import "swiper/css/free-mode";
import "react-calendar/dist/Calendar.css";
import "../styles/ListingDetails.scss";

// Constants
const AMENITY_CONFIGS = {
  wifi: { icon: FaWifi, label: "WiFi", field: "wifi" },
  parking: { icon: FaParking, label: "Free parking on premises", field: "parking" },
  pool: { icon: FaSwimmingPool, label: "Pool", field: "pool" },
  kitchen: { icon: FaUtensils, label: "Kitchen", field: "kitchen" },
  stove: { icon: FaFire, label: "Stove", field: "stove" },
  tv: { icon: FaTv, label: "TV", field: "tv" },
  storage: { icon: FaWarehouse, label: "Storage", field: "storage" },
  security: { icon: FaShieldAlt, label: "Security cameras", field: "security" },
  hot: { icon: FaHotTub, label: "Hot water", field: "hot" },
  pets: { icon: FaDog, label: "Pets allowed", field: "pets" },
  prepaid: { icon: FaBolt, label: "Prepaid electricity", field: "prepaid" },
  fridge: { icon: FaSnowflake, label: "Refrigerator", field: "fridge" },
  share: { icon: FaUserFriends, label: "Shared space", field: "share" },
  breakfast: { icon: FaCoffee, label: "Breakfast", field: "breakfast" },
  furnished: { icon: FaCouch, label: "Furnished", field: "furnished" },
  ac: { icon: FaSnowflake, label: "Air conditioning", field: "ac" },
  heater: { icon: FaFire, label: "Heating", field: "heater" },
  washer: { icon: FaShower, label: "Washer", field: "washer" },
  dryer: { icon: FaWind, label: "Dryer", field: "dryer" },
  workspace: { icon: FaDesktop, label: "Dedicated workspace", field: "workspace" },
  patio: { icon: FaTree, label: "Patio or balcony", field: "patio" },
  garden: { icon: FaTree, label: "Garden", field: "garden" },
  beach: { icon: FaUmbrellaBeach, label: "Beach access", field: "beach" },
  gym: { icon: FaDumbbell, label: "Gym", field: "gym" },
  fireplace: { icon: FaFire, label: "Indoor fireplace", field: "fireplace" },
  smoking: { icon: FaSmokingBan, label: "Smoking allowed", field: "smoking" },
  instantConfirmation: { icon: FaBolt, label: "Instant confirmation", field: "instantConfirmation" },
  kidFriendly: { icon: FaUsers, label: "Kid-friendly", field: "kidFriendly" },
  wheelchairAccessible: { icon: FaUserFriends, label: "Wheelchair accessible", field: "wheelchairAccessible" },
  parkingAvailable: { icon: FaParking, label: "Parking available", field: "parkingAvailable" },
  environmentallyFriendly: { icon: FaTree, label: "Environmentally friendly", field: "environmentallyFriendly" },
};

const startOfLocalDay = (value) => {
  const parsed = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(parsed.getTime())) return null;
  return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
};

const dateOnlyString = (value) => {
  const date = startOfLocalDay(value);
  if (!date) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const hasBookedNightOverlap = (checkInValue, checkOutValue, ranges = []) => {
  const checkIn = startOfLocalDay(checkInValue);
  const checkOut = startOfLocalDay(checkOutValue);
  if (!checkIn || !checkOut) return false;
  return ranges.some((range) => {
    const bookedStart = startOfLocalDay(range.start);
    const bookedEnd = startOfLocalDay(range.end);
    return bookedStart && bookedEnd && checkIn < bookedEnd && checkOut > bookedStart;
  });
};

const RATING_CATEGORIES = [
  { name: "Cleanliness", icon: MdCleanHands, key: "cleanliness" },
  { name: "Accuracy", icon: MdOutlineGppGood, key: "accuracy" },
  { name: "Check-in", icon: MdLogin, key: "checkin" },
  { name: "Communication", icon: MdChat, key: "communication" },
  { name: "Location", icon: MdLocationOn, key: "location" },
  { name: "Value", icon: MdAttachMoney, key: "value" },
];

const LISTING_EMOJI_RATINGS = [
  { label: "Hospitality", emoji: "🛎️", key: "hospitality" },
  { label: "Comfort", emoji: "🛋️", key: "comfort" },
  { label: "Location", emoji: "📍", key: "location" },
  { label: "Owner / host", emoji: "🧑‍💼", key: "host" },
  { label: "Cleanliness", emoji: "🧹", key: "cleanliness" },
];

const LISTING_TYPES = {
  rent: { label: 'Room / Home to Rent', color: 'bg-slate-900 text-white', icon: FaHome, period: '/month' },
  apartment: { label: 'Apartment / Complex', color: 'bg-indigo-600 text-white', icon: FaHome, period: '/month' },
  over: { label: 'Guest House / B&B', color: 'bg-rose-600 text-white', icon: FaBed, period: '/day' },
  hotel: { label: 'Hotel / Lodge', color: 'bg-blue-600 text-white', icon: FaHotel, period: '/day' },
  land: { label: 'Self Catering', color: 'bg-emerald-700 text-white', icon: FaHome, period: '/day' },
  resort: { label: 'Resort & Holiday Park', color: 'bg-cyan-600 text-white', icon: FaUmbrellaBeach, period: '/day' },
  office: { label: 'Room Per Hour', color: 'bg-amber-600 text-white', icon: FaClock, period: '/hour' }
};

const SOCIAL_PLATFORMS = [
  { name: 'facebook', icon: FaFacebook, color: 'text-blue-600', baseUrl: 'https://facebook.com/' },
  { name: 'instagram', icon: FaInstagram, color: 'text-pink-600', baseUrl: 'https://instagram.com/' },
  { name: 'twitter', icon: FaTwitter, color: 'text-blue-400', baseUrl: 'https://twitter.com/' },
  { name: 'linkedin', icon: FaLinkedin, color: 'text-blue-700', baseUrl: 'https://linkedin.com/in/' },
  { name: 'tiktok', icon: FaTiktok, color: 'text-black', baseUrl: 'https://tiktok.com/@' },
];

// Replaced with 3-step bottom popout sheet
const WhatsAppBookingModal = ListingBookingSheet;

// Contact Host Modal Component
const ContactHostModal = ({ listing, user, isOpen, onClose }) => {
  const [contactMethod, setContactMethod] = useState('internal');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const defaultMessage = `Hello, I'm ${user?.name || 'Interested Client'}. I'm interested in your "${listing?.name || 'Listing'}" listing. Could you please provide more details?`;

  const formatPhoneNumber = (phone) => {
    if (!phone) return '';
    const phoneStr = String(phone).trim();
    const digits = phoneStr.replace(/\D/g, '');
    if (digits.length === 0) return '';
    if (digits.startsWith('27') && digits.length === 11) return '0' + digits.substring(2);
    if (digits.length === 10 && digits.startsWith('0')) return digits;
    if (digits.length === 9) return '0' + digits;
    if (digits.length > 10) {
      const last10Digits = digits.substring(digits.length - 10);
      return last10Digits.startsWith('0') ? last10Digits : '0' + last10Digits.substring(1);
    }
    if (!digits.startsWith('0') && digits.length >= 9) return '0' + digits;
    return digits;
  };

  const formatPhoneNumberForWhatsApp = (phone) => {
    const formatted = formatPhoneNumber(phone);
    if (!formatted) return '';
    if (formatted.startsWith('0') && formatted.length === 10) return '27' + formatted.substring(1);
    return formatted;
  };

  const handleSubmit = async () => {
    const contactNumber = listing?.contact || listing?.phone || listing?.userRef?.contact || listing?.userRef?.phone || '';
    const emailAddress = listing?.email || listing?.userRef?.email;
    const hostId = typeof listing.userRef === 'string' ? listing.userRef : listing.userRef._id;

    if (contactMethod === 'internal') {
      if (!user) {
        navigate('/sign-in');
        return;
      }
      
      if (user._id === hostId) {
        alert("You cannot message yourself.");
        return;
      }

      try {
        const res = await fetch('/api/messages/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            receiverId: hostId,
            content: message || defaultMessage,
          }),
        });
        const data = await res.json();
        if (res.ok) {
          navigate(`/messages/${data.conversationId || data._id}`);
          onClose();
        } else {
          alert(data.message || 'Failed to start conversation');
        }
      } catch (error) {
        console.error('Error starting conversation:', error);
        alert('An error occurred. Please try again.');
      }
      return;
    }

    const hasWhatsApp = contactNumber && contactMethod === 'whatsapp';
    const hasEmail = emailAddress && contactMethod === 'email';
    const hasCall = contactNumber && contactMethod === 'call';

    if (!hasWhatsApp && !hasEmail && !hasCall) {
      alert(`No ${contactMethod} information available`);
      return;
    }

    const finalMessage = message || defaultMessage;

    if (contactMethod === 'whatsapp' && contactNumber) {
      const whatsappNumber = formatPhoneNumberForWhatsApp(contactNumber);
      if (!whatsappNumber || whatsappNumber.length < 10) {
        alert('Invalid phone number for WhatsApp');
        return;
      }
      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(finalMessage)}`;
      window.open(whatsappUrl, '_blank');
    } else if (contactMethod === 'email' && emailAddress) {
      const subject = `Interest in "${listing?.name || 'Property'}"`;
      window.location.href = `mailto:${emailAddress}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(finalMessage)}`;
    } else if (contactMethod === 'call' && contactNumber) {
      const telNumber = formatPhoneNumber(contactNumber);
      window.location.href = `tel:${telNumber}`;
    }

    onClose();
  };

  const getAvailableContactMethods = () => {
    const contactNumber = listing?.contact || listing?.phone || listing?.userRef?.contact || listing?.userRef?.phone || '';
    const emailAddress = listing?.email || listing?.userRef?.email;
    const methods = ['internal'];
    if (contactNumber) { methods.push('whatsapp'); methods.push('call'); }
    if (emailAddress) methods.push('email');
    return methods;
  };

  const availableMethods = getAvailableContactMethods();
  const displayPhoneNumber = listing?.contact || listing?.phone || listing?.userRef?.contact || listing?.userRef?.phone || '';
  const formattedDisplayNumber = formatPhoneNumber(displayPhoneNumber);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200 dark:border-gray-800">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Contact Host</h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Get in touch with the property owner</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
              <FaTimes className="text-gray-500 dark:text-gray-400 text-lg" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto max-h-[calc(90vh-180px)]">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Your Name</label>
            <input type="text" value={user?.name || ''} readOnly={!!user?.name}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-black" />
          </div>

          <div>
            <label className="block text-sm font-black text-gray-400 uppercase tracking-widest mb-3">Choice of Connection</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button onClick={() => setContactMethod('internal')}
                  className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all duration-300 ${contactMethod === 'internal' ? 'border-rose-500 bg-rose-50/50 shadow-lg shadow-rose-100 scale-[1.02]' : 'border-gray-100 dark:border-gray-800 hover:border-gray-200 dark:hover:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
                  <div className={`p-2 rounded-xl ${contactMethod === 'internal' ? 'bg-rose-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}>
                    <FaRegCommentDots className="text-xl" />
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-tight ${contactMethod === 'internal' ? 'text-rose-600' : 'text-gray-500 dark:text-gray-400'}`}>Direct</span>
                </button>

              {availableMethods.includes('whatsapp') && (
                <button onClick={() => setContactMethod('whatsapp')}
                  className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all duration-300 ${contactMethod === 'whatsapp' ? 'border-emerald-500 bg-emerald-50/50 shadow-lg shadow-emerald-100 scale-[1.02]' : 'border-gray-100 dark:border-gray-800 hover:border-gray-200 dark:hover:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
                  <div className={`p-2 rounded-xl ${contactMethod === 'whatsapp' ? 'bg-emerald-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}>
                    <FaWhatsapp className="text-xl" />
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-tight ${contactMethod === 'whatsapp' ? 'text-emerald-600' : 'text-gray-500 dark:text-gray-400'}`}>WhatsApp</span>
                </button>
              )}

              {availableMethods.includes('email') && (
                <button onClick={() => setContactMethod('email')}
                  className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all duration-300 ${contactMethod === 'email' ? 'border-blue-500 bg-blue-50/50 shadow-lg shadow-blue-100 scale-[1.02]' : 'border-gray-100 dark:border-gray-800 hover:border-gray-200 dark:hover:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
                  <div className={`p-2 rounded-xl ${contactMethod === 'email' ? 'bg-blue-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}>
                    <FaEnvelope className="text-xl" />
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-tight ${contactMethod === 'email' ? 'text-blue-600' : 'text-gray-500 dark:text-gray-400'}`}>Email</span>
                </button>
              )}

              {availableMethods.includes('call') && (
                <button onClick={() => setContactMethod('call')}
                  className={`p-4 rounded-2xl border-2 flex flex-col items-center justify-center gap-2 transition-all duration-300 ${contactMethod === 'call' ? 'border-orange-500 bg-orange-50/50 shadow-lg shadow-orange-100 scale-[1.02]' : 'border-gray-100 dark:border-gray-800 hover:border-gray-200 dark:hover:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
                  <div className={`p-2 rounded-xl ${contactMethod === 'call' ? 'bg-orange-500 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}>
                    <FaPhone className="text-xl" />
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-tight ${contactMethod === 'call' ? 'text-orange-600' : 'text-gray-500 dark:text-gray-400'}`}>Call Host</span>
                </button>
              )}
            </div>

            <div className="mt-6 p-5 bg-slate-50/50 border border-slate-200/50 rounded-3xl">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Proprietor Credentials</p>
              <div className="space-y-2">
                {formattedDisplayNumber && (
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white dark:bg-gray-800 flex items-center justify-center text-rose-500 shadow-sm border border-slate-200/50 dark:border-gray-700">
                         <PhoneIcon className="w-4 h-4" />
                      </div>
                      <p className="text-sm font-bold text-gray-900 dark:text-white">{formattedDisplayNumber}</p>
                   </div>
                )}
                {listing?.email && (
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white dark:bg-gray-800 flex items-center justify-center text-blue-500 shadow-sm border border-slate-200/50 dark:border-gray-700">
                         <EnvelopeIcon className="w-4 h-4" />
                      </div>
                      <p className="text-sm font-bold text-gray-900 dark:text-white">{listing.email}</p>
                   </div>
                )}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Your Message</label>
            <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder={defaultMessage} rows="4"
              className="w-full px-4 py-3 border border-gray-200 dark:border-gray-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-black resize-none" />
          </div>
        </div>

        <div className="p-6 border-t border-gray-100 dark:border-gray-800">
          <div className="flex gap-3">
            <button onClick={onClose} className="flex-1 px-4 py-3 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 text-gray-700 dark:text-gray-300 rounded-lg font-medium transition-colors">Cancel</button>
            <button onClick={handleSubmit} disabled={availableMethods.length === 0}
              className="flex-1 px-4 py-3 bg-rose-500 hover:bg-rose-600 text-white rounded-lg font-medium transition-all">Send Message</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Full Screen Gallery Component
const FullScreenGallery = ({ images, currentIndex, isOpen, onClose, onPrev, onNext, onIndexChange }) => {
  if (!isOpen) return null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="fixed inset-0 z-[9999] flex h-[100dvh] min-h-0 flex-col overflow-hidden bg-black">
      {/* Header */}
      <div className="flex shrink-0 items-center justify-between gap-2 px-3 py-2.5 pt-[max(env(safe-area-inset-top),0.5rem)] text-white sm:p-4">
        <button onClick={onClose} aria-label="Close photo viewer" className="shrink-0 rounded-full p-2 transition-colors hover:bg-white/10">
          <MdClose className="text-2xl" />
        </button>
        <span className="min-w-0 truncate text-sm font-medium">{currentIndex + 1} / {images.length}</span>
        <div className="flex shrink-0 gap-1 sm:gap-2">
          <button aria-label="Share photo" className="rounded-full p-2 transition-colors hover:bg-white/10">
            <FiShare2 className="text-xl" />
          </button>
          <button aria-label="Add photo to wishlist" className="rounded-full p-2 transition-colors hover:bg-white/10">
            <FiHeart className="text-xl" />
          </button>
        </div>
      </div>

      {/* Main Image */}
      <div className="relative flex min-h-0 min-w-0 flex-1 items-center justify-center px-11 sm:px-16">
        <button onClick={onPrev} aria-label="Previous photo" className="absolute left-2 z-20 rounded-full bg-white/10 p-2 text-white transition-colors hover:bg-white/20 sm:left-4 sm:p-3">
          <FaChevronLeft className="text-base sm:text-xl" />
        </button>

        <ImageWithFallback
          src={images[currentIndex]}
          imageUrls={images.slice(currentIndex)}
          alt={`Photo ${currentIndex + 1}`}
          type="property"
          className="h-full w-full min-w-0 max-w-full"
          imageClassName="object-contain"
        />

        <button onClick={onNext} aria-label="Next photo" className="absolute right-2 z-20 rounded-full bg-white/10 p-2 text-white transition-colors hover:bg-white/20 sm:right-4 sm:p-3">
          <FaChevronRight className="text-base sm:text-xl" />
        </button>
      </div>

      {/* Thumbnails */}
      <div className="shrink-0 bg-black/50 px-3 py-3 pb-[max(env(safe-area-inset-bottom),0.75rem)] sm:p-4">
        <Swiper modules={[FreeMode]} spaceBetween={8} slidesPerView="auto" freeMode={true} className="thumbs-swiper">
          {images.map((img, index) => (
            <SwiperSlide key={index} style={{ width: '100px' }}>
              <button onClick={() => onIndexChange(index)}
                className={`block w-full h-16 rounded-lg overflow-hidden ${index === currentIndex ? 'ring-2 ring-white' : 'opacity-50 hover:opacity-100'}`}>
                <ImageWithFallback
                  src={img}
                  alt={`Thumbnail ${index + 1}`}
                  type="property"
                  className="w-full h-full object-cover"
                />
              </button>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </motion.div>
  );
};

// Airbnb Style Float-in Gallery Component
const AirbnbFloatGallery = ({
  images = [],
  isOpen,
  onClose,
  listingName = 'Listing',
  listingAddress = '',
  onImageClick,
  handleShare,
  toggleFavorite,
  isFavorite = false
}) => {
  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ y: "100%", opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: "100%", opacity: 0 }}
      transition={{ type: "spring", damping: 28, stiffness: 220, mass: 0.85 }}
      className="fixed inset-0 z-[1000] flex h-[100dvh] min-h-0 w-full flex-col overflow-x-hidden overflow-y-auto overscroll-contain bg-white text-slate-900"
    >
      {/* Sticky Header */}
      <header className="sticky top-0 z-40 flex shrink-0 items-center justify-between gap-2 border-b border-slate-200/80 bg-white/95 px-3 py-2.5 pt-[max(env(safe-area-inset-top),0.5rem)] backdrop-blur-md sm:px-8 sm:py-3.5">
        <div className="flex min-w-0 items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={onClose}
            aria-label="Back to listing"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-slate-700 transition-colors hover:bg-slate-100 sm:h-10 sm:w-10"
          >
            <ArrowLeftIcon className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="max-w-[34vw] truncate text-sm font-semibold text-slate-900 sm:max-w-md sm:text-base">
              {listingName}
            </h2>
            <p className="truncate text-[11px] font-medium text-slate-500 sm:text-xs">
              Photo tour · {images.length} {images.length === 1 ? 'photo' : 'photos'}
            </p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1 sm:gap-2">
          {handleShare && (
            <button
              type="button"
              onClick={handleShare}
              aria-label="Share listing"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-700 transition-colors hover:bg-slate-100 sm:h-10 sm:w-10"
            >
              <ShareIcon className="w-4 h-4" />
            </button>
          )}
          {toggleFavorite && (
            <button
              type="button"
              onClick={toggleFavorite}
              aria-label={isFavorite ? "Remove from wishlist" : "Add to wishlist"}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 transition-colors hover:bg-slate-100 sm:h-10 sm:w-10"
            >
              {isFavorite ? (
                <HeartIconSolid className="w-5 h-5 text-rose-500" />
              ) : (
                <HeartIcon className="w-5 h-5 text-slate-700" />
              )}
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close photo tour"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-700 transition-colors hover:bg-slate-100 sm:h-10 sm:w-10"
          >
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Gallery Content */}
      <div className="mx-auto w-full min-w-0 max-w-5xl flex-1 space-y-5 px-4 py-5 sm:space-y-6 sm:px-6 sm:py-8 lg:px-8">
        {/* Intro */}
        <div className="border-b border-slate-100 pb-5">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-600 mb-2">
            Property Photo Tour
          </span>
          <h1 className="break-words text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            {listingName}
          </h1>
          {listingAddress && (
            <p className="mt-1 flex min-w-0 items-start gap-1.5 break-words text-sm text-slate-500">
              <MapPinIcon className="w-4 h-4 text-slate-400 shrink-0" />
              <span className="min-w-0 break-words">{listingAddress}</span>
            </p>
          )}
        </div>

        {/* Photos Layout - Airbnb Style */}
        <div className="space-y-4">
          {/* Main Hero Photo */}
          {images.length > 0 && (
            <div
              onClick={() => onImageClick?.(0)}
              className="group relative aspect-[4/3] w-full overflow-hidden rounded-2xl bg-slate-100 shadow-sm transition-all duration-300 hover:shadow-md sm:aspect-[16/9]"
            >
              <ImageWithFallback
                src={images[0]}
                imageUrls={images}
                alt={`${listingName} photo 1`}
                type="property"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
              <div className="absolute bottom-4 left-4 rounded-lg bg-black/60 backdrop-blur-sm px-3 py-1 text-xs font-medium text-white">
                1 / {images.length}
              </div>
            </div>
          )}

          {/* Subsequent Photos in dynamic Airbnb Grid */}
          {images.length > 1 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {images.slice(1).map((img, sliceIdx) => {
                const actualIdx = sliceIdx + 1;
                const isWide = actualIdx % 5 === 0;

                return (
                  <div
                    key={`photo-${actualIdx}`}
                    onClick={() => onImageClick?.(actualIdx)}
                    className={`group relative rounded-2xl overflow-hidden bg-slate-100 cursor-pointer shadow-sm hover:shadow-md transition-all duration-300 ${
                      isWide ? 'sm:col-span-2 aspect-[16/9]' : 'aspect-[4/3]'
                    }`}
                  >
                    <ImageWithFallback
                      src={img}
                      imageUrls={images.slice(actualIdx)}
                      alt={`${listingName} photo ${actualIdx + 1}`}
                      type="property"
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
                    <div className="absolute bottom-3 left-3 rounded-md bg-black/60 backdrop-blur-sm px-2.5 py-1 text-[11px] font-medium text-white">
                      {actualIdx + 1} / {images.length}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="pt-10 pb-8 text-center border-t border-slate-100">
          <p className="text-sm font-medium text-slate-500 mb-4">
            You&apos;ve viewed all {images.length} photos of {listingName}
          </p>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-all active:scale-95 shadow-sm"
          >
            <ArrowLeftIcon className="w-4 h-4" />
            Back to listing
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default function Listing() {
  const { listingId } = useParams();
  const location = useLocation();
  const { currentUser } = useSelector((state) => state.user);
  const navigate = useNavigate();
  const [showCommentsPanel, setShowCommentsPanel] = useState(false);
  const [commentCount, setCommentCount] = useState(0);
  const [ratings, setRatings] = useState({ cleanliness: 0, accuracy: 0, overall: 0, hospitality: 0, comfort: 0, location: 0, host: 0 });
  const [topComments, setTopComments] = useState([]);
  const [numberOfGuests, setNumberOfGuests] = useState(2);
  const [extraBed, setExtraBed] = useState('no');

  // Modal states
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedUnit, setSelectedUnit] = useState('');
  const [showContactModal, setShowContactModal] = useState(false);
  const [showFullGallery, setShowFullGallery] = useState(false);
  const [showFloatGallery, setShowFloatGallery] = useState(false);
  const [galleryIndex, setGalleryIndex] = useState(0);
  const [roomsDrawerOpen, setRoomsDrawerOpen] = useState(false);

  // State declarations
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [isScrolled, setIsScrolled] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestContact, setGuestContact] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [listing, setListing] = useState(null);
  const [failedHostAvatar, setFailedHostAvatar] = useState('');
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [similarListings, setSimilarListings] = useState([]);
  const [bookedDates, setBookedDates] = useState([]);
  const [bookingSummary, setBookingSummary] = useState({ count: 0, recentBookers: [] });

  const RECENTLY_VIEWED_KEY = 'recentlyViewed';

  useEffect(() => {
    if (listing) {
      fetchSimilarListings();
      fetchBookingSummary();
      saveToHistory(listing);
    }
  }, [listing, currentUser?._id]);

  const fetchBookingSummary = async () => {
    if (!currentUser) {
      setBookingSummary({ count: 0, recentBookers: [] });
      return;
    }
    try {
      const res = await fetch(`/api/bookings/listing-summary/${listing._id}`, { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        setBookingSummary(data);
      }
    } catch (error) {
      console.error('Error fetching booking summary:', error);
    }
  };

  const fetchSimilarListings = async () => {
    try {
      const res = await fetch(`/api/listing/similar/${listingId}`);
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setSimilarListings(data);
    } catch (error) {
      console.error('Error fetching similar listings:', error);
    }
  };

  const saveToHistory = (item) => {
    try {
      const stored = localStorage.getItem(RECENTLY_VIEWED_KEY);
      let history = stored ? JSON.parse(stored) : [];
      history = history.filter(h => h._id !== item._id);
      history.unshift({
        ...item,
        itemType: 'listing',
        viewedAt: new Date().toISOString()
      });
      localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(history.slice(0, 20)));
    } catch (error) {
      console.error('Error saving history:', error);
    }
  };

  const [mealPlan, setMealPlan] = useState('none');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('17:00');
  const [isExpanded, setIsExpanded] = useState(false);
  const [isNearExpanded, setIsNearExpanded] = useState(false);
  const [dateRange, setDateRange] = useState([null, null]);

  const [uiState, setUiState] = useState({
    loading: true,
    error: false,
    submitting: false,
    showAllReviews: false,
    newReviewsAvailable: false
  });

  const [contactForm, setContactForm] = useState({
    name: "",
    phone: "",
    message: "",
    phoneError: false
  });

  const [fullscreenImage, setFullscreenImage] = useState({
    open: false,
    index: 0
  });

  const [hostRatings, setHostRatings] = useState({
    average: 0,
    totalRatings: 0,
    categoryRatings: {},
    userRating: null,
  });

  const { isFavorite, toggleFavorite } = useWishlist(listing, 'listing');

  const [hostData, setHostData] = useState({
    likeCount: 124,
    dislikeCount: 3,
    userAction: null,
  });
  const [ratingLoading, setRatingLoading] = useState(false);


  const [socialMediaVerified, setSocialMediaVerified] = useState({
    facebook: true,
    instagram: true,
    twitter: true,
    linkedin: false,
    tiktok: false,
    website: true,
    loading: false
  });

  const [isFacebookPosted, setIsFacebookPosted] = useState(true);
  const [hostSocialLinks, setHostSocialLinks] = useState({
    facebook: 'https://facebook.com/johnproperty',
    instagram: 'https://instagram.com/johnproperty',
    twitter: 'https://twitter.com/johnproperty',
    website: 'https://johnproperty.com'
  });

  const breakfastPrice = 250;

  const days = dateRange[0] && dateRange[1]
    ? Math.max(1, Math.round((Date.UTC(dateRange[1].getFullYear(), dateRange[1].getMonth(), dateRange[1].getDate()) - Date.UTC(dateRange[0].getFullYear(), dateRange[0].getMonth(), dateRange[0].getDate())) / 86400000))
    : 0;

  const calculateTotalHours = (start, end) => {
    const [startHour, startMinute] = start.split(':').map(Number);
    const [endHour, endMinute] = end.split(':').map(Number);
    const startInMinutes = startHour * 60 + startMinute;
    const endInMinutes = endHour * 60 + endMinute;
    if (endInMinutes <= startInMinutes) return 0;
    return (endInMinutes - startInMinutes) / 60;
  };

  const totalHours = calculateTotalHours(startTime, endTime);
  const isHourlyType = getPropertyRatePeriod(listing) === 'hour';
  const totalPrice = isHourlyType
    ? (listing.regularPrice * totalHours).toFixed(2)
    : 0;

  const truncateDescription = (text, wordLimit = 50) => {
    if (!text) return '';
    const words = text.split(' ');
    if (words.length <= wordLimit) return text;
    return words.slice(0, wordLimit).join(' ') + '...';
  };

  const validatePhone = (phone) => /^0\d{9}$/.test(phone);
  const generateTimeOptions = (isEnd = false) => {
    const times = [];
    for (let hour = 0; hour < 24; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        
        const isBooked = bookedDates.some(range => {
          const start = new Date(range.start);
          const end = new Date(range.end);
          if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return false;
          const currentCheck = new Date(selectedDate);
          currentCheck.setHours(hour, minute, 0, 0);
          return currentCheck >= start && currentCheck < end; 
        });

        if (!isBooked) times.push(timeString);
      }
    }
    return times;
  };

  // toggleFavorite is handled by useWishlist

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: listing.name,
        text: `Check out ${listing.name} on loopOut`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const formatPhoneNumberSafe = (phone) => {
    if (!phone) return '';
    const phoneStr = String(phone).trim();
    const digits = phoneStr.replace(/\D/g, '');
    if (digits.length === 0) return '';
    if (digits.startsWith('27') && digits.length === 11) return '0' + digits.substring(2);
    if (digits.length === 10 && digits.startsWith('0')) return digits;
    if (digits.length === 9) return '0' + digits;
    if (digits.length > 10) {
      const last10Digits = digits.substring(digits.length - 10);
      return last10Digits.startsWith('0') ? last10Digits : '0' + last10Digits.substring(1);
    }
    if (!digits.startsWith('0') && digits.length >= 9) return '0' + digits;
    return digits;
  };

  const formatPhoneNumberForWhatsApp = (phone) => {
    const formatted = formatPhoneNumberSafe(phone);
    if (!formatted) return '';
    if (formatted.startsWith('0') && formatted.length === 10) return '27' + formatted.substring(1);
    return formatted;
  };

  
  const handleEscrowCheckout = async () => {
    if (!currentUser) {
      window.location.href = '/sign-in';
      return;
    }

    const isDailyStayType = getPropertyRatePeriod(listing) === 'day';
    if (isDailyStayType && dateRange && dateRange[0] && dateRange[1]) {
      const hasOverlap = hasBookedNightOverlap(dateRange[0], dateRange[1], bookedDates);
      if (hasOverlap) {
        alert('The selected reservation dates are already booked or occupied. Please select available dates on the calendar.');
        return;
      }
    }

    try {
      setIsContacting(true);
      const res = await fetch('/api/payment/escrow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
           userId: currentUser._id,
           amount: listing.regularPrice, // Simple price for now
           name: currentUser.username,
           email: currentUser.email,
           serviceId: listing._id,
           providerName: listing.name
        })
      });
      const data = await res.json();
      if (data.success && data.payfast) {
         const form = document.createElement('form');
         form.method = 'POST';
         form.action = data.payfast.url;
         Object.keys(data.payfast.fields).forEach(key => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = data.payfast.fields[key];
            form.appendChild(input);
         });
         document.body.appendChild(form);
         form.submit();
      } else {
         console.error(data.message);
         setIsContacting(false);
      }
    } catch(err) {
      console.error(err);
      setIsContacting(false);
    }
  };

  const handleContactHost = () => {
    const contactNumber = listing?.contact || listing?.phone || listing?.userRef?.contact || listing?.userRef?.phone || '';
    const emailAddress = listing?.email || listing?.userRef?.email;

    if (!contactNumber && !emailAddress) {
      alert('No contact information available for this host');
      return;
    }

    const userName = currentUser?.name || 'Interested Client';
    const listingName = listing.name || 'Listing detail';
    const message = `Hello, I'm ${userName}. I'm interested in your "${listingName}" listing. Could you please provide more details?`;

    if (contactNumber) {
      const whatsappNumber = formatPhoneNumberForWhatsApp(contactNumber);
      if (whatsappNumber && whatsappNumber.length >= 10) {
        const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
        return;
      }
    }

    if (emailAddress) {
      const subject = `Interest in "${listingName}"`;
      window.location.href = `mailto:${emailAddress}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
    }
  };

  const handleQuickBooking = () => {
    setShowBookingModal(true);
  };

  const handleRateHostLikeDislike = async (action) => {
    if (!currentUser) {
      navigate('/sign-in');
      return;
    }
    if (!listing?.userRef) return;
    const hostId = typeof listing.userRef === 'string' ? listing.userRef : listing.userRef._id;
    if (!hostId) return;

    setRatingLoading(true);
    try {
      const token = currentUser?.token || currentUser?.access_token || '';
      const response = await fetch(`/api/user/rate-host/${hostId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action })
      });

      if (response.ok) {
        const data = await response.json();
        setHostData({
          likeCount: data.likeCount,
          dislikeCount: data.dislikeCount,
          userAction: data.userAction
        });
      }
    } catch (error) {
      console.error('Rating error:', error);
    } finally {
      setRatingLoading(false);
    }
  };

  const getActiveAmenities = () => {
    if (!listing) return [];
    return Object.entries(AMENITY_CONFIGS)
      .filter(([key, config]) => listing[config.field] === true)
      .map(([key, config]) => config);
  };

  const hostStarRating = Math.min(5, Math.floor(hostData.likeCount / 40));

  const verifySocialMedia = async (hostData) => {
    if (!hostData) return;
    setSocialMediaVerified(prev => ({ ...prev, loading: true }));

    setTimeout(() => {
      setSocialMediaVerified({
        facebook: Math.random() > 0.3,
        instagram: Math.random() > 0.4,
        twitter: Math.random() > 0.5,
        linkedin: Math.random() > 0.6,
        tiktok: Math.random() > 0.7,
        website: Math.random() > 0.4,
        loading: false
      });
    }, 1500);
  };

  const checkFacebookListing = async () => {
    return Math.random() > 0.5;
  };

  const handleSocialMediaClick = (platform) => {
    if (hostSocialLinks[platform]) {
      window.open(hostSocialLinks[platform], '_blank');
    } else if (socialMediaVerified[platform]) {
      const hostUsername = listing.userRef?.username || '';
      if (hostUsername) {
        window.open(`${SOCIAL_PLATFORMS.find(p => p.name === platform)?.baseUrl}${hostUsername}`, '_blank');
      }
    }
  };

  const isValidListingId = (id) => {
    if (!id || id === "undefined" || id === "null" || id.trim() === "") return false;
    return /^[a-zA-Z0-9]{20,}$/.test(id);
  };

  const getRelativeTime = (dateString) => {
    const diffInMs = new Date() - new Date(dateString);
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    if (diffInDays < 1) return 'Today';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    const diffInWeeks = Math.floor(diffInDays / 7);
    if (diffInWeeks < 4) return `${diffInWeeks} week${diffInWeeks > 1 ? 's' : ''} ago`;
    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths < 12) return `${diffInMonths} month${diffInMonths > 1 ? 's' : ''} ago`;
    const diffInYears = Math.floor(diffInDays / 365);
    return `${diffInYears} year${diffInYears > 1 ? 's' : ''} ago`;
  };

  // Effects
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (showFloatGallery || showFullGallery) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [showFloatGallery, showFullGallery]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        if (showFullGallery) {
          setShowFullGallery(false);
        } else if (showFloatGallery) {
          setShowFloatGallery(false);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showFullGallery, showFloatGallery]);

  useEffect(() => {
    if (typeof process !== 'undefined' && process.env.REACT_APP_EMAILJS_PUBLIC_KEY) {
      emailjs.init(process.env.REACT_APP_EMAILJS_PUBLIC_KEY);
    }
  }, []);

  useEffect(() => {
    const fetchListing = async () => {
      if (!isValidListingId(listingId)) {
        setUiState(prev => ({ ...prev, loading: false, error: true }));
        return;
      }

      try {
        setUiState({ loading: true, error: false, submitting: false, showAllReviews: false, newReviewsAvailable: false });

        const response = await fetch(`/api/listing/get/${listingId}`, {
          headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) throw new Error('Failed to fetch');

        const listingData = await response.json();

        if (!listingData._id || !listingData.name) {
          throw new Error('Invalid listing data');
        }

        listingData.imageUrls = Array.isArray(listingData.imageUrls)
          ? listingData.imageUrls.filter((url) => typeof url === 'string' && url.trim())
          : [];

        setListing(listingData);
        setUiState(prev => ({ ...prev, loading: false, error: false }));
      } catch (err) {
        console.error("Fetch error:", err);
        setUiState(prev => ({ ...prev, loading: false, error: true }));
      }
    };

    const fetchBookedDates = async () => {
      try {
        const res = await fetch(`/api/bookings/booked-dates/${listingId}`);
        if (res.ok) {
          const data = await res.json();
          setBookedDates(data);
        }
      } catch (error) {
        console.error('Error fetching booked dates:', error);
      }
    };

    if (listingId) {
      fetchListing();
      fetchBookedDates();
    }
  }, [listingId, navigate]);

  const getOperatingStatus = () => {
    if (!listing?.operatingHours) return { isClosed: false };
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const now = new Date();
    const currentDay = days[now.getDay()];
    const schedule = listing.operatingHours[currentDay];

    if (!schedule || schedule.closed) return { isClosed: true, reason: 'Closed today' };

    const currentTime = now.getHours() * 60 + now.getMinutes();
    const [openH, openM] = (schedule.open || '08:00').split(':').map(Number);
    const [closeH, closeM] = (schedule.close || '19:00').split(':').map(Number);
    const openTime = openH * 60 + openM;
    const closeTime = closeH * 60 + closeM;

    if (currentTime < openTime) return { isClosed: true, reason: `Opens at ${schedule.open}` };
    if (currentTime >= closeTime) return { isClosed: true, reason: `Closed at ${schedule.close}` };

    return { isClosed: false };
  };

  const operatingStatus = getOperatingStatus();

  useEffect(() => {
    if (listing) {
      verifySocialMedia(listing.userRef);
      checkFacebookListing().then(setIsFacebookPosted);
    }
  }, [listing]);

  // Fetch comment count, ratings and top comments
  useEffect(() => {
    const fetchCommentData = async () => {
      if (!listingId || !isValidListingId(listingId)) {
        setCommentCount(0);
        return;
      }
      try {
        const response = await fetch(`/api/comments/${listingId}?limit=6`);
        if (response.ok) {
          const data = await response.json();
          setCommentCount(data.totalComments || 0);
          setTopComments(data.comments || []);
          if (data.ratings) {
            setRatings({
              cleanliness: data.ratings.cleanliness || 0,
              accuracy: data.ratings.staff || data.ratings.accuracy || 0,
              overall: data.ratings.overall || 0,
              hospitality: data.ratings.hospitality || 0,
              comfort: data.ratings.comfort || 0,
              location: data.ratings.location || 0,
              host: data.ratings.host || 0,
            });
          }
        } else setCommentCount(0);
      } catch (error) {
        console.error('Error fetching comment data:', error);
        setCommentCount(0);
      }
    };
    if (listingId) fetchCommentData();
  }, [listingId]);

  useEffect(() => {
    const fetchHostRatings = async () => {
      const hostId = typeof listing?.userRef === 'string' ? listing.userRef : listing?.userRef?._id;
      if (!hostId || !listingId) return;
      try {
        const query = new URLSearchParams({ listingId });
        const headers = currentUser?.token ? { Authorization: `Bearer ${currentUser.token}` } : {};
        const response = await fetch(`/api/user/host-ratings/${hostId}?${query}`, { headers });
        if (!response.ok) return;
        const result = await response.json();
        if (result?.success && result.data) setHostRatings(result.data);
      } catch (error) {
        console.error('Error fetching listing host ratings:', error);
      }
    };
    fetchHostRatings();
  }, [listing?.userRef, listingId, currentUser?.token]);

  // Loading and error states
  if (uiState.loading) {
    return <NeuralLoader fullScreen text="Initializing Property Matrix..." />;
  }

  if (uiState.error || !listing) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Listing not found</h2>
          <button onClick={() => navigate('/listing-home-page')} className="mt-4 px-6 py-2 bg-rose-500 text-white rounded-lg">
            Browse Listings
          </button>
        </div>
      </div>
    );
  }

  const listingType = LISTING_TYPES[listing.type] || LISTING_TYPES.over;
  const pricePeriod = getPropertyRatePeriod(listing);
  const activeAmenities = getActiveAmenities();
  const displayContactNumber = listing?.contact || listing?.phone || '';
  const formattedDisplayNumber = formatPhoneNumberSafe(displayContactNumber);
  const displayEmail = listing?.email || listing?.userRef?.email || '';
  const hostAvatarSrc = resolveApiUrl(listing?.userRef?.avatar || '');

  // Determine property type for UI
  const isDailyStay = pricePeriod === 'day' || pricePeriod === 'night';
  const isHourlyRoom = pricePeriod === 'hour';
  const isRent = pricePeriod === 'month';
  const showCalendar = isDailyStay || isHourlyRoom;
  const isSaleOrRent = isRent;

  // Calculate prices
  const roomTotal = listing.regularPrice * (days || 1);
  const breakfastTotal = mealPlan === 'breakfast' ? breakfastPrice * (days || 1) : 0;
  const grandTotal = roomTotal + breakfastTotal;
  const hasListingImages = listing.imageUrls.length > 0;
  const hasReviews = commentCount > 0 && ratings?.overall > 0;
  const listingRatingScores = {
    hospitality: ratings.hospitality || hostRatings.categoryRatings?.staff || 0,
    comfort: ratings.comfort || 0,
    location: ratings.location || hostRatings.categoryRatings?.location_rating || 0,
    host: ratings.host || hostRatings.average || 0,
    cleanliness: ratings.cleanliness || hostRatings.categoryRatings?.host_cleanliness || 0,
  };
  const isGuestFavourite = hasReviews && ratings.overall >= 4.8 && commentCount >= 5;
  // Google/email account verification and Superhost status do not prove identity.
  const isIdentityVerifiedHost = listing.userRef?.kycStatus === 'verified';
  const hasOfferPrice = !isRent && listing.offer && Number(listing.discountPrice) > 0 && Number(listing.discountPrice) < Number(listing.regularPrice);
  const displayedPrice = hasOfferPrice ? Number(listing.discountPrice) : Number(listing.regularPrice);
  const listingHighlights = [
    listing.pool && {
      icon: FaSwimmingPool,
      title: 'Enjoy the pool',
      detail: 'A pool is available at this property.',
    },
    (listing.parking || (Number(listing.garages) > 0) || (Number(listing.parkingSpaces) > 0)) && {
      icon: FaParking,
      title: 'Park for free',
      detail: 'Free parking is available at this property.',
    },
    isIdentityVerifiedHost && {
      icon: MdOutlineGppGood,
      title: 'Identity checked',
      detail: 'LoopOut has completed an identity review for this host.',
    },
  ].filter(Boolean);
  const cancellationSummary = !isSaleOrRent
    ? 'Cancel up to 48 hours before the scheduled start or check-in'
    : null;
  return (
    <div className="min-h-screen overflow-x-hidden p-0 app-safe-content-bottom pb-36 lg:pb-0 bg-white text-slate-900">
      {/* Navigation Header - Transparent on top of image */}
      <nav className={`app-safe-top fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 dark:bg-gray-900/95 backdrop-blur-md shadow-sm border-b border-slate-200/50 dark:border-gray-800' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <button 
              onClick={() => navigate(-1)} 
              aria-label="Go back"
              className={`flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 ${isScrolled ? 'border-slate-200 bg-white dark:bg-gray-800 text-slate-900 dark:text-white shadow-sm' : 'border-white/50 bg-black/30 text-white shadow-lg backdrop-blur-md hover:bg-black/50'}`}
            >
              <ArrowLeftIcon className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <button 
                onClick={handleShare} 
                aria-label="Share listing"
                className={`flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 ${isScrolled ? 'border-slate-200 bg-white dark:bg-gray-800 text-slate-900 dark:text-white shadow-sm' : 'border-white/50 bg-black/30 text-white shadow-lg backdrop-blur-md hover:bg-black/50'}`}
              >
                <ShareIcon className="w-5 h-5" />
              </button>
              <button 
                onClick={toggleFavorite} 
                aria-label={isFavorite ? "Remove from wishlist" : "Add to wishlist"}
                className={`flex h-11 w-11 items-center justify-center rounded-full border transition-all duration-300 ${isScrolled ? 'border-slate-200 bg-white dark:bg-gray-800 text-slate-900 dark:text-white shadow-sm' : 'border-white/50 bg-black/30 text-white shadow-lg backdrop-blur-md hover:bg-black/50'}`}
              >
                {isFavorite ? <HeartIconSolid className="w-5 h-5 text-rose-500" /> : <HeartIcon className={`w-5 h-5 ${isScrolled ? 'text-slate-900 dark:text-white' : 'text-white'}`} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Image Gallery - Full Width covering left, right, and top (Helper & Services standard) */}
      <div className="relative h-[45svh] sm:h-[45svh] md:h-[440px] lg:h-[520px] w-full bg-slate-100 overflow-hidden">
        {!hasListingImages ? (
          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-slate-800 to-slate-950 px-6 text-center text-white">
            <PhotoIcon className="h-12 w-12 text-white/50" aria-hidden="true" />
            <p className="mt-3 text-base font-semibold">Photos coming soon</p>
            <p className="mt-1 text-sm text-white/65">The host has not added photos for this listing yet.</p>
          </div>
        ) : (
          <>
            {/* Mobile Swiper (hidden on md and up) */}
            <div className="block md:hidden h-full w-full">
              <Swiper
                modules={[Pagination]}
                pagination={{ clickable: true, bulletActiveClass: 'swiper-pagination-bullet-active !bg-rose-500' }}
                className="h-full w-full"
              >
                {listing.imageUrls.map((url, index) => (
                  <SwiperSlide key={index}>
                    <div 
                      onClick={() => setShowFloatGallery(true)}
                      className="w-full h-full cursor-pointer relative"
                    >
                      <ImageWithFallback
                        src={url}
                        imageUrls={listing.imageUrls}
                        alt={`${listing.name} ${index + 1}`}
                        type="property"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
                    </div>
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>

            {/* Desktop Grid (hidden on mobile) */}
            <div className="hidden h-full w-full grid-cols-4 grid-rows-2 gap-1.5 md:grid">
              {/* Main Image - Takes left half (2 cols, 2 rows) */}
              <div
                className="col-span-2 row-span-2 relative overflow-hidden cursor-pointer group"
                onClick={() => setShowFloatGallery(true)}
              >
                <ImageWithFallback
                  src={listing.imageUrls[0]}
                  imageUrls={listing.imageUrls}
                  alt={listing.name}
                  type="property"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-500" />
              </div>

              {/* Side Images - 2x2 grid on right */}
              {listing.imageUrls.slice(1, 5).map((url, index) => (
                <div
                  key={index}
                  className="relative overflow-hidden cursor-pointer group"
                  onClick={() => setShowFloatGallery(true)}
                >
                  <ImageWithFallback
                    src={url}
                    imageUrls={listing.imageUrls.slice(index + 1)}
                    alt={`${listing.name} ${index + 2}`}
                    type="property"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/15 transition-colors duration-500" />
                </div>
              ))}
              {Array.from({ length: Math.max(0, 4 - Math.min(4, listing.imageUrls.length - 1)) }).map((_, index) => (
                <div key={`listing-gallery-placeholder-${index}`} className="bg-slate-200" aria-hidden="true" />
              ))}
            </div>

            {/* Photo count button - Clean number without background, no word "photos" */}
            <button
              type="button"
              onClick={() => setShowFloatGallery(true)}
              aria-label={`Open photo gallery with ${listing.imageUrls.length} photos`}
              className="absolute bottom-6 right-5 sm:bottom-8 sm:right-8 z-20 font-bold text-white text-lg sm:text-2xl tracking-tight drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)] hover:scale-110 active:scale-95 transition-all duration-200 cursor-pointer focus:outline-none"
            >
              {listing.imageUrls.length}
            </button>
          </>
        )}
      </div>

      {/* Airbnb Style Float-In Gallery Page */}
      <AnimatePresence>
        {showFloatGallery && hasListingImages && (
          <AirbnbFloatGallery
            images={listing.imageUrls}
            isOpen={showFloatGallery}
            onClose={() => setShowFloatGallery(false)}
            listingName={listing.name}
            listingAddress={listing.address}
            onImageClick={(index) => {
              setGalleryIndex(index);
              setShowFullGallery(true);
            }}
            handleShare={handleShare}
            toggleFavorite={toggleFavorite}
            isFavorite={isFavorite}
          />
        )}
      </AnimatePresence>

      {/* Full Screen Gallery (Lightbox zoom) */}
      {hasListingImages && (
        <FullScreenGallery
          images={listing.imageUrls}
          currentIndex={galleryIndex}
          isOpen={showFullGallery}
          onClose={() => setShowFullGallery(false)}
          onPrev={() => setGalleryIndex(prev => prev === 0 ? listing.imageUrls.length - 1 : prev - 1)}
          onNext={() => setGalleryIndex(prev => prev === listing.imageUrls.length - 1 ? 0 : prev + 1)}
          onIndexChange={setGalleryIndex}
        />
      )}

      {/* Main Content - Overlapping sheet matching Helper and Services standard */}
      <ListingDetailShell>
        <section className="mx-auto mb-8 max-w-4xl border-b border-slate-200 px-1 pb-7 text-center" aria-labelledby="listing-title">
          <h1 id="listing-title" className="text-2xl font-semibold leading-tight tracking-tight text-slate-900 sm:text-3xl">{formatListingTitle(listing.name)}</h1>
          <p className="mt-2 text-sm text-slate-600 sm:text-base">
            {pricePeriod === 'night' ? (listing.kind ? `${listing.kind.replace(/_/g, ' ')} · Per night` : 'Per night') :
             pricePeriod === 'day' ? (listing.kind ? `${listing.kind.replace(/_/g, ' ')} · Per day` : 'Per day') :
             pricePeriod === 'hour' ? (listing.kind ? `${listing.kind.replace(/_/g, ' ')} · Per hour` : 'Per hour') :
             `${listingType.label}${listing.kind ? ` · ${listing.kind.replace(/_/g, ' ')}` : ''} · Per month`}
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-x-5 gap-y-3 text-sm text-slate-700">
            <span className="inline-flex items-center gap-1.5">
              <StarIconSolid className="h-4 w-4 text-amber-400" />
              {hasReviews ? <><strong className="font-semibold text-slate-900">{Number(ratings.overall).toFixed(1)}</strong><span className="underline">{commentCount} {commentCount === 1 ? 'review' : 'reviews'}</span></> : <span>New · {commentCount} reviews</span>}
            </span>
            <span className="inline-flex items-center gap-1.5"><TicketIcon className="h-4 w-4 text-slate-500" /><strong className="font-medium text-slate-900">{bookingSummary.count}</strong> {bookingSummary.count === 1 ? 'booking' : 'bookings'}</span>
            {cancellationSummary && <span className="inline-flex items-center gap-1.5 text-emerald-700"><CheckCircleIcon className="h-4 w-4" />{cancellationSummary}</span>}
            {listing.address && <span className="inline-flex items-center gap-1.5"><MapPinIcon className="h-4 w-4 shrink-0 text-slate-500" /><span>{listing.address}</span></span>}
          </div>
        </section>
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3 lg:gap-12">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8 lg:space-y-10">
            {/* Guest Favorite Badge — only backed by real reviews */}
            {isGuestFavourite && <div className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-r from-rose-50 to-orange-50 border border-rose-100">
              <div className="flex-shrink-0">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-rose-400 to-orange-400 flex items-center justify-center shadow-md">
                  <StarIconSolid className="w-7 h-7 text-white" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-0.5">Guest Favourite</p>
                <p className="text-sm font-semibold text-gray-900 dark:text-white leading-snug">One of the most loved homes, according to guests</p>
                <div className="flex items-center gap-1.5 mt-1">
                  {/* Stars — filled proportionally to the real rating */}
                  <div className="flex">
                    {[1,2,3,4,5].map(s => {
                      const guestRating = ratings.overall;
                      return (
                        <StarIconSolid
                          key={s}
                          className={`w-3 h-3 ${s <= Math.round(guestRating) ? 'text-rose-400' : 'text-gray-200'}`}
                        />
                      );
                    })}
                  </div>
                  {/* Rating number — same expression as reviews section */}
                  <span className="text-xs font-bold text-gray-900 dark:text-white">
                    {ratings.overall.toFixed(1)}
                  </span>
                  {/* Review count — same variable as reviews section */}
                  <span className="text-xs text-gray-500 dark:text-gray-400">· {commentCount} reviews</span>
                </div>
              </div>
            </div>}

            {/* Property Highlights */}
            <div className="border-y border-gray-200 dark:border-gray-800 py-6">
              <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-white">Property details</h2>
              <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                {[
                  { label: "Bedrooms", value: listing.bedrooms ?? 1, icon: <FaBed className="text-slate-500" /> },
                  { label: "Bathrooms", value: listing.bathrooms ?? 1, icon: <FaBath className="text-rose-400" /> },
                  { label: "Toilets", value: (listing.toilets !== undefined && listing.toilets !== null && listing.toilets !== "") ? listing.toilets : (listing.bathrooms ?? 1), icon: <span aria-hidden="true">🚽</span> },
                  { label: "Garages", value: (listing.garages !== undefined && listing.garages !== null && listing.garages !== "") ? listing.garages : 0, icon: <span aria-hidden="true">🚗</span> },
                  { label: "Parking spaces", value: (listing.parkingSpaces !== undefined && listing.parkingSpaces !== null && listing.parkingSpaces !== "") ? listing.parkingSpaces : (listing.parking ? 1 : 0), icon: <FaParking className="text-slate-500" /> },
                ].map((detail) => (
                  <div key={detail.label} className="min-w-0 rounded-xl bg-gray-50 px-3 py-3 dark:bg-gray-800 sm:px-4">
                    <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                      {detail.icon}<span>{detail.label}</span>
                    </div>
                    <p className="mt-1 text-sm font-semibold text-gray-900 dark:text-white">
                      {detail.value === null || detail.value === undefined || detail.value === "" ? "Not provided" : detail.value}
                    </p>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-3">
              {listing.numberOfApartments > 0 && (
                <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-2xl text-sm font-bold text-blue-700">
                  🏢 {listing.numberOfApartments} Apartment{listing.numberOfApartments > 1 ? "s" : ""} in complex
                </div>
              )}
              {listing.numberOfRooms > 1 && listing.numberOfRooms !== listing.bedrooms && (
                <div className="flex items-center gap-2 px-4 py-2 bg-purple-50 rounded-2xl text-sm font-bold text-purple-700">
                  🛌 {listing.numberOfRooms} Guest Rooms Available
                </div>
              )}
              {listing.kind && (
                <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-gray-800 rounded-2xl text-sm font-bold text-gray-700 dark:text-gray-300 capitalize">
                  <HomeModernIcon className="w-4 h-4 text-rose-400" /> {listing.kind.replace(/_/g, " ")}
                </div>
              )}
              {listing.period && (
                <div className="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-2xl text-sm font-bold text-green-700">
                  <CalendarDaysIcon className="w-4 h-4" /> Available {listing.period}
                </div>
              )}
            </div>
            </div>

            {/* Host Info */}
            <div className="py-6 border-b border-gray-200 dark:border-gray-800">
              <Link
                to={`/user-profile/${listing.userRef?._id || listing.userRef}`}
                className="flex items-center gap-4 hover:opacity-80 transition-opacity w-fit"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-full border border-gray-100 bg-gray-100 text-2xl shadow-sm dark:border-gray-800 dark:bg-gray-800 lg:h-14 lg:w-14">
                  {hostAvatarSrc && failedHostAvatar !== hostAvatarSrc ? (
                    <img
                      src={hostAvatarSrc}
                      alt={listing.userRef?.username ? `${listing.userRef.username}'s profile photo` : 'Host profile photo'}
                      className="h-full w-full rounded-full object-cover"
                      onError={() => setFailedHostAvatar(hostAvatarSrc)}
                    />
                  ) : (
                    <span role="img" aria-label="Host profile icon">👤</span>
                  )}
                </div>
                <div>
                  <h2 className="text-base lg:text-lg font-semibold text-gray-900 dark:text-white">Hosted by {listing.userRef?.username || 'Host'}</h2>
                  <p className="text-gray-600 dark:text-gray-400 text-xs lg:text-sm">
                    {listing.userRef?.isSuperhost ? 'Superhost · ' : isIdentityVerifiedHost ? 'Identity checked · ' : 'Host · '}
                    {listing.userRef?.createdAt ? (() => {
                      const months = Math.max(1, Math.floor((new Date() - new Date(listing.userRef.createdAt)) / (1000 * 60 * 60 * 24 * 30)));
                      return months < 12 ? `${months} month${months > 1 ? 's' : ''} hosting` : `${Math.floor(months / 12)} year${Math.floor(months / 12) > 1 ? 's' : ''} hosting`;
                    })() : '1 month hosting'}
                  </p>
                </div>
              </Link>
            </div>

            {/* Listing Highlights */}
            {listingHighlights.length > 0 && (
              <section className="border-b border-gray-200 py-6 dark:border-gray-800" aria-labelledby="listing-highlights-title">
                <h2 id="listing-highlights-title" className="mb-5 text-lg font-semibold text-gray-900 dark:text-white">Listing highlights</h2>
                <div className="grid gap-5 sm:grid-cols-2">
                  {listingHighlights.map(({ icon: Icon, title, detail }) => (
                    <div key={title} className="flex items-start gap-4">
                      <Icon className="mt-0.5 h-5 w-5 shrink-0 text-slate-700 dark:text-slate-300" aria-hidden="true" />
                      <div>
                        <h3 className="text-sm font-semibold text-gray-900 dark:text-white">{title}</h3>
                        <p className="mt-1 text-sm leading-5 text-gray-500 dark:text-gray-400">{detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Description */}
            <div className="py-6 border-b border-gray-200 dark:border-gray-800">
              <h2 className="text-lg lg:text-xl font-semibold text-gray-900 dark:text-white mb-4">About this place</h2>
              <div className="text-gray-700 dark:text-gray-300 leading-relaxed text-sm lg:text-base">
                {isExpanded ? listing.description : truncateDescription(listing.description, 60)}
              </div>
              {listing.description?.split(' ').length > 60 && (
                <button onClick={() => setIsExpanded(!isExpanded)} className="mt-4 font-semibold underline flex items-center gap-1 text-sm lg:text-base">
                  {isExpanded ? 'Show less' : 'Show more'}
                </button>
              )}
            </div>

            {/* Available Units & Rooms — horizontal scroll carousel */}
            {listing.roomTypes && listing.roomTypes.length > 0 && (
              <div className="py-5 border-b border-gray-200 dark:border-gray-800">
                {/* Header */}
                <div className="flex items-center justify-between mb-3.5">
                  <div>
                    <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white tracking-tight flex items-center gap-2">
                      Choose your room
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 font-medium mt-0.5">
                      {listing.roomTypes.length} {listing.roomTypes.length === 1 ? 'unit' : 'units'} available at this property
                    </p>
                  </div>
                  <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                    {listing.roomTypes.length} {listing.roomTypes.length === 1 ? 'Unit' : 'Units'}
                  </span>
                </div>

                {/* Horizontal scroll strip */}
                <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 snap-x snap-mandatory scrollbar-hide">
                  {listing.roomTypes.map((room, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05, duration: 0.3 }}
                      className="flex w-60 flex-none snap-start flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition-shadow duration-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900 sm:w-64"
                    >
                      {/* Image */}
                      <div className="relative h-36 w-full flex-shrink-0 overflow-hidden bg-gray-100 dark:bg-gray-800 sm:h-40">
                        {room.image ? (
                          <img src={room.image} alt={room.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        ) : listing.imageUrls && listing.imageUrls[0] ? (
                          <img src={listing.imageUrls[0]} alt={room.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-3xl bg-gradient-to-br from-slate-100 to-gray-200 dark:from-gray-800 dark:to-gray-900">🚪</div>
                        )}
                        <div className="absolute top-2 right-2 px-2 py-0.5 bg-black/75 backdrop-blur-md rounded-full text-white text-[10px] font-bold shadow-xs">
                          R{room.price ? Number(room.price).toLocaleString() : listing.regularPrice?.toLocaleString()}
                        </div>
                      </div>

                      {/* Details */}
                      <div className="p-2.5 sm:p-3 flex flex-col flex-1">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <h3 className="font-bold text-gray-900 dark:text-white text-xs sm:text-[13px] leading-tight truncate" title={room.name}>
                            {room.name}
                          </h3>
                          {room.capacity && (
                            <span className="text-[9px] font-semibold text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded flex-shrink-0">
                              👥 {room.capacity}
                            </span>
                          )}
                        </div>

                        {room.description && (
                          <p className="text-[10px] text-gray-500 dark:text-gray-400 leading-snug line-clamp-1 mb-2">
                            {room.description}
                          </p>
                        )}

                        {/* Small, neat Reserve action with hand pointer */}
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedUnit(room.name);
                            setShowBookingModal(true);
                          }}
                          className="mt-auto flex w-full items-center justify-center rounded-xl bg-rose-600 px-3 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-rose-700 active:scale-[0.99]"
                        >
                          Reserve
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Amenities */}
            {activeAmenities.length > 0 && (
              <div className="py-6 border-b border-gray-200 dark:border-gray-800">
                <h2 className="text-lg lg:text-xl font-semibold text-gray-900 dark:text-white mb-4">What this place offers</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {activeAmenities.slice(0, 10).map((amenity, index) => {
                    const Icon = amenity.icon;
                    return (
                      <div key={index} className="flex items-center gap-3 py-2">
                        <Icon className="text-gray-700 dark:text-gray-300 text-base lg:text-lg" />
                        <span className="text-gray-700 dark:text-gray-300 text-sm lg:text-base">{amenity.label}</span>
                      </div>
                    );
                  })}
                </div>
                {activeAmenities.length > 10 && (
                  <button className="mt-4 px-4 lg:px-6 py-2 lg:py-3 border border-gray-900 rounded-lg font-semibold hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-sm lg:text-base">
                    Show all {activeAmenities.length} amenities
                  </button>
                )}
              </div>
            )}

            {/* Check-in & Check-out timings — hidden for rent, shown for daily stays/hourly rooms */}
            {(isDailyStay || isHourlyRoom) && !isRent && (
              <div className="py-6 border-b border-gray-200 dark:border-gray-800">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2.5 bg-rose-50 rounded-2xl">
                    <ClockIcon className="w-6 h-6 text-rose-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">Check-in &amp; Check-out</h3>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Standard timing windows</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-5 rounded-3xl border border-gray-150/60 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center text-xl font-bold">
                        🛬
                      </div>
                      <div>
                        <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Check-in Time</span>
                        <span className="text-base lg:text-lg font-black text-gray-900 dark:text-white mt-0.5 block">{listing.checkInTime || '14:00'}</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-wide bg-gray-50 dark:bg-gray-800 px-3 py-1 rounded-full">After</span>
                  </div>

                  <div className="flex items-center justify-between p-5 rounded-3xl border border-gray-150/60 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center text-xl font-bold">
                        🛫
                      </div>
                      <div>
                        <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Check-out Time</span>
                        <span className="text-base lg:text-lg font-black text-gray-900 dark:text-white mt-0.5 block">{listing.checkOutTime || '11:00'}</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-wide bg-gray-50 dark:bg-gray-800 px-3 py-1 rounded-full">Before</span>
                  </div>
                </div>
              </div>
            )}

            {/* Monthly Payment Schedule — rent listings only */}
            {isRent && (
              <div className="py-6 border-b border-gray-200 dark:border-gray-800">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2.5 bg-green-50 rounded-2xl">
                    <BanknotesIcon className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">Monthly Payment Schedule</h3>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Accepted payment windows</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Window 1: 15th – 17th */}
                  <div className="flex items-center justify-between p-5 rounded-3xl border border-green-100 bg-green-50/40 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-green-100 text-green-700 flex items-center justify-center text-xl font-black">
                        💳
                      </div>
                      <div>
                        <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Payment Window 1</span>
                        <span className="text-base lg:text-lg font-black text-gray-900 dark:text-white mt-0.5 block">15th – 17th</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">of every month</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold text-green-600 uppercase tracking-wide bg-green-100 px-3 py-1 rounded-full">Window 1</span>
                    </div>
                  </div>

                  {/* Window 2: 30th – 5th */}
                  <div className="flex items-center justify-between p-5 rounded-3xl border border-green-100 bg-green-50/40 shadow-sm">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-green-100 text-green-700 flex items-center justify-center text-xl font-black">
                        💳
                      </div>
                      <div>
                        <span className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Payment Window 2</span>
                        <span className="text-base lg:text-lg font-black text-gray-900 dark:text-white mt-0.5 block">30th – 5th</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">end of month to 5th</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold text-green-600 uppercase tracking-wide bg-green-100 px-3 py-1 rounded-full">Window 2</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-gray-500 dark:text-gray-400 mt-4 flex items-center gap-1.5">
                  <BanknotesIcon className="w-3.5 h-3.5" />
                  Monthly rent: <span className="font-semibold text-gray-900 dark:text-white">R{Number(listing.regularPrice || 0).toLocaleString('en-ZA')}/month</span>
                </p>
              </div>
            )}

            {/* Calendar - Only for daily stays and room per hour */}
            {showCalendar && (
              <div className="py-6 border-b border-gray-200 dark:border-gray-800" id="calendar-section">
                <h2 className="text-lg lg:text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  {isHourlyRoom ? 'Select date & time' : 'Select your dates (per day)'}
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
                  {isDailyStay && (
                    <div>
                      <p className="mb-3 text-sm leading-6 text-gray-600 dark:text-gray-300">
                        Choose a check-in date, then a check-out date. Booked nights are unavailable; you may check out on the day another stay begins.
                      </p>
                      <Calendar
                        onChange={(nextRange) => setDateRange(Array.isArray(nextRange) ? nextRange : [nextRange, null])}
                        value={dateRange}
                        selectRange={true}
                        minDate={startOfLocalDay(new Date())}
                        tileClassName={({ date, view }) => {
                          if (view !== 'month') return null;
                          const day = startOfLocalDay(date);
                          const today = startOfLocalDay(new Date());
                          if (!day || day < today) return null;
                          const checkIn = dateRange[0] && !dateRange[1] ? startOfLocalDay(dateRange[0]) : null;
                          const unavailable = bookedDates.some((range) => {
                            const bookedStart = startOfLocalDay(range.start);
                            const bookedEnd = startOfLocalDay(range.end);
                            if (!bookedStart || !bookedEnd) return false;
                            if (!checkIn) return day >= bookedStart && day < bookedEnd;
                            if (day <= checkIn) return true;
                            return checkIn < bookedEnd && day > bookedStart;
                          });
                          return unavailable ? 'listing-calendar-unavailable' : null;
                        }}
                        tileDisabled={({ date, view }) => {
                          if (view !== 'month') return false;
                          const day = startOfLocalDay(date);
                          const today = startOfLocalDay(new Date());
                          if (!day || day < today) return true;
                          const checkIn = dateRange[0] && !dateRange[1] ? startOfLocalDay(dateRange[0]) : null;
                          return bookedDates.some((range) => {
                            const bookedStart = startOfLocalDay(range.start);
                            const bookedEnd = startOfLocalDay(range.end);
                            if (!bookedStart || !bookedEnd) return false;
                            if (!checkIn) return day >= bookedStart && day < bookedEnd;
                            if (day <= checkIn) return true;
                            return checkIn < bookedEnd && day > bookedStart;
                          });
                        }}
                        className="listing-booking-calendar rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm w-full"
                      />

                      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-gray-500 dark:text-gray-400">
                        <span>Unavailable dates are disabled. Your checkout date is not charged as a night.</span>
                        {(dateRange[0] || dateRange[1]) && (
                          <button type="button" onClick={() => setDateRange([null, null])} className="font-semibold text-rose-600 underline underline-offset-2 hover:text-rose-700 dark:text-rose-400">
                            Clear dates
                          </button>
                        )}
                      </div>

                      {dateRange?.[0] && dateRange?.[1] && hasBookedNightOverlap(dateRange[0], dateRange[1], bookedDates) && (
                        <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold flex items-center gap-2">
                          <span className="text-base">⚠️</span>
                          <span>Those nights overlap an existing booking. Please choose different dates.</span>
                        </div>
                      )}
                    </div>
                  )}

                  {isHourlyRoom && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Date</label>
                        <input
                          type="date"
                          value={dateOnlyString(selectedDate)}
                          onChange={(e) => setSelectedDate(new Date(`${e.target.value}T00:00:00`))}
                          min={dateOnlyString(new Date())}
                          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Start Time</label>
                        <select value={startTime} onChange={(e) => setStartTime(e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg text-sm">
                          {generateTimeOptions().map(time => <option key={time} value={time}>{time}</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">End Time</label>
                        <select value={endTime} onChange={(e) => setEndTime(e.target.value)}
                          className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg text-sm">
                          {generateTimeOptions(true).map(time => <option key={time} value={time}>{time}</option>)}
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Reviews */}
            <div className="pb-6 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center gap-2 mb-8">
                {hasReviews ? <>
                  <StarIconSolid className="text-[#FFB400] text-2xl drop-shadow-sm w-7 h-7" />
                  <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">{ratings.overall.toFixed(1)} · {commentCount} reviews</h2>
                </> : <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">Reviews</h2>}
              </div>

              <>
                <div className="mb-8 -mx-4 px-4 sm:mx-0 sm:px-0">
                    <Swiper
                      spaceBetween={12}
                      slidesPerView="auto"
                      freeMode
                      modules={[FreeMode]}
                      className="listing-rating-carousel"
                    >
                      {LISTING_EMOJI_RATINGS.map(({ label, emoji, key }) => {
                        const score = Number(listingRatingScores[key]) || 0;
                        return (
                          <SwiperSlide key={key} className="!w-[112px] sm:!w-[128px]">
                            <div className="h-full min-h-[100px] rounded-2xl bg-gray-50 dark:bg-gray-900/60 px-3 py-3 flex flex-col items-center justify-center text-center">
                              <span className="text-2xl leading-none" aria-hidden="true">{emoji}</span>
                              <span className="mt-2 text-xs font-medium text-gray-700 dark:text-gray-200">{label}</span>
                              <span className={`mt-1 text-center ${score > 0 ? 'text-sm font-semibold text-gray-950 dark:text-white' : 'text-[11px] font-medium text-gray-500 dark:text-gray-400'}`}>
                                {score > 0 ? `${score.toFixed(1)} / 5` : 'Not rated yet'}
                              </span>
                            </div>
                          </SwiperSlide>
                        );
                      })}
                    </Swiper>
                </div>

                {/* Top Comments Swiper */}
                {topComments.length > 0 && (
                    <div className="mb-8">
                      <Swiper
                        spaceBetween={16}
                        slidesPerView={1.1}
                        breakpoints={{
                          640: { slidesPerView: 2.1 },
                          1024: { slidesPerView: 2.2 }
                        }}
                        freeMode={true}
                        modules={[FreeMode]}
                        className="-mx-4 px-4 sm:mx-0 sm:px-0"
                      >
                        {topComments.map(comment => {
                          const rating = comment.rating || 5;
                          return (
                            <SwiperSlide key={comment._id} className="h-auto">
                              <div className="h-full bg-gradient-to-br from-[#F8F9FA] to-white border border-[#EBEBEB] rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-[#FFB400]/10 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                                <div className="relative z-10">
                                  <div className="flex items-center justify-between mb-4">
                                    <div className="flex items-center gap-3">
                                      <img
                                        src={comment.userAvatar || '/default-avatar.jpg'}
                                        alt={comment.userName}
                                        className="w-12 h-12 rounded-full object-cover border border-gray-100 dark:border-gray-800 shadow-sm"
                                        onError={(e) => { e.target.src = '/default-avatar.jpg'; }}
                                      />
                                      <div>
                                        <h4 className="font-semibold text-[#222222] dark:text-white leading-tight">{comment.userName}</h4>
                                        <p className="text-sm text-[#717171] dark:text-white mt-0.5">{getRelativeTime(comment.createdAt)}</p>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-4 mb-4">
                                    <div className="flex items-center">
                                      {[...Array(5)].map((_, i) => (
                                        <StarIconSolid
                                          key={i}
                                          className={`w-3.5 h-3.5 mr-1 ${i < Math.round(rating) ? 'text-[#FFB400]' : 'text-gray-200'}`}
                                        />
                                      ))}
                                    </div>
                                    {comment.likes?.length > 0 && (
                                      <div className="flex items-center gap-1 text-xs text-rose-500 font-medium">
                                        <FaHeart />
                                        {comment.likes.length}
                                      </div>
                                    )}
                                  </div>
                                  <p className="text-gray-700 dark:text-gray-300 line-clamp-4 leading-relaxed whitespace-pre-line">
                                    {comment.content}
                                  </p>
                                </div>
                              </div>
                            </SwiperSlide>
                          );
                        })}
                      </Swiper>
                    </div>
                )}
                {commentCount === 0 && (
                  <p className="text-gray-600 dark:text-gray-400 mb-6">No reviews yet. Be the first to leave a review!</p>
                )}
              </>

              {commentCount >= 10 && (
                <button
                  onClick={() => setShowCommentsPanel(true)}
                  className="px-6 py-3 border border-gray-900 rounded-lg font-semibold hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors w-full sm:w-auto"
                >
                  Show all {commentCount} reviews
                </button>
              )}
            </div>

            {/* Location */}
            <div className="py-6 border-t border-gray-200 dark:border-gray-800">
              <h2 className="text-lg lg:text-xl font-semibold text-gray-900 dark:text-white mb-4">Where you'll be</h2>
              <p className="text-gray-700 dark:text-gray-300 mb-4 text-sm lg:text-base">{listing.address}</p>
              <div className="relative h-[320px] w-full overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 sm:h-[360px]">
                <GoogleMapComponent 
                  latitude={listing.latitude} 
                  longitude={listing.longitude} 
                  address={listing.address} 
                  title={listing.name} 
                />
              </div>

              {listing.near && (
                <div className="mt-6">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">What's nearby</h3>
                  <div className="text-gray-700 dark:text-gray-300 text-xs lg:text-sm space-y-1">
                    {listing.near.split('\n').slice(0, isNearExpanded ? undefined : 4).map((item, i) => (
                      <p key={i}>{item}</p>
                    ))}
                  </div>
                  {listing.near.split('\n').length > 4 && (
                    <button onClick={() => setIsNearExpanded(!isNearExpanded)} className="mt-2 font-semibold underline text-sm">
                      {isNearExpanded ? 'Show less' : 'Show more'}
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Things to Know */}
            <div className="py-8 border-t border-gray-200 dark:border-gray-800">
              <h2 className="text-lg lg:text-xl font-semibold text-gray-900 dark:text-white mb-6">Things to know</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">

                {/* Cancellation Policy */}
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3 text-sm lg:text-base">Cancellation policy</h3>
                  <div className="space-y-2 text-gray-600 dark:text-gray-400 text-xs lg:text-sm">
                    {cancellationSummary ? (
                      <p className="leading-relaxed">{cancellationSummary}</p>
                    ) : listing.cancel ? (
                      listing.cancel.split('\n').map((policy, i) => (
                        <p key={i} className="leading-relaxed">{policy}</p>
                      ))
                    ) : (
                      <>
                        <p className="leading-relaxed">Cancel up to 48 hours before the scheduled start or check-in. Any payment or refund is arranged directly with the host.</p>
                      </>
                    )}
                    <button className="text-gray-900 dark:text-white font-semibold underline underline-offset-2 text-xs mt-1 hover:text-rose-500 transition-colors">
                      Review host's full policy
                    </button>
                  </div>
                </div>

                {/* House Rules */}
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3 text-sm lg:text-base">House rules</h3>
                  <div className="space-y-2 text-gray-600 dark:text-gray-400 text-xs lg:text-sm">
                    {isRent ? (
                      /* Rent: show payment windows instead of check-in/out times */
                      <>
                        <p className="flex items-center gap-2">
                          <BanknotesIcon className="w-4 h-4 text-green-500 flex-shrink-0" />
                          Pay between 15th – 17th
                        </p>
                        <p className="flex items-center gap-2">
                          <BanknotesIcon className="w-4 h-4 text-green-500 flex-shrink-0" />
                          Pay between 30th – 5th
                        </p>
                        {listing.rules ? (
                          listing.rules.split('\n').slice(0, 2).map((rule, i) => (
                            rule.trim() && (
                              <p key={i} className="flex items-start gap-2 leading-relaxed">
                                <CheckCircleIcon className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" />
                                {rule.replace(/^[-•*]\s*/, '')}
                              </p>
                            )
                          ))
                        ) : null}
                      </>
                    ) : (
                      /* Non-rent: show check-in/out times and rules */
                      <>
                        {listing.checkInTime && (
                          <p className="flex items-center gap-2">
                            <ClockIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                            Check-in after {listing.checkInTime}
                          </p>
                        )}
                        {listing.checkOutTime && (
                          <p className="flex items-center gap-2">
                            <ClockIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                            Checkout before {listing.checkOutTime}
                          </p>
                        )}
                        {listing.rules ? (
                          listing.rules.split('\n').slice(0, 3).map((rule, i) => (
                            rule.trim() && (
                              <p key={i} className="flex items-start gap-2 leading-relaxed">
                                <CheckCircleIcon className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" />
                                {rule.replace(/^[-•*]\s*/, '')}
                              </p>
                            )
                          ))
                        ) : (
                          <>
                            <p className="flex items-center gap-2"><CheckCircleIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />4 guests maximum</p>
                          </>
                        )}
                      </>
                    )}
                    <button className="text-gray-900 dark:text-white font-semibold underline underline-offset-2 text-xs mt-1 hover:text-rose-500 transition-colors">
                      Learn more
                    </button>
                  </div>
                </div>

                {/* Safety & Property */}
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3 text-sm lg:text-base">Safety &amp; property</h3>
                  <div className="space-y-2 text-gray-600 dark:text-gray-400 text-xs lg:text-sm">
                    {listing.security ? (
                      <p className="flex items-center gap-2">
                        <CheckCircleIcon className="w-4 h-4 text-green-500 flex-shrink-0" />
                        Carbon monoxide alarm
                      </p>
                    ) : (
                      <p className="flex items-center gap-2">
                        <XMarkIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                        Carbon monoxide alarm not reported
                      </p>
                    )}
                    <p className="flex items-center gap-2">
                      <XMarkIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                      Smoke alarm not reported
                    </p>
                    <button className="text-gray-900 dark:text-white font-semibold underline underline-offset-2 text-xs mt-1 hover:text-rose-500 transition-colors">
                      Learn more
                    </button>
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* Right Column - Booking Card */}
          <div className="hidden lg:block lg:col-span-1 relative">
            <div className="lg:sticky lg:top-28 space-y-4 pb-8 z-10">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-[0_8px_30px_rgba(15,23,42,0.08)] lg:p-7">
                {/* Price Header */}
                <div className="flex items-baseline justify-between mb-4 lg:mb-6">
                  <div>
                    <span className="text-xl lg:text-2xl font-semibold text-gray-900 dark:text-white">R{displayedPrice.toLocaleString('en-ZA')}</span>
                    <span className="text-gray-600 dark:text-gray-400 text-sm lg:text-base">/{pricePeriod}</span>
                  </div>
                  {hasOfferPrice && (
                    <span className="text-gray-400 line-through text-sm lg:text-base">R{Number(listing.regularPrice).toLocaleString('en-ZA')}</span>
                  )}
                </div>

                {/* Listing Type Info / Rent Payment Info */}
                <div className="mb-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl space-y-2 text-xs lg:text-sm">
                  {isRent ? (
                    /* Rent: show monthly rate + payment windows */
                    <>
                      <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                        <span className="font-semibold text-gray-600 dark:text-gray-400">Monthly Rent:</span>
                        <span className="font-bold text-gray-900 dark:text-white">R{listing.regularPrice.toLocaleString('en-ZA')}/month</span>
                      </p>
                      {listing.discountPrice && (
                        <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                          <span className="font-semibold text-gray-600 dark:text-gray-400">Deposit:</span>
                          <span>R{Number(listing.discountPrice).toLocaleString('en-ZA')}</span>
                        </p>
                      )}
                      {listing.period && (
                        <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                          <span className="font-semibold text-gray-600 dark:text-gray-400">Available From:</span>
                          <span>{listing.period}</span>
                        </p>
                      )}
                      <div className="pt-2 border-t border-gray-200 dark:border-gray-800/70 space-y-1.5">
                        <p className="font-semibold text-gray-600 dark:text-gray-400 text-[11px] uppercase tracking-wide">Payment Windows</p>
                        <p className="flex items-center gap-2 text-green-700 font-semibold">
                          <BanknotesIcon className="w-3.5 h-3.5" />
                          15th – 17th of every month
                        </p>
                        <p className="flex items-center gap-2 text-green-700 font-semibold">
                          <BanknotesIcon className="w-3.5 h-3.5" />
                          30th – 5th (end of month)
                        </p>
                      </div>
                    </>
                  ) : (
                    /* Non-rent: existing listing type info */
                    <>
                      <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                        <span className="font-semibold text-gray-600 dark:text-gray-400">Rate:</span>
                        <span className="capitalize font-bold text-gray-900 dark:text-white">Per {pricePeriod}</span>
                      </p>
                      <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                        <span className="font-semibold text-gray-600 dark:text-gray-400">Listing Type:</span>
                        <span>{pricePeriod === 'night' ? (listing.kind ? `${listing.kind.replace(/_/g, ' ')} Stay` : 'Overnight Stay') : pricePeriod === 'day' ? (listing.kind === 'house' ? 'Full House Stay' : 'Daily Stay') : pricePeriod === 'hour' ? 'Hourly Room' : listingType.label}</span>
                      </p>
                      {listing.kind && (
                        <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                          <span className="font-semibold text-gray-600 dark:text-gray-400">Property Type:</span>
                          <span className="capitalize">{listing.kind.replace(/_/g, " ")}</span>
                        </p>
                      )}
                      {listing.period && (
                        <p className="text-gray-700 dark:text-gray-300 flex justify-between gap-2">
                          <span className="font-semibold text-gray-600 dark:text-gray-400">Available From:</span>
                          <span>{listing.period}</span>
                        </p>
                      )}
                      {listing.cancel && (
                        <p className="text-gray-700 dark:text-gray-300 flex flex-col gap-0.5 pt-1 border-t border-gray-200 dark:border-gray-800/50">
                          <span className="font-semibold text-gray-600 dark:text-gray-400">Cancellation Policy:</span>
                          <span className="text-gray-500 dark:text-gray-400 text-[11px] leading-snug">{cancellationSummary || listing.cancel}</span>
                        </p>
                      )}
                    </>
                  )}
                </div>

                {/* Action Button - Different based on property type */}
                <button
                  onClick={() => setShowBookingModal(true)}
                  disabled={!formattedDisplayNumber}
                  className="w-full rounded-xl bg-rose-600 py-3 text-sm font-semibold text-white transition-colors hover:bg-rose-700 disabled:opacity-50 lg:text-base"
                >
                  {isSaleOrRent ? 'Contact host' : 'Reserve'}
                </button>
                <p className="mt-2 text-center text-xs text-gray-500">You won’t be charged yet</p>

                <button
                  onClick={handleEscrowCheckout}
                  className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white py-3 text-sm font-semibold text-slate-800 transition-colors hover:bg-slate-50 lg:text-base"
                >
                  <FaShieldAlt className="text-base text-indigo-600 lg:text-lg" />
                  Pay securely via escrow
                </button>


                <p className="text-center text-gray-500 dark:text-gray-400 text-xs lg:text-sm mt-2">
                  {isSaleOrRent ? 'Ask questions about this listing' : 'Your request will be sent to the host'}
                </p>

                {/* Quick Contact Button */}
                <button
                  onClick={handleContactHost}
                  className="w-full mt-2 py-2 border border-gray-300 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 font-medium rounded-lg transition-colors text-sm lg:text-base"
                >
                  Quick Contact
                </button>
              </div>

              {/* Contact Info Card */}
              <div className="rounded-2xl border border-slate-200 bg-white p-6 lg:p-7">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-3 lg:mb-4">Contact Information</h3>
                {currentUser ? (
                  <div className="space-y-2 lg:space-y-3">
                    {formattedDisplayNumber && (
                      <a href={`tel:${formattedDisplayNumber}`} className="flex items-center gap-3 p-2 lg:p-3 bg-slate-50/50 rounded-2xl hover:bg-slate-100 transition-all border border-slate-200/30">
                        <div className="w-8 h-8 lg:w-10 lg:h-10 bg-rose-100 rounded-full flex items-center justify-center shadow-sm">
                          <PhoneIcon className="w-4 h-4 text-rose-600" />
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Phone</p>
                          <p className="font-bold text-gray-900 dark:text-white text-sm lg:text-base tracking-tight">{formattedDisplayNumber}</p>
                        </div>
                      </a>
                    )}
                    {displayEmail && (
                      <a href={`mailto:${displayEmail}`} className="flex items-center gap-3 p-2 lg:p-3 bg-slate-50/50 rounded-2xl hover:bg-slate-100 transition-all border border-slate-200/30">
                        <div className="w-8 h-8 lg:w-10 lg:h-10 bg-blue-100 rounded-full flex items-center justify-center shadow-sm">
                          <EnvelopeIcon className="w-4 h-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Email</p>
                          <p className="font-bold text-gray-900 dark:text-white text-sm lg:text-base tracking-tight">{displayEmail}</p>
                        </div>
                      </a>
                    )}
                    {formattedDisplayNumber && (
                      <a href={`https://wa.me/${formatPhoneNumberForWhatsApp(formattedDisplayNumber)}`} target="_blank" rel="noopener noreferrer"
                        className="flex items-center gap-3 p-2 lg:p-3 bg-green-50/50 rounded-2xl hover:bg-green-100 transition-all border border-green-200/30">
                        <div className="w-8 h-8 lg:w-10 lg:h-10 bg-green-100 rounded-full flex items-center justify-center shadow-sm">
                          <ChatBubbleLeftRightIcon className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">WhatsApp</p>
                          <p className="font-bold text-gray-900 dark:text-white text-sm lg:text-base tracking-tight">Message host</p>
                        </div>
                      </a>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3 py-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                      <UserIcon className="w-5 h-5 text-gray-400" />
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center">Sign in to view host contact details</p>
                    <Link
                      to="/sign-in"
                      className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-white text-sm font-semibold rounded-lg transition-colors"
                    >
                      Sign In
                    </Link>
                  </div>
                )}
              </div>

              {/* Report Listing */}
              <div className="flex items-center justify-center gap-2 text-gray-400 text-xs lg:text-sm pt-4">
                <FlagIcon className="w-4 h-4" />
                <button className="underline underline-offset-4 font-black uppercase tracking-widest text-[9px] hover:text-rose-500">Report this listing</button>
              </div>
            </div>
          </div>
        </div>
        <ListingWeatherForecast listing={listing} />
      </ListingDetailShell>

      {/* WhatsApp Booking Modal */}
      <WhatsAppBookingModal
        listing={listing}
        isOpen={showBookingModal}
        onClose={() => {
          setShowBookingModal(false);
          setSelectedUnit('');
        }}
        bookedDates={bookedDates}
        initialDates={{
          checkIn: dateRange?.[0] ? dateOnlyString(dateRange[0]) : '',
          checkOut: dateRange?.[1] ? dateOnlyString(dateRange[1]) : '',
          selectedDate: selectedDate ? dateOnlyString(selectedDate) : '',
          startTime,
          endTime,
          selectedUnit,
          guests: numberOfGuests || 2
        }}
      />

      {/* Contact Modal */}
      <ContactHostModal
        listing={listing}
        user={currentUser}
        isOpen={showContactModal}
        onClose={() => setShowContactModal(false)}
      />

      {/* Comments Side Panel */}
      {showCommentsPanel && (
        <CommentsSidePanel
          listingId={listingId}
          onClose={() => setShowCommentsPanel(false)}
          currentUser={currentUser}
          listing={listing}
        />
      )}

      {/* Mobile Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 p-4 lg:hidden z-40 safe-area-bottom mobile-booking-bar">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xl font-bold text-gray-900 dark:text-white">
              R{isDailyStay ? (days > 0 ? grandTotal.toLocaleString() : listing.regularPrice.toLocaleString()) :
                isHourlyRoom && totalHours > 0 ? totalPrice :
                  listing.regularPrice.toLocaleString()}
            </span>
            <span className="text-gray-600 dark:text-gray-400 text-sm">
              {isDailyStay ? (days > 0 ? ` (${days} day${days > 1 ? 's' : ''})` : ' / day') : 
               isHourlyRoom ? (totalHours > 0 ? ` (${totalHours} hr)` : ' / hour') : 
               isRent ? ' / month' : ` / ${pricePeriod}`}
            </span>
          </div>
          <button
            onClick={handleQuickBooking}
            className="px-8 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-lg transition-colors"
          >
            {isRent ? 'Inquire Now' : 'Book Now'}
          </button>
        </div>
      </div>
    </div>
  );
}
