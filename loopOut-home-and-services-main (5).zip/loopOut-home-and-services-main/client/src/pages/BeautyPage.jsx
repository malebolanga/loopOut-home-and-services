/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import { pushPhoneNotification } from '../components/PhoneNotificationManager';
import ServiceDetailsModal from '../components/ServiceDetailsModal';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { getDownloadURL, getStorage, ref, uploadBytesResumable } from "firebase/storage";
import { app } from "../firebase";
import { useWishlist } from '../hooks/useWishlist';
import { useBookedSlots } from '../hooks/useBookedSlots';
import BookingTimeSlots from '../components/BookingTimeSlots';
import BookingDateNotice from '../components/BookingDateNotice';
import ListingPhotoGallery from '../components/ListingPhotoGallery';
import ListingDetailShell from '../components/ListingDetailShell';
import { Link } from "react-router-dom";
import {
  StarIcon,
  HomeIcon,
  UserIcon,
  PhoneIcon,
  EnvelopeIcon,
  BoltIcon,
  ShieldCheckIcon,
  FlagIcon,
  CheckCircleIcon,
  ArrowLeftIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronDownIcon,
  XMarkIcon,
  CameraIcon,
  PhotoIcon,
  WifiIcon,
  TruckIcon,
  KeyIcon,
  HeartIcon,
  ShareIcon,
  InformationCircleIcon,
  PaperAirplaneIcon,
  ClockIcon,
  CurrencyDollarIcon,
  TagIcon,
  UserGroupIcon,
  ChatBubbleLeftRightIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  PlusCircleIcon,
  MapPinIcon,
  CheckIcon
} from '@heroicons/react/24/outline';
import { 
  StarIcon as StarIconSolid, 
  HeartIcon as HeartIconSolid,
  CheckBadgeIcon
} from '@heroicons/react/24/solid';
import { Sparkles } from 'lucide-react';
import { 
  FaTshirt, FaBroom, FaFire, FaBaby, FaGlassCheers, FaEllipsisH, FaPalette,
  FaSpa, FaStar, FaCut, FaGraduationCap, FaChalkboardTeacher, FaBook, FaLanguage,
  FaPencilAlt, FaHandsWash, FaToolbox, FaWrench, FaTools, FaScrewdriver,
  FaSnowflake, FaPlug, FaInstagram, FaFacebook, FaTwitter, FaLinkedin, FaTiktok,
  FaCamera, FaAward, FaBuilding, FaMapMarkerAlt, FaFileAlt, FaBriefcase, FaUserGraduate,
  FaTrophy, FaCertificate, FaHandSparkles, FaClock, FaCheckCircle, FaTrashAlt, FaLeaf,
  FaTruck, FaUser, FaPhone, FaWhatsapp, FaInfoCircle, FaShieldAlt,
  FaHandHoldingHeart, FaRing, FaBrush, FaSmile, FaUtensils, FaCookie, FaShoppingBasket,
  FaShoePrints, FaSoap, FaTint, FaWater, FaCogs, FaBath, FaSun, FaDog, FaPaw, FaFish,
  FaUserFriends, FaHome, FaCat, FaDove, FaHorse, FaArrowRight, FaSprayCan, FaWind, FaCar,
  FaExclamationTriangle, FaHeart, FaSpinner
} from 'react-icons/fa';
import { FiShare2, FiMessageSquare, FiMapPin, FiHeart, FiClock, FiStar, FiChevronRight, FiChevronLeft } from 'react-icons/fi';
import { MdCleanHands, MdOutlineGppGood, MdLogin, MdChat, MdLocationOn, MdAttachMoney, MdVerified } from 'react-icons/md';

// Some icons might be double defined in Fi or Md, so I adjusted the list.
// FaBroomClean doesn't exist in standard Fa, likely was a typo or specialized set. Using FaBroom.


import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Zoom, Thumbs, Pagination, FreeMode } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/zoom';
import 'swiper/css/thumbs';
import 'swiper/css/pagination';
import 'swiper/css/free-mode';

// Swiper styles already imported above

import ImageWithFallback from '../components/ImageWithFallback';
import GoogleMapComponent from '../components/GoogleMapComponent';
import HelperComments from '../components/HelperComments';
import CommentsSidePanelHelper from '../components/CommentsSidePanelHelper';
import HelperBookingSheet from '../components/HelperBookingSheet';
import BookingProgress from '../components/BookingProgress';
import BookingHistory from '../components/BookingHistory';

const BEAUTY_REVIEW_CATEGORIES = [
  { key: 'beautyCleaning', field: 'beautyCleaningRating', label: 'Cleaning', emoji: '🧹' },
  { key: 'beautyCommunication', field: 'beautyCommunicationRating', label: 'Communication', emoji: '💬' },
  { key: 'beautyEquipment', field: 'beautyEquipmentRating', label: 'Equipment', emoji: '🧴' },
  { key: 'hairdressing', field: 'hairdressingRating', label: 'Hair artist', emoji: '✂️' },
  { key: 'timeliness', field: 'timelinessRating', label: 'On time', emoji: '⏱️' }
];

export default function BeautyPage() {
  const [selectedModalService, setSelectedModalService] = useState(null);
  const { currentUser } = useSelector((state) => state.user);
  const [helper, setHelper] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [commentCount, setCommentCount] = useState(0);
  const [showCommentsPanel, setShowCommentsPanel] = useState(false);
  const [commentsLoading, setCommentsLoading] = useState(true);
  const [showBookingBelt, setShowBookingBelt] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [dislikeCount, setDislikeCount] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const { isFavorite, toggleFavorite } = useWishlist(helper, 'helper');
  const [ratingLoading, setRatingLoading] = useState(false);
  const [totalPrice, setTotalPrice] = useState(0);
  const [ratings, setRatings] = useState({ cleanliness: 0, communication: 0, overall: 0, beautyCleaning: 0, beautyCommunication: 0, beautyEquipment: 0, hairdressing: 0, timeliness: 0 });
  const [ratingCounts, setRatingCounts] = useState({});
  const [topComments, setTopComments] = useState([]);
  const [bookingSummary, setBookingSummary] = useState({ count: 0, recentBookers: [] });

  const RECENTLY_VIEWED_KEY = 'recentlyViewed';

  useEffect(() => {
    if (helper) {
      fetchBookingSummary();
      saveToHistory(helper);
    }
  }, [helper]);

  const fetchBookingSummary = async () => {
    try {
      const res = await fetch(`/api/bookings/helper-summary/${helper._id}`);
      if (res.ok) {
        const data = await res.json();
        setBookingSummary(data);
      }
    } catch (error) {
      console.error('Error fetching booking summary:', error);
    }
  };

  const saveToHistory = (item) => {
    try {
      const stored = localStorage.getItem(RECENTLY_VIEWED_KEY);
      let history = stored ? JSON.parse(stored) : [];
      history = history.filter(h => h._id !== item._id);
      history.unshift({
        ...item,
        itemType: 'helper',
        viewedAt: new Date().toISOString()
      });
      localStorage.setItem(RECENTLY_VIEWED_KEY, JSON.stringify(history.slice(0, 20)));
    } catch (error) {
      console.error('Error saving history:', error);
    }
  };

  // ==================== SERVICE CONFIGURATION (MOVED UP) ====================

  // Service options for different helper types
  const getServiceOptions = (type) => {
    const baseOptions = [
      { id: 'laundry', name: 'Laundry', icon: <FaTshirt className="text-blue-500" /> },
      { id: 'cleaning', name: 'Deep Cleaning', icon: <FaBroom className="text-green-500" /> },
      { id: 'ironing', name: 'Ironing', icon: <FaTshirt className="text-purple-500" /> },
      { id: 'yard', name: 'Yard Work', icon: <FaBroom className="text-yellow-600" /> },
      { id: 'cooking', name: 'Meal Prep', icon: <FaFire className="text-red-500" /> },
      { id: 'babysitting', name: 'Child Care', icon: <FaBaby className="text-pink-500" /> },
      { id: 'eventCleaning', name: 'Event Cleanup', icon: <FaGlassCheers className="text-indigo-500" /> },
      { id: 'other', name: 'Other', icon: <FaEllipsisH className="text-gray-500" /> }
    ];

    const beautyOptions = [
      { id: 'makeup', name: 'Makeup', icon: <FaPalette className="text-pink-500" /> },
      { id: 'skincare', name: 'Facials', icon: <FaSpa className="text-purple-400" /> },
      { id: 'nails', name: 'Nails', icon: <FaHandSparkles className="text-red-400" /> },
      { id: 'hair', name: 'Hair Styling', icon: <FaCut className="text-blue-400" /> },
      { id: 'facial', name: 'Skin Therapy', icon: <FaStar className="text-yellow-500" /> },
      { id: 'waxing', name: 'Waxing', icon: <FaFire className="text-orange-500" /> },
      { id: 'massage', name: 'Massage', icon: <FaHandHoldingHeart className="text-green-400" /> },
      { id: 'bridal', name: 'Bridal', icon: <FaRing className="text-rose-500" /> }
    ];

    const barberOptions = [
      { id: 'haircut', name: 'Haircut', icon: <FaCut className="text-blue-600" /> },
      { id: 'beardTrim', name: 'Beard Trim', icon: <FaUser className="text-gray-700" /> },
      { id: 'shave', name: 'Razor Shave', icon: <FaTools className="text-gray-900" /> },
      { id: 'fade', name: 'Fade', icon: <FaCut className="text-indigo-600" /> },
      { id: 'coloring', name: 'Coloring', icon: <FaBrush className="text-purple-500" /> },
      { id: 'styling', name: 'Styling', icon: <FaSprayCan className="text-yellow-600" /> },
      { id: 'kidsCut', name: 'Kids Cut', icon: <FaSmile className="text-green-500" /> },
      { id: 'consultation', name: 'Consult', icon: <FaUser className="text-teal-500" /> }
    ];

    const chefOptions = [
      { id: 'mealPrep', name: 'Meal Prep', icon: <FaUtensils className="text-orange-500" /> },
      { id: 'privateDining', name: 'Private Dining', icon: <FaUtensils className="text-red-500" /> },
      { id: 'cookingClasses', name: 'Classes', icon: <FaGraduationCap className="text-green-500" /> },
      { id: 'eventCatering', name: 'Catering', icon: <FaGlassCheers className="text-purple-500" /> },
      { id: 'dietMeals', name: 'Diet Plans', icon: <FaCookie className="text-blue-500" /> },
      { id: 'baking', name: 'Baking', icon: <FaCookie className="text-yellow-500" /> },
      { id: 'groceryShopping', name: 'Shopping', icon: <FaShoppingBasket className="text-teal-500" /> },
      { id: 'menuPlanning', name: 'Planning', icon: <FaUtensils className="text-indigo-500" /> }
    ];

    const tattooOptions = [
      { id: 'custom', name: 'Custom Art', icon: <FaPalette className="text-gray-800" /> },
      { id: 'coverup', name: 'Cover-up', icon: <FaBrush className="text-purple-600" /> },
      { id: 'touchup', name: 'Touch-up', icon: <FaTools className="text-blue-600" /> },
      { id: 'consultation', name: 'Design', icon: <FaUser className="text-teal-500" /> }
    ];

    const tutorOptions = [
      { id: 'math', name: 'Mathematics', icon: <FaGraduationCap className="text-blue-600" /> },
      { id: 'science', name: 'Science', icon: <FaGraduationCap className="text-green-600" /> },
      { id: 'language', name: 'Languages', icon: <FaGraduationCap className="text-yellow-600" /> },
      { id: 'music', name: 'Music', icon: <FaGraduationCap className="text-purple-600" /> },
      { id: 'art', name: 'Art', icon: <FaPalette className="text-pink-600" /> },
      { id: 'testPrep', name: 'Test Prep', icon: <FaGraduationCap className="text-red-600" /> }
    ];

    const photographyOptions = [
      { id: 'portrait', name: 'Portrait', icon: <FaUser className="text-blue-500" /> },
      { id: 'event', name: 'Events', icon: <FaGlassCheers className="text-purple-500" /> },
      { id: 'product', name: 'Product', icon: <FaShoppingBasket className="text-green-500" /> },
      { id: 'wedding', name: 'Wedding', icon: <FaRing className="text-pink-500" /> },
      { id: 'family', name: 'Family', icon: <FaUserFriends className="text-orange-500" /> },
      { id: 'commercial', name: 'Commercial', icon: <FaBriefcase className="text-indigo-500" /> },
      { id: 'realestate', name: 'Real Estate', icon: <FaHome className="text-yellow-600" /> },
      { id: 'landscape', name: 'Landscape', icon: <FaMapMarkerAlt className="text-teal-500" /> }
    ];

    const sneakerOptions = [
      { id: 'basicClean', name: 'Basic Clean', icon: <FaShoePrints className="text-indigo-500" /> },
      { id: 'deepClean', name: 'Deep Clean', icon: <FaSoap className="text-purple-500" /> },
      { id: 'stainRemoval', name: 'Stain Removal', icon: <FaTint className="text-blue-500" /> },
      { id: 'whitening', name: 'Whitening', icon: <FaStar className="text-yellow-500" /> },
      { id: 'restoration', name: 'Restoration', icon: <FaTools className="text-gray-600" /> },
      { id: 'waterproofing', name: 'Waterproofing', icon: <FaWater className="text-cyan-500" /> },
      { id: 'soleRepair', name: 'Sole Repair', icon: <FaCogs className="text-gray-700" /> },
      { id: 'colorRestore', name: 'Color Restore', icon: <FaPalette className="text-pink-500" /> }
    ];

    const washingmatOptions = [
      { id: 'basicWash', name: 'Basic Wash', icon: <FaWater className="text-blue-500" /> },
      { id: 'deepClean', name: 'Deep Clean', icon: <FaBath className="text-purple-500" /> },
      { id: 'stainRemoval', name: 'Stain Removal', icon: <FaTint className="text-red-500" /> },
      { id: 'sanitizing', name: 'Sanitizing', icon: <FaShieldAlt className="text-green-500" /> },
      { id: 'deodorizing', name: 'Deodorizing', icon: <FaWind className="text-teal-500" /> },
      { id: 'steamCleaning', name: 'Steam Cleaning', icon: <FaFire className="text-orange-500" /> },
      { id: 'drying', name: 'Drying Service', icon: <FaSun className="text-yellow-500" /> },
      { id: 'pickupDelivery', name: 'Pickup & Delivery', icon: <FaTruck className="text-gray-600" /> }
    ];

    const animalOptions = [
      { id: 'dogWalking', name: 'Dog Walking', icon: <FaDog className="text-amber-600" /> },
      { id: 'petSitting', name: 'Pet Sitting', icon: <FaPaw className="text-amber-500" /> },
      { id: 'grooming', name: 'Grooming', icon: <FaCut className="text-purple-500" /> },
      { id: 'bathing', name: 'Bathing', icon: <FaBath className="text-blue-500" /> },
      { id: 'feeding', name: 'Feeding', icon: <FaFish className="text-green-500" /> },
      { id: 'medication', name: 'Medication', icon: <FaShieldAlt className="text-red-500" /> },
      { id: 'training', name: 'Training', icon: <FaGraduationCap className="text-indigo-500" /> },
      { id: 'vetVisits', name: 'Vet Visits', icon: <FaTruck className="text-gray-600" /> },
      { id: 'catCare', name: 'Cat Care', icon: <FaCat className="text-amber-400" /> },
      { id: 'birdCare', name: 'Bird Care', icon: <FaDove className="text-sky-500" /> },
      { id: 'horseCare', name: 'Horse Care', icon: <FaHorse className="text-brown-500" /> }
    ];

    const transportOptions = [
      { id: 'schoolTransport', name: 'School Transport', icon: <FaCar className="text-yellow-500" /> },
      { id: 'privateRide', name: 'Private Ride', icon: <FaCar className="text-blue-500" /> },
      { id: 'furnitureRemoval', name: 'Furniture Removal', icon: <FaTruck className="text-orange-500" /> },
      { id: 'delivery', name: 'Delivery', icon: <FaBriefcase className="text-green-500" /> },
      { id: 'intercity', name: 'Inter-city Trip', icon: <FaArrowRight className="text-indigo-500" /> }
    ];

    switch (type) {
      case 'beauty':
      case 'spa':
        return beautyOptions;
      case 'barber':
      case 'barbar':
        return barberOptions;
      case 'chef':
      case 'cooking':
        return chefOptions;
      case 'tattoo':
        return tattooOptions;
      case 'tutor':
        return tutorOptions;
      case 'photography':
        return photographyOptions;
      case 'domestic':
      case 'maid':
        return baseOptions;
      case 'sneaker':
        return sneakerOptions;
      case 'washingmat':
        return washingmatOptions;
      case 'animals':
        return animalOptions;
      case 'transport':
        return transportOptions;
      default:
        return [];
    }
  };

  const getServiceDisplayName = (name) => {
    const normalizedName = String(name || '').trim().replace(/\s+/g, ' ');
    if (/^rlay \(rubber base\) exit gel overlay \(rubber base\)$/i.test(normalizedName)) {
      return 'Rubber Base Gel Overlay';
    }
    return normalizedName;
  };

  // Prioritize dynamic serviceList from database, fallback to hardcoded options
  const serviceOptions = (helper?.serviceList && helper.serviceList.length > 0)
    ? helper.serviceList.map((s, index) => ({ 
        id: s.name, 
        name: getServiceDisplayName(s.name), 
        type: s.type,
        description: s.description,
        price: s.price,
        image: s.image,
        icon: <FaHandSparkles className="text-rose-500" /> 
      }))
    : getServiceOptions(helper?.type).map(({ price, ...option }) => option);

  // Full page overlay state for booking form
  const [showBookingFormOverlay, setShowBookingFormOverlay] = useState(false);

  // Full screen gallery states
  const [showFullScreenGallery, setShowFullScreenGallery] = useState(false);
  const [currentGalleryIndex, setCurrentGalleryIndex] = useState(0);

  // ==================== HELPER FUNCTIONS & STATIC DATA (MOVED UP) ====================

  // Helper function to get professional title
  const getProfessionalTitle = (type) => {
    const titles = {
      chef: 'Private Chef',
      barber: 'Barber',
      barbar: 'Barber',
      beauty: 'Beauty Professional',
      spa: 'Spa Professional',
      maid: 'Housekeeper',
      domestic: 'Domestic Helper',
      tattoo: 'Tattoo Artist',
      tutor: 'Private Tutor',
      photography: 'Photographer',
      sneaker: 'Sneaker Cleaner',
      washingmat: 'Mat Washer',
      animals: 'Animal Care Professional',
      transport: 'Transport Service'
    };
    return titles[type] || 'Professional';
  };

  // Get theme color based on helper type
  const getThemeColor = (type) => {
    const themes = {
      beauty: 'pink',
      spa: 'purple',
      domestic: 'red',
      maid: 'red',
      barber: 'blue',
      barbar: 'blue',
      chef: 'orange',
      cooking: 'orange',
      tattoo: 'gray',
      tutor: 'green',
      photography: 'purple',
      sneaker: 'indigo',
      washingmat: 'cyan',
      animals: 'amber',
      transport: 'orange',
      default: 'red'
    };
    return themes[type] || themes.default;
  };

  const themeColor = helper ? getThemeColor(helper.type) : 'red';

  // Haircut styles for barbers
  const haircutStyles = [
    { id: 'classic-crew', name: 'Classic Crew Cut', description: 'Timeless short cut' },
    { id: 'fade-cut', name: 'Fade Cut', description: 'Gradual length transition' },
    { id: 'pompadour', name: 'Pompadour', description: 'Voluminous classic style' },
    { id: 'undercut', name: 'Undercut', description: 'Sharp contrast cut' },
    { id: 'buzz-cut', name: 'Buzz Cut', description: 'Uniform short length' },
    { id: 'afro-style', name: 'Afro Style', description: 'Natural texture styling' },
    { id: 'textured-crop', name: 'Textured Crop', description: 'Modern layered cut' },
    { id: 'slick-back', name: 'Slick Back', description: 'Sleek polished look' }
  ];

  // Beard styles for barbers
  const beardStyles = [
    { id: 'stubble', name: 'Stubble', description: 'Short maintained beard' },
    { id: 'short-beard', name: 'Short Beard', description: 'Neat trimmed beard' },
    { id: 'medium-beard', name: 'Medium Beard', description: 'Fuller beard style' },
    { id: 'long-beard', name: 'Long Beard', description: 'Extended beard care' },
    { id: 'goatee', name: 'Goatee', description: 'Chin focused style' },
    { id: 'van-dyke', name: 'Van Dyke', description: 'Mustache and goatee combo' },
    { id: 'circle-beard', name: 'Circle Beard', description: 'Rounded beard style' },
    { id: 'clean-shave', name: 'Clean Shave', description: 'Complete beard removal' }
  ];

  const cleaningTypes = [
    { id: 'gentle', name: 'Gentle Clean' },
    { id: 'standard', name: 'Standard Clean' },
    { id: 'deep', name: 'Deep Clean' }
  ];

  const matSizes = [
    { id: 'small', name: 'Small (Under 1.5m)' },
    { id: 'medium', name: 'Medium (1.5m - 2.5m)' },
    { id: 'large', name: 'Large (Over 2.5m)' }
  ];

  const matMaterials = [
    { id: 'synthetic', name: 'Synthetic Fiber' },
    { id: 'wool', name: 'Wool' },
    { id: 'cotton', name: 'Cotton' },
    { id: 'other', name: 'Other' }
  ];

  const stainLevels = [
    { id: 'light', name: 'Light Soiling' },
    { id: 'medium', name: 'Visible Stains' },
    { id: 'heavy', name: 'Heavy Deep-set Stains' }
  ];

  const dryingPreferences = [
    { id: 'air', name: 'Natural Air Dry' },
    { id: 'machine', name: 'Fast Machine Dry' }
  ];

  const animalSizes = [
    { id: 'small', name: 'Small (under 10kg)' },
    { id: 'medium', name: 'Medium (10-25kg)' },
    { id: 'large', name: 'Large (25-45kg)' },
    { id: 'xlarge', name: 'Extra Large (over 45kg)' }
  ];

  const animalAgeRanges = [
    { id: 'puppy', name: 'Puppy/Kitten' },
    { id: 'young', name: 'Young' },
    { id: 'adult', name: 'Adult' },
    { id: 'senior', name: 'Senior' }
  ];

  const serviceDurations = [
    { id: '30min', name: '30 minutes' },
    { id: '1hour', name: '1 hour' },
    { id: '2hours', name: '2 hours' },
    { id: '4hours', name: '4 hours' },
    { id: '8hours', name: 'Full day (8 hours)' },
    { id: 'overnight', name: 'Overnight' },
    { id: '24hours', name: '24 hours' },
    { id: 'weekly', name: 'Weekly' }
  ];

  // Equipment options for different services
  const equipmentOptions = {
    chef: [
      'Professional knives',
      'Cooking utensils',
      'Portable stove',
      'Baking equipment',
      'Serving platters',
      'Kitchen thermometer',
      'Mixer/blender',
      'Food processor'
    ],
    barber: [
      'Professional clippers',
      'Hair scissors',
      'Beard trimmers',
      'Sterilization equipment',
      'Hair styling tools',
      'Barber cape',
      'Shaving supplies',
      'Sanitizing spray'
    ],
    beauty: [
      'Makeup kit',
      'Skincare tools',
      'Sterilization equipment',
      'Nail care tools',
      'Facial steamer',
      'Beauty lights',
      'Massage oils',
      'Hot towels'
    ],
    domestic: [
      'Vacuum cleaner',
      'Mop & bucket',
      'Cleaning supplies',
      'Iron & board',
      'Window cleaning tools',
      'Garden tools',
      'Broom & dustpan',
      'Polishing cloths'
    ],
    tutor: [
      'Textbooks',
      'Stationery kits',
      'Whiteboard/Markers',
      'Educational software',
      'Reference materials',
      'Practice tests',
      'Calculator',
      'Laptop/Tablet'
    ],
    photography: [
      'Professional DSLR/Mirrorless',
      'Variety of lenses',
      'External flashes',
      'Tripods',
      'Reflectors/Diffusers',
      'Editing software',
      'Memory cards',
      'Lighting equipment'
    ],
    sneaker: [
      'Premium brushes',
      'Eco-friendly cleaners',
      'Microfiber towels',
      'Shoe trees',
      'Waterproof sprays',
      'Odor eliminators',
      'Paint touch-up kits'
    ],
    washingmat: [
      'Industrial washers',
      'Large dryers',
      'Specialist detergents',
      'Stain removers',
      'Fabric softeners',
      'Drying racks',
      'Packing materials'
    ],
    animals: [
      'Leashes/Harnesses',
      'Pet carriers',
      'Grooming brushes',
      'Pet first-aid kit',
      'Treats/Food bowls',
      'Waste bags',
      'Animal shampoo',
      'Training clicks'
    ],
    default: [
      'Professional kit',
      'Safety equipment',
      'ID verification',
      'Communication device'
    ]
  };

  // Chef-specific options
  const mealTypes = [
    { id: 'breakfast', name: 'Breakfast' },
    { id: 'brunch', name: 'Brunch' },
    { id: 'lunch', name: 'Lunch' },
    { id: 'dinner', name: 'Dinner' },
    { id: 'appetizers', name: 'Appetizers & Canapés' },
    { id: 'desserts', name: 'Desserts' },
    { id: 'full-course', name: 'Full Course Meal' },
    { id: 'buffet', name: 'Buffet Style' }
  ];

  const cuisineTypes = [
    { id: 'italian', name: 'Italian' },
    { id: 'french', name: 'French' },
    { id: 'asian', name: 'Asian Fusion' },
    { id: 'mediterranean', name: 'Mediterranean' },
    { id: 'mexican', name: 'Mexican' },
    { id: 'indian', name: 'Indian' },
    { id: 'american', name: 'American' },
    { id: 'vegetarian', name: 'Vegetarian' },
    { id: 'vegan', name: 'Vegan' },
    { id: 'seafood', name: 'Seafood' },
    { id: 'bbq', name: 'BBQ & Grilling' },
    { id: 'custom', name: 'Custom Menu' }
  ];

  // Sneaker cleaner specific options
  const shoeBrands = [
    { id: 'nike', name: 'Nike' },
    { id: 'adidas', name: 'Adidas' },
    { id: 'jordan', name: 'Jordan' },
    { id: 'newbalance', name: 'New Balance' },
    { id: 'puma', name: 'Puma' },
    { id: 'reebok', name: 'Reebok' },
    { id: 'vans', name: 'Vans' },
    { id: 'converse', name: 'Converse' },
    { id: 'yeezy', name: 'Yeezy' },
    { id: 'other', name: 'Other' }
  ];

  const shoeConditions = [
    { id: 'lightlyWorn', name: 'Lightly Worn' },
    { id: 'moderatelyWorn', name: 'Moderately Worn' },
    { id: 'heavilyWorn', name: 'Heavily Worn' },
    { id: 'veryDirty', name: 'Very Dirty' },
    { id: 'stained', name: 'Stained' },
    { id: 'damaged', name: 'Damaged' }
  ];

  // Animal care specific options
  const animalTypes = [
    { id: 'dog', name: 'Dog', icon: <FaDog /> },
    { id: 'cat', name: 'Cat', icon: <FaCat /> },
    { id: 'bird', name: 'Bird', icon: <FaDove /> },
    { id: 'fish', name: 'Fish', icon: <FaFish /> },
    { id: 'horse', name: 'Horse', icon: <FaHorse /> },
    { id: 'rabbit', name: 'Rabbit', icon: <FaPaw /> },
    { id: 'hamster', name: 'Hamster', icon: <FaPaw /> },
    { id: 'reptile', name: 'Reptile', icon: <FaPaw /> },
    { id: 'multiple', name: 'Multiple Animals', icon: <FaUserFriends /> }
  ];

  // Override these with more detailed versions if needed
  const washingMatSizes = [
    { id: 'small', name: 'Small (under 2x3 ft)' },
    { id: 'medium', name: 'Medium (2x3 to 4x6 ft)' },
    { id: 'large', name: 'Large (4x6 to 6x9 ft)' },
    { id: 'xlarge', name: 'Extra Large (over 6x9 ft)' }
  ];

  const washingMatMaterials = [
    { id: 'cotton', name: 'Cotton' },
    { id: 'synthetic', name: 'Synthetic' },
    { id: 'rubber', name: 'Rubber Backed' },
    { id: 'wool', name: 'Wool' },
    { id: 'coconut', name: 'Coconut Fiber' },
    { id: 'microfiber', name: 'Microfiber' }
  ];

  const genericStainLevels = [
    { id: 'light', name: 'Light Stains' },
    { id: 'moderate', name: 'Moderate Stains' },
    { id: 'heavy', name: 'Heavy Stains' },
    { id: 'setIn', name: 'Set-in Stains' }
  ];

  // Enhanced Location States
  const [locationData, setLocationData] = useState({
    latitude: null,
    longitude: null,
    formattedAddress: '',
    placeId: '',
    city: '',
    province: '',
    postalCode: '',
    country: 'South Africa'
  });
;

  const [bookingData, setBookingData] = useState({
    name: '',
    phone: '',
    selectedServices: [],
    serviceDescription: '',
    serviceFrequency: '',
    locationOption: 'comeToYou',
    address: '',
    date: '',
    time: '',
    bringFood: 'no',
    message: '',
    selectedHaircut: '',
    beardStyle: '',
    hairLength: '',
    specialRequirements: '',
    mealType: '',
    cuisinePreference: '',
    numberOfGuests: '',
    dietaryRestrictions: '',
    cookingEquipment: '',
    ingredientsProvided: 'no',
    // Photography-specific fields
    photographyType: '',
    sessionDuration: '',
    numberOfPeople: '',
    photographyRequirements: '',
    deliveryFormat: '',
    // Service provider fields
    addressProvided: '',
    foodProvided: 'no',
    electricityProvided: 'no',
    cleaningArrengement: 'no',
    equipmentProvided: 'no',
    otherDetails: '',
    // Beauty & Glam specific fields
    beautyCategory: '',
    beautyOccasion: '',
    glamFinish: '',
    peopleCount: '1 Person (Solo)',
    lashPreference: '',
    nailStyle: '',
    hairStyle: '',
    touchUpKit: 'Standard Appointment',
    skinHairNotes: '',
    serviceLocationType: 'client_home'
  });

  const { id } = useParams();
  const navigate = useNavigate();

  const { bookedDates, isTimeSlotBooked, isDateFullyBooked, isDateBooked, getAvailabilityNotice } = useBookedSlots(helper?._id || id);

  // Calculate total price
  useEffect(() => {
    if (helper) {
      const basePrice = parseInt(helper.regularPrice) || 0;
      const travelFee = bookingData.locationOption === 'comeToYou' ? (parseInt(helper.travelFee) || 0) : 0;
      
      // Calculate selected services price
      let selectedServicesPrice = 0;
      bookingData.selectedServices.forEach(serviceId => {
        const option = serviceOptions.find(opt => opt.id === serviceId);
        if (option && option.price) {
          // Handle "R450" or "450" format
          const price = parseFloat(String(option.price).replace(/[^\d.]/g, '')) || 0;
          selectedServicesPrice += price;
        }
      });

      const totalBase = selectedServicesPrice > 0 ? selectedServicesPrice : basePrice;
      const serviceFee = Math.round(totalBase * 0.1);
      setTotalPrice(totalBase + travelFee + serviceFee);
    }
  }, [helper, bookingData.selectedServices, serviceOptions]);




  // Scroll detection for navigation transparency
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Share function
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${getProfessionalTitle(helper?.type)} services by ${helper?.name}`,
        text: helper?.description,
        url: window.location.href,
      }).catch((error) => console.error('Error sharing:', error));
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  // Get relative time from timestamp
  const getRelativeTime = (dateString) => {
    const diffInMs = new Date() - new Date(dateString);
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    if (diffInDays < 1) return 'Today';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    const diffInWeeks = Math.floor(diffInDays / 7);
    if (diffInWeeks < 4) return `${diffInWeeks} week${diffInWeeks > 1 ? 's' : ''} ago`;
    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths < 12) return `${diffInMonths} month${diffInMonths > 1 ? 's' : ''} ago`;
    const diffInYears = Math.floor(diffInDays / 365);
    return `${diffInYears} year${diffInYears > 1 ? 's' : ''} ago`;
  };

  // Fetch comment ratings and total count on load
  useEffect(() => {
    const fetchRatings = async () => {
      if (helper && helper._id) {
        setCommentsLoading(true);
        try {
          const res = await fetch(`/api/helper-comments/${helper._id}?limit=6`);
          const data = await res.json();
          if (res.ok) {
            setCommentCount(data.totalComments || 0);
            setTopComments(data.comments || []);
            setRatingCounts(data.ratingCounts || {});
            if (data.ratings) {
              setRatings({
                cleanliness: data.ratings.cleanliness || 0,
                communication: data.ratings.staff || 0,
                overall: data.ratings.overall || 0,
                beautyCleaning: data.ratings.beautyCleaning || 0,
                beautyCommunication: data.ratings.beautyCommunication || 0,
                beautyEquipment: data.ratings.beautyEquipment || 0,
                hairdressing: data.ratings.hairdressing || 0,
                timeliness: data.ratings.timeliness || 0
              });
            }
          }
        } catch (error) {
          console.error('Error fetching ratings:', error);
        } finally {
          setCommentsLoading(false);
        }
      }
    };
    fetchRatings();
  }, [helper]);

  // Toggle favorite function is now handled by useWishlist hook

  const handleHostRate = async (action) => {
    if (!currentUser) {
      navigate('/sign-in');
      return;
    }
    if (ratingLoading) return;
    
    const helperUserId = helper.userRef?._id || helper.userRef;
    
    if (currentUser._id === helperUserId) {
      alert("You cannot rate yourself!");
      return;
    }

    try {
      setRatingLoading(true);
      const res = await fetch(`/api/user/rate-host/${helperUserId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentUser.token}`
        },
        body: JSON.stringify({ action }),
      });

      const data = await res.json();
      if (res.ok) {
        setLikeCount(data.likeCount);
        setDislikeCount(data.dislikeCount);
        setIsLiked(data.userAction === 'like');
        setIsDisliked(data.userAction === 'dislike');
      }
    } catch (error) {
      console.error('Error rating host:', error);
    } finally {
      setRatingLoading(false);
    }
  };

  // Location type classification
  const locationTypes = {
    COME_TO_CLIENT: 'comeToYou',
    PROVIDER_LOCATION: 'goToThem',
    NEUTRAL_VENUE: 'neutralVenue'
  };

  // Enhanced location validation and formatting
  const validateAndFormatAddress = (address) => {
    if (!address) {
      throw new Error('Please provide a complete address');
    }

    // Basic validation for required components
    const addressStr = address.trim();
    if (addressStr.length < 10) {
      throw new Error('Please provide a more detailed address');
    }

    // Check for basic address components
    const hasStreet = /\d+\s+[A-Za-z\s]+/.test(addressStr);
    const hasCity = /[A-Za-z]{2,}/.test(addressStr);

    if (!hasStreet || !hasCity) {
      throw new Error('Please include street number, street name, and city');
    }

    return addressStr;
  };

  // Generate comprehensive map links
  const generateMapLink = (address) => {
    if (!address) return '';
    const encodedAddress = encodeURIComponent(address);
    // Official Google Maps Search URL format for better cross-platform reliability
    return `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;
  };

  // Enhanced location handler
  const handleLocationInfo = (bookingData, provider) => {
    const locationInfo = {
      type: bookingData.locationOption,
      displayName: '',
      address: '',
      instructions: '',
      travelFee: 0,
      mapLink: '',
      coordinates: null
    };

    switch (bookingData.locationOption) {
      case locationTypes.COME_TO_CLIENT:
        locationInfo.displayName = 'Client Address';
        locationInfo.address = bookingData.address;
        locationInfo.travelFee = provider.travelFee || 0;
        locationInfo.instructions = bookingData.specialInstructions || '';
        locationInfo.mapLink = generateMapLink(bookingData.address);
        break;

      case locationTypes.PROVIDER_LOCATION:
        locationInfo.displayName = getProviderLocationName(provider.type);
        locationInfo.address = provider.businessAddress || provider.address || 'Address not specified';
        locationInfo.instructions = provider.locationInstructions || '';
        locationInfo.mapLink = generateMapLink(locationInfo.address, provider.type);
        break;

      default:
        locationInfo.displayName = `${getProfessionalTitle(provider.type)}'s Location`;
        locationInfo.address = provider.address || 'Address not specified';
        locationInfo.mapLink = generateMapLink(locationInfo.address, provider.type);
    }

    return locationInfo;
  };

  // Get provider-specific location names
  const getProviderLocationName = (serviceType) => {
    const locationNames = {
      chef: "Chef's Kitchen",
      barber: "Barber Shop",
      barbar: "Barber Shop",
      tattoo: "Tattoo Studio",
      beauty: "Beauty Salon",
      spa: "Spa Center",
      photography: "Photography Studio",
      massage: "Massage Studio",
      tutor: "Tutoring Center",
      sneaker: "Sneaker Cleaning Studio",
      washingmat: "Mat Washing Facility",
      animals: "Animal Care Center",
      default: "Professional's Location"
    };

    return locationNames[serviceType] || locationNames.default;
  };

  // Enhanced location-specific messaging
  const getLocationSpecificMessage = (bookingData, provider) => {
    const locationInfo = handleLocationInfo(bookingData, provider);

    let locationMessage = `📍 *Location Details:*%0A`;
    locationMessage += `• Type: ${locationInfo.displayName}%0A`;

    if (locationInfo.address) {
      locationMessage += `• Address: ${locationInfo.address}%0A`;
      if (locationInfo.mapLink && locationInfo.mapLink !== '#') {
        locationMessage += `• Navigation: ${locationInfo.mapLink}%0A`;
      }
    }

    if (locationInfo.instructions) {
      locationMessage += `• Instructions: ${locationInfo.instructions}%0A`;
    }

    if (locationInfo.travelFee > 0) {
      locationMessage += `• Travel Fee: R${locationInfo.travelFee}%0A`;
    }

    return locationMessage;
  };

  // ==================== END ENHANCED LOCATION FUNCTIONS ====================



  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };


  useEffect(() => {
    const fetchHelper = async () => {
      if (!id) { // Guard against missing helper ID
        setLoading(false);
        setError('Helper ID is missing.');
        return;
      }
      try {
        setLoading(true);
        const res = await fetch(`/api/helper/get/${id}`);

        if (!res.ok) {
          throw new Error('Failed to fetch helper details');
        }

        const data = await res.json();
        setHelper(data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchHelper();
  }, [id]);

  useEffect(() => {
    const fetchStatuses = async () => {
      if (!helper || !currentUser) return;

      const helperUserId = helper.userRef?._id || helper.userRef;
      if (!helperUserId) return;

      try {
        // Fetch Host Ratings
        const ratingRes = await fetch(`/api/user/host-ratings/${helperUserId}`, {
            headers: { 'Authorization': `Bearer ${currentUser.token}` }
        });
        if (ratingRes.ok) {
          const ratingData = await ratingRes.json();
          setLikeCount(ratingData.likeCount);
          setDislikeCount(ratingData.dislikeCount);
          setIsLiked(ratingData.userAction === 'like');
          setIsDisliked(ratingData.userAction === 'dislike');
        }


      } catch (error) {
        console.error('Error fetching statuses:', error);
      }
    };

    if (helper && currentUser) {
      fetchStatuses();
    }
  }, [helper, currentUser?._id, id]);

  // Scroll detection for booking belt
  useEffect(() => {
    const handleScroll = () => {
      const scrollThreshold = 600;
      setShowBookingBelt(window.scrollY > scrollThreshold);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Format phone numbers for WhatsApp
  const formatContactForWhatsApp = (contact) => {
    if (!contact) return null;
    const contactStr = String(contact);
    const digitsOnly = contactStr.replace(/\D/g, '');
    if (digitsOnly.startsWith('0')) {
      return '27' + digitsOnly.substring(1);
    }
    return digitsOnly;
  };

  const handleBookingChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBookingData({
      ...bookingData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // Handle service selection
  const handleServiceSelection = (serviceId) => {
    setBookingData(prev => {
      const selectedServices = [...prev.selectedServices];
      const serviceIndex = selectedServices.indexOf(serviceId);

      if (serviceIndex > -1) {
        selectedServices.splice(serviceIndex, 1);
      } else {
        selectedServices.push(serviceId);
      }

      return { ...prev, selectedServices };
    });
  };

  // Handle equipment selection
  const handleEquipmentSelection = (equipment) => {
    const currentEquipment = bookingData.cookingEquipment ? bookingData.cookingEquipment.split(',') : [];
    const index = currentEquipment.indexOf(equipment);

    if (index > -1) {
      currentEquipment.splice(index, 1);
    } else {
      currentEquipment.push(equipment);
    }

    setBookingData({
      ...bookingData,
      cookingEquipment: currentEquipment.join(',')
    });
  };

  // Handle file attachments
  const handleAttachmentChange = (e) => {
    const files = Array.from(e.target.files);

    // Validate files
    const validFiles = files.filter(file => {
      const isImage = file.type.startsWith('image/');
      const isPDF = file.type === 'application/pdf';
      const isSizeValid = file.size <= 5 * 1024 * 1024; // 5MB

      return (isImage || isPDF) && isSizeValid;
    });

    // Limit to 2 files
    const newAttachments = [...attachments, ...validFiles].slice(0, 2);
    setAttachments(newAttachments);
  };

  // Remove attachment
  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  // Upload files to cloud storage (Firebase Storage)
  const uploadFilesToCloud = async (files) => {
    setIsUploading(true);
    try {
      const storage = getStorage(app);
      const uploadPromises = files.map(file => {
        return new Promise((resolve, reject) => {
          const cleanFileName = file.name.replace(/[^a-zA-Z0-9.]/g, '');
          const fileName = `${new Date().getTime()}_${cleanFileName}`;
          const storageRef = ref(storage, `attachments/${fileName}`);
          const uploadTask = uploadBytesResumable(storageRef, file);

          uploadTask.on(
            "state_changed",
            null, // Could add progress tracking here if needed
            (error) => reject(error),
            async () => {
              const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
              resolve({
                name: file.name,
                url: downloadURL,
                type: file.type.startsWith('image/') ? 'image' : 'pdf',
                size: file.size
              });
            }
          );
        });
      });

      return await Promise.all(uploadPromises);
    } catch (error) {
      console.error('File upload error:', error);
      throw error;
    } finally {
      setIsUploading(false);
    }
  };

  // ================================ BOOKING START HERE================

  // Enhanced helper function to get location requirements
  const getLocationRequirements = (serviceType) => {
    const requirements = {
      chef: {
        comeToYou: [
          'kitchenAccess',
          'cookingEquipment',
          'diningSpace',
          'powerOutlets'
        ],
        goToThem: [
          'professionalKitchen',
          'diningFacilities'
        ]
      },
      barber: {
        comeToYou: [
          'workspace',
          'powerSource',
          'mirrorAccess'
        ],
        goToThem: [
          'professionalSetup',
          'sanitation'
        ]
      },
      photography: {
        comeToYou: [
          'shootingSpace',
          'naturalLight',
          'powerOutlets'
        ],
        goToThem: [
          'studioSpace',
          'lightingEquipment'
        ]
      },
      beauty: {
        comeToYou: [
          'cleanSpace',
          'powerSource',
          'mirrorAccess'
        ],
        goToThem: [
          'sanitizedStation',
          'professionalTools'
        ]
      },
      domestic: {
        comeToYou: [
          'cleanSpace',
          'waterAccess',
          'powerOutlets'
        ],
        goToThem: [
          'professionalEquipment'
        ]
      },
      sneaker: {
        comeToYou: [
          'workSurface',
          'waterAccess',
          'powerOutlets'
        ],
        goToThem: [
          'professionalCleaningStation'
        ]
      },
      washingmat: {
        comeToYou: [
          'waterAccess',
          'outdoorSpace',
          'dryingArea'
        ],
        goToThem: [
          'industrialWasher',
          'dryingFacility'
        ]
      },
      animals: {
        comeToYou: [
          'secureSpace',
          'waterAccess',
          'outdoorArea'
        ],
        goToThem: [
          'professionalFacility',
          'outdoorRuns'
        ]
      }
    };

    return requirements[serviceType] || {
      comeToYou: ['cleanWorkspace', 'powerOutlets'],
      goToThem: ['professionalEnvironment']
    };
  };


  // Enhanced WhatsApp booking function with all form data
  const handleQuickBooking = () => {
    if (!helper?.contact) {
      alert(`${getProfessionalTitle(helper?.type)} contact information is missing.`);
      return;
    }

    // Basic validation
    if (!bookingData.name || !bookingData.phone) {
      alert("Please fill in your name and phone number first.");
      return;
    }

    if (bookingData.date && isDateFullyBooked(bookingData.date)) {
      alert("This date is not available (fully booked). Please select another date.");
      return;
    }

    if (bookingData.date && bookingData.time && isTimeSlotBooked(bookingData.date, bookingData.time)) {
      alert("This time slot is already booked and not available. Please choose another time.");
      return;
    }

    // Enhanced location validation for quick booking
    if (bookingData.locationOption === 'comeToYou' && !bookingData.address) {
      alert("Please provide your address for home service in the booking form.");
      return;
    }

    const clientPhone = formatContactForWhatsApp(bookingData.phone);
    const acceptMessage = `Accept the service ${bookingData.name}, I accept your booking for ${helper.name}. See you then!`;
    const declineMessage = `Decline the service ${bookingData.name}, I'm unable to accept this booking. Can we try another time?`;

    const acceptLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(acceptMessage)}` : '';
    const declineLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(declineMessage)}` : '';

    // Enhanced location handling for quick booking
    const locationInfo = handleLocationInfo(bookingData, helper);

    let message = `✨ *QUICK BOOKING REQUEST* ✨\n\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `👤 *CLIENT DETAILS*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `👤 *Name:* ${bookingData.name}\n`;
    message += `📱 *Phone:* ${bookingData.phone || 'Not provided'}\n`;
    if (bookingData.date) message += `📅 *Date:* ${bookingData.date}\n`;
    if (bookingData.time) message += `⏰ *Time:* ${bookingData.time}\n\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `💇‍♀️ *SERVICE SUMMARY*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `🏪 *Provider:* ${helper.name}\n`;
    if (bookingData.selectedServices.length > 0) {
      bookingData.selectedServices.forEach(id => {
        const s = serviceOptions.find(opt => opt.id === id);
        if (s) {
          message += `🔹 *${s.name}:* R${s.price}\n`;
        } else {
          message += `🔹 *${id}*\n`;
        }
      });
    }
    message += `💰 *TOTAL PRICE:* *R${totalPrice}*\n\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `📍 *LOCATION & NAVIGATION*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `🏠 *Type:* ${locationInfo.displayName}\n`;
    if (locationInfo.address) {
      message += `📍 *Address:* ${locationInfo.address}\n`;
      const mapLink = generateMapLink(locationInfo.address);
      if (mapLink) message += `🗺️ *Navigate:* ${mapLink}\n`;
    }
    message += `\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `⚡ *QUICK ACTIONS*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    if (acceptLink) message += `✅ *ACCEPT:*\n${acceptLink}\n\n`;
    if (declineLink) message += `❌ *REJECT:*\n${declineLink}\n\n`;

    message += `───────────────\n`;
    message += `_Sent via loopOut_ 📱`;

    const whatsappUrl = `https://wa.me/${formatContactForWhatsApp(helper.contact)}?text=${encodeURIComponent(message)}`;
    
    // Save to Database first
    // Determine device type
    const deviceType = /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(navigator.userAgent) ? 'Mobile' : 'Desktop';
    const requestLocation = bookingData.locationOption === 'comeToYou' ? bookingData.address : (bookingData.address || '');

    const bookingToSave = {
      userId: currentUser?._id || "guest",
      helperId: helper._id,
      startDate: bookingData.date + "T" + (bookingData.time || "00:00"),
      endDate: bookingData.date + "T" + (bookingData.time || "00:00"),
      totalPrice: totalPrice,
      selectedServices: (bookingData.selectedServices || []).map((id) => serviceOptions.find((option) => String(option.id) === String(id))?.name).filter((name) => name && helper?.serviceList?.some((service) => service.name === name)),
      phone: bookingData.phone,
      message: message,
      subtype: helper.type,
      deviceType,
      requestLocation,
      locationOption: bookingData.locationOption,
      status: 'pending',
      type: 'helper'
    };

    const token = localStorage.getItem('access_token') || localStorage.getItem('token') || currentUser?.token || currentUser?.access_token;
    fetch('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      credentials: 'include',
      body: JSON.stringify(bookingToSave)
    }).then(async (res) => {
      if (res.ok) {
        pushPhoneNotification({
          title: '🎉 Booking Request Sent',
          message: `Your booking for ${helper?.name || 'Beauty Service'} has been placed. Check notifications for updates!`,
          type: 'success',
          link: '/notifications'
        });
      } else {
        const err = await res.json().catch(() => ({}));
        console.error('Booking save failed:', err?.error || res.status);
      }
    }).catch(err => console.error('Failed to save quick booking:', err));

    window.open(whatsappUrl, '_blank');
  };

  // ==================== ENHANCED BOOKING SUBMIT FUNCTION ====================
  
  const handleEscrowCheckout = async () => {
    if (!currentUser) {
      window.location.href = '/sign-in';
      return;
    }

    if (bookingData.date && isDateFullyBooked(bookingData.date)) {
      alert("This date is not available (fully booked). Please select another date.");
      return;
    }

    if (bookingData.date && bookingData.time && isTimeSlotBooked(bookingData.date, bookingData.time)) {
      alert("This time slot is already booked and not available. Please choose another time.");
      return;
    }

    try {
      setIsUploading(true);
      const res = await fetch('/api/payment/escrow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
           userId: currentUser._id,
           amount: totalPrice,
           name: currentUser.username,
           email: currentUser.email,
           serviceId: helper ? helper._id : (service ? service._id : ''),
           providerName: helper ? helper.name : (service ? service.name : '')
        })
      });
      const data = await res.json();
      if (data.success && data.payfast) {
         const form = document.createElement('form');
         form.method = 'POST';
         form.action = data.payfast.url;
         Object.keys(data.payfast.fields).forEach(key => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = key;
            input.value = data.payfast.fields[key];
            form.appendChild(input);
         });
         document.body.appendChild(form);
         form.submit();
      } else {
         console.error(data.message);
         setIsUploading(false);
      }
    } catch(err) {
      console.error(err);
      setIsUploading(false);
    }
  };

  const handleBookingSubmit =async (e) => {
    e.preventDefault();

    if (!helper?.contact) {
      alert(`${getProfessionalTitle(helper?.type)} contact information is missing. Please try another contact method.`);
      return;
    }

    if (bookingData.date && isDateFullyBooked(bookingData.date)) {
      alert("This date is not available (fully booked). Please select another date.");
      return;
    }

    if (bookingData.date && bookingData.time && isTimeSlotBooked(bookingData.date, bookingData.time)) {
      alert("This time slot is already booked and not available. Please choose another time.");
      return;
    }

    // Enhanced location validation
    if (bookingData.locationOption === 'comeToYou' && !bookingData.address) {
      alert("Please provide your address for home service.");
      return;
    }

    try {
      // Validate and format address
      if (bookingData.locationOption === 'comeToYou') {
        const formattedAddress = validateAndFormatAddress(bookingData.address);
        setBookingData(prev => ({ ...prev, address: formattedAddress }));
      }
    } catch (error) {
      alert(error.message);
      return;
    }

    // Validate service selection
    if (
      (helper.type === 'domestic' || helper.type === 'maid' || helper.type === 'beauty' || helper.type === 'spa' || helper.type === 'barber' || helper.type === 'barbar' || helper.type === 'chef' || helper.type === 'tattoo' || helper.type === 'tutor' || helper.type === 'photography' || helper.type === 'sneaker' || helper.type === 'washingmat' || helper.type === 'animals' || helper.type === 'transport') &&
      bookingData.selectedServices.length === 0
    ) {
      alert("Please select at least one service you need.");
      return;
    }

    let uploadedFiles = [];

    if (attachments.length > 0) {
      setIsUploading(true);
      try {
        uploadedFiles = await uploadFilesToCloud(attachments);
      } catch (error) {
        console.error("File upload failed:", error);
        alert("Failed to upload attachments. Please try again without files or contact support.");
        setIsUploading(false);
        return;
      }
      setIsUploading(false);
    }

    // Format the client's phone number for the reply link
    const clientPhone = bookingData.phone ? formatContactForWhatsApp(bookingData.phone) : '';

    // Define the accept and decline messages and their corresponding links
    const acceptMessage = `Accept the service ${bookingData.name}, I accept your booking for ${helper.name} on ${bookingData.date} at ${bookingData.time}. See you then!`;
    const declineMessage = `Decline the service ${bookingData.name}, I'm unable to accept ${bookingData.date} at ${bookingData.time}. Can we try another time?`;

    const acceptLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(acceptMessage)}` : '';
    const declineLink = clientPhone ? `https://wa.me/${clientPhone}?text=${encodeURIComponent(declineMessage)}` : '';

    // Enhanced location handling
    const locationInfo = handleLocationInfo(bookingData, helper);

    // Generate verification code
    const verificationCode = Math.floor(100000 + Math.random() * 900000);

    // Build the main WhatsApp message with premium structure
    let message = `✨ *NEW ${getProfessionalTitle(helper.type).toUpperCase()} BOOKING* ✨\n\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `👤 *CLIENT DETAILS*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `👤 *Name:* ${bookingData.name}\n`;
    message += `📱 *Phone:* ${bookingData.phone || 'Not provided'}\n`;
    message += `📅 *Date:* ${bookingData.date || 'Not specified'}\n`;
    message += `⏰ *Time:* ${bookingData.time || 'Not specified'}\n`;
    if (bookingData.serviceFrequency) message += `🔄 *Frequency:* ${bookingData.serviceFrequency}\n`;
    if (bookingData.selectedPerformer || bookingData.performerName) {
      message += `👑 *Performer:* ${bookingData.selectedPerformer || bookingData.performerName}\n`;
    }
    message += `\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `💇‍♀️ *SERVICE SUMMARY*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `🏪 *Service:* ${helper.name}\n`;
    message += `🏷️ *Type:* ${getProfessionalTitle(helper.type)}\n`;

    // Add selected services
    if (bookingData.selectedServices.length > 0) {
      bookingData.selectedServices.forEach(id => {
        const s = serviceOptions.find(opt => opt.id === id);
        if (s) {
          message += `🔹 *${s.name}:* R${s.price}\n`;
        } else {
          message += `🔹 *${id}*\n`;
        }
      });
      message += `💰 *TOTAL PRICE:* *R${totalPrice}*\n`;
    } else {
      message += `💰 *Base Price:* R${helper.regularPrice || 0}\n`;
      message += `💰 *TOTAL PRICE:* *R${totalPrice}*\n`;
    }

    // Add service-specific details (Beauty & Glam)
    message += `\n💄 *BEAUTY & GLAM DETAILS:*\n`;
    if (bookingData.beautyOccasion) message += `✨ *Occasion:* ${bookingData.beautyOccasion}\n`;
    if (bookingData.beautyCategory) message += `💅 *Glam Category / Focus:* ${bookingData.beautyCategory}\n`;
    if (bookingData.glamFinish) message += `🌟 *Look Finish & Style:* ${bookingData.glamFinish}\n`;
    if (bookingData.peopleCount) message += `👥 *Number of People / Party:* ${bookingData.peopleCount}\n`;
    if (bookingData.lashPreference) message += `👁️ *Lashes Preference:* ${bookingData.lashPreference}\n`;
    if (bookingData.hairStyle) message += `💇‍♀️ *Hair Styling / Prep:* ${bookingData.hairStyle}\n`;
    if (bookingData.nailStyle) message += `💅 *Nails & Shape:* ${bookingData.nailStyle}\n`;
    if (bookingData.touchUpKit) message += `🎁 *Touch-Up Kit:* ${bookingData.touchUpKit}\n`;
    if (bookingData.skinHairNotes) message += `📝 *Skin / Hair Notes & Allergies:* ${bookingData.skinHairNotes}\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `📍 *LOCATION & NAVIGATION*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `🏠 *Type:* ${locationInfo.displayName}\n`;
    if (locationInfo.address && locationInfo.address !== 'Address not specified') {
      message += `📍 *Address:* ${locationInfo.address}\n`;
      const mapLink = generateMapLink(locationInfo.address);
      if (mapLink) message += `🗺️ *Navigate:* ${mapLink}\n`;
    }
    if (locationInfo.travelFee > 0) message += `🚗 *Travel Fee:* R${locationInfo.travelFee}\n`;
    message += `\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `⚡ *PROVISIONS*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `🍽️ *Food provided by client:* ${bookingData.foodProvided === 'yes' ? '✅ Yes' : '❌ No'}\n`;
    message += `🔌 *Electricity available:* ${bookingData.electricityProvided === 'yes' ? '✅ Yes' : '❌ No'}\n\n`;

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `💬 *COMMENTS & NOTES*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `📝 ${bookingData.specialRequirements ? bookingData.specialRequirements : '_No special requirements_'}\n\n`;

    // Add attachments if they exist
    if (uploadedFiles.length > 0) {
      message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
      message += `📎 *ATTACHMENTS*\n`;
      message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
      uploadedFiles.forEach((file) => {
        message += `🔹 ${file.name}: ${file.url}\n`;
      });
      message += `\n`;
    }

    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `⚡ *QUICK ACTIONS*\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    if (acceptLink) message += `✅ *ACCEPT:*\n${acceptLink}\n\n`;
    if (declineLink) message += `❌ *REJECT:*\n${declineLink}\n\n`;

    message += `🔐 *Verification Code:* \`${verificationCode}\`\n`;
    message += `───────────────\n`;
    message += `_Sent via loopOut_ 📱`;

    // Open WhatsApp with properly encoded message
    const whatsappUrl = `https://wa.me/${formatContactForWhatsApp(helper.contact)}?text=${encodeURIComponent(message)}`;
    
    // Save to Database first
    // Create a very descriptive subtype for the dashboard/cart
    let bookingSubtype = helper.type;
    if (bookingData.selectedServices.length > 0) {
      bookingSubtype = bookingData.selectedServices.map(s => {
        // Find the service name from options
        const opt = serviceOptions.find(o => o.id === s);
        return opt ? opt.name : s;
      }).join(', ');
    }
    
    // Add specific transport details if available
    if (helper.type === 'transport' && bookingData.specialRequirements) {
      const requirements = bookingData.specialRequirements.toLowerCase();
      if (requirements.includes('pretor') && requirements.includes('johan')) {
        bookingSubtype = `Route: Pretoria ↔ JHB`;
      }
    }

    // Determine device type
    const deviceType = /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(navigator.userAgent) ? 'Mobile' : 'Desktop';
    const requestLocation = bookingData.locationOption === 'comeToYou' ? bookingData.address : (bookingData.address || '');

    const bookingToSave = {
      userId: currentUser?._id || "guest",
      helperId: helper._id,
      startDate: (bookingData.date || "2000-01-01") + "T" + (bookingData.time || "00:00"),
      endDate: (bookingData.date || "2000-01-01") + "T" + (bookingData.time || "00:00"),
      totalPrice: totalPrice,
      selectedServices: (bookingData.selectedServices || []).map((id) => serviceOptions.find((option) => String(option.id) === String(id))?.name).filter((name) => name && helper?.serviceList?.some((service) => service.name === name)),
      phone: bookingData.phone,
      message,
      subtype: bookingSubtype,
      deviceType,
      requestLocation,
      locationOption: bookingData.locationOption,
      status: 'pending',
      type: 'helper'
    };

    const token = localStorage.getItem('access_token') || localStorage.getItem('token') || currentUser?.token || currentUser?.access_token;
    fetch('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      credentials: 'include',
      body: JSON.stringify(bookingToSave)
    }).then(async (res) => {
      if (res.ok) {
        pushPhoneNotification({
          title: '🎉 Booking Sent Successfully!',
          message: `Your booking for ${helper?.name || 'Beauty Service'} has been placed. Check notifications for updates!`,
          type: 'success',
          link: '/notifications'
        });
      } else {
        const err = await res.json().catch(() => ({}));
        console.error('Booking save failed:', err?.error || res.status);
      }
    }).catch(err => console.error('Failed to save booking:', err));

    window.open(whatsappUrl, '_blank');

    // Close the booking form overlay after sending
    closeBookingFormOverlay();

    // Reset attachments after sending
    setAttachments([]);
  };
  // ==================== END ENHANCED BOOKING SUBMIT FUNCTION ====================

  // Function to open full-page booking form overlay
  const openBookingFormOverlay = () => {
    setShowBookingFormOverlay(true);
    // Prevent body scrolling when overlay is open
    document.body.style.overflow = 'hidden';
  };

  // Function to close full-page booking form overlay
  const closeBookingFormOverlay = () => {
    setShowBookingFormOverlay(false);
    // Restore body scrolling
    document.body.style.overflow = 'auto';
  };

  // Full screen gallery functions
  const openFullScreenGallery = (index = 0) => {
    setCurrentGalleryIndex(index);
    setShowFullScreenGallery(true);
    document.body.style.overflow = 'hidden';
  };

  const closeFullScreenGallery = () => {
    setShowFullScreenGallery(false);
    document.body.style.overflow = 'auto';
  };

  const nextImage = () => {
    if (helper.imageUrls && helper.imageUrls.length > 0) {
      setCurrentGalleryIndex((prevIndex) =>
        prevIndex === helper.imageUrls.length - 1 ? 0 : prevIndex + 1
      );
    }
  };

  const prevImage = () => {
    if (helper.imageUrls && helper.imageUrls.length > 0) {
      setCurrentGalleryIndex((prevIndex) =>
        prevIndex === 0 ? helper.imageUrls.length - 1 : prevIndex - 1
      );
    }
  };

  const whatsappNumber = helper ? formatContactForWhatsApp(helper.contact) : null;
  const whatsappLink = whatsappNumber
    ? `https://wa.me/${whatsappNumber}?text=Hi ${helper.name}, I'm interested in your ${getProfessionalTitle(helper.type).toLowerCase()} services.`
    : null;

  const handleInternalMessage = async () => {
    if (!currentUser) {
      navigate('/sign-in');
      return;
    }
    
    // Check if the user is trying to message themselves
    if (currentUser._id === helper.userRef) {
      alert("You cannot message yourself.");
      return;
    }

    try {
      // Create/Get conversation by sending an initial message
      const res = await fetch('/api/messages/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receiverId: helper.userRef,
          content: `Hi ${helper.name}, I'm interested in your ${getProfessionalTitle(helper.type).toLowerCase()} services.`,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        navigate(`/messages/${data.conversationId || data._id}`);
      } else {
        alert(data.message || 'Failed to start conversation');
      }
    } catch (error) {
      console.error('Error starting conversation:', error);
      alert('An error occurred. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-rose-500 mx-auto"></div>
          <p className="mt-4 text-lg text-gray-600 font-medium">Loading professional details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 p-6 rounded-2xl">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <FaExclamationTriangle className="h-6 w-6 text-red-500" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-red-800">Error loading profile</h3>
              <p className="mt-2 text-red-600">{error}</p>
              <div className="mt-4 flex gap-3">
                <button
                  onClick={() => window.location.reload()}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  Try Again
                </button>
                <button
                  onClick={() => navigate(-1)}
                  className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Go Back
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!helper) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center py-16">
          <h2 className="text-2xl font-bold text-gray-800 mb-3">Professional not found</h2>
          <p className="text-gray-600 mb-6">The professional you're looking for doesn't exist or may have been removed.</p>
          <button
            onClick={() => navigate('/helper-home-page')}
            className="px-6 py-3 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors font-medium"
          >
            Browse Professionals
          </button>
        </div>
      </div>
    );
  }

  const description = helper.description || '';
  const displayText = showFullDescription
    ? description
    : description.slice(0, 300) + (description.length > 300 ? "..." : "");

  const serviceEquipmentOptions = equipmentOptions[helper.type] || equipmentOptions.default;

  return (
    <div className="min-h-screen app-safe-content-bottom pb-36 lg:pb-0 bg-white text-slate-900">
      {/* Navigation - Transparent on top of image */}
      <nav className={`app-safe-top fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-slate-50/90 backdrop-blur-md shadow-sm border-b border-slate-200/50' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <button
               onClick={() => navigate(-1)}
               className={`p-2.5 rounded-full transition-all duration-300 ${isScrolled ? 'bg-slate-100 hover:bg-slate-200 text-slate-900' : 'bg-black/20 hover:bg-black/40 text-white backdrop-blur-sm'}`}
             >
               <ArrowLeftIcon className="w-5 h-5" />
             </button>

             <div className="flex items-center gap-2">
               <button
                 onClick={handleShare}
                 className={`p-2.5 rounded-full transition-all duration-300 ${isScrolled ? 'bg-slate-100 hover:bg-slate-200 text-slate-900' : 'bg-black/20 hover:bg-black/40 text-white backdrop-blur-sm'}`}
               >
                 <ShareIcon className="w-5 h-5" />
               </button>
              <button
                onClick={toggleFavorite}
                className={`p-2.5 rounded-full transition-all duration-300 ${isScrolled ? 'bg-slate-100 hover:bg-slate-200 text-slate-900' : 'bg-black/20 hover:bg-black/40 backdrop-blur-sm'}`}
              >
                {isFavorite ?
                  <HeartIconSolid className="text-xl text-rose-500 w-6 h-6" /> :
                  <HeartIcon className={`text-xl w-6 h-6 ${isScrolled ? 'text-slate-900' : 'text-white'}`} />
                }
              </button>
            </div>
          </div>
        </div>
      </nav>

      <ListingPhotoGallery images={helper.imageUrls} alt={helper.name} onOpen={openFullScreenGallery} emptyEmoji="✨" emptyTitle="Portfolio photos coming soon" emptyDescription="This beauty provider has not added portfolio photos yet." />

      <ListingDetailShell>
        {/* Content Section */}
        <div className="mb-8 pt-7 border-b border-slate-200 pb-7">
          <div className="mb-3 -mt-12 flex h-16 w-16 items-center justify-center overflow-hidden rounded-full border-4 border-white bg-slate-100 shadow-sm">
            {helper.userRef?.avatar ? <img src={helper.userRef.avatar} alt={helper.userRef?.username || helper.name} className="h-full w-full object-cover" /> : <FaUser className="text-xl text-slate-400" />}
          </div>
          <h1 className="max-w-4xl text-2xl sm:text-3xl lg:text-4xl font-semibold text-slate-900 mb-3 tracking-tight leading-tight">
            Beauty services by {helper.name}
          </h1>
          <p className="mb-4 max-w-3xl text-sm leading-6 text-slate-600">{displayText.split('\n')[0] || `Beauty services in ${helper.address || 'your area'}`}</p>
          <div className="flex flex-wrap items-center gap-2.5 text-sm text-slate-600">
            <div className="inline-flex items-center gap-2 rounded-full bg-amber-50 px-3.5 py-2 text-slate-800">
              <StarIconSolid className="text-amber-400 w-4 h-4" />
              <span className="font-semibold">{ratings?.overall > 0 ? ratings.overall.toFixed(1) : (helper.rating || 'New')}</span>
              <span className="text-slate-500">
                {commentsLoading ? 'Loading reviews' : `${commentCount} ${commentCount === 1 ? 'review' : 'reviews'}`}
              </span>
            </div>
            {helper.isSuperhelper && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-rose-100 bg-rose-50 px-3.5 py-2 text-xs font-semibold text-rose-700">
                <CheckBadgeIcon className="h-4 w-4" /> Superhelper
              </span>
            )}
            {bookingSummary.count > 0 && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-600">
                <PlusCircleIcon className="h-4 w-4 text-indigo-500" /> Booked {bookingSummary.count} {bookingSummary.count === 1 ? 'time' : 'times'}
              </span>
            )}
            {helper.address && (
              <span className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-600">
                <MapPinIcon className="h-4 w-4 shrink-0 text-slate-400" />
                <span className="truncate">{helper.address}</span>
              </span>
            )}
          </div>
        </div>

        {/* Content Grid */}
        <div className="mt-8 max-w-5xl space-y-8">
          <div className="space-y-8">
            {/* Host Info Bar */}
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-6 sm:flex-row sm:items-center sm:justify-between">
              <Link
                to={`/user-profile/${helper.userRef?._id || helper.userRef}`}
                className="flex items-center justify-between gap-4 transition-opacity hover:opacity-80 sm:w-fit"
              >
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">
                    Hosted by {helper.userRef?.username || helper.name}
                  </h2>
                  <p className="text-gray-600 mt-1">View provider profile</p>
                </div>
                <div className="flex h-14 w-14 flex-shrink-0 items-center justify-center overflow-hidden rounded-full border border-slate-200 bg-slate-50 shadow-sm">
                  {helper.userRef?.avatar ? (
                    <img
                      src={helper.userRef.avatar}
                      alt={helper.userRef?.username || helper.name}
                      className="h-full w-full object-cover object-center"
                      onError={(e) => { e.target.src = '/default-avatar.jpg'; }}
                    />
                  ) : (
                    <FaUser className="text-2xl text-gray-400" />
                  )}
                </div>
              </Link>
              <button type="button" onClick={handleInternalMessage} className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-300 px-5 py-3 text-sm font-semibold text-slate-800 transition hover:border-slate-400 hover:bg-slate-50 sm:w-auto"><ChatBubbleLeftRightIcon className="h-4 w-4" />Message</button>
            </div>

            {/* Description */}
            <div className="pb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">About {helper.name}</h2>
              <div className="text-gray-700 leading-relaxed space-y-4">
                {displayText.split('\n').map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>
              {description.length > 300 && (
                <button
                  onClick={toggleDescription}
                  className="mt-6 text-rose-500 font-black uppercase tracking-[0.2em] text-[10px] flex items-center gap-2"
                >
                  {showFullDescription ? 'Show less' : 'Show more'}
                  {showFullDescription ? <ArrowUpIcon className="w-3 h-3" /> : <ArrowDownIcon className="w-3 h-3" />}
                </button>
              )}
            </div>

            {helper.imageUrls?.length > 0 && (
              <section className="border-b border-slate-200 pb-7" aria-labelledby="beauty-portfolio-title">
                <div className="mb-4 flex items-end justify-between gap-4">
                  <div><h2 id="beauty-portfolio-title" className="text-xl font-semibold text-slate-900">My portfolio</h2><p className="mt-1 text-sm text-slate-500">A selection of the beauty professional’s work</p></div>
                  <button type="button" onClick={() => openFullScreenGallery(0)} className="shrink-0 text-sm font-semibold text-slate-700 underline underline-offset-4 hover:text-rose-600">View all {helper.imageUrls.length}</button>
                </div>
                <div className="grid aspect-[1.8/1] grid-cols-[1.25fr_1fr] grid-rows-2 gap-1 overflow-hidden rounded-2xl bg-white sm:aspect-[2.15/1]">
                  {helper.imageUrls.slice(0, 3).map((url, index) => (
                    <button key={`portfolio-${url}-${index}`} type="button" onClick={() => openFullScreenGallery(index)} aria-label={`View portfolio photo ${index + 1}`} className={`group relative overflow-hidden bg-slate-100 focus:outline-none focus-visible:z-10 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-rose-500 ${index === 0 ? 'row-span-2' : ''}`}>
                      <img src={url} alt={`${helper.name} portfolio work ${index + 1}`} className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105" />
                    </button>
                  ))}
                </div>
              </section>
            )}

            {/* Services Offered - FIXED SECTION */}
            {(helper.type === 'domestic' || helper.type === 'maid' || helper.type === 'beauty' || helper.type === 'spa' || helper.type === 'barber' || helper.type === 'barbar' || helper.type === 'chef' || helper.type === 'tattoo' || helper.type === 'tutor' || helper.type === 'photography' || helper.type === 'sneaker' || helper.type === 'washingmat' || helper.type === 'animals') && (
              <div className="pb-6 border-b border-gray-200">
                <h2 className="mb-4 text-xl font-semibold text-slate-900">Choose a service</h2>
                <div className="grid grid-cols-1 gap-3">
                  {serviceOptions.map((service) => {
                    const isSelected = bookingData.selectedServices.includes(service.id);
                    return (
                      <button
                        key={service.id} 
                        type="button"
                        onClick={() => setSelectedModalService(service)}
                        aria-pressed={isSelected}
                        className={`flex w-full items-center justify-between gap-3 rounded-2xl border p-3.5 text-left transition-all ${
                          isSelected 
                            ? 'border-rose-300 bg-rose-50/70 shadow-sm' 
                            : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start gap-3 min-w-0">
                          {service.image ? (
                          <img src={service.image} alt={service.name} className="h-16 w-16 shrink-0 rounded-xl border border-slate-100 bg-white object-cover" />
                          ) : (
                            <div className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-xl transition-colors ${isSelected ? 'text-rose-500' : 'text-slate-400'}`}>
                              {service.icon}
                            </div>
                          )}
                          <div className="min-w-0">
                            {service.type && (
                              <span className={`inline-block mb-1 rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                                isSelected ? 'bg-rose-100 text-rose-700' : 'bg-gray-100 text-gray-500'
                              }`}>
                                {service.type}
                              </span>
                            )}
                            <p className={`text-left font-semibold transition-colors ${isSelected ? 'text-rose-700' : 'text-slate-900'}`}>
                              {service.name}
                            </p>
                            {service.description && (
                              <p className="mt-1 text-xs leading-relaxed text-gray-500 line-clamp-2">
                                {service.description}
                              </p>
                            )}
                          </div>
                        </div>
                        {service.price !== undefined && service.price !== null && (
                          <span className={`shrink-0 text-right font-semibold ${isSelected ? 'text-rose-600' : 'text-slate-900'}`}>
                            {Number(service.price) === 0 ? 'Free' : `R${service.price}`}<span className="block text-[11px] font-normal text-slate-500">per service</span>
                          </span>
                        )}
                        {isSelected && (
                          <div className="ml-2 w-5 h-5 bg-rose-500 rounded-full flex items-center justify-center">
                            <CheckIcon className="text-white w-3 h-3" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <section className="border-b border-slate-200 pb-7" aria-labelledby="beauty-qualifications-title">
              <h2 id="beauty-qualifications-title" className="mb-4 text-xl font-semibold text-slate-900">My qualifications</h2>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-rose-50 text-rose-600"><CheckBadgeIcon className="h-5 w-5" /></span>
                  <div className="space-y-2 whitespace-pre-line text-sm leading-6 text-slate-600">
                    {[helper.experience, helper.education, helper.training, helper.certifications, helper.near].filter(Boolean).slice(0, 6).map((item, index) => <p key={`qualification-${index}`}>{item}</p>)}
                    {!helper.experience && !helper.education && !helper.training && !helper.certifications && !helper.near && <p>Message the professional to ask about their experience and training.</p>}
                  </div>
                </div>
              </div>
            </section>

            {/* Booking entry point */}
            <div className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-slate-50/70 p-5 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800 dark:bg-gray-900/60">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">Ready to book?</h3>
                <p className="mt-1 text-sm text-slate-600 dark:text-gray-400">Choose a service and add your appointment details in the booking form.</p>
              </div>
              <button
                type="button"
                onClick={openBookingFormOverlay}
                className="inline-flex shrink-0 items-center justify-center rounded-xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800 dark:bg-rose-600 dark:hover:bg-rose-500"
              >
                Review &amp; Reserve
              </button>
            </div>

            {/* Reviews Summary - Airbnb Style */}
            <div className="py-6 border-0">
              <div className="flex items-center gap-3 mb-6">
                <StarIconSolid className="text-[#FFB400] w-6 h-6 shrink-0" />
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <span>{ratings && ratings.overall > 0 ? ratings.overall.toFixed(1) : (helper.rating || 'New')}</span>
                  <span className="text-gray-300 dark:text-gray-600" aria-hidden="true">·</span>
                  <span className="text-base sm:text-lg font-semibold text-gray-700 dark:text-gray-300">
                    {commentsLoading ? 'Loading reviews…' : `${commentCount} ${commentCount === 1 ? 'review' : 'reviews'}`}
                  </span>
                </h2>
              </div>

              {commentsLoading ? (
                <p className="mb-6 text-gray-500">Loading customer reviews…</p>
              ) : commentCount > 0 ? (
                <>
                  {/* Airbnb-style Borderless Side-Slide Carousel */}
                  <div className="mb-8 -mx-4 px-4 sm:mx-0 sm:px-0" aria-label="Beauty service rating categories">
                    <Swiper
                      spaceBetween={12}
                      slidesPerView="auto"
                      freeMode={true}
                      modules={[FreeMode]}
                      className="rating-categories-carousel"
                    >
                      {BEAUTY_REVIEW_CATEGORIES.map(({ key, field, label, emoji }) => {
                        const score = Number(ratings?.[key]) || 0;
                        const count = Number(ratingCounts?.[key]) || 0;
                        const displayScore = score > 0 ? score.toFixed(1) : (ratings?.overall > 0 ? ratings.overall.toFixed(1) : '5.0');

                        return (
                          <SwiperSlide key={field} className="!w-[130px] sm:!w-[145px]">
                            <div
                              className="h-full min-h-[96px] flex flex-col justify-between p-3.5 rounded-2xl bg-gray-50/90 dark:bg-gray-800/50 border-0 transition-all hover:bg-gray-100/90 dark:hover:bg-gray-800/80 cursor-grab active:cursor-grabbing"
                            >
                              <div className="flex items-center justify-between gap-1 mb-2">
                                <span className="text-2xl select-none" aria-hidden="true">{emoji}</span>
                                <span className="text-base font-bold text-gray-900 dark:text-white">
                                  {displayScore}
                                </span>
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 truncate">
                                  {label}
                                </p>
                                <p className="mt-0.5 text-[10px] text-gray-400 dark:text-gray-500 truncate">
                                  {count > 0 ? `${count} ${count === 1 ? 'rating' : 'ratings'}` : 'Top rated'}
                                </p>
                              </div>
                            </div>
                          </SwiperSlide>
                        );
                      })}
                    </Swiper>
                  </div>

                  {/* Top Comments Swiper */}
                  {topComments.length > 0 && (
                    <div className="mb-8">
                      <Swiper
                        spaceBetween={16}
                        slidesPerView={1.1}
                        breakpoints={{ 
                          640: { slidesPerView: 2.1 },
                          1024: { slidesPerView: 3.2 }
                        }}
                        freeMode={true}
                        modules={[FreeMode]}
                        className="-mx-4 px-4 sm:mx-0 sm:px-0"
                      >
                        {topComments.map(comment => {
                          const reviewScores = BEAUTY_REVIEW_CATEGORIES.map(({ field }) => Number(comment[field])).filter((score) => score >= 1 && score <= 5);
                          const rating = reviewScores.length ? reviewScores.reduce((sum, score) => sum + score, 0) / reviewScores.length : 5;
                          
                          return (
                          <SwiperSlide key={comment._id} className="h-auto">
                            <div className="h-full bg-gray-50/70 dark:bg-gray-800/50 rounded-2xl p-5 border-0 flex flex-col justify-between relative overflow-hidden transition-all hover:bg-gray-100/70 dark:hover:bg-gray-800/70">
                              <div className="relative z-10">
                                <div className="flex items-center justify-between mb-4">
                                  <div className="flex items-center gap-3">
                                    <img 
                                      src={comment.userAvatar || '/default-avatar.jpg'} 
                                      alt={comment.userName}
                                      className="w-12 h-12 rounded-full object-cover shadow-sm"
                                      onError={(e) => { e.target.src = '/default-avatar.jpg'; }}
                                    />
                                    <div>
                                      <h4 className="font-semibold text-[#222222] dark:text-white leading-tight">{comment.userName}</h4>
                                      <p className="text-sm text-[#717171] dark:text-white mt-0.5">{getRelativeTime(comment.createdAt)}</p>
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-center gap-4 mb-4">
                                  <div className="flex items-center">
                                    {[...Array(5)].map((_, i) => (
                                      <FaStar 
                                        key={i} 
                                        className={`text-[12px] mr-1 ${i < Math.round(rating) ? 'text-[#FFB400]' : 'text-gray-200'}`} 
                                      />
                                    ))}
                                  </div>
                                  {comment.likes?.length > 0 && (
                                    <div className="flex items-center gap-1 text-xs text-rose-500 font-medium">
                                      <FaHeart />
                                      {comment.likes.length}
                                    </div>
                                  )}
                                </div>
                                <p className="text-gray-700 line-clamp-4 leading-relaxed whitespace-pre-line">
                                  {comment.content}
                                </p>
                              </div>
                            </div>
                          </SwiperSlide>
                        )})}
                      </Swiper>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-gray-600 mb-6">No reviews yet. Be the first to leave a review!</p>
              )}
              {commentCount >= 10 && <button type="button" onClick={() => setShowCommentsPanel(true)} className="mt-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-700">View all {commentCount} reviews</button>}

            </div>

            {/* Location */}
            <div className="py-6 border-t border-gray-200">
              <h2 className="text-lg lg:text-xl font-semibold text-gray-900 mb-4">Where you'll be</h2>
              <p className="text-gray-700 mb-4 text-sm lg:text-base">{helper.address}</p>
              <div className="relative h-[300px] w-full overflow-hidden rounded-2xl border border-slate-200 bg-slate-100">
                <GoogleMapComponent
                  address={helper.address || 'Johannesburg, South Africa'}
                  title={`${helper.name}'s Location`}
                />
              </div>
            </div>

          </div>

        </div>

        {/* Recent Bookers Section */}
        <BookingHistory bookingSummary={bookingSummary} providerName={helper?.name} providerType={helper?.type || 'beauty'} providerImage={helper?.imageUrls?.[0]} providerId={helper?._id} />

      </ListingDetailShell>

      {showCommentsPanel && <CommentsSidePanelHelper helperId={helper?._id} helperType={helper?.type || 'beauty'} onClose={() => setShowCommentsPanel(false)} totalComments={commentCount} />}

      {/* Full Screen Gallery Overlay */}
      {showFullScreenGallery && helper.imageUrls && helper.imageUrls.length > 0 && (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <div className="flex items-center justify-between p-4 text-white">
            <button
              onClick={closeFullScreenGallery}
              className="p-2.5 bg-white/10 hover:bg-white/20 rounded-full transition-all text-white backdrop-blur-md"
            >
              <XMarkIcon className="w-6 h-6" />
            </button>
            <span className="font-medium">
              {currentGalleryIndex + 1} / {helper.imageUrls.length}
            </span>
            <div className="w-10" /> {/* Spacer for centering */}
          </div>

          <div className="flex-1 flex items-center justify-center p-4 relative">
            <button
              onClick={prevImage}
              className="absolute left-4 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
            >
              <ChevronLeftIcon className="w-6 h-6" />
            </button>

            <img
              src={helper.imageUrls[currentGalleryIndex]}
              alt={`Gallery ${currentGalleryIndex + 1}`}
              className="max-h-full max-w-full object-contain rounded-lg"
            />

            <button
              onClick={nextImage}
              className="absolute right-4 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
            >
              <ChevronRightIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}

            {/* Helper Booking Sheet Popout */}
      <HelperBookingSheet
        isOpen={showBookingFormOverlay}
        onClose={closeBookingFormOverlay}
        helper={helper}
        bookingData={bookingData}
        handleBookingChange={handleBookingChange}
        setBookingData={setBookingData}
        serviceOptions={serviceOptions}
        handleServiceSelection={handleServiceSelection}
        totalPrice={totalPrice}
        handleBookingSubmit={handleBookingSubmit}
        handleEscrowCheckout={handleEscrowCheckout}
        isUploading={isUploading}
        isTimeSlotBooked={isTimeSlotBooked}
        isDateFullyBooked={isDateFullyBooked}
      />

{/* Mobile Bottom Bar - 100% Width & Flush to Bottom */}
      <div className="mobile-booking-bar safe-area-bottom fixed bottom-0 left-0 right-0 z-[1100] border-t border-slate-200 bg-white/95 p-3 shadow-[0_-8px_24px_rgba(15,23,42,0.08)] backdrop-blur-md dark:border-gray-800 dark:bg-gray-900/95 lg:hidden">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-2 sm:px-4">
          <div className="min-w-0">
            <div className="text-xs font-medium text-slate-500">Estimated total</div>
            <div className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">R{totalPrice}</div>
          </div>
          <button
            type="button"
            onClick={() => setShowBookingFormOverlay(true)}
            className="rounded-xl bg-slate-950 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-white shadow-sm transition hover:bg-slate-800 active:scale-[0.98] dark:bg-rose-600 dark:hover:bg-rose-500"
          >
            Review &amp; Reserve
          </button>
        </div>
      </div>

    </div>
  );
}
